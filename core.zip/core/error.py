# Python stuff
from enum   import Enum, auto
from typing import Optional

class ErrorKind(Enum):
    FILE     = auto()    # File could not be processed at all
    INTERNAL = auto()    # File processed with error

class ErrorContext:
    __slots__ = (
        "kind",
        "message",
        "file",
        "stage",
    )

    def __init__(
        self,
        *,
        kind: ErrorKind,
        message: str,
        file: Optional[str] = None,
        stage: Optional[str] = None,
    ) -> None:
        self.kind: ErrorKind      = kind
        self.message: str         = message
        self.file: Optional[str]  = file
        self.stage: Optional[str] = stage
