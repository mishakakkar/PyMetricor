# My stuff
from core.interface                import BasePipelineStage, BaseVisitor
from core.context                  import FileContext, ErrorContext, ErrorKind
from core.visitors.readability     import NestingVisitor, StyleVisitor, IdentifierLengthVisitor, DocstringVisitor, \
                                          ConsistencyVisitor, CognitiveComplexityVisitor, IdentifierQualityVisitor
from core.visitors.efficiency      import ComplexityVisitor, RedundantCodeVisitor, DeadCodeVisitor
from core.visitors.maintainability import ParameterBloat, MethodReceiverNamingConsistency, \
                                            FunctionLength, InheritanceDepth, ExceptionHygiene, ClassComplexity, ModuleCoupling
from core.visitors.security        import SecurityRiskVisitor

# Python stuff
from astroid                       import nodes, parse # type: ignore
from typing                        import List, Set, Tuple, Type, override

class S1ASTScan(BasePipelineStage):
    '''
    Unified AST Analysis Stage.
    Parses the code once and dispatches nodes to registered visitors.
    '''

    __slots__ = ("_visitors", "_block_nodes")

    def __init__(self) -> None:
        super().__init__()

        # vvv Configuration vvv
        self._block_nodes: Set[Type[nodes.NodeNG]] = {
            nodes.If, nodes.For, nodes.While, nodes.Try, nodes.With,
            nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.ClassDef,
            nodes.Match, nodes.MatchCase,
        }

        # vvv Register Visitors vvv
        self._visitors: List[BaseVisitor] = [
            # Readability
            NestingVisitor(),
            StyleVisitor(),
            IdentifierLengthVisitor(),
            DocstringVisitor(),
            ConsistencyVisitor(),
            CognitiveComplexityVisitor(),
            IdentifierQualityVisitor(),

            # Efficiency
            ComplexityVisitor(),
            RedundantCodeVisitor(),
            DeadCodeVisitor(),

            # Security
            SecurityRiskVisitor(),

            # Maintainability
            ParameterBloat(),
            MethodReceiverNamingConsistency(),
            FunctionLength(),
            InheritanceDepth(),
            ExceptionHygiene(),
            ClassComplexity(),
            ModuleCoupling(),
        ]

    # vvv Main Function vvv
    @override
    def Run(self, ctx: FileContext) -> bool:
        if not ctx.file_data:
            return False

        try:
            root_node: nodes.Module = parse(ctx.file_data)
        except Exception as e:
            ctx.AddError(ErrorContext(
                kind    = ErrorKind.FILE,
                message = f"AST Parse failed: {str(e).replace('\n', ' ')}",
                file    = ctx.file_path,
                stage   = "ASTAnalysisStage"
            ))
            return False

        # Counter for total AST nodes
        total_nodes = 0

        # Stack Item: (Node, Depth, IsExit)
        # IsExit = False -> Visit, IsExit = True -> Leave
        stack: List[Tuple[nodes.NodeNG, int, bool]] = [(root_node, 0, False)]

        while stack:
            current_node, current_depth, is_exit = stack.pop()

            # Increment counter for every node popped
            total_nodes += 1

            # vvv LEAVE (Post-Order) vvv
            if is_exit:
                for visitor in self._visitors:
                    visitor.Leave(current_node, current_depth)
                continue

            # vvv VISIT (Pre-Order) vvv
            for visitor in self._visitors:
                visitor.Visit(current_node, current_depth)

            # Re push current node with is_exit = True so we hit it again- 
            # -after processing all its children
            stack.append((current_node, current_depth, True))

            # Add children to stack
            children: List[nodes.NodeNG] = list(current_node.get_children())
            if children:
                for child in reversed(children):
                    is_elif: bool = (
                        isinstance(child, nodes.If)
                        and isinstance(current_node, nodes.If)
                        and child in current_node.orelse
                    )
                    increment: int = 1 if (type(child) in self._block_nodes and not is_elif) else 0
                    stack.append((child, current_depth + increment, False))

        # Finalize metrics
        for visitor in self._visitors:
            visitor.Finalize(ctx)

        # Set the final file mass metric
        ctx.SetASTNodeCount(total_nodes)

        return True