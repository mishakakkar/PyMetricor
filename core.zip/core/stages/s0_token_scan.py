# My stuff
from core.interface import BasePipelineStage
from core.context   import FileContext, SignalContext, MetricExplanation, OffenderContext
from core.error     import ErrorContext, ErrorKind
from core.enums     import ReadabilityMetric
from utils.math     import ShannonEntropyFromCounts
from config         import Config, ConfigNamespace

# Python stuff
from io             import StringIO
from collections    import Counter
from typing         import List, Set, Tuple, override
from math           import exp, tanh
import tokenize
import statistics

class S0TokenScan(BasePipelineStage):
    '''
    Stage 0 - Pure lexical analysis.

    Metrics Handled:
    - LINE_LENGTH_DISTRIBUTION
        - Average excess per line (Mean Squared Error)
        - Penalizes 'extreme' outliers (e.g: 140 chars) significantly more than minor overflows
    - INDENTATION_STABILITY
        - Number of indentation levels used
        - Mixed indentation detection (tabs vs spaces)
        - Inconsistent indent width (e.g. 2 vs 4 spaces)
    - COMMENT_DOC_DENSITY
        - Documentation ratio = (hash comment lines + docstring lines) / non-blank lines
        - Relative Squared Error below the ideal ratio, only for files longer than min_function_size
        - Hash comments above ideal + tolerance are penalised as 'comment noise'; docstrings never are
    - BLANK_LINE_RHYTHM
        - Quadratic penalty for excessive vertical gaps (e.g: > 2 blank lines)
        - Adaptive mode detection
        - Variance penalty for inconsistent rhythm (noise around the mode)
    - LINE_DENSITY
        - Mean excess of tokens per line over 'max_tokens_per_line' (string literals and layout tokens excluded)
        - Dense lines were the strongest readability predictor in Buse & Weimer (2010)
    - FORMATTING_CONSISTENCY
        - Within-file mix of spaced and unspaced binary operators, share of commas without a following
          space, and mix of single and double quotes
    '''

    __slots__ = (
        "_preferred_line_length",
        "_ideal_comment_ratio",
        "_ignore_token_types",
        "_max_blank_lines",

        "_k_line_length",
        "_k_indent_stability",
        "_k_blank_rhythm",
    )

    def __init__(self) -> None:
        super().__init__()

        # Global config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Thresholds vvv
        self._preferred_line_length: int     = self._readability_tuning.thresholds.preferred_line_length
        self._ideal_comment_ratio: float     = self._readability_tuning.thresholds.ideal_comment_ratio
        self._comment_ratio_tolerance: float = self._readability_tuning.thresholds.comment_ratio_tolerance
        self._max_blank_lines: int           = self._readability_tuning.thresholds.max_blank_lines
        self._blank_lines_tolerance: int     = self._readability_tuning.thresholds.blank_lines_tolerance
        self._min_function_size: int         = self._readability_tuning.thresholds.min_function_size

        # vvv Sensitivity Coefficients (Higher the harsher) vvv
        self._k_line_length: float      = self._readability_tuning.sensitivity.line_length
        self._k_indent_stability: float = self._readability_tuning.sensitivity.indent_stability
        self._k_comment_density: float  = self._readability_tuning.sensitivity.comment_density
        self._k_blank_rhythm: float     = self._readability_tuning.sensitivity.blank_rhythm
        self._k_line_density: float     = self._readability_tuning.sensitivity.line_density
        self._k_formatting: float       = self._readability_tuning.sensitivity.formatting_consistency
        self._max_tokens_per_line: int  = self._readability_tuning.thresholds.max_tokens_per_line

        # vvv Internals vvv
        self._ignore_token_types: Set[int] = {
            tokenize.ENCODING,
            tokenize.ENDMARKER,
            tokenize.NL,
        }
        # Tokens that do not add to how much a reader must take in on one line
        self._layout_token_types: Set[int] = {
            tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NL, tokenize.NEWLINE,
            tokenize.INDENT, tokenize.DEDENT, tokenize.COMMENT, tokenize.STRING,
        }
        self._spaced_operators: Set[str] = {
            "=", "+", "-", "*", "/", "//", "%", "==", "!=", "<", ">", "<=", ">=", "+=", "-=", "*=",
        }

    # vvv Internal Functions vvv
    def _ScanLines(self, source: str) -> Tuple[
        int, int, int, int,
        List[Tuple[int, int]],   # (length, line_no)
        List[Tuple[int, int]],   # (gap_size, start_line_no)
        Counter[str],
        List[int],
        List[Tuple[int, int]],   # (delta, line_no) for indent violations
    ]:
        '''First pass: Raw line processing. Basic metrics extracted.'''
        loc: int           = 0
        blank_lines: int   = 0
        hash_comments: int = 0
        doc_lines: int     = 0  # lines of triple-quoted strings (docstrings), counted as documentation

        line_lengths:    List[Tuple[int, int]] = []  # (length, line_no)
        blank_runs:      List[Tuple[int, int]] = []  # (gap_size, start_line_no)
        cur_blank_run:   int                   = 0
        blank_run_start: int                   = 0

        prev_indent: int                  = 0
        indent_char_counter: Counter[str] = Counter()
        indent_delta_list:   List[int]    = []
        indent_violations:   List[Tuple[int, int]] = []  # (delta, line_no)

        in_docstring: bool = False
        doc_delimiter: str = ""

        for line in source.splitlines():
            loc += 1

            raw: str = line.rstrip("\n")
            s: str   = raw.strip()

            # Blank line detection
            if not s:
                blank_lines += 1
                if cur_blank_run == 0:
                    blank_run_start = loc
                cur_blank_run += 1
                continue

            # End of a blank run
            if cur_blank_run:
                blank_runs.append((cur_blank_run, blank_run_start))
                cur_blank_run = 0

            # Hash comment detection
            if s.startswith("#"):
                hash_comments += 1
                continue

            # Docstring state check
            inside_docstring_body: bool = in_docstring
            if in_docstring or '"""' in s or "'''" in s:
                doc_lines += 1
            for delim in ["'''", '"""']:
                if delim in s:
                    # Closing existing docstring
                    if in_docstring and doc_delimiter == delim:
                        if s.count(delim) % 2 != 0:
                            in_docstring  = False
                            doc_delimiter = ""
                    # Opening new docstring
                    elif not in_docstring:
                        if s.count(delim) % 2 != 0:
                            in_docstring          = True
                            doc_delimiter         = delim
                            inside_docstring_body = False

            # Physical line length
            raw_line_length: int = len(raw)
            line_lengths.append((raw_line_length, loc))

            # Indentation Analysis (Skipped if inside docstring body)
            if not inside_docstring_body:
                # 'indent' is the physical width (len of leading whitespace)
                indent: int = raw_line_length - len(s)

                if indent:
                    indent_char_counter.update(raw[:indent])

                # Delta tracking for consistency
                if indent != prev_indent:
                    delta: int = indent - prev_indent
                    indent_delta_list.append(delta)
                    indent_violations.append((delta, loc))
                    prev_indent = indent

        # Capture trailing blank run
        if cur_blank_run:
            blank_runs.append((cur_blank_run, blank_run_start))

        return (
            loc,
            blank_lines,
            hash_comments,
            doc_lines,
            line_lengths,
            blank_runs,
            indent_char_counter,
            indent_delta_list,
            indent_violations,
        )

    def _CalculateIndentConsistency(self, deltas: List[int]) -> float:
        '''
        Calculates indentation consistency score and detects the base step.
        Returns penalty [0.0 - 1.0]
        '''
        valid_moves: List[int] = [c for c in deltas if c != 0]

        # Default assumption if no valid moves exists
        if not valid_moves:
            return 0.0

        increments: List[int] = [c for c in valid_moves if c > 0]
        step: float = 0

        # Use 'Median' of increments / decrements to ignore outliers like +16 jumps
        if increments:
            step = max(1.0, round(statistics.median(increments)))
        else:
            step = max(1.0, round(statistics.median(abs(c) for c in valid_moves)))

        squared_errors: List[float] = []

        for vm in valid_moves:
            # Increment: Must match step exactly
            if vm > 0:
                error: float = abs(vm - step) / step
                squared_errors.append(error * error)

            # Decrement: Must be divisible by step
            else:
                abs_vm: int         = abs(vm)
                remainder: float    = abs_vm % step
                dist_to_sync: float = min(remainder, step - remainder)

                error = dist_to_sync / step
                squared_errors.append(error * error)

        if not squared_errors:
            return 0.0

        # Mean Squared Error
        mse: float = sum(squared_errors) / len(squared_errors)
        
        # Tanh with 2.0 multiplier:
        #   Small errors (mse < 0.1) -> Score < 0.2
        #   Large errors (mse > 1.0) -> Score > 0.96
        score: float = tanh(mse * 2.0)
        return round(score, 3)

    # vvv Main Function vvv
    @override
    def Run(self, ctx: FileContext) -> bool:
        source: str = ctx.file_data  # type: ignore

        # vvv Line Scans vvv
        (
            loc,
            blank_lines,
            hash_comments,
            doc_lines,
            line_lengths,
            blank_runs,
            indent_char_counter,
            indent_delta_list,
            indent_violations,
        ) = self._ScanLines(source)

        # vvv Token Scans vvv
        token_count: int = 0
        tokens: List[tokenize.TokenInfo] = []
        stream: StringIO = StringIO(source)
        try:
            for t in tokenize.generate_tokens(stream.readline):
                tokens.append(t)
                if t.type in self._ignore_token_types:
                    continue
                token_count += 1

        # SyntaxError covers IndentationError/TabError, which Python 3.12+ tokenize raises
        # directly; without this a single malformed file aborted the whole run
        except (tokenize.TokenError, SyntaxError) as e:
            ctx.AddError(ErrorContext(
                kind    = ErrorKind.FILE,
                message = f"{str(e)}",
                file    = ctx.file_path,
                stage   = "S0TokenScan"
            ))
            return False

        ctx.SetLOC(loc)
        ctx.SetTokenCount(token_count)

        # vvv Readability Metrics vvv
        #   LINE_LENGTH_DISTRIBUTION
        lld_penalty: float = 0.0
        if line_lengths:
            squared_excess = [max(0, l - self._preferred_line_length) ** 2 for l, _ in line_lengths]
            mse: float = sum(squared_excess) / len(line_lengths)
            lld_penalty = mse * self._k_line_length

        ctx.AddReadabilitySignal(
            ReadabilityMetric.LINE_LENGTH_DISTRIBUTION,
            SignalContext(max(0.0, 100.0 * exp(-lld_penalty)), 1.0)
        )

        if lld_penalty > 0.0:
            # Top 3 longest lines over limit
            over_limit: List[Tuple[int, int]] = [
                (l, n) for l, n in line_lengths if l > self._preferred_line_length
            ]
            worst_lines: List[Tuple[int, int]] = sorted(over_limit, key=lambda x: -x[0])[:3]

            if worst_lines:
                ctx.SetMetricExplanation("LINE_LENGTH_DISTRIBUTION", MetricExplanation(
                    summary   = (
                        f"{len(over_limit)} line(s) exceed the {self._preferred_line_length}-char limit. "
                        f"Longest is {worst_lines[0][0]} chars."
                    ),
                    offenders = [
                        OffenderContext(
                            filepath = ctx.file_path,
                            line     = line_no,
                            detail   = f"{length} chars",
                            severity = "high" if length > self._preferred_line_length * 1.5 else "medium",
                        )
                        for length, line_no in worst_lines
                    ],
                    fix = f"Keep lines under {self._preferred_line_length} characters."
                            " Break long expressions across multiple lines.",
                ))

        # INDENTATION_STABILITY
        is_score: float = 0.0
        if indent_char_counter:
            char_entropy: float = ShannonEntropyFromCounts(indent_char_counter)
            step_penalty: float = self._CalculateIndentConsistency(indent_delta_list)
            is_score            = (char_entropy + step_penalty) * self._k_indent_stability

        ctx.AddReadabilitySignal(
            ReadabilityMetric.INDENTATION_STABILITY,
            SignalContext(max(0.0, 100.0 * exp(-is_score)), 1.0)
        )

        if is_score > 0.0:
            has_tabs:   bool = "\t" in indent_char_counter
            has_spaces: bool = " "  in indent_char_counter
            mixed: bool      = has_tabs and has_spaces

            # Top 3 largest unexpected indent jumps
            worst_deltas: List[Tuple[int, int]] = sorted(
                indent_violations, key=lambda x: abs(x[0]), reverse=True
            )[:3]

            summary: str = (
                "Mixed tabs and spaces detected." if mixed
                else f"Inconsistent indentation width across {len(indent_violations)} transition(s)."
            )

            ctx.SetMetricExplanation("INDENTATION_STABILITY", MetricExplanation(
                summary   = summary,
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line_no,
                        detail   = f"delta {delta:+d}",
                        severity = "high" if mixed else "medium",
                    )
                    for delta, line_no in worst_deltas
                ],
                fix = "Use a consistent indent width (4 spaces recommended). Never mix tabs and spaces.",
            ))

        # COMMENT_DENSITY (documentation ratio)
        # Docstrings count as documentation, so well-documented code is not punished for them.
        # Too little documentation is only penalised once a file is longer than 'min_function_size'
        # non-blank lines (a short snippet needs none); too much is judged on hash comments alone,
        # since a long docstring is not comment noise.
        hcd_penalty: float   = 0.0
        total_non_blank: int = loc - blank_lines
        actual_ratio: float  = 0.0
        too_few: bool        = False
        if total_non_blank > 0:
            actual_ratio      = (hash_comments + doc_lines) / total_non_blank
            hash_ratio: float = hash_comments / total_non_blank

            if actual_ratio < self._ideal_comment_ratio and total_non_blank > self._min_function_size:
                too_few                = True
                relative_miss: float   = (self._ideal_comment_ratio - actual_ratio) / self._ideal_comment_ratio
                hcd_penalty            = (relative_miss ** 2) * self._k_comment_density
            else:
                excess: float = hash_ratio - (self._ideal_comment_ratio + self._comment_ratio_tolerance)
                if excess > 0:
                    hcd_penalty = ((excess / self._ideal_comment_ratio) ** 2) * self._k_comment_density

        ctx.AddReadabilitySignal(
            ReadabilityMetric.COMMENT_DENSITY,
            SignalContext(max(0.0, 100.0 * exp(-hcd_penalty)), 1.0)
        )

        if hcd_penalty > 0.0:
            ideal_pct:  int = round(self._ideal_comment_ratio * 100)
            actual_pct: int = round(actual_ratio * 100)

            ctx.SetMetricExplanation("COMMENT_DENSITY", MetricExplanation(
                summary   = (
                    f"Comment ratio is {actual_pct}%, target is ~{ideal_pct}%. "
                    f"{'Too few comments.' if too_few else 'Excessive comment noise.'}"
                ),
                offenders = [],  # No line-level offenders, this is a file-level ratio
                fix = (
                    "Add docstrings to public functions and inline comments for non-obvious logic."
                    if too_few else
                    "Reduce redundant or noisy comments. Prefer self-documenting code."
                ),
            ))

        # BLANK_LINE_RHYTHM
        blr_score: float = 100.0 if loc > self._blank_lines_tolerance else 0.0
        if blank_runs:
            excess_penalty: float = 0.0
            sane_gaps: List[int]  = []

            for gap, _ in blank_runs:
                if gap > self._max_blank_lines:
                    excess_gap: int = gap - self._max_blank_lines
                    excess_penalty += (excess_gap ** 2)
                    sane_gaps.append(self._max_blank_lines)
                else:
                    sane_gaps.append(gap)

            counts        = Counter(sane_gaps)
            modes         = [m[0] for m in counts.most_common(2)]
            noise_penalty: float = 0.0

            if modes:
                for gap in sane_gaps:
                    dist           = min(abs(gap - m) for m in modes)
                    noise_penalty += (dist ** 2)

            avg_excess: float = excess_penalty / len(blank_runs)
            avg_noise: float  = noise_penalty  / len(blank_runs)
            blr_score         = (avg_excess + avg_noise) * self._k_blank_rhythm

        ctx.AddReadabilitySignal(
            ReadabilityMetric.BLANK_LINE_RHYTHM,
            SignalContext(max(0.0, 100.0 * exp(-blr_score)), 1.0)
        )

        if blank_runs and blr_score > 0.0:
            over_limit_runs: List[Tuple[int, int]] = [
                (gap, start) for gap, start in blank_runs if gap > self._max_blank_lines
            ]
            worst_gaps: List[Tuple[int, int]] = sorted(over_limit_runs, key=lambda x: -x[0])[:3]

            if worst_gaps:
                ctx.SetMetricExplanation("BLANK_LINE_RHYTHM", MetricExplanation(
                    summary   = (
                        f"{len(over_limit_runs)} gap(s) exceed the {self._max_blank_lines}-line max. "
                        f"Largest gap is {worst_gaps[0][0]} blank lines."
                    ),
                    offenders = [
                        OffenderContext(
                            filepath = ctx.file_path,
                            line     = start_line,
                            detail   = f"{gap} blank lines",
                            severity = "medium",
                        )
                        for gap, start_line in worst_gaps
                    ],
                    fix = f"Keep vertical gaps to {self._max_blank_lines} blank lines maximum.",
                ))

        # LINE_DENSITY
        self._ScoreLineDensity(ctx, tokens)

        # FORMATTING_CONSISTENCY
        self._ScoreFormattingConsistency(ctx, tokens)

        return True

    def _ScoreLineDensity(self, ctx: FileContext, tokens: List[tokenize.TokenInfo]) -> None:
        per_line: Counter[int] = Counter(
            t.start[0] for t in tokens if t.type not in self._layout_token_types
        )
        excess: List[Tuple[int, int]] = [
            (n - self._max_tokens_per_line, line) for line, n in per_line.items() if n > self._max_tokens_per_line
        ]
        mean_excess: float = sum(e for e, _ in excess) / len(per_line) if per_line else 0.0
        penalty: float     = mean_excess * self._k_line_density

        ctx.AddReadabilitySignal(
            ReadabilityMetric.LINE_DENSITY,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if excess:
            worst: List[Tuple[int, int]] = sorted(excess, key=lambda x: -x[0])[:3]
            ctx.SetMetricExplanation("LINE_DENSITY", MetricExplanation(
                summary   = (
                    f"{len(excess)} line(s) hold more than {self._max_tokens_per_line} tokens. "
                    f"The densest has {worst[0][0] + self._max_tokens_per_line}."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{e + self._max_tokens_per_line} tokens",
                        severity = "high" if e > self._max_tokens_per_line else "medium",
                    )
                    for e, line in worst
                ],
                fix = "Split dense lines: name intermediate results and put one step per line.",
            ))

    def _ScoreFormattingConsistency(self, ctx: FileContext, tokens: List[tokenize.TokenInfo]) -> None:
        # Binary operators written with spaces on both sides vs with none
        spaced: int = 0
        tight: int  = 0
        for a, b, c in zip(tokens, tokens[1:], tokens[2:]):
            if b.type != tokenize.OP or b.string not in self._spaced_operators:
                continue
            if a.type in (tokenize.NAME, tokenize.NUMBER) or a.string in (")", "]"):
                gaps: Tuple[bool, bool] = (a.end == b.start, b.end == c.start)
                if gaps == (False, False):
                    spaced += 1
                elif gaps == (True, True):
                    tight += 1
        operator_mix: float = min(spaced, tight) / (spaced + tight) if spaced + tight else 0.0

        # Commas followed directly by the next item
        commas: List[bool] = [
            a.end == b.start
            for a, b in zip(tokens, tokens[1:])
            if a.string == "," and b.type not in (tokenize.NL, tokenize.NEWLINE) and b.string not in (")", "]", "}")
        ]
        comma_tight: float = sum(commas) / len(commas) if commas else 0.0

        # Single vs double quotes (docstrings excluded)
        quotes: Counter[str] = Counter(
            "double" if t.string.lstrip("rbfuRBFU").startswith('"') else "single"
            for t in tokens
            if t.type == tokenize.STRING and not t.string.startswith(('"""', "'''"))
        )
        quote_mix: float = 1.0 - max(quotes.values()) / sum(quotes.values()) if quotes else 0.0

        penalty: float = (operator_mix + comma_tight + quote_mix) * self._k_formatting
        ctx.AddReadabilitySignal(
            ReadabilityMetric.FORMATTING_CONSISTENCY,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if penalty > 0.0:
            parts: List[str] = []
            if operator_mix:
                parts.append(f"{min(spaced, tight)} of {spaced + tight} operators break the file's spacing habit")
            if comma_tight:
                parts.append(f"{sum(commas)} of {len(commas)} commas have no following space")
            if quote_mix:
                parts.append(f"quotes mixed ({quotes['single']} single, {quotes['double']} double)")
            ctx.SetMetricExplanation("FORMATTING_CONSISTENCY", MetricExplanation(
                summary   = "; ".join(parts) + ".",
                offenders = [],  # File-wide ratios
                fix       = "Pick one spacing and quote style for the file; a formatter such as Black does this.",
            ))