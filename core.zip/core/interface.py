# My stuff
from .context import FileContext

# Python stuff
from astroid  import nodes # type: ignore
from abc      import ABC, abstractmethod

class BasePipelineStage(ABC):
    @abstractmethod
    def Run(self, ctx: FileContext) -> bool:
        '''
        Process the file. Return `False` to abort this file.

        Args:
            `ctx` (FileContext): The project context to process.
        '''
        raise NotImplementedError

class BaseVisitor(ABC):
    '''
    Abstract Base Class for all AST Visitors.
    
    Implementations of this class are responsible for analyzing specific 
    aspects of the code (Readability, Efficiency, etc.) during the 
    single-pass AST traversal.
    '''

    @abstractmethod
    def Visit(self, node: nodes.NodeNG, depth: int) -> None:
        '''
        Called for every node during the AST traversal.

        Args:
            `node`: The current AST node being visited.
            `depth`: The current nesting depth of the node (0 for module level).
        '''
        pass

    @abstractmethod
    def Leave(self, node: nodes.NodeNG, depth: int) -> None:
        '''
        Called after all children of the node have been visited.
        
        Args:
            `node`: The AST node being left.
            `depth`: The current nesting depth of the node.
        '''
        pass

    @abstractmethod
    def Finalize(self, ctx: FileContext) -> None:
        '''
        Called after the AST traversal is complete.
        
        This method should aggregate the data collected during visitation,
        compute the final metric score, and register the SignalContext 
        into the FileContext.

        Args:
            `ctx`: The file context object where signals and errors are stored.
        '''
        pass