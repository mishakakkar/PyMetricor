'''
Walks an astroid Module node, propagates abstract values through the program,
detects capability invocations, and collects CapabilityRecords.

Because the SecurityRiskVisitor already parses files via astroid, this
interpreter works directly on astroid nodes — no double-parsing.

Recursive string analysis is applied when exec/eval/compile receive a string
literal argument. The string is re-parsed with astroid.builder.parse() and
run as a full sub-analysis. This catches:

    exec("a = input(); exec(a)")     →  critical, not just low
    exec("os.system(input())")       →  spawn + external origin

Design:
  Single forward pass per function scope.
  Control-flow join at if/try branches (join = set union per lattice).
  Loops: iterate the body (without recording) until the entry state stops
  changing, then one recording pass. Terminates because transfer functions
  are monotone over a finite lattice; MAX_LOOP_ITERS is a safety bound.
  Import aliases (import x as y, from m import f) are resolved before schema lookup.
  String recursion bounded by string_analyzer.MAX_DEPTH (default 5).
  Calls to functions defined in the project are followed through memoised
  function summaries (summaries.py); other calls use the schema.
  Field-sensitive: an assignment to an attribute of a variable (self.cmd = x,
  obj.path = p, self.repo.url = u) is tracked on that variable's value, and
  carried into and out of method summaries (the object a constructor builds,
  the receiver after a setter).
'''

# My stuff
from .loader          import SchemaBundle
from .state           import (AbstractValue, CapabilityRecord, Environment, make_constant, make_external, make_unknown,
                             MAX_FIELD_DEPTH)
from .summaries       import Summary, SummaryEngine
from .transfer        import (TransferExpr, TransferCallExpr, ApplyRefinement, ApplyValidator, ExtractCallName, IsSafeCall,
                             LookupCall, MatchingValidator, ResolveCallName, TryConcatStrings, COMPAREOP_TO_SCHEMA)
from .string_analyzer import AnalyzeStringLiteral, StringAnalysisResult

# Python stuff
from astroid import nodes  # type: ignore
from dataclasses import replace
from typing  import Callable, Dict, List, Optional, Tuple
import fnmatch

# vvv Constants vvv
MAX_LOOP_ITERS: int = 10

# A check that a value does not contain one of these (`";" not in cmd`, `if ".." in p: raise`)
# is a blacklist validation of that value
METACHARACTERS: str = ";|&$`'\"\\/<>(){}*?!\n"

# Capabilities whose arguments are another language (SQL, URLs, templates)
NON_PYTHON_SINKS: frozenset = frozenset({"EXECUTE_QUERY", "SEND_REQUEST", "RENDER_TEMPLATE"})

# vvv Main Stuff vvv
class Interpreter:
    '''
    Abstract interpreter over astroid nodes.
    Call Analyze(module) to get all CapabilityRecords.
    Returned list includes synthetic records from recursive string analysis.
    '''

    __slots__ = ("_schema", "_capabilities", "_string_analyses", "_recording", "_engine", "_returns", "_exit_env")

    def __init__(self, schema: SchemaBundle, engine: Optional[SummaryEngine] = None) -> None:
        self._schema:          SchemaBundle                         = schema
        self._capabilities:    List[CapabilityRecord]               = []
        self._string_analyses: List[Optional[StringAnalysisResult]] = []
        self._recording:       bool                                 = True
        # Shared across the files of a project run so summaries are computed once
        self._engine:          SummaryEngine                        = engine or SummaryEngine(schema)
        # Values returned by the function being summarised (None outside a summary)
        self._returns:         Optional[List[AbstractValue]]        = None
        # State at the end of the body run by RunBody (for the receiver's fields)
        self._exit_env:        Optional[Environment]                = None

    def Analyze(self, module: nodes.Module, file: Optional[str] = None) -> List[CapabilityRecord]:
        '''Analyze an astroid Module node. Returns all detected capability records.'''
        self._capabilities    = []
        self._string_analyses = []
        self._recording       = True
        env: Environment      = Environment()

        self._engine.BeginFile(module, file)
        self._SeedGlobals(env)
        self._ExecBody(module.body, env)

        return list(self._capabilities)

    # vvv Function Summaries (used by SummaryEngine) vvv
    def Spawn(self) -> "Interpreter":
        '''A fresh interpreter sharing this one's schema and summary engine.'''
        return Interpreter(self._schema, self._engine)

    def RunBody(
        self,
        func: nodes.FunctionDef | nodes.AsyncFunctionDef,
        env:  Environment,
    ) -> Tuple[List[CapabilityRecord], AbstractValue]:
        '''Run a function body from a seeded environment; return its capability records and return value.'''
        self._capabilities    = []
        self._string_analyses = []
        self._recording       = True
        self._returns         = []
        self._exit_env        = self._ExecBody(func.body, env)

        returned: AbstractValue = make_constant("NoneType", func.lineno or 0)
        if self._returns:
            returned = self._returns[0]
            for val in self._returns[1:]:
                returned = returned.join(val)
        return list(self._capabilities), returned

    def ExitEnvironment(self) -> Optional[Environment]:
        '''The state at the end of the last RunBody (None before one).'''
        return self._exit_env

    def ModuleEnvironment(self, module: nodes.Module) -> Environment:
        '''Globals and import aliases of a module, without running the rest of its body.'''
        env: Environment = Environment()
        self._SeedGlobals(env)
        was_recording: bool = self._recording
        self._recording     = False
        stack: List[nodes.NodeNG] = list(module.body)
        while stack:
            stmt: nodes.NodeNG = stack.pop(0)
            if isinstance(stmt, (nodes.Import, nodes.ImportFrom)):
                env = self._ExecStmt(stmt, env)
            elif isinstance(stmt, (nodes.Try, nodes.If)):
                # try: import x / except ImportError: ... and if TYPE_CHECKING: import y
                stack.extend(stmt.body)
                stack.extend(getattr(stmt, "orelse", []))
                for handler in getattr(stmt, "handlers", []):
                    stack.extend(handler.body)
        self._recording = was_recording
        return env

    def GetStringAnalyses(self) -> List[Optional[StringAnalysisResult]]:
        '''Return string analysis results parallel to the capabilities list.'''
        return list(self._string_analyses)

    # vvv Statement Execution vvv
    def _ExecBody(self, stmts: List[nodes.NodeNG], env: Environment) -> Environment:  # type: ignore
        for stmt in stmts:
            env = self._ExecStmt(stmt, env)

        return env

    def _ExecStmt(self, node: nodes.NodeNG, env: Environment) -> Environment:
        # x = expr
        if isinstance(node, nodes.Assign):
            val: AbstractValue = self._EvalAndDetect(node.value, env)
            for target in node.targets:
                env = self._ExecAssign(target, val, env)

        # x: T = expr
        elif isinstance(node, nodes.AnnAssign):
            if node.value:
                val = self._EvalAndDetect(node.value, env)
                env = self._ExecAssign(node.target, val, env)

        # x += expr
        elif isinstance(node, nodes.AugAssign):
            current: AbstractValue = self._ReadTarget(node.target, env)
            new_val: AbstractValue = self._EvalAndDetect(node.value, env)
            env                    = self._ExecAssign(node.target, current.join(new_val), env)

        # expr;  (standalone call)
        elif isinstance(node, nodes.Expr):
            self._EvalAndDetect(node.value, env)
            # validate_path(p) as a statement raises unless p is valid, so p is validated after it
            if isinstance(node.value, nodes.Call):
                env = self._ApplyValidatorStatement(node.value, env)

        # assert check(p) / assert ";" not in p: the code after it runs only if the check held
        elif isinstance(node, nodes.Assert):
            self._EvalAndDetect(node.test, env)
            env = self._ApplyTestRefinements(node.test, env.copy(), negate=False)

        # if / else
        elif isinstance(node, nodes.If):
            env = self._ExecIf(node, env)

        # for
        elif isinstance(node, nodes.For):
            env = self._ExecFor(node, env)

        # while
        elif isinstance(node, nodes.While):
            env = self._ExecWhile(node, env)

        # try / except
        elif isinstance(node, nodes.Try):
            env = self._ExecTry(node, env)

        # with
        elif isinstance(node, nodes.With):
            # astroid With.items: list of (context_expr_node, optional_vars_node | None)
            for context_expr, as_name in node.items:
                cm_val: AbstractValue = self._EvalAndDetect(context_expr, env)
                if as_name is not None:
                    env = self._ExecAssign(as_name, cm_val, env)
            env = self._ExecBody(node.body, env)

        # def / async def
        elif isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            env = self._ExecFuncDef(node, env)

        # class
        elif isinstance(node, nodes.ClassDef):
            env = self._ExecClassDef(node, env)

        # return
        elif isinstance(node, nodes.Return):
            if node.value:
                returned: AbstractValue = self._EvalAndDetect(node.value, env)
                # `return None` exits are left out of a summary: joining their CONSTANT would mask the real value
                is_none: bool = isinstance(node.value, nodes.Const) and node.value.value is None
                if self._returns is not None and not is_none:
                    self._returns.append(returned)

        # import / from import
        elif isinstance(node, nodes.Import):
            for name, asname in node.names:
                local: str = asname or name.split(".")[0]
                env.set(local, make_constant("module", node.lineno or 0))
                if asname:
                    env.aliases[asname] = name
                else:
                    env.aliases.pop(local, None)

        elif isinstance(node, nodes.ImportFrom):
            for name, asname in node.names:
                if name == "*":
                    continue
                local = asname or name
                env.set(local, make_constant("module", node.lineno or 0))
                # Relative imports (from . import x) name project code, never the stdlib sinks
                if node.level:
                    env.aliases.pop(local, None)
                else:
                    env.aliases[local] = f"{node.modname}.{name}"

        return env

    # vvv Core: Evaluate + Detect vvv
    def _EvalAndDetect(self, node: nodes.NodeNG, env: Environment) -> AbstractValue:
        '''
        Evaluate an astroid expression node AND detect any capabilities it invokes.

        For capability-producing calls:
          1. Record the CapabilityRecord.
          2. If any argument is a string literal, parse it with astroid and run
             a recursive sub-analysis, injecting inner capabilities as synthetic
             records so the query system sees them.
        '''
        line: int = node.lineno or 0

        if isinstance(node, nodes.Call):
            # Chained calls: in hashlib.md5(x).hexdigest() or os.popen(c).read() the
            # capability-producing call is the receiver, so detect inside it too
            if isinstance(node.func, nodes.Attribute):
                self._EvalAndDetect(node.func.expr, env)

            # Evaluate arguments first (also detects nested call capabilities)
            positional: List[AbstractValue]     = [self._EvalAndDetect(a, env) for a in node.args]
            keywords:   Dict[str, AbstractValue] = {}
            arg_vals:   List[AbstractValue]     = list(positional)
            for kw in node.keywords:
                if kw.value:
                    kw_val: AbstractValue = self._EvalAndDetect(kw.value, env)
                    arg_vals.append(kw_val)
                    if kw.arg:
                        keywords[kw.arg] = kw_val

            func_name: str = ResolveCallName(node.func, env)
            spec            = self._schema.functions.lookup(func_name)

            # obj.m(...) not known by name: a method sink when obj has the method's receiver type
            # (p.read_text() with p a pathlib path, tar.extractall() with tar from tarfile.open)
            if (spec.name == "*" and isinstance(node.func, nodes.Attribute)
                    and self._schema.functions.HasMethod(node.func.attrname)):
                receiver: AbstractValue = TransferExpr(node.func.expr, env, self._schema, self._CallValue)
                method_spec = LookupCall(node, env, self._schema, receiver)
                # A method modelled for any receiver (x.execute(sql)) that resolves to a
                # project method (Job.execute) is that method, followed through its summary
                if method_spec.name != "*" and not ("*" in (method_spec.receiver_types or [])
                                                    and self._engine.ResolveCached(node)[0] is not None):
                    spec = method_spec
                    arg_vals.insert(0, receiver)

            # A call the schema does not model may be a project function: follow it through its summary
            if spec.name == "*":
                summary: Optional[Summary] = self._Summarize(node, env, positional, keywords)
                if summary is not None:
                    if self._recording:
                        for flow in summary.flows:
                            self._capabilities.append(flow)
                            self._string_analyses.append(None)
                    # obj.set_path(p) / self._configure(): the receiver's attributes after the call
                    if summary.receiver_fields and isinstance(node.func, nodes.Attribute):
                        path = _AccessPath(node.func.expr)
                        if path is not None:
                            _SetPath(env, path, _GetPath(env, path).with_fields(dict(summary.receiver_fields)))
                    return ApplyValidator(node, env, self._schema, summary.returns)

            if spec.produces_capability and self._recording and not IsSafeCall(node, spec):
                if spec.sink_positions is not None:
                    # only the query / URL / template argument
                    arg_vals = [positional[i] for i in spec.sink_positions if i < len(positional)]
                    arg_vals += [keywords[k] for k in (spec.sink_keywords or []) if k in keywords]
                record: CapabilityRecord = CapabilityRecord(
                    capability_used = spec.produces_capability,
                    call_name       = func_name,
                    argument_state  = list(arg_vals),
                    line            = line,
                )
                self._capabilities.append(record)

                # SQL, URLs and templates are not Python: no embedded-code analysis for their sinks
                string_analysis: Optional[StringAnalysisResult] = (
                    None if spec.produces_capability in NON_PYTHON_SINKS
                    else self._AnalyzeStringArgs(node.args, func_name))
                self._string_analyses.append(string_analysis)

                if string_analysis is not None:
                    self._InjectStringCapabilities(string_analysis, line, func_name)

            return TransferCallExpr(node, env, self._schema, self._CallValue)

        # Non-call: evaluate via transfer function, recurse into sub-expressions
        result: AbstractValue = TransferExpr(node, env, self._schema, self._CallValue)
        for child in node.get_children():
            if not isinstance(node, nodes.Call):
                self._EvalAndDetect(child, env)

        # A generator's summary returns what it yields
        if isinstance(node, (nodes.Yield, nodes.YieldFrom)) and node.value is not None and self._returns is not None:
            self._returns.append(TransferExpr(node.value, env, self._schema, self._CallValue))

        return result

    def _Summarize(
        self,
        node:       nodes.Call,
        env:        Environment,
        positional: List[AbstractValue],
        keywords:   Dict[str, AbstractValue],
    ) -> Optional[Summary]:
        callee = self._Resolve(node, env)
        if callee is None:
            return None
        return self._engine.Apply(callee, node, positional, keywords, self)

    def _Resolve(self, node: nodes.Call, env: Environment):
        '''
        The project function a call reaches, or None. Resolution needs no values, so the
        receiver is evaluated only once the call resolves: evaluating it (and the
        arguments, in _CallValue) for every unresolved call re-evaluated a method chain
        such as s.replace(..).replace(..) at every link, exponential in its length.
        '''
        callee, uses_receiver = self._engine.ResolveCached(node)
        if callee is not None and uses_receiver:
            callee = replace(callee, receiver=TransferExpr(node.func.expr, env, self._schema, self._CallValue))
        return callee

    def _CallValue(self, node: nodes.Call, env: Environment) -> Optional[AbstractValue]:
        '''Call hook for the transfer functions: the summary's return value for a project call.'''
        if self._schema.functions.lookup(ResolveCallName(node.func, env)).name != "*":
            return None
        callee = self._Resolve(node, env)
        if callee is None:
            return None
        positional: List[AbstractValue]      = [TransferExpr(a, env, self._schema, self._CallValue) for a in node.args]
        keywords:   Dict[str, AbstractValue] = {
            kw.arg: TransferExpr(kw.value, env, self._schema, self._CallValue)
            for kw in node.keywords if kw.arg and kw.value
        }
        summary: Optional[Summary] = self._engine.Apply(callee, node, positional, keywords, self)
        return summary.returns if summary is not None else None

    def _AnalyzeStringArgs(self, args: List[nodes.NodeNG], func_name: str) -> Optional[StringAnalysisResult]:
        '''Check if any argument is a string literal or concatenation that parses as Python.'''
        for arg in args:
            # Direct string constant: exec("code here")
            if isinstance(arg, nodes.Const) and isinstance(arg.value, str):
                result: Optional[StringAnalysisResult] = AnalyzeStringLiteral(
                    arg.value, self._schema, depth=0, outer_call_name=func_name
                )
                if result is not None:
                    return result

            # String concatenation: exec("part1" + "part2")
            elif isinstance(arg, nodes.BinOp) and arg.op == "+":
                combined: Optional[str] = TryConcatStrings(arg)
                if combined is not None:
                    result = AnalyzeStringLiteral(
                        combined, self._schema, depth=0, outer_call_name=func_name
                    )
                    if result is not None:
                        return result

        return None

    def _InjectStringCapabilities(
        self,
        string_result: StringAnalysisResult,
        outer_line:    int,
        outer_func:    str,
    ) -> None:
        '''
        Inject capabilities found inside a string literal as synthetic CapabilityRecords
        so the query system evaluates them at the outer call site.

        Arguments are tagged with embedded_depth_N and "embedded_code" origins so
        findings clearly show nesting context in their output.
        '''
        depth_tag: str = f"embedded_depth_{string_result.depth + 1}"

        for inner_cap in string_result.capabilities:
            marked_args: List[AbstractValue] = [
                AbstractValue(
                    type_set     = av.type_set,
                    property_set = av.property_set,
                    origin_set   = av.origin_set | frozenset({depth_tag, "embedded_code"}),
                    source_line  = av.source_line,
                )
                for av in inner_cap.argument_state
            ]
            self._capabilities.append(CapabilityRecord(
                capability_used = inner_cap.capability_used,
                call_name       = f"{outer_func}(→{inner_cap.call_name})",
                argument_state  = marked_args,
                line            = outer_line,
            ))
            self._string_analyses.append(None)

        for nested in string_result.nested:
            self._InjectStringCapabilities(nested, outer_line, outer_func)

    # vvv Control Flow vvv
    def _ExecIf(self, node: nodes.If, env: Environment) -> Environment:
        then_env: Environment = self._ApplyTestRefinements(node.test, env.copy(), negate=False)
        else_env: Environment = self._ApplyTestRefinements(node.test, env.copy(), negate=True)
        then_env              = self._ExecBody(node.body,   then_env)
        else_env              = self._ExecBody(node.orelse, else_env)
        # A branch that always leaves (raise, return, abort()) does not reach the code
        # after the if, so `if not safe(p): abort(403)` leaves only the guarded state.
        then_exits: bool = self._Exits(node.body, env)
        else_exits: bool = bool(node.orelse) and self._Exits(node.orelse, env)
        if then_exits and not else_exits:
            return else_env
        if else_exits and not then_exits:
            return then_env
        return then_env.join(else_env)

    def _Exits(self, stmts: List[nodes.NodeNG], env: Environment) -> bool:
        if not stmts:
            return False
        last: nodes.NodeNG = stmts[-1]
        if isinstance(last, (nodes.Raise, nodes.Return, nodes.Break, nodes.Continue)):
            return True
        if isinstance(last, nodes.Expr) and isinstance(last.value, nodes.Call):
            name: str = ResolveCallName(last.value.func, env)
            terms     = self._schema.control.terminators
            return name in terms or name.rsplit(".", 1)[-1] in terms
        if isinstance(last, nodes.If):
            return self._Exits(last.body, env) and self._Exits(last.orelse, env)
        return False

    def _ApplyGuard(self, call: nodes.Call, env: Environment) -> Environment:
        '''If call is a schema guard (e.g. is_safe_path(base, p)), refine its Name arguments.'''
        name: str  = ResolveCallName(call.func, env)
        short: str = name.rsplit(".", 1)[-1]
        for guard in self._schema.guards:
            if any(fnmatch.fnmatchcase(name, pat) or fnmatch.fnmatchcase(short, pat) for pat in guard.patterns):
                lat = self._schema.lattice
                if guard.receiver:
                    recv = call.func.expr if isinstance(call.func, nodes.Attribute) else None
                    targets = [recv] if recv is not None else []
                else:
                    targets = list(call.args)
                    if guard.anchored and not _IsAnchoredPattern(call.args[0] if call.args else None):
                        targets = []
                for arg in targets:
                    path = _AccessPath(arg)
                    if path is None:
                        continue
                    cur: AbstractValue = _GetPath(env, path)
                    if guard.requires and not all(r in cur.property_set for r in guard.requires):
                        continue
                    props              = cur.property_set
                    for prop in guard.effect.remove: props = lat.remove(props, prop)
                    for prop in guard.effect.add:    props = lat.add(props, prop)
                    _SetPath(env, path, replace(cur, property_set=props))
                break
        return env

    def _ApplyValidatorStatement(self, call: nodes.Call, env: Environment) -> Environment:
        '''validate_x(p, ...) used as a statement: its Name arguments are validated after the call.'''
        validator = MatchingValidator(call, env, self._schema)
        if validator is None:
            return env
        lat = self._schema.lattice
        for arg in [*call.args, *(kw.value for kw in call.keywords)]:
            path = _AccessPath(arg)
            if path is not None:
                cur: AbstractValue = _GetPath(env, path)
                props              = cur.property_set
                for prop in validator.effect.remove: props = lat.remove(props, prop)
                for prop in validator.effect.add:    props = lat.add(props, prop)
                _SetPath(env, path, replace(cur, property_set=props))
        return env

    def _Sanitize(self, target: nodes.NodeNG, env: Environment, requires: Tuple[str, ...] = ()) -> Environment:
        '''Apply the path/command validation effect (as for a guard) to a variable or attribute.'''
        path = _AccessPath(target)
        if path is None:
            return env
        cur: AbstractValue = _GetPath(env, path)
        if requires and not all(r in cur.property_set for r in requires):
            return env
        lat   = self._schema.lattice
        props = lat.add(lat.remove(cur.property_set, "EXTERNAL_ORIGIN", "DYNAMIC"), "SANITIZED")
        _SetPath(env, path, replace(cur, property_set=props))
        return env

    def _ApplyTestRefinements(self, test: nodes.NodeNG, env: Environment, negate: bool) -> Environment:
        # `not X`: X holds exactly when `not X` fails
        if isinstance(test, nodes.UnaryOp) and test.op == "not" and not isinstance(test.operand, nodes.Call):
            return self._ApplyTestRefinements(test.operand, env, negate=not negate)

        # `if a or b: raise` -- after it (the negated branch) neither a nor b holds
        if isinstance(test, nodes.BoolOp) and test.op == "or" and negate:
            for val in test.values:
                env = self._ApplyTestRefinements(val, env, negate=True)
            return env

        if isinstance(test, nodes.Compare) and len(test.ops) == 1:
            op_str, right = test.ops[0]
            # ";" not in cmd  (or the negated branch of  ";" in cmd)
            if (((op_str == "not in" and not negate) or (op_str == "in" and negate))
                    and isinstance(test.left, nodes.Const) and isinstance(test.left.value, str)
                    and _AccessPath(right) is not None
                    and (".." in test.left.value or any(ch in METACHARACTERS for ch in test.left.value))):
                env = self._Sanitize(right, env)
            # os.path.commonpath([base, p]) == base  (or the negated branch of  !=): p is inside base,
            # if p was normalised first (commonpath does not resolve '..'). commonprefix is a string
            # prefix and does not count.
            if (((op_str == "==" and not negate) or (op_str == "!=" and negate))
                    and isinstance(test.left, nodes.Call)
                    and ResolveCallName(test.left.func, env).endswith("commonpath")
                    and test.left.args and isinstance(test.left.args[0], (nodes.List, nodes.Tuple))):
                base = _AccessPath(right)
                for elt in test.left.args[0].elts:
                    if _AccessPath(elt) is not None and _AccessPath(elt) != base:
                        env = self._Sanitize(elt, env, requires=("NORMALIZED",))

        # astroid Compare: .left and .ops is list of (op_string, comparator_node)
        if isinstance(test, nodes.Compare) and not negate:
            for op_str, comparator in test.ops:
                schema_op: Optional[str] = COMPAREOP_TO_SCHEMA.get(op_str)
                if not schema_op:
                    continue
                op_def = self._schema.operators.get(schema_op)
                if not op_def or not op_def.refinement:
                    continue
                if isinstance(test.left, nodes.Name):
                    env = ApplyRefinement(op_def.refinement, test.left.name, env, self._schema, comparator)

        if isinstance(test, nodes.Call) and not negate:
            env = self._ApplyGuard(test, env)

        # `if not guard(p): ...` -- the else branch (and code after an exiting body) has the guard holding
        if (isinstance(test, nodes.UnaryOp) and test.op == "not" and negate
                and isinstance(test.operand, nodes.Call)):
            env = self._ApplyGuard(test.operand, env)

        if isinstance(test, nodes.Call) and not negate:
            fname: str = ExtractCallName(test.func)
            if fname == "isinstance" and len(test.args) >= 1:
                if isinstance(test.args[0], nodes.Name):
                    env = ApplyRefinement("isinstance", test.args[0].name, env, self._schema)

        # astroid BoolOp.op is a string "and" / "or"
        if isinstance(test, nodes.BoolOp) and test.op == "and" and not negate:
            for val in test.values:
                env = self._ApplyTestRefinements(val, env, negate=False)

        return env

    def _ExecFor(self, node: nodes.For, env: Environment) -> Environment:
        iter_val: AbstractValue = self._EvalAndDetect(node.iter, env)
        elt_val: AbstractValue  = iter_val.with_props("DYNAMIC")

        def body(e: Environment) -> Environment:
            return self._ExecBody(node.body, self._ExecAssign(node.target, elt_val, e))

        return self._ExecLoop(body, env)

    def _ExecWhile(self, node: nodes.While, env: Environment) -> Environment:
        return self._ExecLoop(lambda e: self._ExecBody(node.body, e), env)

    def _ExecLoop(self, body: Callable[[Environment], Environment], env: Environment) -> Environment:
        '''
        Iterate the loop body to a fixed point of its entry state without recording
        capabilities, then run one recording pass from the stable state, so that
        loop-carried taint (x = input() on iteration 1, exec(x) on iteration 2) is seen
        and each call site is recorded once.
        '''
        was_recording: bool = self._recording
        self._recording     = False

        state: Environment = env
        for _ in range(MAX_LOOP_ITERS):
            nxt: Environment = state.join(body(state.copy()))
            if nxt == state:
                break
            state = nxt

        self._recording = was_recording
        return state.join(body(state.copy()))

    def _ExecTry(self, node: nodes.Try, env: Environment) -> Environment:
        try_env: Environment           = self._ExecBody(node.body, env.copy())
        branch_envs: List[Environment] = [try_env]

        for handler in node.handlers:
            h_env: Environment = env.copy()

            if handler.name:
                exc_name: str = handler.name.name
                h_env.set(exc_name, make_unknown(handler.lineno or 0))

            branch_envs.append(self._ExecBody(handler.body, h_env))

        if node.orelse:    branch_envs.append(self._ExecBody(node.orelse,    env.copy()))
        if node.finalbody: branch_envs.append(self._ExecBody(node.finalbody, env.copy()))

        result: Environment = branch_envs[0]
        for e in branch_envs[1:]:
            result = result.join(e)

        return result

    def _ExecFuncDef(
        self,
        node:      nodes.FunctionDef | nodes.AsyncFunctionDef,
        outer_env: Environment,
    ) -> Environment:
        inner: Environment = outer_env.copy()
        line: int          = node.lineno or 0

        # astroid Arguments: .args, .posonlyargs, .kwonlyargs are lists of AssignName
        all_args = (
            (node.args.args        or []) +
            (node.args.posonlyargs or []) +
            (node.args.kwonlyargs  or [])
        )
        # Web handlers (@app.route('/<name>'), @router.get(...)): parameters arrive from the request
        external: bool = self._IsRouteHandler(node)
        for k, arg in enumerate(all_args):
            seeded = external and not (k == 0 and arg.name in ("self", "cls"))
            inner.set(arg.name, make_external("str", line) if seeded else make_unknown(line))

        # vararg / kwarg are plain strings in astroid
        if node.args.vararg: inner.set(node.args.vararg, make_unknown(line))
        if node.args.kwarg:  inner.set(node.args.kwarg,  make_unknown(line))

        self._ExecBody(node.body, inner)
        return outer_env

    def _IsRouteHandler(self, node: nodes.FunctionDef | nodes.AsyncFunctionDef) -> bool:
        names = self._schema.sources.route_decorators
        for dec in (node.decorators.nodes if node.decorators else []):
            func = dec.func if isinstance(dec, nodes.Call) else dec
            if isinstance(func, nodes.Attribute) and func.attrname in names:
                return True
        return False

    def _ExecClassDef(self, node: nodes.ClassDef, env: Environment) -> Environment:
        self._ExecBody(node.body, env.copy())
        env.set(node.name, AbstractValue(
            type_set     = frozenset({"callable"}),
            property_set = frozenset({"CONSTANT"}),
            source_line  = node.lineno or 0,
        ))
        return env

    # vvv Helpers vvv
    def _ExecAssign(self, target: nodes.NodeNG, val: AbstractValue, env: Environment) -> Environment:
        # astroid uses AssignName (not Name) for assignment targets
        if isinstance(target, nodes.AssignName):
            env.set(target.name, val)
            env.aliases.pop(target.name, None)  # Rebinding shadows an import alias

        elif isinstance(target, (nodes.Tuple, nodes.List)):
            spread: AbstractValue = val.without_fields().with_props("DYNAMIC")
            for elt in target.elts:
                env = self._ExecAssign(elt, spread, env) # type: ignore

        # self.cmd = x, obj.path = p, self.repo.url = u: a strong update of that attribute
        elif isinstance(target, nodes.AssignAttr):
            path = _AccessPath(target)
            if path is not None:
                _SetPath(env, path, val)

        return env

    def _ReadTarget(self, target: nodes.NodeNG, env: Environment) -> AbstractValue:
        if isinstance(target, nodes.AssignName):
            return env.get(target.name)
        if isinstance(target, nodes.AssignAttr):
            path = _AccessPath(target)
            if path is not None:
                return _GetPath(env, path)
        return make_unknown()

    def _SeedGlobals(self, env: Environment) -> None:
        env.set("sys", make_constant("module"))
        env.set("os",  make_constant("module"))
        for name, type_name in self._schema.sources.globals.items():
            env.set(name, make_external(type_name))
# vvv Access Paths vvv
def _AccessPath(node: Optional[nodes.NodeNG]) -> Optional[Tuple[str, ...]]:
    '''x -> ("x",), self.cmd -> ("self", "cmd"), self.repo.url -> ("self", "repo", "url"); None otherwise.'''
    attrs: List[str] = []
    while isinstance(node, (nodes.Attribute, nodes.AssignAttr)):
        attrs.append(node.attrname)
        node = node.expr
    if not isinstance(node, (nodes.Name, nodes.AssignName)) or len(attrs) > MAX_FIELD_DEPTH:
        return None
    return (node.name, *reversed(attrs))

def _GetPath(env: Environment, path: Tuple[str, ...]) -> AbstractValue:
    val: AbstractValue = env.get(path[0])
    for attr in path[1:]:
        tracked: Optional[AbstractValue] = val.field(attr)
        val = tracked if tracked is not None else val.attribute_fallback()
    return val

def _SetPath(env: Environment, path: Tuple[str, ...], value: AbstractValue) -> None:
    if len(path) == 1:
        env.set(path[0], value)
        return
    env.set(path[0], _WithPath(env.get(path[0]), path[1:], value))

def _WithPath(obj: AbstractValue, attrs: Tuple[str, ...], value: AbstractValue) -> AbstractValue:
    if len(attrs) == 1:
        return obj.with_field(attrs[0], value)
    child: Optional[AbstractValue] = obj.field(attrs[0])
    return obj.with_field(attrs[0], _WithPath(child if child is not None else obj.attribute_fallback(), attrs[1:], value))

def _IsAnchoredPattern(node: Optional[nodes.NodeNG]) -> bool:
    '''A regex literal that must match to the end (re.match(r"^[a-z]+$", v) is an allowlist check).'''
    return (isinstance(node, nodes.Const) and isinstance(node.value, str)
            and (node.value.endswith("$") or node.value.endswith("\\Z")))
