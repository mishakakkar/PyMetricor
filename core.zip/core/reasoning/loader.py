'''
Loads schema.yml and builds every data structure the engine needs.

Produces:
  SchemaBundle
    .lattice      — PropertyLattice
    .capabilities — dict[name → CapabilityDef]
    .functions    — FunctionTable
    .operators    — dict[name → OperatorDef]
    .refinements  — dict[name → RefinementDef]
    .queries      — list[QueryDef]
    .sources      — SourcesDef (external attributes / globals)
    .guards       — list[GuardDef]
    .validators   — list[ValidatorDef]
'''

# Python stuff
import yaml
from dataclasses import dataclass
from pathlib     import Path
from typing      import Any, Dict, FrozenSet, List, Optional

# vvv Schema Data Classes  (1:1 with YAML structure) vvv
@dataclass
class PropertyDef:
    name:    str
    kind:    str            # "base" | "refinement"
    refines: Optional[str]

@dataclass
class CapabilityDef:
    name:     str
    consumes: List[str]

@dataclass
class ReturnSpec:
    type:               Optional[str]
    adds:               List[str]
    removes:            List[str]
    propagate_args:     bool
    dynamic_if_unknown: bool

@dataclass
class SafeArgDef:
    '''A call passing this argument with one of these values is safe: yaml.load(f, Loader=SafeLoader).'''
    keyword:  str
    position: Optional[int]      # also accepted positionally at this index
    values:   List[str]          # fnmatch patterns over the argument's name (last component); "*" = any value

@dataclass
class FunctionSpec:
    name:                str
    returns:             ReturnSpec
    produces_capability: Optional[str]
    safe_args:           List[SafeArgDef] = None    # type: ignore
    receiver_types:      List[str]        = None    # type: ignore  # methods only: receiver must have one of these types ("*": any receiver)
    excluded_receivers:  List[str]        = None    # type: ignore  # methods with "*": receiver types for which the method is safe
    # The arguments the capability is about (cursor.execute's query, requests.get's URL):
    # when given, only these are recorded, so a parameterised query's tainted parameters
    # do not make it a finding. Positions count the call's own arguments (not the receiver).
    sink_positions:      List[int]        = None    # type: ignore
    sink_keywords:       List[str]        = None    # type: ignore

@dataclass
class OperatorDef:
    name:       str
    propagate:  bool
    refinement: Optional[str]

@dataclass
class RefinementEffect:
    remove:      List[str]
    add:         List[str]
    narrow_type: bool

@dataclass
class RefinementDef:
    name:    str
    pattern: Optional[str]
    effect:  RefinementEffect

@dataclass
class QueryCondition:
    capability:     str
    argument_has:   List[str]
    argument_lacks: List[str]
    origin_has:     List[str]
    type_is:        List[str]

@dataclass
class SourcesDef:
    attributes: FrozenSet[str]   # x.<attr> reads that carry EXTERNAL_ORIGIN
    globals:    Dict[str, str]   # name -> type, seeded as external at module start
    route_decorators: FrozenSet[str] = frozenset()  # @app.<name>(...) handlers: parameters are external

@dataclass
class GuardDef:
    patterns: List[str]          # fnmatch patterns over resolved call names
    effect:   RefinementEffect   # applied to Name arguments when the guard is known to hold
    receiver: bool = False       # refine the method receiver (p in p.startswith(base)) instead
    requires: List[str] = None   # receiver must carry these properties (e.g. NORMALIZED)
    anchored: bool = False       # first argument must be a regex literal anchored at the end ($ or \\Z)

@dataclass
class ValidatorDef:
    '''A call that checks or cleans its arguments: refines them when called as a statement, and its result.'''
    patterns: List[str]          # fnmatch patterns over the call's last name component, leading underscores stripped
    effect:   RefinementEffect

@dataclass
class ControlDef:
    terminators: FrozenSet[str]  # calls that never return (abort, sys.exit ...)

@dataclass
class QueryDef:
    name:      str
    condition: QueryCondition
    severity:  str          # info | low | medium | high | critical

# vvv Derived Structures vvv
class PropertyLattice:
    '''
    Property lattice. Join = set union. Meet = intersection.
    Bot = empty set. Fixed-point guaranteed by monotone transfer + finite lattice.
    '''
    def __init__(self, defs: Dict[str, PropertyDef]) -> None:
        self._defs: Dict[str, PropertyDef] = defs

    def join(self, a: FrozenSet[str], b: FrozenSet[str]) -> FrozenSet[str]:
        '''a ⊔ b = a ∪ b  (least upper bound)'''
        return a | b

    def add(self, props: FrozenSet[str], *names: str) -> FrozenSet[str]:
        return props | frozenset(names)

    def remove(self, props: FrozenSet[str], *names: str) -> FrozenSet[str]:
        return props - frozenset(names)

    def has(self, props: FrozenSet[str], name: str) -> bool:
        return name in props

class FunctionTable:
    '''
    Lookup table for function specs.
    Resolution order: exact qualified name → base name → wildcard "*".
    Method specs (obj.read_text()) are looked up separately by method name and
    apply only when the receiver has one of the spec's types.
    '''
    def __init__(self, specs: Dict[str, FunctionSpec], methods: Optional[Dict[str, FunctionSpec]] = None) -> None:
        self._specs:   Dict[str, FunctionSpec] = specs
        self._default: Optional[FunctionSpec]  = specs.get("*")
        self._methods: Dict[str, FunctionSpec] = methods or {}

    def HasMethod(self, method_name: str) -> bool:
        return method_name in self._methods

    def method(self, method_name: str, receiver_types: FrozenSet[str]) -> Optional[FunctionSpec]:
        spec: Optional[FunctionSpec] = self._methods.get(method_name)
        if spec is None:
            return None
        wanted: FrozenSet[str] = frozenset(spec.receiver_types or [])
        if "*" in wanted:
            # imported names are typed "module" too (from db import cursor), so they count
            if receiver_types & frozenset(spec.excluded_receivers or []):
                return None
            return spec
        return spec if receiver_types & wanted else None

    def lookup(self, qualified_name: str) -> FunctionSpec:
        if qualified_name in self._specs:
            return self._specs[qualified_name]

        base: str = qualified_name.split(".")[-1]
        if base in self._specs:
            spec: FunctionSpec = self._specs[base]
            if spec.produces_capability is None:
                return spec

        return self._default or _MakeDefaultSpec()

def _MakeDefaultSpec() -> FunctionSpec:
    '''Fallback spec: propagate args, mark DYNAMIC.'''
    return FunctionSpec(
        name    = "*",
        returns = ReturnSpec(
            type               = None,
            adds               = [],
            removes            = [],
            propagate_args     = True,
            dynamic_if_unknown = True,
        ),
        produces_capability = None,
    )

@dataclass
class CarrierDef:
    '''A type that marks one kind of object (a pathlib path) and is not inherited by values derived from it.'''
    name:         str
    preserved_by: FrozenSet[str]   # methods on the object that return the same kind of object
    attributes:   FrozenSet[str]   # attributes that are the same kind of object (p.parent)

@dataclass
class SchemaBundle:
    '''Everything the engine needs, built once from the YAML.'''
    version:      int
    lattice:      PropertyLattice
    capabilities: Dict[str, CapabilityDef]
    functions:    FunctionTable
    operators:    Dict[str, OperatorDef]
    refinements:  Dict[str, RefinementDef]
    queries:      List[QueryDef]
    sources:      SourcesDef
    guards:       List[GuardDef]
    control:      ControlDef
    validators:   List[ValidatorDef] = None  # type: ignore
    carriers:     Dict[str, CarrierDef] = None  # type: ignore

# vvv Parser vvv
def LoadSchema(path: str | Path) -> SchemaBundle:
    '''Parse schema.yml and build the full SchemaBundle. Raises ValueError on bad schema.'''
    with open(path) as f:
        raw: Dict[str, Any] = yaml.safe_load(f)

    version: int = raw.get("version", 1)

    # Properties
    prop_defs: Dict[str, PropertyDef] = {}
    for name, spec in (raw.get("properties") or {}).items(): # type: ignore
        prop_defs[name] = PropertyDef(
            name    = name,                     # type: ignore
            kind    = spec.get("kind", "base"), # type: ignore
            refines = spec.get("refines"),      # type: ignore
        )

    for p in prop_defs.values():
        if p.refines and p.refines not in prop_defs:
            raise ValueError(f"Property '{p.name}' refines unknown '{p.refines}'")

    # Capabilities
    cap_defs: Dict[str, CapabilityDef] = {}
    for name, spec in (raw.get("capabilities") or {}).items(): # type: ignore
        cap_defs[name] = CapabilityDef(
            name     = name,                     # type: ignore
            consumes = spec.get("consumes", []), # type: ignore
        )

    # Functions and methods
    func_specs:   Dict[str, FunctionSpec] = {name: _FunctionSpec(name, spec) for name, spec in (raw.get("functions") or {}).items()} # type: ignore
    method_specs: Dict[str, FunctionSpec] = {name: _FunctionSpec(name, spec) for name, spec in (raw.get("methods") or {}).items()}   # type: ignore
    for spec in method_specs.values():
        if not spec.receiver_types:
            raise ValueError(f"Method '{spec.name}' needs receiver_types")

    # Operators
    op_defs: Dict[str, OperatorDef] = {}
    for name, spec in (raw.get("operators") or {}).items(): # type: ignore
        op_defs[name] = OperatorDef(
            name       = name,                          # type: ignore
            propagate  = spec.get("propagate", False),  # type: ignore
            refinement = spec.get("refinement"),        # type: ignore
        )

    # Refinements
    ref_defs: Dict[str, RefinementDef] = {}
    for name, spec in (raw.get("refinements") or {}).items(): # type: ignore
        eff_raw: Dict[str, Any] = spec.get("effect", {}) # type: ignore
        ref_defs[name] = RefinementDef(
            name    = name,                 # type: ignore
            pattern = spec.get("pattern"),  # type: ignore
            effect  = RefinementEffect(
                remove      = eff_raw.get("remove", []),         # type: ignore
                add         = eff_raw.get("add", []),            # type: ignore
                narrow_type = eff_raw.get("narrow_type", False), # type: ignore
            ),
        )

    # Queries
    query_list: List[QueryDef] = []
    for name, spec in (raw.get("queries") or {}).items(): # type: ignore
        when: Dict[str, Any] = spec.get("when", {}) # type: ignore
        query_list.append(QueryDef(
            name      = name, # type: ignore
            condition = QueryCondition(
                capability     = when.get("capability", ""),     # type: ignore
                argument_has   = when.get("argument_has", []),   # type: ignore
                argument_lacks = when.get("argument_lacks", []), # type: ignore
                origin_has     = when.get("origin_has", []),     # type: ignore
                type_is        = when.get("type_is", []),        # type: ignore
            ),
            severity = spec.get("severity", "info"), # type: ignore
        ))

    # Sources
    src_raw: Dict[str, Any] = raw.get("sources") or {}
    sources: SourcesDef = SourcesDef(
        attributes = frozenset(src_raw.get("attributes") or []),  # type: ignore
        globals    = dict(src_raw.get("globals") or {}),           # type: ignore
        route_decorators = frozenset(src_raw.get("route_decorators") or []),  # type: ignore
    )

    # Guards
    guard_list: List[GuardDef] = []
    for spec in (raw.get("guards") or {}).values(): # type: ignore
        eff_raw = spec.get("effect", {}) # type: ignore
        guard_list.append(GuardDef(
            patterns = list(spec.get("calls", [])), # type: ignore
            receiver = bool(spec.get("receiver", False)), # type: ignore
            requires = list(spec.get("requires", [])),    # type: ignore
            anchored = bool(spec.get("anchored", False)), # type: ignore
            effect   = RefinementEffect(remove=eff_raw.get("remove", []), add=eff_raw.get("add", []), narrow_type=False), # type: ignore
        ))

    # Carrier types
    carriers: Dict[str, CarrierDef] = {
        name: CarrierDef(name, frozenset(spec.get("preserved_by") or []), frozenset(spec.get("attributes") or []))
        for name, spec in (raw.get("types") or {}).items() if (spec or {}).get("carrier")  # type: ignore
    }

    # Validators
    validator_list: List[ValidatorDef] = []
    for spec in (raw.get("validators") or {}).values(): # type: ignore
        eff_raw = spec.get("effect", {}) # type: ignore
        validator_list.append(ValidatorDef(
            patterns = list(spec.get("calls", [])), # type: ignore
            effect   = RefinementEffect(remove=eff_raw.get("remove", []), add=eff_raw.get("add", []), narrow_type=False), # type: ignore
        ))

    # Control flow
    ctl_raw: Dict[str, Any] = raw.get("control") or {}
    control: ControlDef = ControlDef(terminators=frozenset(ctl_raw.get("terminators") or []))  # type: ignore

    return SchemaBundle(
        version      = version,
        lattice      = PropertyLattice(prop_defs),
        capabilities = cap_defs,
        functions    = FunctionTable(func_specs, method_specs),
        operators    = op_defs,
        refinements  = ref_defs,
        queries      = query_list,
        sources      = sources,
        guards       = guard_list,
        control      = control,
        validators   = validator_list,
        carriers     = carriers,
    )
def _FunctionSpec(name: str, spec: Dict[str, Any]) -> FunctionSpec:
    ret_raw: Dict[str, Any] = spec.get("returns", {})
    safe: List[SafeArgDef]  = [
        SafeArgDef(keyword=kw, position=d.get("position"), values=list(d.get("values", ["*"])))
        for kw, d in (spec.get("safe_args") or {}).items()
    ]
    return FunctionSpec(
        name    = name,
        returns = ReturnSpec(
            type               = ret_raw.get("type"),
            adds               = ret_raw.get("adds", []),
            removes            = ret_raw.get("removes", []),
            propagate_args     = ret_raw.get("propagate_args", False),
            dynamic_if_unknown = ret_raw.get("dynamic_if_unknown", False),
        ),
        produces_capability = spec.get("produces_capability"),
        safe_args           = safe,
        receiver_types      = list(spec.get("receiver_types", [])),
        excluded_receivers  = list(spec.get("excluded_receivers", [])),
        sink_positions      = list((spec.get("sink_args") or {}).get("positions", [])) if spec.get("sink_args") else None,
        sink_keywords       = list((spec.get("sink_args") or {}).get("keywords", [])) if spec.get("sink_args") else None,
    )
