'''
Recursive string literal analysis.

Uses astroid.builder.parse() to parse embedded string literals so the same
interpreter and node types are used throughout. No stdlib ast anywhere.

Problem:
    exec("a = input(); exec(a)")

    The outer call sees a CONSTANT string argument.
    The engine marks it low-risk (dynamic_execution_constant).
    But the string IS valid Python — and inside it, input() feeds exec().
    That inner pattern is CRITICAL.

Solution:
    When a string literal is passed to a capability-producing function, parse
    it with astroid and run a full sub-analysis. Dangerous capabilities found
    inside are injected as synthetic CapabilityRecords by the interpreter so
    the query system evaluates them at the outer call site.

    Recursion is bounded by MAX_DEPTH (default 5).
'''

# My stuff
from .queries     import SEVERITY_RANK, EvaluateAll, Finding
from .loader      import SchemaBundle
from .state       import CapabilityRecord

# Python stuff
from dataclasses  import dataclass, field
from typing       import List, Optional, Set
from astroid      import nodes, builder  # type: ignore

# vvv Constants vvv
MAX_DEPTH: int = 5

# vvv String Analysis Result vvv
@dataclass
class StringAnalysisResult:
    '''Capabilities and findings discovered by recursively analyzing a string literal.'''
    depth:           int
    source_fragment: str
    outer_call_name: str                          = ""
    capabilities:    List["CapabilityRecord"]     = field(default_factory=list)  # type: ignore
    findings:        List["Finding"]              = field(default_factory=list)  # type: ignore
    nested:          List["StringAnalysisResult"] = field(default_factory=list)  # type: ignore

    @property
    def AllFindings(self) -> List["Finding"]:
        '''Flatten findings from this level and all nested levels.'''
        result: List[Finding] = list(self.findings)
        for n in self.nested:
            result.extend(n.AllFindings)

        return result

    @property
    def WorstSeverity(self) -> Optional[str]:
        all_f: List[Finding] = self.AllFindings
        if not all_f:
            return None

        return max(all_f, key=lambda f: SEVERITY_RANK.get(f.severity, 0)).severity

# vvv Analysis vvv
def AnalyzeStringLiteral(
    value:           str,
    schema:          SchemaBundle,
    depth:           int = 0,
    outer_call_name: str = "",
) -> Optional[StringAnalysisResult]:
    '''
    Try to parse value as Python source with astroid and run a sub-analysis.
    Returns None if not valid Python, empty/trivial, or depth exceeded.
    '''
    if depth >= MAX_DEPTH:
        return None

    value = value.strip()
    if not value:
        return None

    # Parse with astroid so the same interpreter and node types are used throughout
    try:
        module = builder.parse(value)
    except Exception:
        return None

    if not module.body:
        return None

    # Skip plain string expressions. "hello world" parses as Expr(Const(...))-
    # -but is not executable code worth analyzing
    if (
        len(module.body) == 1
        and isinstance(module.body[0], nodes.Expr)
        and isinstance(module.body[0].value, nodes.Const)
    ):
        return None

    # Doing it in global space will not work due to circular import
    from .interpreter import Interpreter

    interp:   Interpreter            = Interpreter(schema)
    caps:     List[CapabilityRecord] = interp.Analyze(module)
    findings: List[Finding]          = EvaluateAll(caps, schema)

    result: StringAnalysisResult = StringAnalysisResult(
        depth           = depth,
        source_fragment = value[:120] + ("..." if len(value) > 120 else ""),
        outer_call_name = outer_call_name,
        capabilities    = caps,
        findings        = findings,
    )

    result.nested.extend(_WalkForStringLiterals(module, schema, depth + 1))
    return result

# vvv Internals vvv
def _WalkForStringLiterals(
    module: nodes.Module,
    schema: SchemaBundle,
    depth:  int,
) -> List[StringAnalysisResult]:
    '''Walk an astroid Module and recursively analyze string literals passed to exec/eval/compile.'''
    if depth >= MAX_DEPTH:
        return []

    results:         List[StringAnalysisResult] = []
    exec_eval_names: Set[str]                   = {"exec", "eval", "compile", "execfile"}

    for call_node in module.nodes_of_class(nodes.Call):
        fname: str = ""
        if isinstance(call_node.func, nodes.Name):
            fname = call_node.func.name
        elif isinstance(call_node.func, nodes.Attribute):
            fname = call_node.func.attrname

        if fname not in exec_eval_names:
            continue

        for arg in call_node.args:
            if isinstance(arg, nodes.Const) and isinstance(arg.value, str):
                sub: Optional[StringAnalysisResult] = AnalyzeStringLiteral(arg.value, schema, depth, fname)
                if sub is not None:
                    results.append(sub)

    return results