'''
Function summaries: following a call into a function defined in the project.

Without summaries a call to a project function is treated like any unknown call
(the result joins its arguments and is DYNAMIC) and nothing inside the callee is
connected to the caller. With summaries, a call that resolves to a function in
the same file, or in another file of the project (see project.py), is analysed
once per abstract calling context:

    summary(f, (props, types) of each parameter) =
        return value          the join of every returned (or yielded) value
        flows                 every capability use inside f (or below it) whose
                              argument derives from one of f's parameters

Each parameter is seeded with the caller's properties and a private origin marker
(§i), so after the callee runs the engine knows which sink arguments and which
parts of the return value came from which parameter. At the call site the markers
are replaced by the actual arguments' origins, and each flow becomes a capability
record at the call line, named caller-side as "helper→os.system". The queries
then decide severity as for a direct call, so

    def run(cmd): subprocess.run(cmd, shell=True)
    run(request.args["c"])          ->  spawn_external_command at this line

Summaries are memoised per (function, context) for the whole project run, so
each function is analysed at most once per distinct context. Recursion, depth
beyond MAX_CALL_DEPTH and a per-file budget fall back to the unknown-call rule.

Calls are resolved without type inference:
    f(...)                 a def, class or import visible from the call (astroid lookup)
    mod.f(...), pkg.mod.f  a function in a project module
    self.m(...), cls.m     a method of the enclosing class or its project bases
    super().m(...)         a method of a project base class
    C(...), C.m(...)       C.__init__, or a method called through the class
Calls on other objects (obj.m() where obj is a value) stay unresolved.
'''

# My stuff
from .loader  import SchemaBundle
from .project import ProjectIndex
from .state   import AbstractValue, CapabilityRecord, Environment, make_constant, make_unknown

# Python stuff
from astroid     import nodes  # type: ignore
from dataclasses import dataclass, field, replace
from os          import path as os_path
from typing      import Dict, FrozenSet, List, Optional, Set, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from .interpreter import Interpreter

# vvv Constants vvv
MAX_CALL_DEPTH:       int = 4    # callee chain length followed from a call site
MAX_SUMMARIES_PER_FILE: int = 400  # new summaries computed while analysing one file
MAX_RESOLVE_DEPTH:    int = 5    # re-exports and base classes followed when resolving a name
MARKER:               str = "§"
INTERPROCEDURAL:      str = "interprocedural"

# Stands in for a receiver value to find out whether a resolution binds the receiver
_PROBE: AbstractValue = AbstractValue(origin_set=frozenset({"probe"}))

ContextKey = Tuple[str, int, str, Tuple[object, ...]]

# vvv Data vvv
@dataclass
class Callee:
    '''A resolved call target.'''
    function:   nodes.FunctionDef | nodes.AsyncFunctionDef
    name:       str            # display name, e.g. "Repo.run" or "utils.run_command"
    bind_first: bool           # first parameter is bound to the receiver (self / cls / new object)
    receiver:   Optional[AbstractValue] = None
    constructor: bool          = False   # C(...) through C.__init__: the call's value is the new object

@dataclass
class Summary:
    returns: AbstractValue
    flows:   List[CapabilityRecord] = field(default_factory=list)
    # The receiver's attributes when the method returns (self.x = ... in __init__ or a setter)
    receiver_fields: Tuple[Tuple[str, AbstractValue], ...] = ()

# vvv Main Stuff vvv
class SummaryEngine:
    '''Resolves calls to project functions and computes their summaries.'''

    __slots__ = ("_schema", "_index", "_memo", "_active", "_module_envs", "_budget", "depth", "_resolved")

    def __init__(self, schema: SchemaBundle, index: Optional[ProjectIndex] = None) -> None:
        self._schema:      SchemaBundle                 = schema
        self._index:       ProjectIndex                 = index or ProjectIndex([])
        self._memo:        Dict[ContextKey, Summary]    = {}
        self._active:      Set[ContextKey]              = set()
        self._module_envs: Dict[str, Environment]       = {}
        self._budget:      int                          = MAX_SUMMARIES_PER_FILE
        self.depth:        int                          = 0
        # call node -> (callee resolved without a receiver, whether its resolution takes the receiver)
        self._resolved:    Dict[nodes.Call, Tuple[Optional[Callee], bool]] = {}

    def BeginFile(self, module: nodes.Module, file: Optional[str] = None) -> None:
        '''Called when analysis of a new file starts. file is needed when the module was parsed without a path.'''
        self._budget = MAX_SUMMARIES_PER_FILE
        self._resolved.clear()   # holds nodes of the previous file's modules
        file = file or (module.file if module.file != "<?>" else None)
        if file:
            self._index.Adopt(file, module)
            self._module_envs.pop(os_path.abspath(file), None)

    # vvv Summaries vvv
    def Apply(
        self,
        callee:      Callee,
        call:        nodes.Call,
        positional:  List[AbstractValue],
        keywords:    Dict[str, AbstractValue],
        interpreter: "Interpreter",
    ) -> Optional[Summary]:
        '''
        Summary of callee for these arguments, already rewritten for the call site:
        markers replaced by the actual arguments' origins and flows placed at the
        call line. None when the call must fall back to the unknown-call rule.
        '''
        if self.depth >= MAX_CALL_DEPTH:
            return None
        bound: Optional[List[Tuple[str, AbstractValue]]] = self._Bind(callee, call, positional, keywords)
        if bound is None:
            return None

        func: nodes.FunctionDef = callee.function
        root: nodes.Module      = func.root()
        key: ContextKey         = (self._index.FileOf(root), func.lineno or 0, func.name,
                                   tuple(_Signature(av) for _, av in bound))
        if key in self._active:
            return None
        summary: Optional[Summary] = self._memo.get(key)
        if summary is None:
            if self._budget <= 0:
                return None
            self._budget -= 1
            self._active.add(key)
            self.depth += 1
            try:
                summary = self._Compute(func, bound, interpreter, callee.bind_first)
            finally:
                self.depth -= 1
                self._active.discard(key)
            self._memo[key] = summary

        # One record per capability at the call site: a call that reaches two subprocess
        # sinks inside the callee is one finding here, not two
        actuals: List[AbstractValue]                = [av for _, av in bound]
        line: int                                   = call.lineno or 0
        by_capability: Dict[str, CapabilityRecord] = {}
        for rec in summary.flows:
            args: List[AbstractValue] = [_Rewrite(av, actuals, av.source_line) for av in rec.argument_state]
            merged: Optional[CapabilityRecord] = by_capability.get(rec.capability_used)
            if merged is None:
                by_capability[rec.capability_used] = CapabilityRecord(
                    capability_used = rec.capability_used,
                    call_name       = f"{callee.name}→{rec.call_name}",
                    argument_state  = args,
                    line            = line,
                )
            else:
                merged.argument_state.extend(args)
        returns: AbstractValue = _Rewrite(summary.returns, actuals, line)
        fields: Tuple[Tuple[str, AbstractValue], ...] = tuple(
            (name, _Rewrite(av, actuals, line)) for name, av in summary.receiver_fields)
        if callee.constructor:
            # C(x): the new object, with the attributes __init__ assigned
            return Summary(returns=returns.with_fields(dict(fields)), flows=list(by_capability.values()))
        return Summary(returns=returns, flows=list(by_capability.values()), receiver_fields=fields)

    def _Compute(
        self,
        func:        nodes.FunctionDef | nodes.AsyncFunctionDef,
        bound:       List[Tuple[str, AbstractValue]],
        interpreter: "Interpreter",
        bind_first:  bool = False,
    ) -> Summary:
        env: Environment = self._ModuleEnv(func.root(), interpreter).copy()
        line: int        = func.lineno or 0
        for i, (name, av) in enumerate(bound):
            env.set(name, _Mark(av, i, line))
            env.aliases.pop(name, None)

        runner = interpreter.Spawn()
        records, returns = runner.RunBody(func, env)
        flows: List[CapabilityRecord] = [
            rec for rec in records
            if any(o.startswith(MARKER) for av in rec.argument_state for o in av.origin_set)
        ]
        receiver_fields: Tuple[Tuple[str, AbstractValue], ...] = ()
        exit_env: Optional[Environment] = runner.ExitEnvironment()
        if bind_first and bound and exit_env is not None:
            receiver_fields = exit_env.get(bound[0][0]).fields
        return Summary(returns=returns, flows=flows, receiver_fields=receiver_fields)

    def _ModuleEnv(self, module: nodes.Module, interpreter: "Interpreter") -> Environment:
        '''Import aliases of the callee's module, so sinks inside it resolve (sp.run -> subprocess.run).'''
        file: str = os_path.abspath(self._index.FileOf(module))
        env: Optional[Environment] = self._module_envs.get(file)
        if env is None:
            env = interpreter.Spawn().ModuleEnvironment(module)
            self._module_envs[file] = env
        return env

    def _Bind(
        self,
        callee:     Callee,
        call:       nodes.Call,
        positional: List[AbstractValue],
        keywords:   Dict[str, AbstractValue],
    ) -> Optional[List[Tuple[str, AbstractValue]]]:
        '''Parameter name -> abstract argument, in parameter order.'''
        args: nodes.Arguments = callee.function.args
        if args.args is None:  # built from a C module, no signature
            return None
        line: int               = call.lineno or 0
        positional_params       = list(args.posonlyargs or []) + list(args.args or [])
        values: Dict[str, AbstractValue] = {}

        pending: List[AbstractValue] = list(positional)
        if callee.bind_first and positional_params:
            values[positional_params[0].name] = callee.receiver or make_unknown(line)
            positional_params = positional_params[1:]

        starred: bool = any(isinstance(a, nodes.Starred) for a in call.args) or any(kw.arg is None for kw in call.keywords)
        for param in positional_params:
            if pending:
                values[param.name] = pending.pop(0)
        if args.vararg:
            extra: AbstractValue = make_unknown(line) if starred else make_constant("tuple", line)
            for av in pending:
                extra = extra.join(av)
            values[args.vararg] = extra

        kwonly: List[nodes.AssignName] = list(args.kwonlyargs or [])
        names: Set[str] = {p.name for p in positional_params} | {p.name for p in kwonly}
        leftover: Optional[AbstractValue] = None
        for name, av in keywords.items():
            if name in names and name not in values:
                values[name] = av
            else:
                leftover = av if leftover is None else leftover.join(av)
        if args.kwarg:
            values[args.kwarg] = leftover.with_props("DYNAMIC") if leftover else make_unknown(line)

        # Parameters the call does not supply take their default, or are unknown
        defaults: Dict[str, nodes.NodeNG] = {}
        for param, default in zip(reversed(positional_params), reversed(args.defaults or [])):
            defaults[param.name] = default
        for param, default in zip(kwonly, args.kw_defaults or []):
            if default is not None:
                defaults[param.name] = default
        ordered: List[Tuple[str, AbstractValue]] = []
        first: List[nodes.AssignName] = list(args.posonlyargs or []) + list(args.args or [])
        for param in first + kwonly:
            if param.name not in values:
                default = defaults.get(param.name)
                values[param.name] = (
                    make_unknown(line) if starred or default is None or not isinstance(default, nodes.Const)
                    else make_constant(type(default.value).__name__, line)
                )
            ordered.append((param.name, values[param.name]))
        for name in (args.vararg, args.kwarg):
            if name:
                ordered.append((name, values[name]))
        return ordered

    # vvv Call Resolution vvv
    def ResolveCached(self, call: nodes.Call) -> Tuple[Optional[Callee], bool]:
        '''
        Resolve(call, None), memoised per call node, and whether the resolution binds the
        receiver (self.m(), obj.m()), so the caller evaluates the receiver only then.
        Resolution needs no values, so the same call always resolves the same way.
        '''
        hit = self._resolved.get(call)
        if hit is None:
            callee: Optional[Callee] = self.Resolve(call, _PROBE)
            uses: bool               = callee is not None and callee.receiver is _PROBE
            if uses:
                callee = replace(callee, receiver=None)
            hit = (callee, uses)
            self._resolved[call] = hit
        return hit

    def Resolve(self, call: nodes.Call, receiver: Optional[AbstractValue]) -> Optional[Callee]:
        func: nodes.NodeNG = call.func
        file: str          = self._index.FileOf(call.root())

        if isinstance(func, nodes.Name):
            target = self._ResolveName(func, file, 0)
            if isinstance(target, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
                bind: bool = isinstance(target.parent, nodes.ClassDef)  # a method name used bare is unbound
                return None if bind else Callee(target, target.name, bind_first=False)
            if isinstance(target, nodes.ClassDef):
                return self._Constructor(target, 0)
            return None

        if not isinstance(func, nodes.Attribute):
            return None

        expr: nodes.NodeNG = func.expr
        # self.m(...) / cls.m(...)
        if isinstance(expr, nodes.Name) and self._IsReceiverName(expr):
            cls: Optional[nodes.ClassDef] = self._EnclosingClass(expr)
            method = self._Method(cls, func.attrname, 0) if cls else None
            if method is not None:
                return Callee(method, f"{method.parent.name}.{method.name}", bind_first=not _IsStatic(method), receiver=receiver)
            return None

        # super().m(...)
        if isinstance(expr, nodes.Call) and isinstance(expr.func, nodes.Name) and expr.func.name == "super":
            cls = self._EnclosingClass(expr)
            if cls is None:
                return None
            for base in self._Bases(cls, 0):
                method = self._Method(base, func.attrname, 0)
                if method is not None:
                    return Callee(method, f"{base.name}.{method.name}", bind_first=not _IsStatic(method), receiver=receiver)
            return None

        # C(...).m(...): a method of a freshly built project object
        if isinstance(expr, nodes.Call):
            built = self._ResolveExpr(expr.func, file, 0)
            if isinstance(built, nodes.ClassDef):
                method = self._Method(built, func.attrname, 0)
                if method is not None:
                    return Callee(method, f"{built.name}.{method.name}", bind_first=not _IsStatic(method), receiver=receiver)
            return None

        owner = self._ResolveExpr(expr, file, 0)
        if isinstance(owner, nodes.Module):
            member = self._Member(owner.name, func.attrname, 0)
            if isinstance(member, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
                return Callee(member, f"{owner.name.rsplit('.', 1)[-1]}.{member.name}", bind_first=False)
            if isinstance(member, nodes.ClassDef):
                return self._Constructor(member, 0)
        if isinstance(owner, nodes.ClassDef):
            method = self._Method(owner, func.attrname, 0)
            if method is not None:
                return Callee(method, f"{owner.name}.{method.name}", bind_first=_IsClassMethod(method))
            return None

        # obj.m(...) where obj = C(...) in this scope, or self.obj = C(...) in the class
        built = self._ConstructedClass(expr, file)
        if built is not None:
            method = self._Method(built, func.attrname, 0)
            if method is not None:
                return Callee(method, f"{method.parent.name}.{method.name}", bind_first=not _IsStatic(method), receiver=receiver)
        return None

    def _ConstructedClass(self, expr: nodes.NodeNG, file: str) -> Optional[nodes.ClassDef]:
        '''The project class a variable or self attribute was built from, when that is its only assignment.'''
        values: List[nodes.NodeNG] = []
        if isinstance(expr, nodes.Name):
            try:
                _, stmts = expr.lookup(expr.name)
            except Exception:
                return None
            for stmt in stmts:
                if isinstance(stmt, nodes.AssignName) and isinstance(stmt.parent, (nodes.Assign, nodes.AnnAssign)):
                    values.append(stmt.parent.value)
                else:
                    return None
        elif isinstance(expr, nodes.Attribute) and isinstance(expr.expr, nodes.Name) and self._IsReceiverName(expr.expr):
            cls: Optional[nodes.ClassDef] = self._EnclosingClass(expr)
            if cls is None:
                return None
            for assign in cls.instance_attrs.get(expr.attrname, []):
                if isinstance(assign, nodes.AssignAttr) and isinstance(assign.parent, (nodes.Assign, nodes.AnnAssign)):
                    values.append(assign.parent.value)
        classes: Set[nodes.ClassDef] = set()
        for value in values:
            if not isinstance(value, nodes.Call):
                return None
            target = self._ResolveExpr(value.func, file, 0)
            if not isinstance(target, nodes.ClassDef):
                return None
            classes.add(target)
        return classes.pop() if len(classes) == 1 else None

    def _Constructor(self, cls: nodes.ClassDef, depth: int) -> Optional[Callee]:
        init = self._Method(cls, "__init__", depth)
        return Callee(init, f"{cls.name}", bind_first=True, constructor=True) if init is not None else None

    def _ResolveExpr(self, expr: nodes.NodeNG, file: str, depth: int):
        if isinstance(expr, nodes.Name):
            return self._ResolveName(expr, file, depth)
        if isinstance(expr, nodes.Attribute):
            owner = self._ResolveExpr(expr.expr, file, depth)
            if isinstance(owner, nodes.Module):
                return self._Member(owner.name, expr.attrname, depth)
        return None

    def _ResolveName(self, name: nodes.Name, file: str, depth: int):
        try:
            _, stmts = name.lookup(name.name)
        except Exception:
            return None
        if not stmts:
            return None
        stmt: nodes.NodeNG = stmts[-1]
        if isinstance(stmt, (nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.ClassDef)):
            return stmt
        if isinstance(stmt, nodes.ImportFrom):
            return self._FromImport(stmt, name.name, file, depth)
        if isinstance(stmt, nodes.Import):
            for imported, asname in stmt.names:
                if asname == name.name:
                    return self._index.Load(imported)
                if asname is None and imported.split(".")[0] == name.name:
                    return self._index.Load(name.name)
        return None

    def _FromImport(self, stmt: nodes.ImportFrom, local: str, file: str, depth: int):
        base: Optional[str] = self._index.Absolute(stmt.modname, stmt.level or 0, file)
        if base is None:
            return None
        for imported, asname in stmt.names:
            if (asname or imported) == local:
                return self._Member(base, imported, depth)
        return None

    def _Member(self, module_name: str, attr: str, depth: int):
        '''Top-level def/class `attr` of a project module (following re-exports), or submodule.'''
        if depth > MAX_RESOLVE_DEPTH:
            return None
        module: Optional[nodes.Module] = self._index.Load(module_name)
        if module is not None:
            for stmt in reversed(module.locals.get(attr, [])):
                if isinstance(stmt, (nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.ClassDef)) and stmt.parent is module:
                    return stmt
                owner = stmt.statement() if hasattr(stmt, "statement") else stmt
                if isinstance(owner, nodes.ImportFrom):
                    return self._FromImport(owner, attr, self._index.FileOf(module), depth + 1)
                if isinstance(owner, nodes.Import):
                    break
        sub: Optional[nodes.Module] = self._index.Load(f"{module_name}.{attr}")
        return sub

    def _Method(self, cls: nodes.ClassDef, attr: str, depth: int):
        if depth > MAX_RESOLVE_DEPTH:
            return None
        for stmt in cls.body:
            if isinstance(stmt, (nodes.FunctionDef, nodes.AsyncFunctionDef)) and stmt.name == attr:
                if _IsProperty(stmt):
                    return None
                return stmt
        for base in self._Bases(cls, depth):
            method = self._Method(base, attr, depth + 1)
            if method is not None:
                return method
        return None

    def _Bases(self, cls: nodes.ClassDef, depth: int) -> List[nodes.ClassDef]:
        file: str = self._index.FileOf(cls.root())
        bases: List[nodes.ClassDef] = []
        for expr in cls.bases:
            target = self._ResolveExpr(expr, file, depth + 1)
            if isinstance(target, nodes.ClassDef) and target is not cls:
                bases.append(target)
        return bases

    def _EnclosingClass(self, node: nodes.NodeNG) -> Optional[nodes.ClassDef]:
        frame = node.frame()
        while frame is not None and not isinstance(frame, nodes.Module):
            if isinstance(frame, (nodes.FunctionDef, nodes.AsyncFunctionDef)) and isinstance(frame.parent, nodes.ClassDef):
                return frame.parent
            frame = frame.parent.frame() if frame.parent is not None else None
        return None

    def _IsReceiverName(self, name: nodes.Name) -> bool:
        '''True for the first parameter of the enclosing method (self, cls or whatever it is called).'''
        frame = name.frame()
        while isinstance(frame, (nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.Lambda)):
            if isinstance(frame, (nodes.FunctionDef, nodes.AsyncFunctionDef)) and isinstance(frame.parent, nodes.ClassDef):
                params = list(frame.args.posonlyargs or []) + list(frame.args.args or [])
                return bool(params) and params[0].name == name.name and not _IsStatic(frame)
            frame = frame.parent.frame() if frame.parent is not None else None
        return False

# vvv Helpers vvv
def _Decorators(func: nodes.FunctionDef) -> List[str]:
    names: List[str] = []
    for dec in (func.decorators.nodes if func.decorators else []):
        target = dec.func if isinstance(dec, nodes.Call) else dec
        if isinstance(target, nodes.Name):        names.append(target.name)
        elif isinstance(target, nodes.Attribute): names.append(target.attrname)
    return names

def _IsStatic(func: nodes.FunctionDef) -> bool:
    return "staticmethod" in _Decorators(func)

def _IsClassMethod(func: nodes.FunctionDef) -> bool:
    return "classmethod" in _Decorators(func)

def _IsProperty(func: nodes.FunctionDef) -> bool:
    return any(d in ("property", "cached_property", "setter") for d in _Decorators(func))

def _Signature(av: AbstractValue) -> object:
    '''What a summary depends on in an argument: its types and properties, and those of its tracked fields.'''
    if not av.fields:
        return (av.property_set, av.type_set)
    return (av.property_set, av.type_set, tuple((name, _Signature(f)) for name, f in av.fields))

def _Mark(av: AbstractValue, i: int, line: int) -> AbstractValue:
    '''Parameter i's value inside the callee: its state, with origin replaced by the marker (fields too).'''
    return AbstractValue(type_set=av.type_set, property_set=av.property_set,
                         origin_set=frozenset({f"{MARKER}{i}"}), source_line=line,
                         fields=tuple((name, _Mark(f, i, line)) for name, f in av.fields))

def _AllOrigins(av: AbstractValue) -> FrozenSet[str]:
    origins: FrozenSet[str] = av.origin_set
    for _, f in av.fields:
        origins = origins | _AllOrigins(f)
    return origins

def _Rewrite(av: AbstractValue, actuals: List[AbstractValue], line: int) -> AbstractValue:
    '''Replace parameter markers with the actual arguments' origins.'''
    fields = tuple((name, _Rewrite(f, actuals, line)) for name, f in av.fields) if av.fields else ()
    markers: List[str] = [o for o in av.origin_set if o.startswith(MARKER)]
    if not markers:
        return replace(av, fields=fields) if fields != av.fields else av
    origins: FrozenSet[str] = av.origin_set - frozenset(markers)
    for m in markers:
        i: int = int(m[len(MARKER):])
        if i < len(actuals):
            origins = origins | _AllOrigins(actuals[i])
    return AbstractValue(type_set=av.type_set, property_set=av.property_set,
                         origin_set=origins | frozenset({INTERPROCEDURAL}), source_line=line or av.source_line,
                         fields=fields)
