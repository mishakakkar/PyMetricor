'''
Per the schema spec: "Engine does NOT know what is dangerous. Queries define policy."

Each QueryDef from the schema is evaluated against each CapabilityRecord.
If all conditions match → a Finding is emitted.

Semantics of argument_has + argument_lacks:
  When both are present, they are evaluated on the SAME argument:
    "find an argument that has ALL of argument_has AND lacks ALL of argument_lacks"
  This prevents false positives where a mode/flag argument (like "w" in open())
  satisfies argument_lacks while the real tainted argument (path) has DYNAMIC.
'''

# My Stuff
from .loader import QueryDef, QueryCondition, SchemaBundle
from .state  import CapabilityRecord

# Python Stuff
from dataclasses import dataclass
from typing      import Dict, List, Optional

# vvv Constants vvv
SEVERITY_RANK: Dict[str, int] = {
    "info":     0,
    "low":      1,
    "medium":   2,
    "high":     3,
    "critical": 4,
}

# Human-readable descriptions keyed by query name
# Strips "embedded_code:" prefix before lookup for nested findings
_QUERY_DESCRIPTIONS: Dict[str, str] = {
    "dynamic_execution_external":  (
        "User-controlled input is passed directly to exec/eval. "
        "An attacker can supply arbitrary Python code for immediate execution."
    ),
    "dynamic_execution_decoded":   (
        "Decoded or obfuscated bytes are passed to exec/eval. "
        "This is a common encoding-bypass technique to smuggle executable code."
    ),
    "dynamic_execution_unknown":   (
        "A dynamically-constructed string is passed to exec/eval. "
        "The source of the string cannot be statically verified as safe."
    ),
    "dynamic_execution_constant":  (
        "A string literal is passed to exec/eval. "
        "The literal may itself contain dangerous patterns or embedded calls to input/exec."
    ),
    "filesystem_external_input":   (
        "User-controlled input is used as a filesystem path. "
        "An attacker can perform path traversal (e.g. ../../etc/passwd) or access arbitrary files."
    ),
    "filesystem_dynamic_path":     (
        "A dynamically-constructed path is used in a filesystem operation. "
        "The path cannot be statically verified as pointing to a safe location."
    ),
    "spawn_external_command":      (
        "User-controlled input is passed directly to a subprocess or shell command. "
        "An attacker can inject shell metacharacters to execute arbitrary OS commands."
    ),
    "spawn_dynamic_command":       (
        "A dynamically-constructed command string is passed to a subprocess. "
        "The command cannot be statically verified as safe against injection."
    ),
    "reflective_chain":            (
        "A dynamic value is used in a reflective operation (getattr / __import__). "
        "An attacker may be able to access or invoke arbitrary attributes or modules."
    ),
    "reflective_external":         (
        "User-controlled input is used in a reflective operation. "
        "External data is directly controlling which attributes or modules are accessed."
    ),
    "weak_hash_used":              (
        "A broken hash function (MD5/SHA-1) is used. "
        "It is unsuitable for passwords, signatures or integrity checks."
    ),
    "crypto_external_data":        (
        "User-controlled input is passed to a cryptographic function. "
        "The integrity and authenticity of the data cannot be guaranteed."
    ),
}

# vvv Finding vvv
@dataclass
class Finding:
    '''
    A single security finding produced when a query fires.

    query_name  : the query that matched (e.g. "dynamic_execution_external")
    severity    : from the query definition
    capability  : the capability that was used (e.g. "INVOKE_DYNAMIC")
    call_name   : actual function name in source (e.g. "eval")
    line        : source line number
    evidence    : machine-readable list of why this fired
    '''
    query_name: str
    severity:   str
    capability: str
    call_name:  str
    line:       int
    evidence:   List[str]

    @property
    def rank(self) -> int:
        return SEVERITY_RANK.get(self.severity, 0)

    @property
    def description(self) -> str:
        base: str = self.query_name.split(":")[-1] if ":" in self.query_name else self.query_name
        return _QUERY_DESCRIPTIONS.get(base, "Flagged by security policy query.")

    def __str__(self) -> str:
        label:    str = self.severity.upper()
        evidence: str = " | ".join(self.evidence) if self.evidence else "no additional evidence"
        return "\n".join([
            f"[{label}] Line {self.line:>4} — {self.query_name}",
            f"  Function    : {self.call_name}",
            f"  Capability  : {self.capability}",
            f"  Reason      : {self.description}",
            f"  Evidence    : {evidence}",
        ])

# vvv Query Evaluation vvv
def EvaluateQuery(query: QueryDef, record: CapabilityRecord) -> Optional[Finding]:
    '''
    Evaluate one query against one capability record.
    Returns a Finding if all conditions are satisfied, else None.
    '''
    cond:     QueryCondition = query.condition
    evidence: List[str]      = []

    # Capability must match
    if cond.capability and record.capability_used != cond.capability:
        return None

    # argument_has + argument_lacks are co-evaluated on the SAME argument
    # Prevents a flag arg (e.g. "w" mode in open()) from satisfying the lacks-
    # -condition while the real tainted arg (path) satisfies the has condition
    if cond.argument_has and cond.argument_lacks:
        matched: bool = any(
            av.has_all_props(cond.argument_has) and av.lacks_all(cond.argument_lacks)
            for av in record.argument_state
        )
        if not matched:
            return None
        evidence.append(
            f"arg has {{{', '.join(cond.argument_has)}}} "
            f"and lacks {{{', '.join(cond.argument_lacks)}}}"
        )

    elif cond.argument_has:
        if not any(av.has_all_props(cond.argument_has) for av in record.argument_state):
            return None
        evidence.append(f"arg has {{{', '.join(cond.argument_has)}}}")

    elif cond.argument_lacks:
        if not record.argument_lacks(cond.argument_lacks):
            return None
        evidence.append(f"arg lacks {{{', '.join(cond.argument_lacks)}}}")

    if cond.origin_has:
        if not any(av.origin_set & frozenset(cond.origin_has) for av in record.argument_state):
            return None
        evidence.append(f"origin has {{{', '.join(cond.origin_has)}}}")

    if cond.type_is:
        if not any(av.type_set & frozenset(cond.type_is) for av in record.argument_state):
            return None
        evidence.append(f"type is {{{', '.join(cond.type_is)}}}")

    return Finding(
        query_name = query.name,
        severity   = query.severity,
        capability = record.capability_used,
        call_name  = record.call_name,
        line       = record.line,
        evidence   = evidence,
    )


def EvaluateAll(records: List[CapabilityRecord], schema: SchemaBundle) -> List[Finding]:
    '''
    Run every query against every capability record.
    Returns all fired findings sorted by line number, then severity descending.
    '''
    findings: List[Finding] = []
    for record in records:
        for query in schema.queries:
            finding: Optional[Finding] = EvaluateQuery(query, record)
            if finding is not None:
                findings.append(finding)

    findings.sort(key=lambda f: (f.line, -f.rank))
    return findings