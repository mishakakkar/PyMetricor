'''
Schema-driven transfer functions.

Every rule reads from the SchemaBundle, no hardcoded domain knowledge.
The only hardcoded knowledge is the astroid node dispatch; external sources
(attributes such as sys.argv) come from the schema's `sources` section.
'''

# My stuff
from .loader import SchemaBundle
from .state  import AbstractValue, Environment, make_unknown, make_bottom

# Python stuff
from dataclasses import replace
from astroid import nodes                             # type: ignore
from typing  import Any, Callable, Dict, FrozenSet, List, Optional, Tuple
import fnmatch

# Lets the interpreter supply the value of a call it can resolve (a function summary)
CallHook = Callable[[nodes.Call, Environment], Optional[AbstractValue]]

# vvv Constants vvv
# astroid BinOp.op string → schema operator name
_BINOP_TO_SCHEMA: Dict[str, str] = {
    "+":  "Add",
    "-":  "Sub",
    "*":  "Mult",
    "%":  "Mod",
    "//": "FloorDiv",
    "/":  "Div",
}

# astroid Compare.ops string → schema operator name
COMPAREOP_TO_SCHEMA: Dict[str, str] = {
    "==":     "Eq",
    "!=":     "NotEq",
    "in":     "In",
    "not in": "NotIn",
}

# vvv Expression Transfer vvv
def TransferExpr(node: nodes.NodeNG, env: Environment, schema: SchemaBundle, call_hook: Optional[CallHook] = None) -> AbstractValue:
    '''
    Compute the AbstractValue produced by an astroid expression node.
    All unrecognised constructs → DYNAMIC (conservative).
    '''
    line: int = node.lineno or 0
    lat       = schema.lattice

    # Literals
    if isinstance(node, nodes.Const):
        v: Any = node.value
        props: FrozenSet[str] = frozenset({"CONSTANT"})

        if isinstance(v, str):                  props = lat.add(props, "TEXTUAL")
        elif isinstance(v, (int, float)):       props = lat.add(props, "NUMERIC")
        elif isinstance(v, (bytes, bytearray)): props = lat.add(props, "BYTES_LIKE")

        return AbstractValue(
            type_set     = frozenset({type(v).__name__}),
            property_set = props,
            origin_set   = frozenset({"literal"}),
            source_line  = line,
        )

    # Variable reference
    if isinstance(node, nodes.Name):
        return env.get(node.name)

    # Attribute  a.b
    if isinstance(node, nodes.Attribute):
        obj: AbstractValue = TransferExpr(node.expr, env, schema, call_hook)
        # An attribute assigned on this path (self.cmd = ..., or set by the constructor)
        tracked: Optional[AbstractValue] = obj.field(node.attrname)
        if tracked is not None:
            return tracked
        props: FrozenSet[str] = obj.property_set
        types: FrozenSet[str] = _KeptCarriers(obj.type_set, schema, attribute=node.attrname)

        if node.attrname in schema.sources.attributes:
            props = lat.add(props, "EXTERNAL_ORIGIN", "DYNAMIC", "TEXTUAL")
            # request.args of an imported `request` is data, not a namespace like os.path:
            # request.args.get(k) must keep the receiver's taint
            types = types - frozenset({"module"})

        return AbstractValue(
            type_set     = types,
            property_set = props,
            origin_set   = obj.origin_set,
            source_line  = line,
        )

    # Subscript  x[i]
    if isinstance(node, nodes.Subscript):
        return TransferExpr(node.value, env, schema, call_hook).without_fields().with_props("DYNAMIC")

    # f-string
    if isinstance(node, nodes.JoinedStr):
        combined: FrozenSet[str] = frozenset({"TEXTUAL"})
        origins:  FrozenSet[str] = frozenset()

        for part in node.values:
            if isinstance(part, nodes.FormattedValue):
                sub: AbstractValue = TransferExpr(part.value, env, schema, call_hook)
                combined = lat.join(combined, sub.property_set)
                origins  = origins | sub.origin_set

        if lat.has(combined, "EXTERNAL_ORIGIN") or lat.has(combined, "DYNAMIC"):
            combined = lat.add(combined, "DYNAMIC", "TEXTUAL")

        return AbstractValue(
            type_set     = frozenset({"str"}),
            property_set = combined,
            origin_set   = origins,
            source_line  = line,
        )

    # Binary operation
    # astroid BinOp.op is a string ("+", "-", "*", "%"...) not an ast node
    if isinstance(node, nodes.BinOp):
        schema_op: Optional[str]  = _BINOP_TO_SCHEMA.get(node.op)
        left:      AbstractValue  = TransferExpr(node.left,  env, schema, call_hook)
        right:     AbstractValue  = TransferExpr(node.right, env, schema, call_hook)
        op_def                    = schema.operators.get(schema_op) if schema_op else None

        if op_def and op_def.propagate:
            merged_props:   FrozenSet[str] = lat.join(left.property_set, right.property_set)
            merged_origins: FrozenSet[str] = left.origin_set | right.origin_set

            # If either direct operand is a Name (variable), the result is not statically
            # constant — it went through variable indirection. Also strip CONSTANT if
            # DYNAMIC is already present, handling nested BinOps like a + b + "c".
            #   "a" + "b"        ->  CONSTANT  (both raw literals)
            #   x   + "b"        ->  DYNAMIC   (x is a variable)
            #   (x + "b") + "c"  ->  DYNAMIC   (DYNAMIC propagated from inner)
            # A variable holding a validated or quoted value (SANITIZED) does not count:
            #   q = shlex.quote(x); "ls " + q   ->  not DYNAMIC
            has_name_operand: bool = (
                (isinstance(node.left,  nodes.Name) and not lat.has(left.property_set,  "SANITIZED")) or
                (isinstance(node.right, nodes.Name) and not lat.has(right.property_set, "SANITIZED"))
            )
            if has_name_operand or lat.has(merged_props, "DYNAMIC"):
                merged_props = lat.remove(merged_props, "CONSTANT")
                merged_props = lat.add(merged_props, "DYNAMIC")

            return AbstractValue(
                type_set     = left.type_set | right.type_set,
                property_set = merged_props,
                origin_set   = merged_origins,
                source_line  = line,
            )

        return make_unknown(line)

    # Boolean operation
    if isinstance(node, nodes.BoolOp):
        result: AbstractValue = make_bottom(line)
        for val in node.values:
            result = result.join(TransferExpr(val, env, schema, call_hook))

        return result

    # Unary
    if isinstance(node, nodes.UnaryOp):
        return TransferExpr(node.operand, env, schema, call_hook)

    # Ternary  a if cond else b
    if isinstance(node, nodes.IfExp):
        return TransferExpr(node.body,   env, schema, call_hook).join(
               TransferExpr(node.orelse, env, schema, call_hook))

    # Call
    if isinstance(node, nodes.Call):
        return TransferCallExpr(node, env, schema, call_hook)

    # Collection literals
    if isinstance(node, (nodes.List, nodes.Tuple, nodes.Set)):
        result = make_bottom(line)
        for elt in node.elts:
            result = result.join(TransferExpr(elt, env, schema, call_hook)) # type: ignore

        return result.with_types("list")

    if isinstance(node, nodes.Dict):
        result = make_bottom(line)
        for k, v in node.items:
            if k:
                result = result.join(TransferExpr(k, env, schema, call_hook)) # type: ignore
            result = result.join(TransferExpr(v, env, schema, call_hook))

        return result.with_types("dict")

    # Comprehensions
    if isinstance(node, (nodes.ListComp, nodes.SetComp, nodes.GeneratorExp)):
        result = make_bottom(line)
        for gen in node.generators:
            result = result.join(TransferExpr(gen.iter, env, schema, call_hook))

        return result.with_props("DYNAMIC")

    if isinstance(node, nodes.DictComp):
        return make_unknown(line).with_types("dict")

    # Lambda
    if isinstance(node, nodes.Lambda):
        return AbstractValue(
            type_set     = frozenset({"callable"}),
            property_set = frozenset({"CONSTANT"}),
            source_line  = line,
        )

    # Await
    if isinstance(node, nodes.Await):
        return TransferExpr(node.value, env, schema, call_hook).without_fields().with_props("DYNAMIC")

    return make_unknown(line)

# vvv Call Transfer  (Schema-Driven) vvv
def TransferCallExpr(node: nodes.Call, env: Environment, schema: SchemaBundle, call_hook: Optional[CallHook] = None) -> AbstractValue:
    '''Apply the schema function spec to a Call node and return the abstract result value.'''
    if call_hook is not None:
        hooked: Optional[AbstractValue] = call_hook(node, env)
        if hooked is not None:
            return ApplyValidator(node, env, schema, hooked)

    line: int = node.lineno or 0
    lat       = schema.lattice

    # For method calls (obj.method()), include the receiver as an implicit
    # first argument so EXTERNAL_ORIGIN propagates through chains.
    # Module receivers (os.path.join) are namespaces, not data: skip them so
    # their CONSTANT does not mask a dynamic argument.
    arg_vals: List[AbstractValue] = []
    receiver: Optional[AbstractValue] = None
    if isinstance(node.func, nodes.Attribute):
        receiver = TransferExpr(node.func.expr, env, schema, call_hook)
        if receiver.type_set != frozenset({"module"}):
            arg_vals.append(receiver)

    for arg in node.args:
        arg_vals.append(TransferExpr(arg, env, schema, call_hook))

    for kw in node.keywords:
        if kw.value:
            arg_vals.append(TransferExpr(kw.value, env, schema, call_hook))

    spec = LookupCall(node, env, schema, receiver)
    ret  = spec.returns

    props:   FrozenSet[str] = frozenset()
    types:   FrozenSet[str] = frozenset({ret.type}) if ret.type else frozenset()
    origins: FrozenSet[str] = frozenset()

    if ret.propagate_args:
        for av in arg_vals:
            props   = lat.join(props, av.property_set)
            origins = origins | av.origin_set
            types   = types   | av.type_set

    for p in ret.adds:    props = lat.add(props, p)
    for p in ret.removes: props = lat.remove(props, p)

    if ret.dynamic_if_unknown:
        if not arg_vals or not all(lat.has(av.property_set, "CONSTANT") for av in arg_vals):
            props = lat.add(props, "DYNAMIC")

    # As for BinOp: a value computed from a dynamic argument (os.path.join(BASE, name),
    # "{}".format(x), a helper's result) is not a constant, even if other arguments were
    if ret.propagate_args and lat.has(props, "DYNAMIC"):
        props = lat.remove(props, "CONSTANT")

    # A carrier type (a pathlib path) is not inherited from the arguments: str(p) or
    # helper(p) is not a path, p.resolve() is
    method: Optional[str] = node.func.attrname if isinstance(node.func, nodes.Attribute) else None
    kept: FrozenSet[str]  = _KeptCarriers(receiver.type_set, schema, method=method) if receiver is not None else frozenset()
    types = (types - frozenset(schema.carriers or ())) | kept | (frozenset({ret.type}) if ret.type else frozenset())

    return ApplyValidator(node, env, schema, AbstractValue(
        type_set     = types,
        property_set = props,
        origin_set   = origins,
        source_line  = line,
    ))

def _KeptCarriers(types: FrozenSet[str], schema: SchemaBundle, method: Optional[str] = None, attribute: Optional[str] = None) -> FrozenSet[str]:
    '''The types of `types` kept by obj.method(...) or obj.attribute: non-carriers, and carriers that preserve it.'''
    carriers = schema.carriers or {}
    return frozenset(
        t for t in types
        if (t not in carriers and attribute is not None)
        or (t in carriers and (method in carriers[t].preserved_by or attribute in carriers[t].attributes))
    )

def LookupCall(node: nodes.Call, env: Environment, schema: SchemaBundle, receiver: Optional[AbstractValue] = None):
    '''
    The schema spec for a call: by its (alias-resolved) name, or for obj.m(...) not
    known by name, the method spec for m when obj has one of its receiver types
    (p.read_text() with p a pathlib path).
    '''
    spec = schema.functions.lookup(ResolveCallName(node.func, env))
    if spec.name == "*" and receiver is not None and isinstance(node.func, nodes.Attribute):
        method = schema.functions.method(node.func.attrname, receiver.type_set)
        if method is not None:
            return method
    return spec

def IsSafeCall(node: nodes.Call, spec) -> bool:
    '''True when the call passes one of the spec's safe arguments: yaml.load(f, Loader=SafeLoader).'''
    for safe in spec.safe_args or []:
        value: Optional[nodes.NodeNG] = next((kw.value for kw in node.keywords if kw.arg == safe.keyword), None)
        if value is None and safe.position is not None and len(node.args) > safe.position:
            value = node.args[safe.position]
        if value is None:
            continue
        name: str = ExtractCallName(value).rsplit(".", 1)[-1]
        if isinstance(value, nodes.Const):
            name = str(value.value)
        if any(pat == "*" or fnmatch.fnmatchcase(name, pat) for pat in safe.values):
            return True
    return False

def MatchingValidator(node: nodes.Call, env: Environment, schema: SchemaBundle):
    '''The schema validator a call matches (validate_path(p), sanitize_name(n) ...), or None.'''
    if not schema.validators:
        return None
    short: str = (node.func.attrname if isinstance(node.func, nodes.Attribute)
                  else node.func.name if isinstance(node.func, nodes.Name) else "").lstrip("_")
    validator = _ValidatorFor(short, schema)
    if validator is None or schema.functions.lookup(ResolveCallName(node.func, env)).name != "*":
        return None
    return validator

_VALIDATOR_CACHE: Dict[Tuple[int, str], Any] = {}

def _ValidatorFor(short: str, schema: SchemaBundle):
    '''The validator whose patterns match a call's short name (memoised: called for every call).'''
    key = (id(schema), short)
    if key not in _VALIDATOR_CACHE:
        _VALIDATOR_CACHE[key] = next(
            (v for v in schema.validators if any(fnmatch.fnmatchcase(short, pat) for pat in v.patterns)), None)
    return _VALIDATOR_CACHE[key]

def ApplyValidator(node: nodes.Call, env: Environment, schema: SchemaBundle, value: AbstractValue) -> AbstractValue:
    '''A validator's result is the checked (or cleaned) value: apply the validator's effect to it.'''
    validator = MatchingValidator(node, env, schema)
    if validator is None:
        return value
    props: FrozenSet[str] = value.property_set
    for p in validator.effect.remove: props = schema.lattice.remove(props, p)
    for p in validator.effect.add:    props = schema.lattice.add(props, p)
    return AbstractValue(type_set=value.type_set, property_set=props, origin_set=value.origin_set, source_line=value.source_line)

# vvv Refinement Application vvv
def ApplyRefinement(
    refinement_name: str,
    var_name:        str,
    env:             Environment,
    schema:          SchemaBundle,
    container_node:  Optional[nodes.NodeNG] = None,
) -> Environment:
    '''Apply a refinement rule to a named variable. Returns a narrowed environment.'''
    ref_def = schema.refinements.get(refinement_name)
    if not ref_def:
        return env

    lat                     = schema.lattice
    current: AbstractValue  = env.get(var_name)
    props:   FrozenSet[str] = current.property_set

    if ref_def.pattern == "finite_set" and container_node is not None:
        if not _IsFiniteConstantCollection(container_node):
            return env

    for p in ref_def.effect.remove: props = lat.remove(props, p)
    for p in ref_def.effect.add:    props = lat.add(props, p)

    refined: Environment = env.copy()
    refined.set(var_name, replace(current, property_set=props))
    return refined

def _IsFiniteConstantCollection(node: nodes.NodeNG) -> bool:
    return (
        isinstance(node, (nodes.Set, nodes.List, nodes.Tuple))
        and all(isinstance(e, nodes.Const) for e in node.elts)
    )

# vvv Helpers vvv
def ExtractCallName(node: nodes.NodeNG) -> str:
    '''Best-effort qualified name from Call.func (astroid).'''
    if isinstance(node, nodes.Name):      return node.name
    if isinstance(node, nodes.Attribute): return f"{ExtractCallName(node.expr)}.{node.attrname}"
    return "<unknown>"

def ResolveCallName(node: nodes.NodeNG, env: Environment) -> str:
    '''ExtractCallName with import aliases expanded (sp.run -> subprocess.run).'''
    name: str = ExtractCallName(node)
    head, dot, rest = name.partition(".")
    target: Optional[str] = env.aliases.get(head)
    return f"{target}{dot}{rest}" if target else name

def TryConcatStrings(node: nodes.BinOp) -> Optional[str]:
    '''
    If node is a chain of all-constant string concatenations, return the
    concatenated result. Otherwise None.
    '''
    def _collect(n: nodes.NodeNG) -> Optional[str]:
        if isinstance(n, nodes.Const) and isinstance(n.value, str):
            return n.value

        if isinstance(n, nodes.BinOp) and n.op == "+":
            left: Optional[str]  = _collect(n.left)
            right: Optional[str] = _collect(n.right)

            if left is not None and right is not None:
                return left + right

        return None

    return _collect(node)