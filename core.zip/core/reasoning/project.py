'''
Project index: which module names the analysed files define, and where.

The security engine uses it to follow a call into a function defined in another
file of the project (function summaries, see summaries.py). The module dependency
metric uses it to build the import graph.

Module names follow the package layout: a file's name is its path relative to the
first parent directory that has no __init__.py, so pkg/sub/mod.py with
pkg/__init__.py and pkg/sub/__init__.py is "pkg.sub.mod". Because projects often
put code in namespace packages or under src/, a name that does not resolve
exactly falls back to the unique file whose dotted path ends with it.
'''

# Python stuff
from astroid     import nodes, parse  # type: ignore
from collections import OrderedDict
from os          import path as os_path, walk as os_walk
from typing      import Dict, Iterable, List, Optional, Set

# vvv Constants vvv
MAX_CACHED_MODULES: int = 256

# vvv Main Stuff vvv
class ProjectIndex:
    '''Maps dotted module names to files and parses project modules on demand.'''

    __slots__ = ("_by_name", "_by_suffix", "_name_of", "_cache", "_file_of")

    def __init__(self, files: Iterable[str]) -> None:
        self._by_name:   Dict[str, str]                   = {}
        self._by_suffix: Dict[str, Set[str]]              = {}
        self._name_of:   Dict[str, str]                   = {}
        self._cache:     "OrderedDict[str, nodes.Module]" = OrderedDict()
        self._file_of:   Dict[int, str]                   = {}

        for file in files:
            self._Register(os_path.abspath(file))

    @classmethod
    def FromPaths(cls, paths: Iterable[str]) -> "ProjectIndex":
        '''Index every .py file (including __init__.py) under the given files and directories.'''
        files: List[str] = []
        for p in paths:
            if os_path.isfile(p) and p.endswith(".py"):
                files.append(p)
            elif os_path.isdir(p):
                for root, _, names in os_walk(p):
                    files.extend(os_path.join(root, n) for n in names if n.endswith(".py"))
        return cls(files)

    # vvv Lookup vvv
    def ModuleName(self, file: str) -> Optional[str]:
        return self._name_of.get(os_path.abspath(file))

    def FileOf(self, module: nodes.Module) -> str:
        '''Path of a parsed module, also for the file under analysis (parsed without a path).'''
        return self._file_of.get(id(module)) or (module.file if module.file and module.file != "<?>" else "")

    def Files(self) -> List[str]:
        return list(self._name_of)

    def FileFor(self, module_name: str) -> Optional[str]:
        '''File defining module_name, or None if it is not part of the project.'''
        if module_name in self._by_name:
            return self._by_name[module_name]
        candidates: Set[str] = self._by_suffix.get(module_name, set())
        return next(iter(candidates)) if len(candidates) == 1 else None

    def IsPackage(self, module_name: str) -> bool:
        file: Optional[str] = self.FileFor(module_name)
        return file is not None and os_path.basename(file) == "__init__.py"

    def Absolute(self, module_name: str, level: int, from_file: str) -> Optional[str]:
        '''Absolute name for `from <level dots><module_name> import ...` written in from_file.'''
        if not level:
            return module_name
        current: Optional[str] = self.ModuleName(from_file)
        if current is None:
            return None
        parts: List[str] = current.split(".")
        # A package's __init__ counts as level 1 of itself; a module's level 1 is its package
        if os_path.basename(from_file) != "__init__.py":
            parts = parts[:-1]
        if level > 1:
            if level - 1 > len(parts):
                return None
            parts = parts[:len(parts) - (level - 1)]
        base: str = ".".join(parts)
        return f"{base}.{module_name}".strip(".") if module_name else base or None

    def Load(self, module_name: str) -> Optional[nodes.Module]:
        '''Parse (and cache) a project module. None if not in the project or unparsable.'''
        file: Optional[str] = self.FileFor(module_name)
        if file is None:
            return None
        if file in self._cache:
            self._cache.move_to_end(file)
            return self._cache[file]
        try:
            with open(file, "r", encoding="utf-8", errors="replace") as fh:
                # Parsed without a module name, like the file under analysis: given one, astroid
                # resolves the module's relative imports while building it, against whatever
                # installed package has that name, which can take minutes (pytest's own source).
                module: nodes.Module = parse(fh.read(), path=file)
        except Exception:
            return None
        module.name = module_name
        self.Adopt(file, module)
        return module

    def Adopt(self, file: str, module: nodes.Module) -> None:
        '''Use an already-parsed module (the file under analysis) instead of parsing it again.'''
        file = os_path.abspath(file)
        old: Optional[nodes.Module] = self._cache.get(file)
        if old is not None:
            self._file_of.pop(id(old), None)
        self._cache[file] = module
        self._file_of[id(module)] = file
        self._cache.move_to_end(file)
        while len(self._cache) > MAX_CACHED_MODULES:
            _, evicted = self._cache.popitem(last=False)
            self._file_of.pop(id(evicted), None)

    # vvv Internals vvv
    def _Register(self, file: str) -> None:
        directory, base = os_path.split(file)
        parts: List[str] = [] if base == "__init__.py" else [base[:-3]]
        while os_path.isfile(os_path.join(directory, "__init__.py")):
            directory, package = os_path.split(directory)
            parts.insert(0, package)
            if not package:
                break
        name: str = ".".join(parts)
        if not name or not all(p.isidentifier() for p in parts):
            return
        self._by_name.setdefault(name, file)
        self._name_of[file] = name

        # Suffix fallback for namespace packages and src/ layouts: a/b/c.py also answers to "b.c" and "c"
        dotted: List[str] = os_path.splitext(file)[0].split(os_path.sep)
        if dotted[-1] == "__init__":
            dotted = dotted[:-1]
        for k in range(1, min(len(dotted), 6) + 1):
            suffix: List[str] = dotted[-k:]
            if all(p.isidentifier() for p in suffix):
                self._by_suffix.setdefault(".".join(suffix), set()).add(file)
