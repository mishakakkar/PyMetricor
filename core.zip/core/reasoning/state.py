'''
Abstract state model.

Each variable:
  { type_set: set, property_set: set, origin_set: set }

Each call site:
  { capability_used, call_name, argument_state, line }
'''

# Python stuff
from dataclasses import dataclass, field, replace
from typing      import Dict, FrozenSet, List, Mapping, Optional, Tuple

# Field-sensitive values: an object's attributes are tracked to this depth (self.repo.path)
# and up to this many per object; deeper or further attributes fall back to the object's value
MAX_FIELD_DEPTH: int = 2
MAX_FIELDS:      int = 32

# vvv Abstract Value vvv
@dataclass(frozen=True)
class AbstractValue:
    '''
    Abstract representation of a single runtime value.

    type_set     : which abstract types this value could have
    property_set : current lattice element (set of property names)
    origin_set   : provenance strings for reporting
    source_line  : where this value was first introduced
    fields       : abstract values of the object's attributes (self.x, obj.x) that were
                   assigned on this path, as sorted (name, value) pairs
    '''
    type_set:     FrozenSet[str] = field(default_factory=frozenset)  # type: ignore
    property_set: FrozenSet[str] = field(default_factory=frozenset)  # type: ignore
    origin_set:   FrozenSet[str] = field(default_factory=frozenset)  # type: ignore
    source_line:  int            = 0
    fields:       Tuple[Tuple[str, "AbstractValue"], ...] = ()

    # vvv Lattice Operations vvv
    def join(self, other: "AbstractValue") -> "AbstractValue":
        '''Merge two abstract values at a control-flow join point.'''
        if other is self or other == self:
            return self
        return AbstractValue(
            type_set     = self.type_set     | other.type_set,
            property_set = self.property_set | other.property_set,
            origin_set   = self.origin_set   | other.origin_set,
            source_line  = (
                min(self.source_line, other.source_line)
                if self.source_line and other.source_line
                else self.source_line or other.source_line
            ),
            fields       = _JoinFields(self, other),
        )

    # vvv Fields vvv
    def field(self, name: str) -> Optional["AbstractValue"]:
        '''The tracked value of attribute `name`, or None when it is not tracked.'''
        for key, val in self.fields:
            if key == name:
                return val
        return None

    def attribute_fallback(self) -> "AbstractValue":
        '''What an untracked attribute of this object is taken to be: the object's own state.'''
        return AbstractValue(type_set=frozenset(), property_set=self.property_set,
                             origin_set=self.origin_set, source_line=self.source_line)

    def with_field(self, name: str, value: "AbstractValue") -> "AbstractValue":
        '''This object with attribute `name` bound to value (a strong update).'''
        return self.with_fields({name: value})

    def with_fields(self, updates: Mapping[str, "AbstractValue"]) -> "AbstractValue":
        merged: Dict[str, AbstractValue] = dict(self.fields)
        for name, value in updates.items():
            if name not in merged and len(merged) >= MAX_FIELDS:
                continue
            merged[name] = value
        return replace(self, fields=_Truncate(merged, MAX_FIELD_DEPTH))

    def without_fields(self) -> "AbstractValue":
        return replace(self, fields=()) if self.fields else self

    def with_props(self, *props: str) -> "AbstractValue":
        return replace(self, property_set=self.property_set | frozenset(props))

    def without_props(self, *props: str) -> "AbstractValue":
        return replace(self, property_set=self.property_set - frozenset(props))

    def with_types(self, *types: str) -> "AbstractValue":
        return replace(self, type_set=self.type_set | frozenset(types))

    # vvv Predicates vvv
    def has_prop(self, p: str) -> bool:
        return p in self.property_set

    def has_all_props(self, props: List[str]) -> bool:
        return all(p in self.property_set for p in props)

    def has_any_prop(self, props: List[str]) -> bool:
        return any(p in self.property_set for p in props)

    def lacks_all(self, props: List[str]) -> bool:
        return not self.has_any_prop(props)

    def __repr__(self) -> str:
        parts: List[str] = []
        if self.property_set: parts.append(f"props={{{', '.join(sorted(self.property_set))}}}")
        if self.type_set:     parts.append(f"types={{{', '.join(sorted(self.type_set))}}}")
        if self.origin_set:   parts.append(f"origins={{{', '.join(sorted(self.origin_set))}}}")
        if self.fields:       parts.append(f"fields={{{', '.join(f'{k}: {v!r}' for k, v in self.fields)}}}")
        parts.append(f"line={self.source_line}")
        return f"Value({', '.join(parts)})"

def _JoinFields(a: AbstractValue, b: AbstractValue) -> Tuple[Tuple[str, AbstractValue], ...]:
    '''
    Fields of a join. An attribute tracked on only one side is joined with what the other
    side would read for it (that object's own state), so a field set in one branch keeps
    the other branch's taint.
    '''
    if not a.fields and not b.fields:
        return ()
    if a.fields == b.fields:
        return a.fields
    mine: Dict[str, AbstractValue]   = dict(a.fields)
    theirs: Dict[str, AbstractValue] = dict(b.fields)
    merged: Dict[str, AbstractValue] = {}
    for name in mine.keys() | theirs.keys():
        x: Optional[AbstractValue] = mine.get(name)
        y: Optional[AbstractValue] = theirs.get(name)
        merged[name] = (x.join(y) if x is not None and y is not None
                        else x.join(b.attribute_fallback()) if x is not None
                        else y.join(a.attribute_fallback()))  # type: ignore[union-attr]
    return _Truncate(merged, MAX_FIELD_DEPTH)

def _Truncate(fields: Mapping[str, AbstractValue], depth: int) -> Tuple[Tuple[str, AbstractValue], ...]:
    '''Sorted field pairs, with nested fields kept only to depth.'''
    if depth <= 0:
        return ()
    out: List[Tuple[str, AbstractValue]] = []
    for name in sorted(fields):
        val: AbstractValue = fields[name]
        if val.fields:
            nested = _Truncate(dict(val.fields), depth - 1)
            if nested != val.fields:
                val = replace(val, fields=nested)
        out.append((name, val))
    return tuple(out)

# vvv Canonical Constructors vvv
def make_constant(type_name: str = "", line: int = 0) -> AbstractValue:
    types: FrozenSet[str] = frozenset({type_name}) if type_name else frozenset()
    return AbstractValue(
        type_set     = types,
        property_set = frozenset({"CONSTANT"}),
        origin_set   = frozenset({"literal"}),
        source_line  = line,
    )

def make_external(type_name: str = "str", line: int = 0) -> AbstractValue:
    return AbstractValue(
        type_set     = frozenset({type_name}),
        property_set = frozenset({"EXTERNAL_ORIGIN", "DYNAMIC", "TEXTUAL"}),
        origin_set   = frozenset({"external"}),
        source_line  = line,
    )

def make_unknown(line: int = 0) -> AbstractValue:
    return AbstractValue(
        type_set     = frozenset(),
        property_set = frozenset({"DYNAMIC"}),
        origin_set   = frozenset({"unknown"}),
        source_line  = line,
    )

def make_bottom(line: int = 0) -> AbstractValue:
    '''⊥ — no information at all.'''
    return AbstractValue(source_line=line)

# vvv Capability Record vvv
@dataclass
class CapabilityRecord:
    '''Records a single capability use at a call site.'''
    capability_used: str
    call_name:       str
    argument_state:  List[AbstractValue]
    line:            int

    def argument_lacks(self, props: List[str]) -> bool:
        '''True if NO argument carries ANY of the listed properties.'''
        return not any(av.has_any_prop(props) for av in self.argument_state)

# vvv Environment vvv
class Environment:
    '''
    Maps variable names → AbstractValue.
    join() returns a new merged Environment; set() mutates in-place for
    performance during the forward pass.

    aliases maps a local name to the qualified name it was imported as, e.g.
      import subprocess as sp      ->  sp     : subprocess
      from os import system        ->  system : os.system
    '''
    def __init__(
        self,
        bindings: Optional[Dict[str, AbstractValue]] = None,
        aliases:  Optional[Dict[str, str]]           = None,
    ) -> None:
        self._env:    Dict[str, AbstractValue] = dict(bindings or {})
        self.aliases: Dict[str, str]           = dict(aliases or {})

    def get(self, name: str) -> AbstractValue:
        '''Return value for name, or DYNAMIC if not bound.'''
        return self._env.get(name, _UNKNOWN)

    def set(self, name: str, value: AbstractValue) -> None:
        self._env[name] = value

    def join(self, other: "Environment") -> "Environment":
        '''Merge two environments at a control-flow join point.'''
        # Most bindings are shared by both branches (the same object): keep those as they are
        mine, theirs = self._env, other._env
        merged: Dict[str, AbstractValue] = {}
        for name in mine.keys() | theirs.keys():
            a: AbstractValue = mine.get(name, _UNKNOWN)
            b: AbstractValue = theirs.get(name, _UNKNOWN)
            merged[name] = a if a is b else a.join(b)
        return Environment(merged, {**other.aliases, **self.aliases})

    def copy(self) -> "Environment":
        return Environment(self._env, self.aliases)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Environment) and self._env == other._env and self.aliases == other.aliases

    def __repr__(self) -> str:
        lines = [f"  {k}: {v}" for k, v in sorted(self._env.items())]
        return "Environment{\n" + "\n".join(lines) + "\n}"

# The value of an unbound name (immutable, so one instance serves every lookup)
_UNKNOWN: AbstractValue = make_unknown()
