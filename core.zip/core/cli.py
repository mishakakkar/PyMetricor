# My stuff
from .context import FileContext, MetricExplanation, OffenderContext, ProjectContext

# Python stuff
from typing   import Any, Dict, List, Optional, Tuple
import os
import sys
import json

# vvv Constants vvv
_BOLD: str   = "\033[1m"
_DIM: str    = "\033[2m"
_RED: str    = "\033[91m"
_YELLOW: str = "\033[93m"
_GREEN: str  = "\033[92m"
_CYAN: str   = "\033[96m"
_WHITE: str  = "\033[97m"
_RESET: str  = "\033[0m"

_BAR_WIDTH: int = 26

_W: int         = 64
_RULE_FAT: str  = "━" * _W
_RULE_THIN: str = "─" * _W
_RULE_DOT: str  = "· " * (_W // 2)

# vvv Flags vvv
_use_color: bool = True

def SetColorEnabled(enabled: bool) -> None:
    global _use_color
    _use_color = enabled

def _C(code: str, text: str) -> str:
    return f"{code}{text}{_RESET}" if _use_color else text

def _ScoreColor(score: float) -> str:
    if score >= 75: return _GREEN
    if score >= 50: return _YELLOW
    return _RED

# vvv Score Rendering vvv
def _Bar(score: float, colored: bool = True) -> str:
    filled: int = round(max(0.0, min(100.0, score)) / 100 * _BAR_WIDTH)
    bar: str    = "█" * filled + "░" * (_BAR_WIDTH - filled)

    if colored and _use_color:
        return f"{_ScoreColor(score)}{bar}{_RESET}"

    return bar

def _Score(score: float, width: int = 5) -> str:
    s: str = f"{score:{width}.1f}"
    return _C(_ScoreColor(score), s) if _use_color else s

def _Warn(score: float) -> str:
    if score < 50:
        return _C(_RED + _BOLD, " ⚠")

    return ""

# vvv Layout vvv
def _Header(text: str) -> None:
    print(_C(_BOLD, _RULE_FAT))
    print(_C(_BOLD, f"  {text}"))
    print(_C(_BOLD, _RULE_FAT))

def _SectionRow(label: str, score: float, label_w: int = 17) -> str:
    return (
        f"  {_C(_WHITE, label.ljust(label_w))}"
        f"  {_Score(score)}"
        f"  {_Bar(score)}"
        f"{_Warn(score)}"
    )

def _MetricRow(label: str, score: float, note: str = "", label_w: int = 30) -> str:
    note_str: str = _C(_DIM, f"  ← {note}") if note else ""
    return (
        f"  {label.ljust(label_w)}"
        f"  {_Score(score)}"
        f"  {_Bar(score)}"
        f"{_Warn(score)}"
        f"{note_str}"
    )

def _PrintFileExplanations(fc: FileContext, n_worst: int = 3) -> None:
    """
    Print the worst N metric explanations for a single file.
    Only metrics that have an explanation are shown.
    Printed inline below the file's section scores when --explain is active.
    """
    _SEV_ORDER: Dict[str, int] = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    # Collect all metrics that have an explanation, sorted worst first
    candidates: List[Tuple[str, float, MetricExplanation]] = []
    for metric_name, score in fc.GetAllMetricScores():
        expl: Optional[MetricExplanation] = fc.GetMetricExplanation(metric_name)
        if expl is not None:
            candidates.append((metric_name, score, expl))

    if not candidates:
        print()
        return

    candidates.sort(key=lambda x: x[1])
    worst: List[Tuple[str, float, MetricExplanation]] = candidates[:n_worst]

    for metric_name, score, expl in worst:
        # Metric header
        print(f"    {_C(_DIM, _RULE_DOT)}")
        print(
            f"    {_C(_BOLD + _WHITE, metric_name.lower().ljust(24))}"
            f"  {_Score(score)}"
            f"  {_Bar(score)}"
            f"{_Warn(score)}"
        )
        print()

        # Reason
        if expl.summary:
            print(f"    {_C(_DIM, 'Reason')}   {expl.summary}")
            print()

        # Offenders
        if expl.offenders:
            top: List[OffenderContext] = sorted(
                expl.offenders, key=lambda o: _SEV_ORDER.get(o.severity, 4)
            )[:3]

            print(f"    {_C(_DIM, 'Worst offenders')}")
            for off in top:
                sev_color: str = (
                    _RED    if off.severity in ("critical", "high") else
                    _YELLOW if off.severity == "medium"             else
                    _DIM
                )
                # Truncate long detail strings cleanly at a word boundary
                detail: str = off.detail
                if len(detail) > 52:
                    detail = detail[:49].rstrip() + "..."

                print(
                    f"      {_C(_DIM, '·')}  "
                    f"{_C(sev_color, detail.ljust(54))}"
                    f"  {_C(_DIM, f'line {off.line}')}"
                )
            print()

        # Fix
        if expl.fix:
            parts: List[str] = [s.strip() for s in expl.fix.split(". ") if s.strip()]
            # Re-add the period that split() consumed, except the last part keeps its own ending
            sentences: List[str] = [
                s if s.endswith(".") else s + "."
                for s in parts
            ]

            print(f"    {_C(_DIM, 'Fix')}")
            for sentence in sentences:
                print(
                    f"      {_C(_DIM, '·')}  "
                    f"{_C(_GREEN, sentence)}"
                )
            print()

# vvv Progress (written to stderr so --json stays clean on stdout) vvv
def PrintProgress(current: int, total: int, filepath: str) -> None:
    filled: int = round(current / total * _BAR_WIDTH) if total else 0
    bar: str    = "█" * filled + "░" * (_BAR_WIDTH - filled)
    name: str   = os.path.basename(filepath)

    if len(name) > 32:
        name = "…" + name[-31:]

    line: str = f"  [{bar}] {current}/{total}  {_C(_DIM, name)}"

    sys.stderr.write(f"\r\033[2K{line}" if _use_color else f"\r{line:<70}")

    if current == total:
        sys.stderr.write("\n")

    sys.stderr.flush()

# vvv Main Results Printer vvv
def PrintResults(
    ctx:             ProjectContext,
    final_score:     float,
    section_weights: List[float],
    section_names:   List[str],
    depth:           int,
    top_metrics:     int,
    worst_metrics:   int,
    explain:         bool = False,
) -> None:
    '''
    Print the full results panel:
      - Header with file/error counts
      - Overall score + section breakdown
      - Worst N files with per-section breakdown
        (+ per-metric explanations inline when --explain is active)
      - Top M globally worst metrics - always plain rows
    '''
    files: List[FileContext] = ctx.GetFileOutputs()
    file_count: int          = len(files)
    error_count: int         = sum(1 for f in files if f.HasErrors())

    # Header
    parts: List[str] = [_C(_CYAN + _BOLD, "PyMetricor")]
    parts.append(f"{file_count} file{'s' if file_count != 1 else ''}")

    if error_count:
        parts.append(_C(_RED, f"{error_count} error{'s' if error_count != 1 else ''}"))

    if ctx.aborted_analysis:
        parts.append(_C(_RED + _BOLD, "ABORTED"))

    print()
    _Header("  ·  ".join(parts))
    print()

    # Overall score
    print(
        f"  {_C(_BOLD, 'Score')}"
        f"  {_C(_ScoreColor(final_score) + _BOLD, f'{final_score:.1f} / 100')}"
        f"  {_Bar(final_score)}"
        f"{_Warn(final_score)}"
    )
    print()

    # Section breakdown (average across all files)
    n_sections: int = len(section_names)
    section_avgs: List[float] = [
        sum(f.GetSectionScore(i) for f in files) / max(file_count, 1)
        for i in range(n_sections)
    ]

    for i, (name, avg) in enumerate(zip(section_names, section_avgs)):
        if section_weights[i] > 0:
            print(_SectionRow(name.capitalize(), avg))

    print()

    # Worst N files
    if file_count == 0:
        return

    # Compute per-file total score using section weights
    def _FileScore(f: FileContext) -> float:
        return sum(f.GetSectionScore(i) * section_weights[i] for i in range(n_sections))

    ranked_files: List[FileContext] = sorted(files, key=_FileScore)
    worst_files: List[FileContext]  = ranked_files[:depth]
    shown_depth: int                = min(depth, len(worst_files))

    _Header(f"  {shown_depth} WORST FILE{'S' if shown_depth != 1 else ''}")
    print()

    for rank, fc in enumerate(worst_files, 1):
        file_score: float = _FileScore(fc)
        rel_path: str     = _RelPath(fc.file_path)

        # Truncate long paths from the left
        if len(rel_path) > 45:
            rel_path = "…" + rel_path[-44:]

        score_str: str = _C(_ScoreColor(file_score) + _BOLD, f"{file_score:.1f}")

        print(f"  {_C(_BOLD, f'#{rank}')}  {rel_path.ljust(46)}  {score_str}")

        # Sections sorted worst → best
        sections: List[Tuple[str, float]] = sorted(
            [(section_names[i], fc.GetSectionScore(i)) for i in range(n_sections)],
            key=lambda x: x[1],
        )

        for sec_name, sec_score in sections:
            print(_SectionRow(f"    {sec_name.lower()}", sec_score, label_w=21))

        # Per-file metric explanations when --explain is active
        # No extra blank line here - _PrintFileExplanations handles its own spacing
        if explain:
            print()
            print(f"    {_C(_DIM, '┌─ why this file scored low')}")
            _PrintFileExplanations(fc, worst_metrics)
        else:
            print()

        if rank < shown_depth:
            print(_C(_DIM, f"  {_RULE_THIN}"))
            print()

    # Worst metrics - always plain rows
    # Global averages give orientation; explanations are only meaningful per-file
    metric_totals: Dict[str, List[float]] = {}
    metric_worst:  Dict[str, Tuple[float, str]] = {}

    for fc in files:
        for metric_name, score in fc.GetAllMetricScores():
            metric_totals.setdefault(metric_name, []).append(score)
            prev_worst, _ = metric_worst.get(metric_name, (999.0, ""))

            if score < prev_worst:
                metric_worst[metric_name] = (score, _RelPath(fc.file_path))

    metric_avgs: List[Tuple[str, float, str]] = []
    for name, scores in metric_totals.items():
        avg: float = sum(scores) / len(scores)
        _, worst_file = metric_worst.get(name, (0.0, ""))
        metric_avgs.append((name, avg, worst_file))

    metric_avgs.sort(key=lambda x: x[1])
    shown: List[Tuple[str, float, str]] = metric_avgs[:top_metrics]

    _Header(f"  {len(shown)} WORST METRICS  (avg across all files)")
    print()

    for metric_name, avg, worst_file in shown:
        note: str = os.path.basename(worst_file) if worst_file else ""
        print(_MetricRow(metric_name.lower(), avg, note))

    print()

# vvv JSON Output vvv
def PrintJSON(
    ctx:             ProjectContext,
    final_score:     float,
    section_weights: List[float],
    section_names:   List[str],
) -> None:
    files: List[FileContext] = ctx.GetFileOutputs()
    n_sections: int          = len(section_names)

    def _FileScore(f: FileContext) -> float:
        return sum(f.GetSectionScore(i) * section_weights[i] for i in range(n_sections))

    file_data: List[Dict[str, Any]] = []

    for fc in files:
        file_data.append({
            "path":     fc.file_path,
            "score":    round(_FileScore(fc), 2),
            "sections": {
                section_names[i]: round(fc.GetSectionScore(i), 2)
                for i in range(n_sections)
            },
            "metrics": {
                name: round(score, 2)
                for name, score in fc.GetAllMetricScores()
            },
            "errors": fc.HasErrors(),
        })

    # Global metric averages
    metric_totals: Dict[str, List[float]] = {}
    for fc in files:
        for name, score in fc.GetAllMetricScores():
            metric_totals.setdefault(name, []).append(score)

    metric_avgs: Dict[str, float] = {
        name: round(sum(scores) / len(scores), 2)
        for name, scores in metric_totals.items()
    }

    output: Dict[str, Any] = {
        "score":          round(final_score, 2),
        "aborted":        ctx.aborted_analysis,
        "file_count":     len(files),
        "error_count":    sum(1 for f in files if f.HasErrors()),
        "section_averages": {
            section_names[i]: round(
                sum(f.GetSectionScore(i) for f in files) / max(len(files), 1), 2
            )
            for i in range(n_sections)
        },
        "metric_averages": metric_avgs,
        "files":          sorted(file_data, key=lambda x: x["score"]),
    }

    print(json.dumps(output, indent=2))


# vvv Helpers vvv
def _RelPath(path: str) -> str:
    '''Return path relative to cwd if possible, otherwise absolute.'''
    try:
        return os.path.relpath(path)
    except ValueError:
        return path