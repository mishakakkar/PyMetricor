'''
Module dependency graph of the analysed project.

Nodes are the project's modules (see core/reasoning/project.py for naming); an edge
a -> b means module a imports module b. Imports of anything outside the project
(stdlib, third-party) are not edges.

Per module:
  fan-out   distinct project modules it imports (efferent coupling, Ce)
  fan-in    distinct project modules that import it (afferent coupling, Ca)
  cycle     the size of its import cycle: the strongly connected component of the
            graph of *load-time* imports. Imports inside functions and under
            `if TYPE_CHECKING:` do not run when the module loads, and are the usual
            way to break a cycle, so they count for fan-in/out but not for cycles.

`from pkg import Name`, where pkg/__init__.py only re-exports Name from pkg.mod,
is an edge to pkg.mod: the module that defines Name. Otherwise every module using a
package's public API would sit in one cycle with the package's __init__.py.

The graph is built from the standard-library ast (one cheap parse per file), once
per run, before the per-file pipeline starts.
'''

# My stuff
from core.reasoning.project import ProjectIndex

# Python stuff
import ast
from dataclasses import dataclass, field
from typing      import Dict, Iterator, List, Optional, Set, Tuple

# vvv Data vvv
@dataclass
class ModuleDependencies:
    module:   str
    fan_in:   int
    fan_out:  int
    cycle:    List[str] = field(default_factory=list)   # other modules in its import cycle (empty if none)
    imports:  List[str] = field(default_factory=list)   # project modules it imports, sorted

# vvv Main Stuff vvv
class ModuleGraph:
    __slots__ = ("_index", "_edges", "_load_edges", "_importers", "_cycle_of", "_reexports")

    def __init__(self, index: ProjectIndex) -> None:
        self._index:      ProjectIndex           = index
        self._edges:      Dict[str, Set[str]]    = {}
        self._load_edges: Dict[str, Set[str]]    = {}
        self._importers:  Dict[str, Set[str]]    = {}
        self._cycle_of:   Dict[str, List[str]]   = {}
        self._reexports:  Dict[str, Dict[str, Tuple[str, str]]] = {}

        for file in index.Files():
            name: Optional[str] = index.ModuleName(file)
            if name is None:
                continue
            self._edges.setdefault(name, set())
            self._load_edges.setdefault(name, set())
            for target, at_load in self._Imports(file):
                if target == name:
                    continue
                self._edges[name].add(target)
                if at_load:
                    self._load_edges[name].add(target)

        for source, targets in self._edges.items():
            for target in targets:
                self._importers.setdefault(target, set()).add(source)

        for component in _StronglyConnected(self._load_edges):
            if len(component) > 1:
                for name in component:
                    self._cycle_of[name] = sorted(component - {name})

    # vvv Queries vvv
    def For(self, file: str) -> Optional[ModuleDependencies]:
        name: Optional[str] = self._index.ModuleName(file)
        if name is None or name not in self._edges:
            return None
        return ModuleDependencies(
            module  = name,
            fan_in  = len(self._importers.get(name, ())),
            fan_out = len(self._edges[name]),
            cycle   = self._cycle_of.get(name, []),
            imports = sorted(self._edges[name]),
        )

    def Modules(self) -> List[str]:
        return sorted(self._edges)

    def Cycles(self) -> List[List[str]]:
        seen: Set[str] = set()
        cycles: List[List[str]] = []
        for name, others in sorted(self._cycle_of.items()):
            if name not in seen:
                members: List[str] = sorted([name, *others])
                seen.update(members)
                cycles.append(members)
        return cycles

    # vvv Internals vvv
    def _Imports(self, file: str) -> Iterator[Tuple[str, bool]]:
        '''(project module imported, whether the import runs when the module loads).'''
        try:
            with open(file, "r", encoding="utf-8", errors="replace") as fh:
                tree: ast.Module = ast.parse(fh.read())
        except (SyntaxError, ValueError, OSError):
            return

        for node, at_load in _ImportNodes(tree.body, True):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    target: Optional[str] = self._Longest(alias.name)
                    if target:
                        yield target, at_load
            else:
                base: Optional[str] = self._index.Absolute(node.module or "", node.level, file)
                if base is None:
                    continue
                for alias in node.names:
                    # from pkg import mod  imports the submodule; from mod import name  imports mod
                    sub: Optional[str] = self._index.FileFor(f"{base}.{alias.name}") and f"{base}.{alias.name}"
                    target = self._Canonical(sub) if sub else self._Defining(base, alias.name, 0)
                    if target:
                        yield target, at_load

    def _Defining(self, module: str, name: str, depth: int) -> Optional[str]:
        '''The project module that defines `name` imported from `module`, following package re-exports.'''
        canonical: Optional[str] = self._Longest(module)
        if canonical is None or depth > 5 or not self._index.IsPackage(canonical):
            return canonical
        source: Optional[Tuple[str, str]] = self._ReExports(canonical).get(name)
        return (self._Defining(source[0], source[1], depth + 1) or canonical) if source else canonical

    def _ReExports(self, package: str) -> Dict[str, Tuple[str, str]]:
        '''name -> (module, original name) for the `from x import name` lines of a package __init__.'''
        if package in self._reexports:
            return self._reexports[package]
        found: Dict[str, Tuple[str, str]] = {}
        file: Optional[str]   = self._index.FileFor(package)
        try:
            with open(file or "", "r", encoding="utf-8", errors="replace") as fh:
                tree: ast.Module = ast.parse(fh.read())
        except (SyntaxError, ValueError, OSError):
            tree = ast.Module(body=[], type_ignores=[])
        for node in tree.body:
            if isinstance(node, ast.ImportFrom) and file:
                base: Optional[str] = self._index.Absolute(node.module or "", node.level, file)
                if base and base != package:
                    for alias in node.names:
                        if alias.name != "*":
                            found[alias.asname or alias.name] = (base, alias.name)
        self._reexports[package] = found
        return found

    def _Longest(self, dotted: str) -> Optional[str]:
        '''Longest prefix of a dotted import that is a project module (import a.b.c may name package a.b).'''
        parts: List[str] = dotted.split(".")
        for k in range(len(parts), 0, -1):
            name: Optional[str] = self._Canonical(".".join(parts[:k]))
            if name:
                return name
        return None

    def _Canonical(self, dotted: str) -> Optional[str]:
        file: Optional[str] = self._index.FileFor(dotted)
        return self._index.ModuleName(file) if file else None

# vvv Helpers vvv
def _ImportNodes(stmts: List[ast.stmt], at_load: bool) -> Iterator[Tuple[ast.stmt, bool]]:
    for stmt in stmts:
        if isinstance(stmt, (ast.Import, ast.ImportFrom)):
            yield stmt, at_load
        elif isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            yield from _ImportNodes(stmt.body, False)  # type: ignore
        elif isinstance(stmt, ast.If) and _IsTypeChecking(stmt.test):
            yield from _ImportNodes(stmt.body, False)
            yield from _ImportNodes(stmt.orelse, at_load)
        else:
            for name in ("body", "orelse", "finalbody", "handlers"):
                block = getattr(stmt, name, None)
                if isinstance(block, list):
                    yield from _ImportNodes(block, at_load)  # type: ignore
            for case in getattr(stmt, "cases", []) or []:
                yield from _ImportNodes(case.body, at_load)

def _IsTypeChecking(test: ast.expr) -> bool:
    return (isinstance(test, ast.Name) and test.id == "TYPE_CHECKING") or \
           (isinstance(test, ast.Attribute) and test.attr == "TYPE_CHECKING")

def _StronglyConnected(edges: Dict[str, Set[str]]) -> List[Set[str]]:
    '''Tarjan's algorithm, iterative so deep import chains cannot hit the recursion limit.'''
    index: Dict[str, int]   = {}
    low:   Dict[str, int]   = {}
    on_stack: Set[str]      = set()
    stack: List[str]        = []
    components: List[Set[str]] = []
    counter: int = 0

    for root in sorted(edges):
        if root in index:
            continue
        work: List[Tuple[str, Iterator[str]]] = [(root, iter(sorted(edges.get(root, ()))))]
        index[root] = low[root] = counter; counter += 1
        stack.append(root); on_stack.add(root)
        while work:
            node, children = work[-1]
            advanced: bool = False
            for child in children:
                if child not in edges:
                    continue
                if child not in index:
                    index[child] = low[child] = counter; counter += 1
                    stack.append(child); on_stack.add(child)
                    work.append((child, iter(sorted(edges.get(child, ())))))
                    advanced = True
                    break
                if child in on_stack:
                    low[node] = min(low[node], index[child])
            if advanced:
                continue
            work.pop()
            if work:
                parent: str = work[-1][0]
                low[parent] = min(low[parent], low[node])
            if low[node] == index[node]:
                component: Set[str] = set()
                while True:
                    member: str = stack.pop()
                    on_stack.discard(member)
                    component.add(member)
                    if member == node:
                        break
                components.append(component)
    return components
