# My stuff
from .context     import ProjectContext
from .error       import ErrorContext, ErrorKind
from .interface   import BasePipelineStage
from .reasoning.project import ProjectIndex
from utils.logger import logger

# Python stuff
from os           import path as os_path, walk as os_walk
from typing       import List, Tuple, Callable, Optional, Set

class Analyser:
    __slots__ = (
        "_stages",
        "_max_file_errors",
    )

    def __init__(self, stages: List[BasePipelineStage], max_file_errors: int = 10) -> None:
        '''
        NOTE: 'stages' must be pre-initialized
        '''
        self._stages: List[BasePipelineStage] = stages
        self._max_file_errors: int            = max_file_errors

    # vvv Internal Functions vvv
    def _NormalizeIgnorePaths(self, source_paths: List[str], ignore_paths: List[str]) -> Set[str]:
        normalized: Set[str] = set()
        for ig in ignore_paths:
            if os_path.isabs(ig):
                normalized.add(ig)
                continue

            for src in source_paths:
                base: str = src if os_path.isdir(src) else os_path.dirname(src)
                abs_base: str = os_path.abspath(base)
                candidate: str = os_path.abspath(os_path.join(abs_base, ig))

                # Reject paths that escaped the source root
                if not candidate.startswith(abs_base + os_path.sep):
                    logger.Warn(f"[Pipeline]: Ignoring path outside source root, skipping: {ig!r}")
                    continue

                normalized.add(candidate)
        return normalized

    def _IsIgnored(self, file_path: str, ignored: Set[str]) -> bool:
        '''
        Returns True if file_path lives under (or is exactly) any ignored path.
        '''
        abs_file: str = os_path.abspath(file_path)
        return any(
            abs_file == ig or abs_file.startswith(ig + os_path.sep)
            for ig in ignored
        )

    def _CollectPyFiles(self, paths: List[str], ignored: Set[str]) -> List[str]:
        '''
        Collect .py files excluding __init__.py recursively,
        skipping anything under an ignored path.
        '''
        py_files: List[str] = []

        for path in paths:
            if self._IsIgnored(path, ignored):
                logger.Info(f"[Pipeline]: Ignoring path: {path}")
                continue

            if os_path.isfile(path) and path.endswith(".py") and os_path.basename(path) != "__init__.py":
                py_files.append(path)

            # Recursively collect .py files from directories
            elif os_path.isdir(path):
                for root, dirs, files in os_walk(path):
                    # Prune ignored subdirectories in-place so 'os_walk' won't descend into them
                    dirs[:] = [
                        d for d in dirs
                        if not self._IsIgnored(os_path.join(root, d), ignored)
                    ]
                    for f in files:
                        full: str = os_path.join(root, f)
                        if f.endswith(".py") and f != "__init__.py" and not self._IsIgnored(full, ignored):
                            py_files.append(full)
            else:
                logger.Warn(f"[Pipeline]: Skipping invalid path: {path}")

        return py_files

    def _DoAnalysis(self, file: str, ctx: ProjectContext) -> bool:
        # Returns true if stages succeed, false otherwise
        # This will be useful for limiting the amount of errors that can occur
        with ctx.ProcessFile(file) as file_ctx:
            # Skip if the file context is none (the error is logged by file context)
            if file_ctx is None:
                return False

            # File is empty, no need to process it
            if not file_ctx.file_data:
                return True

            for stage in self._stages:
                # A bug in one rule must not abort a whole project run, so an unexpected
                # exception is recorded against the file and the run moves on
                try:
                    if(not stage.Run(file_ctx)):
                        return False
                except Exception as e:
                    file_ctx.AddError(ErrorContext(
                        kind    = ErrorKind.INTERNAL,
                        message = f"Unexpected {type(e).__name__}: {str(e).replace('\n', ' ')}",
                        file    = file,
                        stage   = type(stage).__name__
                    ))
                    return False

            return True

    def _BuildIndex(self, source_files: List[str]) -> ProjectIndex:
        '''
        Index the analysed files plus the __init__.py files of their packages, which are
        not analysed themselves but define what a package re-exports.
        '''
        files: Set[str] = {os_path.abspath(f) for f in source_files}
        for f in list(files):
            directory: str = os_path.dirname(f)
            while os_path.isfile(os_path.join(directory, "__init__.py")):
                init: str = os_path.join(directory, "__init__.py")
                if init in files:
                    break
                files.add(init)
                directory = os_path.dirname(directory)
        return ProjectIndex(sorted(files))

    # vvv Main Function vvv
    def Run(
        self,
        source_paths:      List[str],
        ignore_paths:      Optional[List[str]]                       = None,
        progress_callback: Optional[Callable[[int, int, str], None]] = None,
    ) -> Tuple[ProjectContext, bool]:
        ignored: Set[str] = self._NormalizeIgnorePaths(source_paths, ignore_paths or [])
        source_files: List[str] = self._CollectPyFiles(source_paths, ignored)

        if not source_files:
            logger.Info("[Pipeline]: No Python files found to process")
            return (ProjectContext([], True), False)

        ctx: ProjectContext = ProjectContext(source_files, project_index=self._BuildIndex(source_files))
        file_error_count: int = 0

        # Loop through all the files and apply the analysis pipeline
        for i, file in enumerate(source_files):
            if progress_callback:
                progress_callback(i + 1, len(source_files), file)
            else:
                logger.Info(f"[Analyser]: Running analysis for file: {file}")

            file_error_count += 1 if not self._DoAnalysis(file, ctx) else 0

            # Error budget exceeded
            if file_error_count >= self._max_file_errors:
                ctx.aborted_analysis = True
                break

        return (ctx, file_error_count > 0)