from enum import IntEnum, auto

# vvv Section Indexing vvv
class Section(IntEnum):
    READABILITY     = 0
    EFFICIENCY      = auto()
    MAINTAINABILITY = auto()
    SECURITY        = auto()
    COUNT = auto()

# vvv Metric Indexing vvv
class ReadabilityMetric(IntEnum):
    LINE_LENGTH_DISTRIBUTION      = 0
    INDENTATION_STABILITY         = auto()
    IDENTIFIER_STYLE              = auto()
    COMMENT_DENSITY               = auto()
    NESTING_DEPTH                 = auto()
    BLANK_LINE_RHYTHM             = auto()
    ANNOTATION_CONSISTENCY        = auto()
    STRING_FORMATTING_CONSISTENCY = auto()
    IDENTIFIER_LENGTH             = auto()
    COGNITIVE_COMPLEXITY          = auto()
    LINE_DENSITY                  = auto()
    IDENTIFIER_QUALITY            = auto()
    FORMATTING_CONSISTENCY        = auto()
    COUNT = auto()

class EfficiencyMetric(IntEnum):
    CYCLOMATIC_COMPLEXITY   = 0
    REDUNDANT_CODE          = auto()
    DEAD_CODE               = auto()
    COUNT = auto()

class SecurityMetric(IntEnum):
    BROKEN_CRYPTOGRAPHY      = 0
    ARBITRARY_CODE_EXECUTION = auto()
    UNSAFE_FILE_ACCESS       = auto()
    INJECTION_AND_REQUEST_FORGERY = auto()   # SQL injection (CWE-89) and SSRF (CWE-918)
    COUNT = auto()

class MaintainabilityMetric(IntEnum):
    INHERITANCE_DEPTH                  = 0
    METHOD_RECEIVER_NAMING_CONSISTENCY = auto()
    PARAMETER_BLOAT                    = auto()
    EXCEPTION_HYGIENE                  = auto()
    FUNCTION_LENGTH                    = auto()
    CLASS_COMPLEXITY                   = auto()
    MODULE_COUPLING                    = auto()
    COUNT = auto()