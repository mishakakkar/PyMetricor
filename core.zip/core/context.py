# My stuff
from .error       import ErrorContext, ErrorKind
from .enums       import Section, ReadabilityMetric, EfficiencyMetric, MaintainabilityMetric, SecurityMetric
from utils.logger import logger
from utils.math   import FLOAT_EPSILON
from config       import Config, ConfigNamespace
from .modules     import ModuleGraph
from .reasoning.project import ProjectIndex

# Python stuff
from dataclasses  import dataclass
from typing       import Dict, List, TextIO, Optional, Iterator, Tuple
from contextlib   import contextmanager
from math         import log1p, isclose

# vvv Per-metric signal Context vvv
@dataclass(frozen = True)
class SignalContext:
    score: float   # [0.0, 100.0]
    weight: float  # [0.0, 1.0]

@dataclass
class OffenderContext:
    filepath:    str
    line:        int
    detail:      str   # "depth 8  _ResolveScope -> _Walk -> ..."
    severity:    str   # "high" | "medium" | "low", for coloring

@dataclass
class MetricExplanation:
    summary:    str                    # "avg nesting 4.2, target <= 3. 5 files exceed max of 6"
    offenders:  List[OffenderContext]  # Top 3, pre-sorted worst first
    fix:        str                    # Flatten deeply nested logic into named helpers

# vvv Per-file Context vvv
class FileContext:
    __slots__ = (
        "file_handle",
        "file_path",
        "file_data",
        "_section_scores",
        "_readability",
        "_efficiency",
        "_maintainability",
        "_security",
        "_loc",
        "_token_count",
        "_ast_nodes",
        "_errors",
        "_explanations",
        "project_index",
        "module_graph",
    )

    def __init__(
        self,
        file_path:     str                    = "",
        project_index: Optional[ProjectIndex] = None,
        module_graph:  Optional[ModuleGraph]  = None,
    ) -> None:
        # Open file handle for per-stage processing
        self.file_path: str                = file_path
        self.file_handle: Optional[TextIO] = None
        self.file_data: Optional[str]      = None

        # The rest of the project: lets the security engine follow calls into other
        # files and the module coupling metric see the import graph (None for a lone file)
        self.project_index: Optional[ProjectIndex] = project_index
        self.module_graph:  Optional[ModuleGraph]  = module_graph

        # Parent section scores: 'Readability', 'Efficiency', 'Maintainability' and 'Security'
        self._section_scores: List[float] = [0.0] * Section.COUNT

        # Per metric scores
        # Each metric is made up of multiple signals collected across stages
        self._readability: List[List[SignalContext]]     = [[] for _ in range(ReadabilityMetric.COUNT)]
        self._efficiency: List[List[SignalContext]]      = [[] for _ in range(EfficiencyMetric.COUNT)]
        self._maintainability: List[List[SignalContext]] = [[] for _ in range(MaintainabilityMetric.COUNT)]
        self._security: List[List[SignalContext]]        = [[] for _ in range(SecurityMetric.COUNT)]

        # Code mass components
        self._loc: int         = 0
        self._token_count: int = 0
        self._ast_nodes: int   = 0

        # Misc
        self._errors: List[ErrorContext] = []
        self._explanations: Dict[str, MetricExplanation] = {}

    # vvv Internal Functions vvv
    #   Validators
    def _ValidateScore(self, score: float) -> None:
        if not (0.0 <= score <= 100.0):
            logger.Fatal(
                f"[FileContext]: '_ValidateScore' expects 'score' be in range [0.0, 100.0], got: {score}"
            )

    def _ValidateSignal(self, signal: SignalContext) -> None:
        if not (0.0 <= signal.score <= 100.0):
            logger.Fatal(
                f"[FileContext]: '_ValidateSignal' expects 'signal.score' be in range [0.0, 100.0],"
                f" got: {signal.score}"
            )

        if not (0.0 < signal.weight <= 1.0):
            logger.Fatal(
                f"[SignalContext]: '_ValidateSignal' expects 'signal.weight' be in range (0.0, 1.0],"
                f" got {signal.weight}"
            )

    def _ValidateMass(self, value: int) -> None:
        if value < 0:
            logger.Fatal(
                f"[FileContext]: '_ValidateMass' expects 'value' to be a non-negative value, got: {value}"
            )

    #   Computation
    def _ComputeMetricScore(self, signals: List[SignalContext]) -> float:
        if not signals:
            return 0.0

        total_weight: float = 0.0
        weighted_sum: float = 0.0

        for s in signals:
            total_weight += s.weight
            weighted_sum += s.score * s.weight

        if isclose(total_weight, 0.0, abs_tol = FLOAT_EPSILON):
            return 0.0

        return max(0.0, min(100.0, weighted_sum / total_weight))

    # vvv Helper Functions vvv
    #   Setters
    def SetSectionScore(self, section: Section, score: float) -> None:
        self._ValidateScore(score)
        self._section_scores[section] = score

    def AddReadabilitySignal(self, metric: ReadabilityMetric, signal: SignalContext) -> None:
        self._ValidateSignal(signal)
        self._readability[metric].append(signal)

    def AddEfficiencySignal(self, metric: EfficiencyMetric, signal: SignalContext) -> None:
        self._ValidateSignal(signal)
        self._efficiency[metric].append(signal)

    def AddMaintainabilitySignal(self, metric: MaintainabilityMetric, signal: SignalContext) -> None:
        self._ValidateSignal(signal)
        self._maintainability[metric].append(signal)

    def AddSecuritySignal(self, metric: SecurityMetric, signal: SignalContext) -> None:
        self._ValidateSignal(signal)
        self._security[metric].append(signal)

    def SetLOC(self, loc: int) -> None:
        self._ValidateMass(loc)
        self._loc = loc

    def SetTokenCount(self, count: int) -> None:
        self._ValidateMass(count)
        self._token_count = count

    def SetASTNodeCount(self, count: int) -> None:
        self._ValidateMass(count)
        self._ast_nodes = count

    def SetMetricExplanation(self, metric_name: str, explanation: MetricExplanation) -> None:
        self._explanations[metric_name] = explanation

    def GetMetricExplanation(self, metric_name: str) -> Optional[MetricExplanation]:
        return self._explanations.get(metric_name)

    #   Getters
    def GetSectionScore(self, section: Section | int) -> float:
        return self._section_scores[int(section)]

    def GetReadabilityScore(self, metric: ReadabilityMetric) -> List[SignalContext]:
        return self._readability[metric]

    def GetEfficiencyScore(self, metric: EfficiencyMetric) -> List[SignalContext]:
        return self._efficiency[metric]

    def GetMaintainabilityScore(self, metric: MaintainabilityMetric) -> List[SignalContext]:
        return self._maintainability[metric]

    def GetSecurityScore(self, metric: SecurityMetric) -> List[SignalContext]:
        return self._security[metric]

    def GetAllMetricScores(self) -> List[Tuple[str, float]]:
        '''
        Returns (metric_name, score) for every metric across all four sections.
        Only meaningful after the file has been fully processed (signals added).
        '''
        scores: List[Tuple[str, float]] = []

        for metric, signals in zip(ReadabilityMetric, self._readability):
            scores.append((metric.name, self._ComputeMetricScore(signals)))

        for metric, signals in zip(EfficiencyMetric, self._efficiency):
            scores.append((metric.name, self._ComputeMetricScore(signals)))

        for metric, signals in zip(MaintainabilityMetric, self._maintainability):
            scores.append((metric.name, self._ComputeMetricScore(signals)))

        for metric, signals in zip(SecurityMetric, self._security):
            scores.append((metric.name, self._ComputeMetricScore(signals)))

        return scores

    #   Errors
    def HasErrors(self) -> bool:
        return bool(self._errors)

    def AddError(self, ctx: ErrorContext) -> None:
        self._errors.append(ctx)

    def GetErrors(self) -> List[ErrorContext]:
        return self._errors

    #   File handling
    def IsFileOpen(self) -> bool:
        return self.file_handle is not None and not self.file_handle.closed

    def OpenFile(self, path: str) -> bool:
        if self.IsFileOpen():
            return True

        # Errors are not logged for this
        try:
            self.file_handle = open(path, "r", encoding="utf-8", errors="replace")
            return True
        except OSError:
            return False

    def CloseFile(self) -> None:
        # Could use 'IsFileOpen' but pylance complains as 'file_handle' is Optional[TextIO]
        if self.file_handle is not None:
            self.file_handle.close()
            self.file_handle = None

    #   Computation
    def ComputeSectionScores(
        self, r_weights: List[float], e_weights: List[float], s_weights: List[float], m_weights: List[float]
    ) -> None:
        '''
        NOTE: No error checking for weights is done here.
              Assuming the input fed to this will always be correct as this is an internal function.
        '''

        # READABILITY
        self._section_scores[Section.READABILITY] = sum(
            self._ComputeMetricScore(metric_signals) * metric_weight
            for metric_signals, metric_weight
                in zip(self._readability, r_weights)
        )

        # EFFICIENCY
        self._section_scores[Section.EFFICIENCY] = sum(
            self._ComputeMetricScore(metric_signals) * metric_weight
            for metric_signals, metric_weight
                in zip(self._efficiency, e_weights)
        )

        # SECURITY
        self._section_scores[Section.SECURITY] = sum(
            self._ComputeMetricScore(metric_signals) * metric_weight
            for metric_signals, metric_weight
                in zip(self._security, s_weights)
        )

        # MAINTAINABILITY
        self._section_scores[Section.MAINTAINABILITY] = sum(
            self._ComputeMetricScore(metric_signals) * metric_weight
            for metric_signals, metric_weight
                in zip(self._maintainability, m_weights)
        )

    def ComputeCompositeMass(self, w_loc: float, w_tokens: float, w_ast: float) -> float:
        '''
        The composite mass currently accounts only for LOC, token count, and AST node count.
        While this captures file size, it does not reflect structural or algorithmic complexity.
        In future iterations, higher complexity files should contribute more mass than
        simpler files of similar size.
        '''
        # Sanity checks
        ws = w_loc + w_tokens + w_ast
        if not isclose(ws, 1.0, rel_tol = FLOAT_EPSILON, abs_tol = FLOAT_EPSILON):
            logger.Fatal(
                "[FileContext]: 'ComputeCompositeMass' expects weights to sum to near 1.0 "
                f"(got {ws:.12f})"
            )

        # Damp values so instead of growing linearly, they grow logarithmically
        damped_loc = log1p(self._loc)
        damped_tc  = log1p(self._token_count)
        damped_an  = log1p(self._ast_nodes)

        mass = (
            w_loc * damped_loc + w_tokens * damped_tc + w_ast * damped_an
        )
        return mass

# vvv Entire Project Context vvv
class ProjectContext:
    __slots__ = (
        "_source_files",
        "_file_outputs",
        "_final_score",
        "aborted_analysis",
        "files_have_errors",
        "_global_config",
        "project_index",
        "module_graph",
    )

    def __init__(
        self,
        source_files:     List[str],
        aborted_analysis: bool                   = False,
        project_index:    Optional[ProjectIndex] = None,
    ) -> None:
        # Input files, per-file analysis results, and final aggregated score
        self._source_files: List[str]         = source_files
        self._file_outputs: List[FileContext] = []
        self._final_score: float              = 0.0

        # Project-wide structure shared by every file
        self.project_index: Optional[ProjectIndex] = project_index
        self.module_graph:  Optional[ModuleGraph]  = ModuleGraph(project_index) if project_index else None

        # Error handling
        self.aborted_analysis: bool  = aborted_analysis
        self.files_have_errors: bool = False

        # Global config
        self._global_config: Config = Config()

    # vvv Main Functions vvv
    def ComputeFinalScore(self, section_weights: List[float]) -> float:
        '''
        Order of 'section_weights' is: Readability, Efficiency, Maintainability and Security
        '''
        # Sanity checks
        if len(section_weights) != Section.COUNT:
            logger.Fatal(
                "[ProjectContext]: 'ComputeFinalScore' received invalid 'section_weights' length: "
                f"expected={Section.COUNT}, got={len(section_weights)}"
            )

        weight_sum: float = sum(section_weights)
        if not isclose(weight_sum, 1.0, rel_tol = FLOAT_EPSILON, abs_tol = FLOAT_EPSILON):
            logger.Fatal(
                "[ProjectContext]: 'ComputeFinalScore' received invalid 'section_weights': "
                f"sum={weight_sum}, expected near 1.0"
            )

        # No file has been computed, return
        if not self._file_outputs:
            self._final_score = 0.0
            return 0.0

        section_totals: List[float] = [0.0] * Section.COUNT
        total_mass: float = 0.0

        # Compute total for each section including all files
        for file_ctx in self._file_outputs:
            # A file whose analysis stopped part-way has only some of its signals, and
            # a missing metric scores 0, so it would drag the project down for being unparseable
            if file_ctx.HasErrors():
                continue

            mass: float = file_ctx.ComputeCompositeMass(
                self._global_config.metrics.weights.file_composite.loc,
                self._global_config.metrics.weights.file_composite.tokens,
                self._global_config.metrics.weights.file_composite.ast_nodes
            )
            if mass <= 0.0:
                continue  # Zero mass files contribute nothing

            total_mass += mass

            file_ctx.ComputeSectionScores(
                self._GetReadabilityWeightsFromConfig(),
                self._GetEfficiencyWeightsFromConfig(),
                self._GetSecurityWeightsFromConfig(),
                self._GetMaintainabilityWeightsFromConfig()
            )

            for i in range(Section.COUNT):
                section_totals[i] += file_ctx.GetSectionScore(Section(i)) * mass

        if isclose(total_mass, 0.0, abs_tol = FLOAT_EPSILON):
            self._final_score = 0.0
            return 0.0

        # Compute averages
        section_averages = [
            total / total_mass for total in section_totals
        ]

        # Compute final score
        self._final_score = sum(
            avg * w for avg, w in zip(section_averages, section_weights)
        )

        return self._final_score

    def GetFileOutputs(self) -> List[FileContext]:
        '''
        Return all per-file analysis results.
        '''
        return self._file_outputs

    def PrettyPrintErrors(self):
        for file_ctx in self._file_outputs:
            if not file_ctx.HasErrors():
                continue

            errors: List[ErrorContext] = file_ctx.GetErrors()
            error_count: int = len(errors)

            logger.Info(
                "[ErrorPrinter]: Printing errors per file (if any)\n"
                f"    {error_count} {"errors" if error_count > 1 else "error"} for file '{file_ctx.file_path}'"
                " listed below: "
            )
            for error_ctx in errors:
                print(
                    f"       - [STAGE]: {error_ctx.stage}\n"
                    f"       - [KIND]: {error_ctx.kind.name}\n"
                    f"       - [ERROR]: {error_ctx.message}\n"
                )

    @contextmanager
    def ProcessFile(self, file: str) -> Iterator[Optional[FileContext]]:
        file_ctx: FileContext = FileContext(file, self.project_index, self.module_graph)
        self._file_outputs.append(file_ctx)

        # Could not open file, yield 'None' so caller can skip it
        # Also add error to file context
        if not file_ctx.OpenFile(file):
            file_ctx.AddError(ErrorContext(
                kind    = ErrorKind.INTERNAL,
                message = "Failed to open file (File not found or access denied)",
                file    = file,
                stage   = "S-1ProcessFile"
            ))
            yield None
            return

        # Try to load the data into memory before yielding
        try:
            file_ctx.file_data = file_ctx.file_handle.read() # type: ignore
            yield file_ctx
        except (OSError, UnicodeDecodeError) as e:
            file_ctx.AddError(ErrorContext(
                kind    = ErrorKind.INTERNAL,
                message = f"File read error: {str(e)}",
                file    = file,
                stage   = "S-1ProcessFile"
            ))
            yield None
        finally:
            file_ctx.CloseFile()

    # vvv Helper Functions vvv
    def _GetReadabilityWeightsFromConfig(self) -> List[float]:
        r: ConfigNamespace = self._global_config.metrics.weights.readability
        return [
            r.line_length_distribution,
            r.indentation_stability,
            r.identifier_style,
            r.comment_density,
            r.nesting_depth,
            r.blank_line_rhythm,
            r.annotation_consistency,
            r.string_formatting_consistency,
            r.identifier_length,
            r.cognitive_complexity,
            r.line_density,
            r.identifier_quality,
            r.formatting_consistency,
        ]

    def _GetEfficiencyWeightsFromConfig(self) -> List[float]:
        e: ConfigNamespace = self._global_config.metrics.weights.efficiency
        return [
            e.cyclomatic_complexity,
            e.redundant_code,
            e.dead_code,
        ]

    def _GetMaintainabilityWeightsFromConfig(self) -> List[float]:
        m: ConfigNamespace = self._global_config.metrics.weights.maintainability
        return [
            m.inheritance_depth,
            m.method_receiver_naming_consistency,
            m.parameter_bloat,
            m.exception_hygiene,
            m.function_length,
            m.class_complexity,
            m.module_coupling,
        ]

    def _GetSecurityWeightsFromConfig(self) -> List[float]:
        s: ConfigNamespace = self._global_config.metrics.weights.security
        return [
            s.broken_cryptography,
            s.arbitrary_code_execution,
            s.unsafe_file_access,
            s.injection_and_request_forgery,
        ]