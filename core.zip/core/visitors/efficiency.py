# My stuff
from core.context       import FileContext, MetricExplanation, OffenderContext, SignalContext
from core.enums         import EfficiencyMetric
from core.interface     import BaseVisitor
from config             import Config, ConfigNamespace

# Python stuff
from astroid            import nodes                           # type: ignore
from astroid.util       import Uninferable                     # type: ignore
from astroid.exceptions import InferenceError, InferenceResult # type: ignore
from xxhash             import xxh64
from math               import exp
from collections        import Counter, defaultdict
from typing             import Any, Dict, Generator, Optional, Set, Type, Tuple, List, Union, override

# vvv Main Visitor vvv
class ComplexityVisitor(BaseVisitor):
    __slots__ = (
        "_decisions",
        "_complex_functions",
        "_function_count",
        "_complexity_nodes",
        "_k_complexity",
    )

    def __init__(self) -> None:
        # Global Config
        self._efficiency_tuning: ConfigNamespace = Config().metrics.tuning.efficiency

        # vvv Settings vvv
        self._complexity_base: float = self._efficiency_tuning.thresholds.avg_complexity_base
        self._k_complexity: float    = self._efficiency_tuning.sensitivity.cyclomatic_complexity

        # vvv Internals vvv
        self._decisions: int      = 0
        self._function_count: int = 0

        self._complexity_nodes: Set[Type[nodes.NodeNG]] = {
            nodes.If,
            nodes.For,
            nodes.AsyncFor,
            nodes.While,
            nodes.ExceptHandler,
            nodes.Assert,
            nodes.MatchCase,           # Python 3.10+ Pattern Matching
        }

        self._complex_functions: List[Tuple[str, int, float]] = []  # (name, line, complexity)

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        # Count decisions (Branches)
        if type(node) in self._complexity_nodes:
            self._decisions += 1

        if isinstance(node, nodes.BoolOp):
            self._decisions += (len(node.values) - 1)

        if isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            self._function_count += 1
            self._complex_functions.append((node.name, node.lineno or 0, 0.0))  # filled in Finalize

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        # Prevent division by zero for files with no functions
        effective_units: int = max(1, self._function_count)
        
        # Calculate Average Complexity
        total_complexity: int = effective_units + self._decisions
        avg_complexity: float = total_complexity / effective_units

        excess: float = max(0.0, avg_complexity - self._complexity_base)
        final_score: float = 100.0 * exp(-excess * self._k_complexity)

        ctx.AddEfficiencySignal(
            EfficiencyMetric.CYCLOMATIC_COMPLEXITY,
            SignalContext(final_score, 1.0)
        )

        if excess > 0.0:
            ctx.SetMetricExplanation("CYCLOMATIC_COMPLEXITY", MetricExplanation(
                summary   = (
                    f"Average cyclomatic complexity is {avg_complexity:.1f} "
                    f"(threshold: {self._complexity_base}). "
                    f"{self._decisions} decision point(s) across {effective_units} function(s)."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  (contributes to avg {avg_complexity:.1f})",
                        severity = "high" if avg_complexity > self._complexity_base + 5 else "medium",
                    )
                    for name, line, _ in self._complex_functions[:3]
                ],
                fix = (
                    "Break large functions into smaller named helpers. "
                    "Each function ideally has a single responsibility and fewer than "
                    f"{int(self._complexity_base)} branches."
                ),
            ))

        # Reset for future use
        self._decisions      = 0
        self._function_count = 0

class RedundantCodeVisitor(BaseVisitor):
    '''
    Detects:
    1. Identity Comprehensions ( [x for x in y] )
    2. Redundant Full Slicing ( x[:] )
    3. Same Type Casting ( list(list(x)) or list([]) )
    4. Unnecessary Unpacking ( [*x] or {**x} )
    5. Structural Code Duplication (Exact logic matches via xxHash)
    '''

    __slots__ = (
        "_violations",
        "_k_sensitivity",
        "_cast_map",
        "_seen_hashes",
        "_config_min_mass",
        "_config_check_types",
        "_violation_details",
    )

    def __init__(self) -> None:
        # Global Config
        self._efficiency_tuning: ConfigNamespace = Config().metrics.tuning.efficiency

        # vvv Settings vvv
        self._config_min_mass: int = self._efficiency_tuning.thresholds.min_mass_for_duplication
        self._k_sensitivity: float = self._efficiency_tuning.sensitivity.redundant_code

        # vvv Internals vvv
        self._violations: int = 0
        self._cast_map: Dict[str, Optional[Type[nodes.NodeNG]]] = {
            # Containers with AST literals
            'list': nodes.List,
            'dict': nodes.Dict,
            'set': nodes.Set,
            'tuple': nodes.Tuple,

            # Primitives with AST Const literals
            'int': nodes.Const,
            'float': nodes.Const,
            'str': nodes.Const,
            'bool': nodes.Const,
            'bytes': nodes.Const,
            'complex': nodes.Const,

            # Built-ins without literal syntax (Checked only for nested calls)
            'frozenset': None,
            'bytearray': None,
            'memoryview': None,
        }

        # Minimum lines of code to consider for duplication checks
        self._config_check_types: Set[Type[nodes.NodeNG]] = {
            nodes.FunctionDef,
            nodes.AsyncFunctionDef,
            nodes.ClassDef,
            nodes.If, nodes.For, nodes.While 
        }

        # Internal State: Hash -> List of (LineNo, ScopeName)
        self._seen_hashes: defaultdict[str, List[Tuple[int, str]]] = defaultdict(list)
        self._violation_details: List[Tuple[str, int]] = []  # (description, line)

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        self._CheckIdentityComprehension(node)
        self._CheckRedundantFullSlicing(node)
        self._CheckRedundantCasting(node)
        self._CheckUnnecessaryUnpacking(node)
        self._CheckCodeDuplication(node)

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        # We only count extra copies as violations
        duplication_penalty: int = 0
        dupe_details: List[Tuple[str, int]] = []

        for _, occurrences in self._seen_hashes.items():
            if len(occurrences) > 1:
                extras: List[Tuple[int, str]] = occurrences[1:]   # first is original
                duplication_penalty += len(extras)
                for line, name in extras:
                    dupe_details.append((f"duplicate block {name!r}", line))

        all_details: List[Tuple[str, int]] = self._violation_details + dupe_details
        total_violations: int = len(all_details)

        final_score: float = 100.0 * exp(-total_violations * self._k_sensitivity)

        ctx.AddEfficiencySignal(
            EfficiencyMetric.REDUNDANT_CODE,
            SignalContext(final_score, 1.0)
        )

        if all_details:
            worst: List[Tuple[str, int]] = sorted(all_details, key=lambda x: x[1])[:3]
            ctx.SetMetricExplanation("REDUNDANT_CODE", MetricExplanation(
                summary   = (
                    f"{total_violations} redundant code instance(s) found: "
                    f"{len(self._violation_details)} micro-redundancies, "
                    f"{duplication_penalty} duplicate block(s)."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = desc,
                        severity = "high" if "duplicate" in desc else "low",
                    )
                    for desc, line in worst
                ],
                fix = (
                    "Remove identity comprehensions, redundant slices, and self-casts. "
                    "Extract duplicated blocks into shared functions."
                ),
            ))

        self._violations        = 0
        self._violation_details = []
        self._seen_hashes       = defaultdict(list)

    # vvv Internal Checks vvv
    def _CheckIdentityComprehension(self, node: nodes.NodeNG) -> None:
        '''
        Flags: [x for x in y], {x for x in y}, (x for x in y)
        '''
        if not isinstance(node, (nodes.ListComp, nodes.SetComp, nodes.GeneratorExp)):
            return

        # Must have exactly one loop and no 'if' conditions
        if len(node.generators) != 1 or node.generators[0].ifs:
            return

        generator: nodes.Comprehension = node.generators[0]
        target: nodes.NodeNG = generator.target
        elt: nodes.NodeNG = node.elt

        # Check if the target is exactly the element being yielded (e.g., 'x' == 'x')
        if isinstance(target, nodes.Name) and isinstance(elt, nodes.Name):
            if target.name == elt.name:
                self._violations += 1
                self._violation_details.append(("identity comprehension", node.lineno or 0))

    def _CheckRedundantFullSlicing(self, node: nodes.NodeNG) -> None:
        '''
        Flags: my_list[:]
        '''
        if not isinstance(node, nodes.Subscript):
            return

        # Check if the subscript is a Slice node
        if isinstance(node.slice, nodes.Slice):
            # A full slice [:] has None for lower, upper, and step
            if node.slice.lower is None and node.slice.upper is None and node.slice.step is None:
                self._violations += 1
                self._violation_details.append(("redundant full slice [:]", node.lineno or 0))

    def _CheckRedundantCasting(self, node: nodes.NodeNG) -> None:
        '''
        Dynamically flags redundant casts for all Python built-in types.
        Detects: 
        1. Nested identical casts: frozenset(frozenset(x)), int(int(x))
        2. Literal / Variable to self casts: complex(1j), float(5.0), list([])
        '''
        if not isinstance(node, nodes.Call):
            return

        func: nodes.NodeNG = node.func
        if not isinstance(func, nodes.Name):
            return
        if func.name not in self._cast_map:
            return

        if len(node.args) != 1:
            return

        arg: nodes.NodeNG = node.args[0]
        cast_type: str = func.name

        # Nested Casting of the exact same type (Just an optimization so we don't have to infer)
        # Flags: frozenset(frozenset(x)), int(int(x)), bytearray(bytearray(x)), ...
        if isinstance(arg, nodes.Call) and isinstance(arg.func, nodes.Name):
            if arg.func.name == cast_type:
                self._violations += 1
                self._violation_details.append((f"redundant cast {cast_type}({cast_type}(...))", node.lineno or 0))
            return

        # Literal to Self
        expected_node_type: Optional[Type[nodes.NodeNG]] = self._cast_map.get(cast_type)

        # If the type has no literal syntax (e.g., memoryview), we are done
        if expected_node_type is None:
            return

        # Check if the argument is the expected literal AST node
        if isinstance(arg, expected_node_type):
            if expected_node_type is nodes.Const:
                # Verify primitive type matches (e.g., ensures int(5.0) is allowed, but int(5) is flagged)
                if type(arg.value).__name__ == cast_type: # type: ignore
                    self._violations += 1
                    self._violation_details.append((f"redundant cast {cast_type}({cast_type}(...))", node.lineno or 0))
            else:
                # Containers (list, dict, set, tuple) are already confirmed by isinstance
                self._violations += 1
                self._violation_details.append((f"redundant cast {cast_type}({cast_type}(...))", node.lineno or 0))

        # Try to infer it (Slow path)
        else:
            try:
                inferred_gen: Generator[InferenceResult, None, None] = arg.infer()
                first: InferenceResult = next(inferred_gen)

                if first is Uninferable:
                    return

                # Check if inferred type matches the redundant cast
                matched: bool = False
                if expected_node_type is nodes.Const:
                    if isinstance(first, nodes.Const) and type(first.value).__name__ == cast_type:
                        matched = True
                elif isinstance(first, expected_node_type):
                    matched = True

                if not matched:
                    return

                # Ensure no ambiguity (Union types)
                try:
                    next(inferred_gen)
                    return 
                except StopIteration:
                    self._violations += 1
                    self._violation_details.append((f"redundant cast {cast_type}({cast_type}(...))", node.lineno or 0))

            except (InferenceError, StopIteration):
                pass

    def _CheckUnnecessaryUnpacking(self, node: nodes.NodeNG) -> None:
        '''
        Flags: [*iterable] or {**mapping}
        '''
        # Check List/Set Unpacking: [*x]
        if isinstance(node, (nodes.List, nodes.Set)):
            if len(node.elts) == 1 and isinstance(node.elts[0], nodes.Starred):
                self._violations += 1
                self._violation_details.append(("unnecessary unpack [*x] or {**x}", node.lineno or 0))
                return

        # Check Dict Unpacking: {**x}
        if isinstance(node, nodes.Dict):
            # In astroid, a dict unpack {**x} uses a DictUnpack node as the key
            if len(node.items) == 1:
                key, _ = node.items[0]
                if isinstance(key, nodes.DictUnpack):
                    self._violations += 1
                    self._violation_details.append(("unnecessary unpack [*x] or {**x}", node.lineno or 0))

    def _CheckCodeDuplication(self, node: nodes.NodeNG) -> None:
        if type(node) not in self._config_check_types:
            return

        # Filter by mass
        if (node.tolineno - node.fromlineno) < self._config_min_mass:
            return

        # Normalize Content
        content_hash: Optional[str] = self._ComputeNodeHash(node)

        if content_hash:
            name: Union[Any, str] = getattr(node, 'name', 'expr')
            self._seen_hashes[content_hash].append((node.lineno, name)) # type: ignore

    def _ComputeNodeHash(self, node: nodes.NodeNG) -> Optional[str]:
        try:
            if not hasattr(node, 'body') or not node.body: # type: ignore
                return None

            doc_node: Union[Any, None] = getattr(node, 'doc_node', None)

            # Build normalized content stream from body elements only
            # This ignores function signatures/decorators, detecting renamed clones
            content_buffer: List[str] = []

            for child in node.body: # type: ignore
                if child is doc_node:
                    continue

                content_buffer.append(child.as_string()) # type: ignore

            if not content_buffer:
                return None

            # Use a separator to prevent token boundary collisions
            normalized_code: str = "\x00".join(content_buffer)

            return xxh64(normalized_code).hexdigest()

        except Exception:
            return None

class DeadCodeVisitor(BaseVisitor):
    '''
    Detects Dead Code using a Symbol Table and Control Flow Analysis.
    
    1. Unreachable Code:
    - Statements after return/raise/break/continue
    - Statically False branches (if False, while 0)
    - Shadowed Exception handlers
    
    2. Unused Symbols (Scope Dead-Ends):
    - Unused Variables (local & global)
    - Unused Arguments
    - Unused Imports
    - Unused Private Functions/Methods
    
    3. Pointless Expressions:
    - Self-assignments (x = x)
    - Standalone literals or arithmetic without side effects
    '''

    __slots__ = (
        "_violations",
        "_violation_details",
        "_k_sensitivity",
        "_terminal_nodes",
        "_ignored_names",
        "_scope_stack",
        "_scope_type_stack",
        "_scope_line_stack",
        "_flag_globals",
        "_class_stack",
        "_method_first_param",
        "_class_method_sets",
    )

    # Scope constants
    SCOPE_GLOBAL: int   = 0
    SCOPE_CLASS: int    = 1
    SCOPE_FUNCTION: int = 2

    # Counter constants
    IMPORT_COUNTER: int = -1

    def __init__(self) -> None:
        # Global Config
        self._efficiency_tuning: ConfigNamespace = Config().metrics.tuning.efficiency

        # vvv Settings vvv
        self._k_sensitivity: float    = self._efficiency_tuning.sensitivity.dead_code
        self._flag_globals: bool      = self._efficiency_tuning.flags.flag_globals
        self._flag_class_public: bool = self._efficiency_tuning.flags.flag_class_public

        # vvv Internals vvv
        # Nodes that definitively end the execution of a block
        self._terminal_nodes: Tuple[Type[nodes.NodeNG], ...] = (
            nodes.Return, nodes.Raise, nodes.Break, nodes.Continue,
        )
        self._violations: int = 0
        self._violation_details: List[Tuple[str, int, str]] = []

        # Symbol Table Stack
        self._scope_stack: List[Counter[str]] = []
        self._scope_type_stack: List[int] = []
        self._scope_line_stack: List[Dict[str, int]] = []
        self._class_method_sets: List[Set[str]] = []
        self._class_stack: List[bool] = []
        self._method_first_param: List[Optional[str]] = []

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        # Control flow checks
        self._CheckUnreachableStatements(node)
        self._CheckDeadBranches(node)
        self._CheckShadowedExceptions(node)

        # Pointless expressions
        self._CheckPointlessExpressions(node)

        # Scope / Symbol table logic
        if isinstance(node, nodes.Module):
            self._PushScope(self.SCOPE_GLOBAL)

        elif isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            # The function name itself is defined in the enclosing scope
            self._RegisterDefinition(node.name, line=node.lineno or 0)

            # Track this as a method name in the enclosing class scope (if any)
            if self._class_stack and self._class_stack[-1] and self._class_method_sets:
                self._class_method_sets[-1].add(node.name)

            self._PushScope(self.SCOPE_FUNCTION)

            first_param: Optional[str] = None
            if self._class_stack and self._class_stack[-1]:
                if node.args.args:
                    first_param = node.args.args[0].name

            self._method_first_param.append(first_param)

            # Register arguments as definitions in the new local scope
            for arg in node.args.args: # type: ignore
                self._RegisterDefinition(arg.as_string(), line=arg.lineno or 0)

            if node.args.vararg:
                self._RegisterDefinition(node.args.vararg, line=node.lineno or 0)

            if node.args.kwarg:
                self._RegisterDefinition(node.args.kwarg, line=node.lineno or 0)
            
        elif isinstance(node, nodes.ClassDef):
            # Class name is defined in enclosing scope
            self._RegisterDefinition(node.name, line=node.lineno or 0)
            self._PushScope(self.SCOPE_CLASS)
            self._class_stack.append(True)
            self._class_method_sets.append(set())

        elif isinstance(node, (nodes.Import, nodes.ImportFrom)):
            # '__future__' imports are compiler directives, not real symbols
            if isinstance(node, nodes.ImportFrom) and node.modname == '__future__':
                return

            # Ex: 'from os import abort, system'
            #   'node.names' contains [(abort, None), (system, None)], register all of them
            # But in the case we do:
            #   from os import abort as myabort
            # 'node.names' will have [(abort, myabort)], so if the 2nd item is not None, register it
            for alias in node.names:
                self._RegisterDefinition(alias[1] or alias[0], is_import=True, line=node.lineno or 0)

        elif isinstance(node, nodes.Expr):
            if isinstance(node.value, nodes.Call):
                call: nodes.NodeNG = node.value
                if not isinstance(call.func, nodes.Attribute):
                    return

                base, full = self._ExtractAttrChain(call.func)
                if base:
                    self._RegisterUse(base)
                    self._RegisterUse(full)  # type: ignore

        elif isinstance(node, (nodes.AssignAttr, nodes.Attribute)):
            base, full = self._ExtractAttrChain(node)
            if not base:
                return

            instance_name: Optional[str] = self._method_first_param[-1] if self._method_first_param else None

            # If inside class method and base == first param, strip alias
            if instance_name and base == instance_name and self._class_stack and self._class_stack[-1]:
                # full = "<alias>.<rest>" -> rest
                rest: Optional[str] = full.split('.', 1)[1] if '.' in full else None # type: ignore
                if not rest:
                    return

                class_scope: Optional[Counter[str]] = self._scope_stack[-2] if len(self._scope_stack) >= 2 else None
                if class_scope is not None:
                    if isinstance(node, nodes.AssignAttr):
                        class_scope.setdefault(rest, 0)
                    else:
                        class_scope[rest] += 1
            else:
                self._RegisterUse(base)
                # For attribute reads on non-self locals, the full dotted name
                # is not a separate symbol - only the base variable matters
                # For attribute writes (e.g. file_ctx.file_data = ...), registering
                # the dotted name as a definition creates a phantom symbol that is
                # never looked up again and would always appear unused
                if not isinstance(node, nodes.AssignAttr):
                    self._RegisterUse(full)  # type: ignore

        elif isinstance(node, nodes.AugAssign):
            if isinstance(node.target, nodes.AssignName):
                self._RegisterUse(node.target.name)

            elif isinstance(node.target, nodes.AssignAttr):
                base, full = self._ExtractAttrChain(node.target)
                if base:
                    self._RegisterUse(base)
                    self._RegisterUse(full)  # type: ignore

        elif isinstance(node, nodes.AssignName):
            self._RegisterDefinition(node.name, line=node.lineno or 0)

        elif isinstance(node, nodes.Name):
            self._RegisterUse(node.name)

        elif isinstance(node, nodes.Comprehension):
            # Comprehension loop variables (eg. 'x' in '[f(x) for x in y]',-
            # -or 'avg, w' in 'sum(avg * w for avg, w in zip(...))') are always consumed by the-
            # -element expression. Because astroid visits the element expression before the generator-
            # -targets in DFS pre-order, the use fires before the definition, leaving the counter at 0
            # Pre-register each target name with count 1 so they are never flagged
            self._PreRegisterComprehensionTargets(node.target)

        elif isinstance(node, nodes.ExceptHandler) and node.name:
            self._RegisterDefinition(node.name.name, line=node.lineno or 0)

    @override
    def Leave(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        '''
        Called when exiting a node. Triggers scope analysis for the scope we just finished.
        '''
        if isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            self._PopScope(scope_type=self.SCOPE_FUNCTION)
            self._method_first_param.pop()

        elif isinstance(node, nodes.ClassDef):
            self._PopScope(scope_type=self.SCOPE_CLASS)
            self._class_stack.pop()
            self._class_method_sets.pop()

        elif isinstance(node, nodes.Module):
            self._PopScope(scope_type=self.SCOPE_GLOBAL)

    @override
    def Finalize(self, ctx: FileContext) -> None:
        while self._scope_stack:
            # If we are here, something went wrong with traversal or we are forcing cleanup
            # We assume global scope for safety
            self._PopScope(scope_type=self.SCOPE_GLOBAL)

        final_score: float = 100.0 * exp(-self._violations * self._k_sensitivity)
        ctx.AddEfficiencySignal(
            EfficiencyMetric.DEAD_CODE,
            SignalContext(final_score, 1.0)
        )

        if self._violations > 0:
            # Sort by line, pick top 3 for offenders
            sorted_details: List[Tuple[str, int, str]] = sorted(self._violation_details, key=lambda x: x[1])
            worst: List[Tuple[str, int, str]] = sorted_details[:3]

            # Bucket counts for summary
            reason_counts: Counter[str] = Counter(reason for _, _, reason in self._violation_details)

            ctx.SetMetricExplanation("DEAD_CODE", MetricExplanation(
                summary = (
                    f"{self._violations} dead code instance(s): "
                    + ", ".join(
                        f"{count} {reason}"
                        for reason, count in reason_counts.most_common()
                    ) + "."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  ({reason})",
                        severity = "medium" if reason == "unused import" or reason == "unreachable code" else "low",
                    )
                    for name, line, reason in worst
                ],
                fix = (
                    "Remove unused imports and variables. "
                    "Delete unreachable code after return/raise/break. "
                    "Remove branches that are always False."
                ),
            ))

        # Reset for future use
        self._violations         = 0
        self._violation_details  = []
        self._scope_stack        = []
        self._scope_line_stack   = []
        self._class_stack        = []
        self._method_first_param = []
        self._class_method_sets  = []

    # vvv Internal Functions vvv
    def _IsIgnorableName(self, name: str) -> bool:
        # Ignore pure underscores
        if name and all(c == '_' for c in name):
            return True

        # Ignore all dunder methods generically (future-proof)
        if len(name) > 4 and name.startswith("__") and name.endswith("__"):
            return True

        # Keep minimal explicit ignores
        if name in {"self", "cls"}:
            return True

        return False

    def _PushScope(self, scope_type: int) -> None:
        self._scope_stack.append(Counter())
        self._scope_line_stack.append({})
        self._scope_type_stack.append(scope_type)

    def _PopScope(self, scope_type: int) -> None:
        '''
        On scope exit, calculate violations.

        Args:
            scope_type: 'function', 'class', or 'module' determines strictness.
        '''
        if not self._scope_stack:
            return

        self._scope_type_stack.pop()

        scope: Counter[str] = self._scope_stack.pop()
        line_map: Dict[str, int] = self._scope_line_stack.pop()

        for name, count in scope.items():
            # If used, it is not dead code
            if count > 0:
                continue

            # If explicitly ignored (e.g. self, __init__)
            if self._IsIgnorableName(name):
                continue

            def_line: Optional[int] = line_map.get(name)
            if not def_line:
                continue

            should_flag: bool = False
            reason: str = "unused symbol"

            # Inside a function, any unused thing (variable, import, etc) is dead
            if scope_type == self.SCOPE_FUNCTION:
                should_flag = True

            elif scope_type == self.SCOPE_CLASS:
                current_methods: Set[str] = self._class_method_sets[-1] if self._class_method_sets else set()

                # Methods (even private) may be called by subclasses in other files, never flag them
                if name in current_methods:
                    continue

                # Methods or Attributes are usually for external use
                # Only flag private identifiers, functions and so on (starting with underscore)
                # Or public functions as well if toggled
                if self._flag_class_public or name.startswith('_'):
                    should_flag = True

            elif scope_type == self.SCOPE_GLOBAL:
                # Imports will always be flagged regardless
                if count == self.IMPORT_COUNTER:
                    should_flag = True
                    reason = "unused import"

                # If user wants to flag everything
                elif self._flag_globals:
                    should_flag = True

                # Only flag if it looks PRIVATE (starts with _)
                # "class User:" -> Public (Ignore)
                # "_INTERNAL_VAR = 1" -> Private (Flag if unused)
                elif name.startswith('_'):
                    should_flag = True

            if should_flag:
                self._violations += 1
                self._violation_details.append((name, def_line, reason))

    def _PreRegisterComprehensionTargets(self, target: nodes.NodeNG) -> None:
        '''
        Pre-registers comprehension loop variables as already-used (count=1).
        Handles simple names (x) and tuple unpacking ((a, b) or (avg, w)).
        '''
        if isinstance(target, nodes.AssignName):
            # Register at 0 first, then immediately mark as used
            self._RegisterDefinition(target.name)
            self._RegisterUse(target.name)

        elif isinstance(target, (nodes.Tuple, nodes.List)):
            # Tuple unpacking: for avg, w in ...  or  for (a, b, c) in ...
            for elt in target.elts:
                self._PreRegisterComprehensionTargets(elt) # type: ignore

    def _RegisterDefinition(self, name: str, is_import: bool = False, line: int = 0) -> None:
        '''
        NOTE: Import identifiers will start their counter from -1 to distinguish-
            -from other identifiers. Using them bumps it up to 1 directly, skipping 0
        '''
        if not self._scope_stack:
            return

        # Ignore names made only of underscores
        if name and all(c == '_' for c in name):
            return

        # Initialize with 0 uses if not already present
        if name not in self._scope_stack[-1]:
            self._scope_stack[-1][name] = self.IMPORT_COUNTER if is_import else 0
            self._scope_line_stack[-1][name] = line

    def _RegisterUse(self, name: str) -> None:
        '''
        Registers a symbol usage. 
        Searches from current scope upwards (LEGB rule approx).
        '''
        # Search scopes in reverse (nearest first)
        for i, scope in enumerate(reversed(self._scope_stack)):
            counter: Optional[int] = scope.get(name)

            if counter is None:
                continue

            # Python's LEGB rule skips class scopes for enclosed lookups.
            # Don't credit a class-scope non-import entry; keep searching outward.
            scope_type: int = self._scope_type_stack[len(self._scope_type_stack) - 1 - i]
            if scope_type == self.SCOPE_CLASS and counter != self.IMPORT_COUNTER:
                continue

            scope[name] = 1 if counter == self.IMPORT_COUNTER else counter + 1
            return

        # If not found in any scope, it's most likely a builtin or global import-
        # -that we haven't visited yet (or dynamic). We ignore it

    def _ExtractAttrChain(self, node: nodes.NodeNG) -> Tuple[Optional[str], Optional[str]]:
        parts: List[str] = []
        cur: nodes.NodeNG = node

        while isinstance(cur, (nodes.AssignAttr, nodes.Attribute)):
            parts.append(cur.attrname)
            cur = cur.expr

        if isinstance(cur, nodes.Name):
            parts.append(cur.name)
        else:
            return None, None   # Not a simple variable/attribute chain

        parts.reverse()
        base: str = parts[0]
        full: str = ".".join(parts)

        return base, full

    def _CheckUnreachableStatements(self, node: nodes.NodeNG) -> None:
        '''
        Flags code immediately following return/break/continue/raise.
        '''
        # Only check nodes that have a body list
        if not hasattr(node, 'body') or not isinstance(node.body, list): # type: ignore
            return

        body: List[nodes.NodeNG] = node.body # type: ignore
        terminal_found: bool = False

        for stmt in body:
            if terminal_found:
                self._violations += 1 # Every statement after is dead
                self._violation_details.append(("<stmt>", stmt.lineno or 0, "unreachable code"))

            elif isinstance(stmt, self._terminal_nodes):
                terminal_found = True

        # Check 'orelse' blocks (e.g., in loops or try blocks)
        if hasattr(node, 'orelse') and isinstance(node.orelse, list): # type: ignore
            terminal_found = False

            for stmt in node.orelse: # type: ignore
                if terminal_found:
                    self._violations += 1
                    self._violation_details.append(("<stmt>", stmt.lineno or 0, "unreachable code")) # type: ignore

                elif isinstance(stmt, self._terminal_nodes):
                    terminal_found = True

    def _CheckDeadBranches(self, node: nodes.NodeNG) -> None:
        '''
        Flags 'if False:', 'while 0:', 'if []:'
        '''
        if not isinstance(node, (nodes.If, nodes.While)):
            return

        test: nodes.NodeNG = node.test

        # Check for literal False, 0, None, "", etc.
        if isinstance(test, nodes.Const) and not bool(test.value):
            self._AddBlockViolations(node.body, reason="dead branch")

        # Empty collections evaluate to False
        # (Dict has 'items' and no 'elts'; astroid proxies unknown attributes to the builtin class)
        elif isinstance(test, (nodes.List, nodes.Tuple, nodes.Set)) and not test.elts:
            self._AddBlockViolations(node.body, reason="dead branch")

        elif isinstance(test, nodes.Dict) and not test.items:
                self._AddBlockViolations(node.body, reason="dead branch")

    def _CheckShadowedExceptions(self, node: nodes.NodeNG) -> None:
        '''
        Flags specific except blocks that appear after generic ones.
        '''
        if not isinstance(node, nodes.Try):
            return

        catch_all_found: bool = False

        for handler in node.handlers:
            if catch_all_found:
                # Dead Code: This handler can never be reached
                self._violations += 1
                self._violation_details.append(("<except>", handler.lineno or 0, "shadowed handler"))
                continue

            if handler.type is None: # bare 'except:'
                catch_all_found = True

            elif isinstance(handler.type, nodes.Name):
                if handler.type.name in ('Exception', 'BaseException'):
                    catch_all_found = True

    def _CheckPointlessExpressions(self, node: nodes.NodeNG) -> None:
        '''
        Flags self-assignments and floating literals.
        '''
        # Self assignment: x = x
        if isinstance(node, nodes.Assign) and len(node.targets) == 1:
            target: nodes.NodeNG = node.targets[0]

            if isinstance(target, nodes.AssignName) and isinstance(node.value, nodes.Name):
                if target.name == node.value.name:
                    self._violations += 1
                    self._violation_details.append((target.name, node.lineno or 0, "self-assignment"))
            return

        if isinstance(node, nodes.Expr):
            # Allow 'Yield' expressions (they have side effects)
            if isinstance(node.value, (nodes.Yield, nodes.YieldFrom, nodes.Call, nodes.Await)):
                return

            # Flag pointless expressions of Constants, BinOps, Bools
            if isinstance(node.value, (nodes.Const, nodes.List, nodes.Dict, nodes.Tuple, nodes.BinOp, nodes.BoolOp, nodes.UnaryOp)):
                self._violations += 1
                self._violation_details.append(("<expr>", node.lineno or 0, "pointless expression"))

    def _AddBlockViolations(self, body: List[nodes.NodeNG], reason: str = "dead branch") -> None:
        if not body:
            return

        for stmt in body:
            self._violations += 1
            self._violation_details.append(("<stmt>", stmt.lineno or 0, reason))