# My stuff
from core.context   import FileContext, MetricExplanation, OffenderContext, SignalContext
from core.enums     import ReadabilityMetric
from core.interface import BaseVisitor
from utils.pattern  import *
from utils.math     import ShannonEntropyFromCounts
from config         import Config, ConfigNamespace

# Python stuff
from astroid        import nodes # type: ignore
from typing         import Any, Dict, List, Optional, Set, Tuple, Type, Pattern, override
from collections    import Counter
from math           import exp
from pathlib        import Path
from keyword        import kwlist
import builtins
import gzip
import re

# vvv Base Helpers vvv
def _ResolveScope(node: nodes.NodeNG, name: str) -> nodes.NodeNG:
    current_scope: nodes.LocalsDictNodeNG = node.scope()
    if isinstance(current_scope, nodes.Module):
        return current_scope

    is_global: bool   = False
    is_nonlocal: bool = False

    body: List[nodes.NodeNG] = (
        getattr(current_scope, 'body', [])
        if not isinstance(current_scope, nodes.Lambda)
        else []
    )

    for child in body:
        if isinstance(child, nodes.Global) and name in child.names:
            is_global = True
            break
        if isinstance(child, nodes.Nonlocal) and name in child.names:
            is_nonlocal = True
            break

    if is_global:
        return node.root()

    if is_nonlocal:
        ancestor: Optional[nodes.NodeNG] = current_scope.parent
        while ancestor:
            scope: nodes.LocalsDictNodeNG = ancestor.scope()
            if name in scope.locals:
                return scope
            ancestor = ancestor.parent
        return node.root()

    return current_scope

def _GetNodeName(node: nodes.NodeNG) -> Optional[str]:
    return node.name if hasattr(node, "name") else None # type: ignore

# vvv Visitors vvv
class NestingVisitor(BaseVisitor):
    __slots__ = (
        "_max_feasible_nesting",
        "_k_nesting_sensitivity",
        "_excessive_depths",
    )

    def __init__(self) -> None:
        # Global Config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Settings vvv
        self._max_feasible_nesting: int    = self._readability_tuning.thresholds.max_feasible_nesting
        self._k_nesting_sensitivity: float = self._readability_tuning.sensitivity.nesting_depth

        # vvv Internals vvv
        self._excessive_depths: List[Tuple[int, int]]  = [] # (depth, line)

    @override
    def Visit(self, node: nodes.NodeNG, depth: int) -> None:
        if depth > self._max_feasible_nesting:
            self._excessive_depths.append((depth, node.lineno or 0))

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._excessive_depths:
            # One term per source line (its deepest node), not per AST node: a single deep
            # line with many sub-expressions used to drive the score straight to 0.
            deepest: Dict[int, int] = {}
            for d, line in self._excessive_depths:
                deepest[line] = max(d, deepest.get(line, 0))
            penalty = sum(
                (d - self._max_feasible_nesting) / self._max_feasible_nesting
                for d in deepest.values()
            ) * self._k_nesting_sensitivity

        ctx.AddReadabilitySignal(
            ReadabilityMetric.NESTING_DEPTH,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        # Build explanation: top 3 worst depths
        if self._excessive_depths:
            worst: List[Tuple[int, int]] = sorted(self._excessive_depths, key=lambda x: -x[0])[:3]
            avg_depth: float = sum(d for d, _ in self._excessive_depths) / len(self._excessive_depths)

            ctx.SetMetricExplanation("NESTING_DEPTH", MetricExplanation(
                summary   = f"avg depth {avg_depth:.1f}, max allowed is {self._max_feasible_nesting}."
                            f"{len(self._excessive_depths)} violation(s).",
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"depth {depth}",
                        severity = "high" if depth > self._max_feasible_nesting + 2 else "medium",
                    )
                    for depth, line in worst
                ],
                fix = "Flatten deeply nested logic into named helper functions.",
            ))

        # Reset for future use
        self._excessive_depths = []

class StyleVisitor(BaseVisitor):
    __slots__ = (
        "_identifier_styling", 
        "_k_style_sensitivity", 
        "_seen_constants",
        "_total_score",
        "_checked_count"
    )

    def __init__(self) -> None:
        # Global Config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Settings vvv
        self._identifier_styling: Dict[Type[nodes.NodeNG] | str, Pattern[str]] = {
            nodes.FunctionDef:      GetMatchingConfig(self._readability_tuning.identifier_style.function_def),
            nodes.AsyncFunctionDef: GetMatchingConfig(self._readability_tuning.identifier_style.async_function_def),
            nodes.ClassDef:         GetMatchingConfig(self._readability_tuning.identifier_style.class_def),
            "variable":             GetMatchingConfig(self._readability_tuning.identifier_style.variable),
            "instance_attr":        GetMatchingConfig(self._readability_tuning.identifier_style.instance_attr),
        }
        self._k_style_sensitivity: float = self._readability_tuning.sensitivity.identifier_style

        # vvv Internals vvv
        self._seen_constants: Dict[nodes.NodeNG, Set[str]] = {}
        self._total_score: float = 0.0
        self._checked_count: int = 0
        self._violations: List[Tuple[str, int, str, float]] = []  # (name, line, kind, match_pct)

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        score: float = self._CalculateScore(node)
        if score >= 0.0:
            self._total_score += score
            self._checked_count += 1

            # Track violations for explanation (anything below 100% match)
            if score < 100.0:
                name: Optional[str] = _GetNodeName(node)
                if not name and isinstance(node, nodes.AssignName):
                    name = node.name
                elif not name and isinstance(node, nodes.Attribute):
                    name = node.attrname

                kind: str = type(node).__name__
                if isinstance(node, nodes.AssignName):
                    kind = "variable"
                elif isinstance(node, nodes.Attribute):
                    kind = "instance_attr"

                if name:
                    self._violations.append((name, node.lineno or 0, kind, score))

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        score: float = 0.0
        if self._checked_count > 0:
            avg_match: float = (self._total_score / self._checked_count) / 100.0
            error_rate: float = 1.0 - avg_match
            score = error_rate * self._k_style_sensitivity

        ctx.AddReadabilitySignal(
            ReadabilityMetric.IDENTIFIER_STYLE,
            SignalContext(max(0.0, 100 * exp(-score)), 1.0)
        )

        if self._violations:
            # Sort by worst match percentage first
            worst: List[Tuple[str, int, str, float]] = sorted(
                self._violations, key=lambda x: x[3]
            )[:3]
            total_violations: int = len(self._violations)

            ctx.SetMetricExplanation("IDENTIFIER_STYLE", MetricExplanation(
                summary   = (
                    f"{total_violations} identifier(s) don't match the configured naming style. "
                    f"{self._checked_count} total identifiers checked."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  ({kind})",
                        severity = "high" if match_pct == 0.0 else "medium",
                    )
                    for name, line, kind, match_pct in worst
                ],
                fix = "Rename identifiers to match the configured style (see identifier_style in pymetricor.yml).",
            ))

        # Reset for future use
        self._seen_constants = {}
        self._total_score    = 0.0
        self._checked_count  = 0
        self._violations     = []

    # vvv Internal Function vvv
    def _CalculateScore(self, node: nodes.NodeNG) -> float:
        node_type: Type[nodes.NodeNG] = type(node)
        target_pattern: Optional[Pattern[str]] = None
        name: Optional[str] = None

        if isinstance(node, nodes.AssignName):
            name = node.name
            if name.isupper():
                # Constants will always be fixed to screaming snake case
                target_pattern = SCREAMING_SNAKE_CASE
                effective_scope: nodes.NodeNG = _ResolveScope(node, name)
                
                if effective_scope not in self._seen_constants:
                    self._seen_constants[effective_scope] = set()
                
                if name in self._seen_constants[effective_scope]:
                    return 0.0
                
                self._seen_constants[effective_scope].add(name)
            else:
                target_pattern = self._identifier_styling["variable"]

        elif node_type in self._identifier_styling:
            target_pattern = self._identifier_styling[node_type] # type: ignore
            name = _GetNodeName(node)

        elif isinstance(node, nodes.Attribute):
            if getattr(node.expr, 'name', None) == 'self':
                parent: Optional[nodes.NodeNG] = node.parent
                if isinstance(parent, (nodes.Assign, nodes.AnnAssign, nodes.AugAssign)):
                    target_pattern = self._identifier_styling["instance_attr"]
                    name = node.attrname

        if not target_pattern or not name or name.startswith("__"):
            return -1.0

        return GetMatchPercentage(name, target_pattern)

class IdentifierLengthVisitor(BaseVisitor):
    '''
    IDENTIFIER_LENGTH: share of distinct names (variables, parameters, functions, classes) shorter
    than 'min_identifier_length'. Short names are one of the strongest negative readability
    features in the code-readability literature (Buse & Weimer 2010, Scalabrino et al. 2018).
    Conventional short names are not counted: loop and comprehension targets (i, k, v),
    lambda parameters, exception names, and '_'.
    '''
    __slots__ = (
        "_min_length",
        "_k_length_sensitivity",
        "_names",
        "_short",
    )

    def __init__(self) -> None:
        # Global Config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Settings vvv
        self._min_length: int             = self._readability_tuning.thresholds.min_identifier_length
        self._k_length_sensitivity: float = self._readability_tuning.sensitivity.identifier_length

        # vvv Internals vvv
        self._names: Set[str]                 = set()
        self._short: Dict[str, int]           = {}  # name -> first line

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        name: Optional[str] = None
        if isinstance(node, nodes.AssignName):
            if not self._IsConventionalShortName(node):
                name = node.name
        elif isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.ClassDef)):
            name = node.name

        if not name or name == "_" or name in ("self", "cls"):
            return

        self._names.add(name)
        if len(name.lstrip("_")) < self._min_length and name not in self._short:
            self._short[name] = node.lineno or 0

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._names:
            penalty = (len(self._short) / len(self._names)) * self._k_length_sensitivity

        ctx.AddReadabilitySignal(
            ReadabilityMetric.IDENTIFIER_LENGTH,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if self._short:
            worst: List[Tuple[str, int]] = sorted(self._short.items(), key=lambda x: x[1])[:3]
            ctx.SetMetricExplanation("IDENTIFIER_LENGTH", MetricExplanation(
                summary   = (
                    f"{len(self._short)} of {len(self._names)} distinct name(s) are shorter than "
                    f"{self._min_length} characters."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = repr(name),
                        severity = "medium",
                    )
                    for name, line in worst
                ],
                fix = "Use descriptive names; keep single letters for loop counters and lambdas.",
            ))

        # Reset for future use
        self._names = set()
        self._short = {}

    # vvv Internal Function vvv
    @staticmethod
    def _IsConventionalShortName(node: nodes.AssignName) -> bool:
        parent: Optional[nodes.NodeNG] = node.parent
        # Unpack nested tuple targets: for k, v in ...
        while isinstance(parent, (nodes.Tuple, nodes.List, nodes.Starred)):
            parent = parent.parent
        if isinstance(parent, (nodes.For, nodes.AsyncFor, nodes.Comprehension, nodes.ExceptHandler)):
            return True
        if isinstance(parent, nodes.Arguments) and isinstance(parent.parent, nodes.Lambda):
            return True
        return False

class DocstringVisitor(BaseVisitor):
    __slots__ = (
        "_doc_weights",
        "_min_func_size",
        "_k_doc_sensitivity",
        "_total_score",
        "_checked_count"
    )

    def __init__(self) -> None:
        # Global Config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Settings vvv
        self._min_func_size: int = self._readability_tuning.thresholds.min_function_size
        self._k_doc_sensitivity: float = self._readability_tuning.sensitivity.docstring_quality

        # vvv Internals vvv
        self._doc_weights: Dict[str, float] = {
            'summary_presence': 0.25,
            'param_section':    0.10,
            'param_coverage':   0.30,
            'no_param_bonus':   0.40,
            'return_section':   0.20,
            'return_bonus':     0.20,
            'formatting':       0.15,
        }
        
        self._total_score: float = 0.0
        self._checked_count: int = 0
        self._missing_docs: List[Tuple[str, int, str]] = []  # (name, line, kind)

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        score: float = self._Analyze(node)
        if score >= 0.0:
            self._total_score += score
            self._checked_count += 1

            # Track undocumented callables for explanation
            if score == 0.0 and isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.ClassDef)):
                kind: str = "class" if isinstance(node, nodes.ClassDef) else "function"
                self._missing_docs.append((node.name, node.lineno or 0, kind))

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._checked_count > 0:
            avg_quality: float = self._total_score / self._checked_count
            gap: float = 1.0 - avg_quality
            penalty = gap * self._k_doc_sensitivity
        
        ctx.AddReadabilitySignal(
            ReadabilityMetric.COMMENT_DENSITY,
            SignalContext(max(0.0, 100 * exp(-penalty)), 1.0)
        )

        if self._missing_docs:
            worst: List[Tuple[str, int, str]] = self._missing_docs[:3]
            total_missing: int = len(self._missing_docs)

            ctx.SetMetricExplanation("COMMENT_DENSITY", MetricExplanation(
                summary   = (
                    f"{total_missing} function(s)/class(es) are missing docstrings out of "
                    f"{self._checked_count} checked."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  ({kind})",
                        severity = "medium",
                    )
                    for name, line, kind in worst
                ],
                fix = "Public functions and classes should ideally include docstrings. At minimum include a one-line summary.",
            ))

        # Reset for future use
        self._total_score   = 0.0
        self._checked_count = 0
        self._missing_docs  = []

    # vvv Internal Function vvv
    def _Analyze(self, node: nodes.NodeNG) -> float:
        is_func: bool   = isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef))
        is_class: bool  = isinstance(node, nodes.ClassDef)
        is_module: bool = isinstance(node, nodes.Module)

        if not (is_func or is_class or is_module):
            return -1.0

        if is_func:
            name: str = node.name
            if name.startswith("__") and name != "__init__":
                return -1.0
            if node.decorators:
                for dec in node.decorators.nodes:
                    if isinstance(dec, nodes.Attribute) and dec.attrname in ('setter', 'deleter'):
                        return -1.0
            if (node.tolineno - node.fromlineno) < self._min_func_size:
                return -1.0

        # Same rule for modules: a file shorter than a documentable function needs no module docstring
        if is_module and ((node.tolineno or 0) - (node.fromlineno or 0)) < self._min_func_size:
            return -1.0

        doc_node: Any = getattr(node, 'doc_node', None)
        docstring: Optional[str] = doc_node.value if doc_node else None

        if not docstring:
            return 0.0

        score: float = 0.0
        doc_lower: str = docstring.lower()
        lines: List[str] = docstring.strip().split('\n')
        weights: Dict[str, float] = self._doc_weights

        if len(lines) > 0 and len(lines[0].strip()) > 5:
            score += weights['summary_presence']

        args_to_check: List[str] = []
        if is_func and node.args:
            args_to_check = [a.name for a in node.args.args if a.name not in ('self', 'cls')] # type: ignore

        if args_to_check:
            if any(x in doc_lower for x in ('args:', 'arguments:', 'parameters:', 'params:')):
                score += weights['param_section']

            mentioned_count: int = sum(1 for arg in args_to_check if arg in docstring)
            coverage: float = mentioned_count / len(args_to_check)
            score += (weights['param_coverage'] * coverage)
        else:
            if len(docstring) > 20:
                score += weights['no_param_bonus']

        expects_return: bool = False
        if is_func and node.returns: # type: ignore
            if not (isinstance(node.returns, nodes.Const) and node.returns.value is None): # type: ignore
                expects_return = True
        
        if expects_return:
            if any(x in doc_lower for x in ('return:', 'returns:', 'yields:', 'yield:')):
                score += weights['return_section']
        else:
            score += weights['return_bonus']

        if len(lines) > 1:
            if not lines[1].strip():
                score += weights['formatting']
        elif docstring.strip().endswith((".", "!")):
            score += weights['formatting']

        return min(1.0, score)

class ConsistencyVisitor(BaseVisitor):
    __slots__ = (
        "_annotation_counter",
        "_format_counter",
        "_seen_assignments",
        "_k_annotation_consistency",
        "_k_string_consistency"
    )

    def __init__(self) -> None:        
        # Global Config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Settings vvv
        self._k_annotation_consistency: float    = self._readability_tuning.sensitivity.annotation_consistency
        self._k_string_format_consistency: float = self._readability_tuning.sensitivity.string_format_consistency

        # vvv Internals vvv
        self._annotation_counter: Counter[str] = Counter()
        self._format_counter: Counter[str] = Counter()
        self._seen_assignments: Dict[nodes.NodeNG, Set[str]] = {}

    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        if isinstance(node, nodes.AssignName):
            if not node.name.startswith("__"):
                name: str = node.name
                scope: nodes.NodeNG = _ResolveScope(node, name)

                if scope not in self._seen_assignments:
                    self._seen_assignments[scope] = set()

                if name not in self._seen_assignments[scope]:
                    self._seen_assignments[scope].add(name)

                    parent: Optional[nodes.NodeNG] = node.parent
                    if isinstance(parent, nodes.AnnAssign):
                        self._annotation_counter['antd'] += 1
                    elif isinstance(parent, nodes.Assign):
                        self._annotation_counter['unantd'] += 1

        elif isinstance(node, nodes.JoinedStr):
            self._format_counter['fstring'] += 1

        elif isinstance(node, nodes.BinOp):
            if node.op == '%' and \
               isinstance(node.left, nodes.Const) and \
               isinstance(node.left.value, str):
                self._format_counter['percent'] += 1

        elif isinstance(node, nodes.Call):
            func: nodes.NodeNG = node.func
            if isinstance(func, nodes.Attribute) and func.attrname == 'format':
                if isinstance(func.expr, nodes.Const) and isinstance(func.expr.value, str):
                    self._format_counter['format_method'] += 1

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        # Annotation Consistency
        an_score: float = 0.0
        if self._annotation_counter:
            an_score = ShannonEntropyFromCounts(self._annotation_counter) * self._k_annotation_consistency

        ctx.AddReadabilitySignal(
            ReadabilityMetric.ANNOTATION_CONSISTENCY,
            SignalContext(max(0.0, 100.0 * exp(-an_score)), 1.0)
        )

        if an_score > 0.0 and self._annotation_counter:
            antd:   int = self._annotation_counter.get('antd',   0)
            unantd: int = self._annotation_counter.get('unantd', 0)
            total:  int = antd + unantd
            majority: str = "annotated" if antd >= unantd else "unannotated"

            ctx.SetMetricExplanation("ANNOTATION_CONSISTENCY", MetricExplanation(
                summary   = (
                    f"{antd} annotated vs {unantd} unannotated assignments ({total} total). "
                    f"File is inconsistently mixed, majority is {majority}."
                ),
                offenders = [],  # No line-level offenders, this is a file-wide ratio
                fix       = (
                    "Inconsistent annotation usage may reduce clarity; consider standardizing where beneficial."
                ),
            ))

        # String Formatting Consistency
        sfc_score: float = 0.0
        if self._format_counter:
            sfc_score = ShannonEntropyFromCounts(self._format_counter) * self._k_string_format_consistency

        ctx.AddReadabilitySignal(
            ReadabilityMetric.STRING_FORMATTING_CONSISTENCY,
            SignalContext(max(0.0, 100.0 * exp(-sfc_score)), 1.0)
        )

        if sfc_score > 0.0 and self._format_counter:
            # Sort styles by usage count descending
            styles: List[Tuple[str, int]] = self._format_counter.most_common()
            dominant: str                 = styles[0][0]
            others: List[str]             = [s for s, _ in styles[1:] if _ > 0]

            _STYLE_NAMES: Dict[str, str] = {
                "fstring":       "f-strings",
                "percent":       "%-formatting",
                "format_method": ".format()",
            }

            dominant_name: str    = _STYLE_NAMES.get(dominant, dominant)
            other_names:   str    = ", ".join(_STYLE_NAMES.get(o, o) for o in others)

            ctx.SetMetricExplanation("STRING_FORMATTING_CONSISTENCY", MetricExplanation(
                summary   = (
                    f"Multiple string formatting styles in use: "
                    f"{dominant_name} (dominant) mixed with {other_names}."
                ),
                offenders = [],  # No line-level offenders, entropy is file-wide
                fix       = f"Standardise on one style. Prefer f-strings for new code.",
            ))

        # Reset for future use
        self._annotation_counter = Counter()
        self._format_counter     = Counter()
        self._seen_assignments   = {}
class CognitiveComplexityVisitor(BaseVisitor):
    '''
    COGNITIVE_COMPLEXITY: cognitive complexity (Campbell 2018) of the worst function in the file,
    with module-level code treated as one more function. Branches and loops cost 1 plus their
    nesting level, 'elif'/'else' and boolean operator sequences cost 1, nested functions and
    lambdas add a nesting level. Recursion is not counted.
    '''
    __slots__ = (
        "_max_complexity",
        "_k_cognitive_sensitivity",
        "_functions",
    )

    def __init__(self) -> None:
        # Global Config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Settings vvv
        self._max_complexity: int            = self._readability_tuning.thresholds.max_cognitive_complexity
        self._k_cognitive_sensitivity: float = self._readability_tuning.sensitivity.cognitive_complexity

        # vvv Internals vvv
        self._functions: List[Tuple[int, str, int]] = []  # (complexity, name, line)

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        if isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            self._functions.append((self._Statements(node.body, 0), node.name, node.lineno or 0))
        elif isinstance(node, nodes.Module):
            top_level: List[nodes.NodeNG] = [
                s for s in node.body
                if not isinstance(s, (nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.ClassDef))
            ]
            self._functions.append((self._Statements(top_level, 0), "<module>", 1))

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        worst: int     = max((c for c, _, _ in self._functions), default=0)
        penalty: float = max(0, worst - self._max_complexity) * self._k_cognitive_sensitivity

        ctx.AddReadabilitySignal(
            ReadabilityMetric.COGNITIVE_COMPLEXITY,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        over: List[Tuple[int, str, int]] = sorted(
            (f for f in self._functions if f[0] > self._max_complexity), key=lambda f: -f[0]
        )
        if over:
            ctx.SetMetricExplanation("COGNITIVE_COMPLEXITY", MetricExplanation(
                summary   = (
                    f"{len(over)} function(s) exceed cognitive complexity {self._max_complexity}. "
                    f"Worst is {over[0][1]!r} at {over[0][0]}."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}: {complexity}",
                        severity = "high" if complexity > 3 * self._max_complexity else "medium",
                    )
                    for complexity, name, line in over[:3]
                ],
                fix = "Flatten nested branches with early returns, and move inner blocks into named helpers.",
            ))

        # Reset for future use
        self._functions = []

    # vvv Internal Functions vvv
    def _Statements(self, body: List[nodes.NodeNG], nest: int) -> int:
        return sum(self._Statement(s, nest) for s in body)

    def _Expression(self, expr: Optional[nodes.NodeNG], nest: int) -> int:
        if expr is None:
            return 0
        total: int = 0
        pending: List[nodes.NodeNG] = [expr]
        while pending:
            n: nodes.NodeNG = pending.pop()
            if isinstance(n, nodes.BoolOp):
                total += 1
            elif isinstance(n, nodes.IfExp):
                total += 1 + nest
            elif isinstance(n, nodes.Lambda):
                total += self._Expression(n.body, nest + 1)
            pending.extend(n.get_children())
        return total

    def _IfChain(self, node: nodes.If, nest: int, is_elif: bool) -> int:
        total: int = (1 if is_elif else 1 + nest) + self._Expression(node.test, nest) + self._Statements(node.body, nest + 1)
        if len(node.orelse) == 1 and isinstance(node.orelse[0], nodes.If):
            total += self._IfChain(node.orelse[0], nest, True)
        elif node.orelse:
            total += 1 + self._Statements(node.orelse, nest + 1)
        return total

    def _Statement(self, s: nodes.NodeNG, nest: int) -> int:
        if isinstance(s, nodes.If):
            return self._IfChain(s, nest, False)
        if isinstance(s, (nodes.For, nodes.AsyncFor, nodes.While)):
            head: Optional[nodes.NodeNG] = s.test if isinstance(s, nodes.While) else s.iter
            total: int = 1 + nest + self._Expression(head, nest) + self._Statements(s.body, nest + 1)
            return total + (1 + self._Statements(s.orelse, nest + 1) if s.orelse else 0)
        if isinstance(s, (nodes.Try, nodes.TryStar)):
            total = self._Statements(s.body, nest) + self._Statements(s.orelse, nest) + self._Statements(s.finalbody, nest)
            return total + sum(1 + nest + self._Statements(h.body, nest + 1) for h in s.handlers)
        if isinstance(s, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            return self._Statements(s.body, nest + 1)
        if isinstance(s, nodes.ClassDef):
            return 0
        if isinstance(s, (nodes.With, nodes.AsyncWith)):
            return self._Statements(s.body, nest)
        if isinstance(s, nodes.Match):
            return 1 + nest + sum(self._Statements(c.body, nest + 1) for c in s.cases)
        return sum(self._Expression(c, nest) for c in s.get_children() if not c.is_statement)

class IdentifierQualityVisitor(BaseVisitor):
    '''
    IDENTIFIER_QUALITY: share of distinct names (variables, parameters, functions, classes) that are
    not made of English words or abbreviations conventional in code. Names are split at underscores
    and case changes ('maxDepth' -> max, depth). Single-letter loop and comprehension targets are
    allowed; builtins and dunder names are skipped. The word list is SCOWL (see core/data).
    '''
    __slots__ = (
        "_k_quality_sensitivity",
        "_names",
        "_loop_names",
        "_unknown",
    )

    _WORDS: Optional[Set[str]] = None
    _SKIP: Set[str]            = set(dir(builtins)) | set(kwlist) | {"self", "cls", "_"}

    def __init__(self) -> None:
        # Global Config
        self._readability_tuning: ConfigNamespace = Config().metrics.tuning.readability

        # vvv Settings vvv
        self._k_quality_sensitivity: float = self._readability_tuning.sensitivity.identifier_quality

        # vvv Internals vvv
        self._names: Dict[str, int]  = {}  # name -> first line
        self._loop_names: Set[str]   = set()

        if IdentifierQualityVisitor._WORDS is None:
            IdentifierQualityVisitor._WORDS = _LoadKnownWords()

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None: # type: ignore
        name: Optional[str] = None
        if isinstance(node, nodes.AssignName):
            parent: Optional[nodes.NodeNG] = node.parent
            if isinstance(parent, nodes.ExceptHandler):
                return
            if isinstance(parent, nodes.Arguments) and isinstance(parent.parent, nodes.Lambda):
                return
            while isinstance(parent, (nodes.Tuple, nodes.List, nodes.Starred)):
                parent = parent.parent
            if isinstance(parent, (nodes.For, nodes.AsyncFor, nodes.Comprehension)):
                self._loop_names.add(node.name)
            name = node.name
        elif isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef, nodes.ClassDef)):
            name = node.name

        if not name or name in self._SKIP or name.startswith("__"):
            return
        self._names.setdefault(name, node.lineno or 0)

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None: # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        unknown: List[Tuple[str, int]] = [(n, line) for n, line in self._names.items() if not self._IsReadable(n)]
        penalty: float = len(unknown) / len(self._names) * self._k_quality_sensitivity if self._names else 0.0

        ctx.AddReadabilitySignal(
            ReadabilityMetric.IDENTIFIER_QUALITY,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if unknown:
            ctx.SetMetricExplanation("IDENTIFIER_QUALITY", MetricExplanation(
                summary   = (
                    f"{len(unknown)} of {len(self._names)} distinct name(s) are not words or common abbreviations."
                ),
                offenders = [
                    OffenderContext(filepath=ctx.file_path, line=line, detail=repr(name), severity="medium")
                    for name, line in sorted(unknown, key=lambda x: x[1])[:3]
                ],
                fix = "Spell names out ('count' rather than 'cnt2'), or add project terms to code_abbreviations.txt.",
            ))

        # Reset for future use
        self._names      = {}
        self._loop_names = set()

    # vvv Internal Function vvv
    def _IsReadable(self, name: str) -> bool:
        if len(name) == 1:
            return name in self._loop_names
        words: Set[str] = self._WORDS or set()
        # A one-letter part of a longer name ('x_pos', 'getX') is a coordinate or index, not a cryptic word
        return all(w in words or len(w) == 1 for w in _SplitIdentifier(name))

def _SplitIdentifier(name: str) -> List[str]:
    '''snake_case and camelCase parts, lower-cased; digits dropped.'''
    parts: List[str] = []
    for chunk in re.split(r"_+", name):
        parts += re.findall(r"[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z]+|[A-Z]+|\d+", chunk)
    return [p.lower() for p in parts if p and not p.isdigit()]

def _LoadKnownWords() -> Set[str]:
    data: Path = Path(__file__).resolve().parent.parent / "data"
    with gzip.open(data / "english_words.txt.gz", "rt", encoding="utf-8") as f:
        words: Set[str] = {w.strip() for w in f if w.strip()}
    for line in (data / "code_abbreviations.txt").read_text(encoding="utf-8").splitlines():
        if line.strip() and not line.startswith("#"):
            words.add(line.strip())
    return words
