# My stuff
from core.context   import FileContext, MetricExplanation, OffenderContext, SignalContext
from core.enums     import MaintainabilityMetric
from core.interface import BaseVisitor
from config         import Config, ConfigNamespace

# Python stuff
from astroid        import nodes # type: ignore
from typing         import List, Set, Tuple, override
from math           import exp, log2
from collections    import Counter

# vvv Visitors vvv
class ParameterBloat(BaseVisitor):
    __slots__ = (
        "_max_feasible_param_count",
        "_k_param_count_sensitivity",
        "_excessive_param_count",
        "_excessive_details",
        "_class_scopes",
    )

    def __init__(self) -> None:
        # Global Config
        self._maintainability_tuning: ConfigNamespace = Config().metrics.tuning.maintainability

        # vvv Settings vvv
        self._max_feasible_param_count: int = self._maintainability_tuning.thresholds.max_parameter_bloat
        self._k_param_count_sensitivity: float = self._maintainability_tuning.sensitivity.parameter_bloat

        # vvv Internals vvv
        self._excessive_param_count: List[int] = []
        self._excessive_details: List[Tuple[str, int, int]] = []
        self._class_scopes: int = 0

    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if isinstance(node, nodes.ClassDef):
            self._class_scopes += 1
            return

        # TODO: Handle lambda functions later on
        if not isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            return

        if node.name == "__init__":
            return

        args: nodes.Arguments = node.args

        param_count: int = len(args.args)    # type: ignore (normal positional args)
        param_count += len(args.kwonlyargs)  # keyword only args
        param_count += len(args.posonlyargs) # position only args

        if self._class_scopes > 0:
            dec_names: Set[str] = set()
            if node.decorators:
                for dec in node.decorators.nodes:
                    if isinstance(dec, nodes.Name):
                        dec_names.add(dec.name)
                    elif isinstance(dec, nodes.Attribute):
                        dec_names.add(dec.attrname)

            if "staticmethod" not in dec_names and param_count > 0:
                param_count -= 1 # Subtract 1 for self / cls

        if param_count > self._max_feasible_param_count:
            self._excessive_param_count.append(param_count)
            self._excessive_details.append((node.name, node.lineno or 0, param_count))

    @override
    def Leave(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if isinstance(node, nodes.ClassDef):
            self._class_scopes -= 1

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._excessive_param_count:
            # Simple sum of overages scaled by sensitivity
            penalty = sum(
                (p - self._max_feasible_param_count) / self._max_feasible_param_count
                for p in self._excessive_param_count
            ) * self._k_param_count_sensitivity

        ctx.AddMaintainabilitySignal(
            MaintainabilityMetric.PARAMETER_BLOAT,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if self._excessive_details:
            worst: List[Tuple[str, int, int]] = sorted(self._excessive_details, key=lambda x: -x[2])[:3]
            ctx.SetMetricExplanation("PARAMETER_BLOAT", MetricExplanation(
                summary   = (
                    f"{len(self._excessive_details)} function(s) exceed the "
                    f"{self._max_feasible_param_count}-parameter limit."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  ({count} params)",
                        severity = "high" if count > self._max_feasible_param_count * 2 else "medium",
                    )
                    for name, line, count in worst
                ],
                fix = (
                    "Group related parameters into a dataclass or config object. "
                    f"Aim for {self._max_feasible_param_count} or fewer parameters per function."
                ),
            ))

        # Reset for future use
        self._excessive_param_count = []
        self._excessive_details     = []
        self._class_scopes          = 0

class MethodReceiverNamingConsistency(BaseVisitor):
    __slots__ = (
        "_class_scopes",
        "_total_methods",
        "_violations",
        "_violation_details",
        "_k_receiver_consistency",
    )

    def __init__(self) -> None:
        # Global Config
        self._maintainability_tuning: ConfigNamespace = Config().metrics.tuning.maintainability

        # vvv Settings vvv
        self._k_receiver_consistency: float = self._maintainability_tuning.sensitivity.method_receiver_naming

        # vvv Internals vvv
        self._class_scopes: int = 0
        self._total_methods: int = 0
        self._violations: int = 0
        self._violation_details: List[Tuple[str, int, str, str]] = []

    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if isinstance(node, nodes.ClassDef):
            self._class_scopes += 1
            return

        if not isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            return

        if self._class_scopes == 0 or not node.args.args:
            return

        dec_names: Set[str] = set()
        if node.decorators:
            for dec in node.decorators.nodes:
                if isinstance(dec, nodes.Name):
                    dec_names.add(dec.name)
                elif isinstance(dec, nodes.Attribute):
                    dec_names.add(dec.attrname)

        if "staticmethod" in dec_names:
            return

        receiver_name: str = node.args.args[0].name # type: ignore
        self._total_methods += 1

        expected: str = "cls" if "classmethod" in dec_names else "self"
        if receiver_name != expected:
            self._violations += 1
            self._violation_details.append(
                (node.name, node.lineno or 0, receiver_name, expected)
            )

    @override
    def Leave(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if isinstance(node, nodes.ClassDef):
            self._class_scopes -= 1

    @override
    def Finalize(self, ctx: FileContext) -> None:
        score: float = 100.0
        if self._total_methods > 0:
            score = 100.0 * (1.0 - (self._violations / self._total_methods))

        ctx.AddMaintainabilitySignal(
            MaintainabilityMetric.METHOD_RECEIVER_NAMING_CONSISTENCY, 
            SignalContext(max(0.0, score), 1.0)
        )

        if self._violation_details:
            worst: List[Tuple[str, int, str, str]] = self._violation_details[:3]
            ctx.SetMetricExplanation("METHOD_RECEIVER_NAMING_CONSISTENCY", MetricExplanation(
                summary   = (
                    f"{self._violations}/{self._total_methods} method(s) use a non-standard "
                    "receiver name."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  (got {bad!r}, expected {expected!r})",
                        severity = "low",
                    )
                    for name, line, bad, expected in worst
                ],
                fix = "Rename the first parameter to 'self' for instance methods and 'cls' for classmethods.",
            ))

        # Reset for future use
        self._class_scopes      = 0
        self._total_methods     = 0
        self._violations        = 0
        self._violation_details = []

class FunctionLength(BaseVisitor):
    __slots__ = (
        "_max_feasible_length",
        "_k_length_sensitivity",
        "_excessive_lengths",
        "_excessive_details",
    )

    def __init__(self) -> None:
        # Global Config
        self._maintainability_tuning: ConfigNamespace = Config().metrics.tuning.maintainability

        # vvv Settings vvv
        self._max_feasible_length: int = self._maintainability_tuning.thresholds.max_function_length
        self._k_length_sensitivity: float = self._maintainability_tuning.sensitivity.function_length

        # vvv Internals vvv
        # List of functions exceeding the limit (exceeding depth)
        self._excessive_lengths: List[int] = []
        self._excessive_details: List[Tuple[str, int, int]] = []

    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if not isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            return

        if node.lineno is None:
            return

        length: int = node.tolineno - node.lineno

        if length > self._max_feasible_length:
            self._excessive_lengths.append(length)
            self._excessive_details.append((node.name, node.lineno, length))

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None:  # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._excessive_lengths:
            penalty = sum(
                (length - self._max_feasible_length) / self._max_feasible_length
                for length in self._excessive_lengths
            ) * self._k_length_sensitivity

        ctx.AddMaintainabilitySignal(
            MaintainabilityMetric.FUNCTION_LENGTH,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if self._excessive_details:
            worst: List[Tuple[str, int, int]] = sorted(self._excessive_details, key=lambda x: -x[2])[:3]
            ctx.SetMetricExplanation("FUNCTION_LENGTH", MetricExplanation(
                summary   = (
                    f"{len(self._excessive_details)} function(s) exceed "
                    f"{self._max_feasible_length} lines."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  ({length} lines)",
                        severity = "high" if length > self._max_feasible_length * 2 else "medium",
                    )
                    for name, line, length in worst
                ],
                fix = (
                    "Split long functions into smaller, single-purpose helpers. "
                    f"Aim for under {self._max_feasible_length} lines per function."
                ),
            ))

        # Reset for future use
        self._excessive_lengths = []
        self._excessive_details = []

class InheritanceDepth(BaseVisitor):
    __slots__ = (
        "_max_feasible_depth",
        "_k_depth_sensitivity",
        "_excessive_depths",
        "_excessive_details",
    )

    def __init__(self) -> None:
        # Global Config
        self._maintainability_tuning: ConfigNamespace = Config().metrics.tuning.maintainability

        # vvv Settings vvv
        self._max_feasible_depth: int = self._maintainability_tuning.thresholds.max_inheritance_depth
        self._k_depth_sensitivity: float = self._maintainability_tuning.sensitivity.inheritance_depth

        # vvv Internals vvv
        # List of classes exceeding depth limit (exceeding depth)
        self._excessive_depths: List[int] = []
        self._excessive_details: List[Tuple[str, int, int]] = []

    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if not isinstance(node, nodes.ClassDef):
            return

        try:
            depth: int = len(list(node.ancestors()))
        except Exception:
            # Fallback in case astroid cannot resolve the MRO
            depth = len(node.bases)

        if depth > self._max_feasible_depth:
            self._excessive_depths.append(depth)
            self._excessive_details.append((node.name, node.lineno or 0, depth))

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None:  # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._excessive_depths:
            penalty = sum(
                (depth - self._max_feasible_depth) / self._max_feasible_depth
                for depth in self._excessive_depths
            ) * self._k_depth_sensitivity

        ctx.AddMaintainabilitySignal(
            MaintainabilityMetric.INHERITANCE_DEPTH,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if self._excessive_details:
            worst: List[Tuple[str, int, int]] = sorted(self._excessive_details, key=lambda x: -x[2])[:3]
            ctx.SetMetricExplanation("INHERITANCE_DEPTH", MetricExplanation(
                summary   = (
                    f"{len(self._excessive_details)} class(es) exceed "
                    f"inheritance depth {self._max_feasible_depth}."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  (depth {depth})",
                        severity = "high" if depth > self._max_feasible_depth * 2 else "medium",
                    )
                    for name, line, depth in worst
                ],
                fix = (
                    "Prefer composition over deep inheritance chains. "
                    "Consider flattening the hierarchy or using mixins."
                ),
            ))

        # Reset for future use
        self._excessive_depths = []
        self._excessive_details = []

class ExceptionHygiene(BaseVisitor):
    '''
    This visitor flags the following four anti-patterns as violations:
    1. Bare except clauses (e.g., `except:`).
    2. Catching broad exceptions (`Exception` or `BaseException`).
    3. Raising broad exceptions (`Exception` or `BaseException`).
    4. Swallowing exceptions (an `except` block containing only `pass` or `...`).
    '''
    __slots__ = (
        "_max_allowed_violations",
        "_violations",
        "_violation_details",
        "_k_penalty",
    )

    def __init__(self) -> None:
        # Global Config
        self._maintainability_tuning: ConfigNamespace = Config().metrics.tuning.maintainability

        # vvv Settings vvv
        self._max_allowed_violations: int = self._maintainability_tuning.thresholds.max_exception_violations
        self._k_penalty: float = self._maintainability_tuning.sensitivity.exception_violations

        # vvv Internals vvv
        self._violations: int = 0
        self._violation_details: List[Tuple[str, int]] = []
        self._broad_names: Set[str] = {"Exception", "BaseException"}

    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if isinstance(node, nodes.ExceptHandler):
            # Bare except
            if node.type is None:
                self._violations += 1
                self._violation_details.append(("bare except", node.lineno or 0))
            
            # Catching Exception or BaseException
            elif isinstance(node.type, nodes.Name) and node.type.name in self._broad_names:
                self._violations += 1
                self._violation_details.append((f"catches {node.type.name}", node.lineno or 0))
            
            elif isinstance(node.type, nodes.Tuple):
                if any(isinstance(elt, nodes.Name) and elt.name in self._broad_names for elt in node.type.elts):
                    self._violations += 1
                    self._violation_details.append(("catches broad exception in tuple", node.lineno or 0))

            # Swallowed exception (only pass or ...)
            if len(node.body) == 1:
                stmt: nodes.NodeNG = node.body[0]
                is_pass: bool = isinstance(stmt, nodes.Pass)
                is_ellipsis: bool = (
                    isinstance(stmt, nodes.Expr) and 
                    isinstance(stmt.value, nodes.Const) and 
                    stmt.value.value is Ellipsis
                )

                if is_pass or is_ellipsis:
                    self._violations += 1
                    self._violation_details.append(("swallowed exception", node.lineno or 0))
            return

        if isinstance(node, nodes.Raise):
            if not node.exc:
                return

            exc_name: str = ""
            if isinstance(node.exc, nodes.Name):
                exc_name = node.exc.name
            elif isinstance(node.exc, nodes.Call) and isinstance(node.exc.func, nodes.Name):
                exc_name = node.exc.func.name
            
            # Raising Exception or BaseException
            if exc_name in self._broad_names:
                self._violations += 1
                self._violation_details.append((f"raises {exc_name}", node.lineno or 0))

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None:  # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._violations > self._max_allowed_violations:
            excess_violations = self._violations - self._max_allowed_violations
            penalty = excess_violations * self._k_penalty
        
        ctx.AddMaintainabilitySignal(
            MaintainabilityMetric.EXCEPTION_HYGIENE,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if self._violations > self._max_allowed_violations:
            worst: List[Tuple[str, int]] = sorted(self._violation_details, key=lambda x: x[1])[:3]
            kind_counts: Counter[str] = Counter(k for k, _ in self._violation_details)

            ctx.SetMetricExplanation("EXCEPTION_HYGIENE", MetricExplanation(
                summary   = (
                    f"{self._violations} exception hygiene violation(s): "
                    + ", ".join(f"{c} {k}" for k, c in kind_counts.most_common()) + "."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = kind,
                        severity = "high" if "swallowed" in kind or "bare" in kind else "medium",
                    )
                    for kind, line in worst
                ],
                fix = (
                    "Catch specific exception types. "
                    "Never silence exceptions with bare pass. "
                    "Raise specific exceptions instead of Exception/BaseException."
                ),
            ))

        # Reset for future use
        self._violations = 0
        self._violation_details = []

class ClassComplexity(BaseVisitor):
    '''
    Composite complexity score for each ClassDef, built from three dimensions:

      1. Public method count  — methods whose names do not start with '_'.
         Threshold: 10. Dunder methods (__x__) are excluded; they are
         interface implementations, not complexity contributors.

      2. Instance attribute count — unique 'self.x' assignments found in any
         method body (detected via Attribute nodes where expr is 'self').
         Threshold: 10.

      3. Direct base class count — len(node.bases), ignoring 'object'.
         Threshold: 3. (InheritanceDepth handles deep chains; this targets
         wide multiple-inheritance fan-out.)

    Each dimension contributes independently to the penalty using the same
    normalised-sum + exp(-penalty) pattern. The three sub-penalties are
    summed before applying sensitivity scaling so that a class that is
    simultaneously wide, attribute-heavy, and multi-inherited is penalised
    proportionally harder than one that violates only a single dimension.
    '''
    __slots__ = (
        "_max_feasible_methods",
        "_max_feasible_attributes",
        "_max_feasible_bases",
        "_k_complexity_sensitivity",
        # per-class accumulators
        "_in_class_scope",
        "_current_class_name",
        "_current_class_line",
        "_current_method_count",
        "_current_attribute_names",
        "_current_base_count",
        # collected per-class penalties
        "_class_penalties",
        "_class_details",
    )

    def __init__(self) -> None:
        # Global Config
        self._maintainability_tuning: ConfigNamespace = Config().metrics.tuning.maintainability

        # vvv Settings vvv
        self._max_feasible_methods: int       = self._maintainability_tuning.thresholds.max_class_methods
        self._max_feasible_attributes: int    = self._maintainability_tuning.thresholds.max_class_attributes
        self._max_feasible_bases: int         = self._maintainability_tuning.thresholds.max_class_bases
        self._k_complexity_sensitivity: float = self._maintainability_tuning.sensitivity.class_complexity

        # vvv Internals vvv
        self._in_class_scope: int = 0
        self._current_class_name: str = ""
        self._current_class_line: int = 0 
        self._current_method_count: int = 0
        self._current_attribute_names: Set[str] = set()
        self._current_base_count: int = 0
        self._class_penalties: List[float] = []
        self._class_details: List[Tuple[str, int, int, int, int]] = [] # (name, line, methods, attrs, bases)

    def _is_dunder(self, name: str) -> bool:
        return name.startswith("__") and name.endswith("__")

    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if isinstance(node, nodes.ClassDef):
            self._in_class_scope += 1
            # Only initialise counters when entering the outermost class
            if self._in_class_scope == 1:
                self._current_class_name = node.name
                self._current_class_line = node.lineno or 0
                self._current_method_count = 0
                self._current_attribute_names = set()
                # Count direct bases, excluding bare 'object'
                self._current_base_count = sum(
                    1 for base in node.bases
                    if not (isinstance(base, nodes.Name) and base.name == "object")
                )
            return

        if self._in_class_scope != 1:
            # Only inspect the immediate body of the outermost class
            return

        # Count public, non-dunder methods defined directly on the class
        if isinstance(node, (nodes.FunctionDef, nodes.AsyncFunctionDef)):
            if not node.name.startswith("_") or self._is_dunder(node.name):
                if not self._is_dunder(node.name):
                    self._current_method_count += 1
            return

        # Detect instance attribute assignments: self.x = ... or self.x: T = ...
        # These appear as Attribute nodes where expr is a Name("self")
        if isinstance(node, nodes.AssignAttr):
            if isinstance(node.expr, nodes.Name) and node.expr.name == "self":
                self._current_attribute_names.add(node.attrname)

    @override
    def Leave(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        if not isinstance(node, nodes.ClassDef):
            return

        self._in_class_scope -= 1

        # Score only when leaving the outermost class
        if self._in_class_scope == 0:
            method_excess: float = max(
                0, self._current_method_count - self._max_feasible_methods
            ) / self._max_feasible_methods

            attr_excess: float = max(
                0, len(self._current_attribute_names) - self._max_feasible_attributes
            ) / self._max_feasible_attributes

            base_excess: float = max(
                0, self._current_base_count - self._max_feasible_bases
            ) / self._max_feasible_bases

            class_penalty: float = (method_excess + attr_excess + base_excess)
            if class_penalty > 0.0:
                self._class_penalties.append(class_penalty)
                self._class_details.append((
                    self._current_class_name,
                    self._current_class_line,
                    self._current_method_count,
                    len(self._current_attribute_names),
                    self._current_base_count,
                ))

            # Reset for the next class
            self._current_class_name      = ""
            self._current_class_line      = 0
            self._current_method_count    = 0
            self._current_attribute_names = set()
            self._current_base_count      = 0

    @override
    def Finalize(self, ctx: FileContext) -> None:
        penalty: float = 0.0
        if self._class_penalties:
            penalty = sum(self._class_penalties) * self._k_complexity_sensitivity

        ctx.AddMaintainabilitySignal(
            MaintainabilityMetric.CLASS_COMPLEXITY,
            SignalContext(max(0.0, 100.0 * exp(-penalty)), 1.0)
        )

        if self._class_details:
            # Sort by total overage (methods + attrs + bases) descending
            worst: List[Tuple[str, int, int, int, int]] = sorted(
                self._class_details,
                key=lambda x: x[2] + x[3] + x[4],
                reverse=True,
            )[:3]

            def _dims(m: int, a: int, b: int) -> str:
                parts: List[str] = []

                if m > self._max_feasible_methods:    parts.append(f"{m} methods")
                if a > self._max_feasible_attributes: parts.append(f"{a} attributes")
                if b > self._max_feasible_bases:      parts.append(f"{b} bases")

                return ", ".join(parts) if parts else "over threshold"

            ctx.SetMetricExplanation("CLASS_COMPLEXITY", MetricExplanation(
                summary   = (
                    f"{len(self._class_details)} class(es) exceed complexity thresholds "
                    f"(methods >{self._max_feasible_methods}, "
                    f"attributes >{self._max_feasible_attributes}, "
                    f"bases >{self._max_feasible_bases})."
                ),
                offenders = [
                    OffenderContext(
                        filepath = ctx.file_path,
                        line     = line,
                        detail   = f"{name!r}  ({_dims(m, a, b)})",
                        severity = "high" if (m + a + b) > (self._max_feasible_methods + self._max_feasible_attributes + self._max_feasible_bases) * 1.5 else "medium",
                    )
                    for name, line, m, a, b in worst
                ],
                fix = (
                    "Split large classes using the Single Responsibility Principle. "
                    "Move attributes into smaller data classes. "
                    "Replace multiple inheritance with composition."
                ),
            ))

        # Reset for future use
        self._in_class_scope          = 0
        self._current_class_name      = ""
        self._current_class_line      = 0
        self._current_method_count    = 0
        self._current_attribute_names = set()
        self._current_base_count      = 0
        self._class_penalties         = []
        self._class_details           = []
class ModuleCoupling(BaseVisitor):
    '''
    Import coupling of the file's module within the analysed project (core/modules.py):
    fan-out above max_fan_out, fan-in above max_fan_in, and membership of a load-time
    import cycle. A file analysed on its own has no project imports and scores 100.
    '''
    __slots__ = (
        "_max_fan_out",
        "_max_fan_in",
        "_k_fan_out",
        "_k_fan_in",
        "_k_cycle",
    )

    def __init__(self) -> None:
        # Global Config
        _tuning: ConfigNamespace = Config().metrics.tuning.maintainability

        # vvv Settings vvv
        self._max_fan_out: int = _tuning.thresholds.max_fan_out
        self._max_fan_in:  int = _tuning.thresholds.max_fan_in
        self._k_fan_out: float = _tuning.sensitivity.fan_out
        self._k_fan_in:  float = _tuning.sensitivity.fan_in
        self._k_cycle:   float = _tuning.sensitivity.import_cycle

    @override
    def Visit(self, _: nodes.NodeNG, __: int) -> None:  # type: ignore
        pass

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None:  # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        deps = ctx.module_graph.For(ctx.file_path) if ctx.module_graph else None
        if deps is None:
            ctx.AddMaintainabilitySignal(MaintainabilityMetric.MODULE_COUPLING, SignalContext(100.0, 1.0))
            return

        excess_out: int = max(0, deps.fan_out - self._max_fan_out)
        excess_in:  int = max(0, deps.fan_in  - self._max_fan_in)
        cycle_size: int = len(deps.cycle) + 1 if deps.cycle else 0
        penalty: float  = (
            self._k_fan_out * excess_out
            + self._k_fan_in * excess_in
            + (self._k_cycle * log2(min(cycle_size, 16)) if cycle_size else 0.0)
        )
        ctx.AddMaintainabilitySignal(
            MaintainabilityMetric.MODULE_COUPLING,
            SignalContext(100.0 * exp(-penalty), 1.0)
        )

        if penalty > 0.0:
            problems: List[str] = []
            if excess_out: problems.append(f"imports {deps.fan_out} project modules (max {self._max_fan_out})")
            if excess_in:  problems.append(f"is imported by {deps.fan_in} project modules (max {self._max_fan_in})")
            if cycle_size: problems.append(f"is in an import cycle of {cycle_size} modules")
            offenders: List[OffenderContext] = [
                OffenderContext(
                    filepath = ctx.file_path,
                    line     = 1,
                    detail   = f"cycle: {deps.module} -> " + " -> ".join(deps.cycle[:4]) + (" ..." if len(deps.cycle) > 4 else ""),
                    severity = "high" if cycle_size > 2 else "medium",
                )
            ] if cycle_size else []
            ctx.SetMetricExplanation("MODULE_COUPLING", MetricExplanation(
                summary   = f"Module {deps.module} " + "; ".join(problems) + ".",
                offenders = offenders,
                fix       = (
                    "Move shared code into a lower-level module both sides can import, invert the dependency, "
                    "or defer the import into the function that needs it. Split modules that import too much."
                ),
            ))
