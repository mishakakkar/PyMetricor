# My stuff
from core.context               import FileContext, MetricExplanation, OffenderContext, SignalContext
from core.enums                 import SecurityMetric
from core.interface             import BaseVisitor
from config                     import Config, ConfigNamespace

from core.reasoning.loader      import LoadSchema, SchemaBundle
from core.reasoning.interpreter import Interpreter
from core.reasoning.project     import ProjectIndex
from core.reasoning.summaries   import SummaryEngine
from core.reasoning.queries     import EvaluateAll, Finding, SEVERITY_RANK

# Python stuff
from astroid  import nodes # type: ignore
from math     import exp
from pathlib  import Path
from typing   import Dict, List, Optional, override

# Schema is loaded once at import time, not per-file, not per-visitor instance
# security.py -> visitors/ -> core/ -> root/ (where schema.yml is located)
_SCHEMA_BUNDLE: SchemaBundle = LoadSchema(Path(__file__).parent.parent.parent / "schema.yml")

# Capabilities that map to each SecurityMetric
# Template injection runs template code, so it counts as code execution
_RCE_CAPABILITIES:    frozenset[str] = frozenset({"INVOKE_DYNAMIC", "SPAWN_PROCESS", "PERFORM_REFLECTION", "DESERIALIZE",
                                                  "RENDER_TEMPLATE"})
_CRYPTO_CAPABILITIES: frozenset[str] = frozenset({"PERFORM_CRYPTO"})
_FILE_CAPABILITIES:   frozenset[str] = frozenset({"MODIFY_FILESYSTEM", "EXTRACT_ARCHIVE"})
_INJECTION_CAPABILITIES: frozenset[str] = frozenset({"EXECUTE_QUERY", "SEND_REQUEST"})

_SEVERITY_WEIGHT: Dict[str, float] = {
    "info":     0.0,
    "low":      0.01,
    "medium":   1.0,
    "high":     2.0,
    "critical": 4.0,
}

_SEVERITY_MAP: Dict[str, str] = {
    "critical": "high",
    "high": "high",
    "medium": "medium",
    "low": "low",
    "info": "low"
}

# Fix advice keyed by capability group
_FIX_ADVICE: Dict[str, str] = {
    "rce":    "Never pass user-controlled or dynamically-constructed strings to exec/eval/subproces/etc. "
              "Use allowlists, parameterised commands, or restructure logic to avoid dynamic execution entirely.",
    "crypto": "Replace MD5/SHA1 with a modern hash (SHA-256 or higher). "
              "For password hashing use bcrypt, scrypt, or argon2 - never a raw digest.",
    "file":   "Resolve user-supplied paths against a fixed base directory and reject anything that escapes it "
              "(e.g. Path(base, name).resolve().is_relative_to(base)), or map user input to an allowlist of files.",
    "inject": "Pass user input to SQL as query parameters (cursor.execute(sql, params)), never by formatting it into "
              "the statement; check request URLs and hosts against an allowlist before fetching them.",
}

# vvv Main Visitor vvv
class SecurityRiskVisitor(BaseVisitor):
    __slots__ = (
        "_k_crypto",
        "_k_rce",
        "_k_file",
        "_k_inject",
        "_module",
        "_engine",
        "_engine_index",
    )

    def __init__(self) -> None:
        _tuning: ConfigNamespace = Config().metrics.tuning.security

        # vvv Settings vvv
        self._k_crypto: float = _tuning.sensitivity.broken_cryptography
        self._k_rce:    float = _tuning.sensitivity.arbitrary_code_execution
        self._k_file:   float = _tuning.sensitivity.unsafe_file_access
        self._k_inject: float = _tuning.sensitivity.injection_and_request_forgery

        # vvv Internals vvv
        self._module: Optional[nodes.Module] = None
        # One summary engine per project run, so each function summary is computed once
        self._engine:       Optional[SummaryEngine] = None
        self._engine_index: Optional[ProjectIndex]  = None

    # vvv Main Functions vvv
    @override
    def Visit(self, node: nodes.NodeNG, _: int) -> None:  # type: ignore
        # Capture the module root on first visit, engine does the full walk internally
        if isinstance(node, nodes.Module) and self._module is None:
            self._module = node

    @override
    def Leave(self, _: nodes.NodeNG, __: int) -> None:  # type: ignore
        pass

    @override
    def Finalize(self, ctx: FileContext) -> None:
        if self._module is None:
            # Module never visited, emit worst-case scores
            ctx.AddSecuritySignal(SecurityMetric.ARBITRARY_CODE_EXECUTION, SignalContext(0.0, 1.0))
            ctx.AddSecuritySignal(SecurityMetric.BROKEN_CRYPTOGRAPHY,      SignalContext(0.0, 1.0))
            ctx.AddSecuritySignal(SecurityMetric.UNSAFE_FILE_ACCESS,       SignalContext(0.0, 1.0))
            ctx.AddSecuritySignal(SecurityMetric.INJECTION_AND_REQUEST_FORGERY, SignalContext(0.0, 1.0))
            self._module = None
            return

        if self._engine is None or ctx.project_index is not self._engine_index:
            self._engine       = SummaryEngine(_SCHEMA_BUNDLE, ctx.project_index)
            self._engine_index = ctx.project_index

        # Run reasoning engine on the already-parsed astroid module
        findings: List[Finding] = EvaluateAll(
            Interpreter(_SCHEMA_BUNDLE, self._engine).Analyze(self._module, ctx.file_path),
            _SCHEMA_BUNDLE,
        )

        rce_findings:    List[Finding] = [f for f in findings if f.capability in _RCE_CAPABILITIES]
        crypto_findings: List[Finding] = [f for f in findings if f.capability in _CRYPTO_CAPABILITIES]
        file_findings:   List[Finding] = [f for f in findings if f.capability in _FILE_CAPABILITIES]
        inject_findings: List[Finding] = [f for f in findings if f.capability in _INJECTION_CAPABILITIES]

        # Compute scores and emit signals
        ctx.AddSecuritySignal(
            SecurityMetric.ARBITRARY_CODE_EXECUTION,
            SignalContext(self._ComputeScore(rce_findings,    self._k_rce),    1.0),
        )
        ctx.AddSecuritySignal(
            SecurityMetric.BROKEN_CRYPTOGRAPHY,
            SignalContext(self._ComputeScore(crypto_findings, self._k_crypto), 1.0),
        )
        ctx.AddSecuritySignal(
            SecurityMetric.UNSAFE_FILE_ACCESS,
            SignalContext(self._ComputeScore(file_findings,   self._k_file),   1.0),
        )
        ctx.AddSecuritySignal(
            SecurityMetric.INJECTION_AND_REQUEST_FORGERY,
            SignalContext(self._ComputeScore(inject_findings, self._k_inject), 1.0),
        )

        # Emit explanations
        self._EmitExplanation(ctx, "ARBITRARY_CODE_EXECUTION", rce_findings,    "rce")
        self._EmitExplanation(ctx, "BROKEN_CRYPTOGRAPHY",      crypto_findings, "crypto")
        self._EmitExplanation(ctx, "UNSAFE_FILE_ACCESS",       file_findings,   "file")
        self._EmitExplanation(ctx, "INJECTION_AND_REQUEST_FORGERY", inject_findings, "inject")

        # Reset
        self._module = None

    # vvv Internals vvv
    def _EmitExplanation(
        self,
        ctx:         FileContext,
        metric_name: str,
        findings:    List[Finding],
        group:       str,
    ) -> None:
        if not findings:
            return

        # Sort worst severity first, then by line number
        sorted_findings: List[Finding] = sorted(
            findings, key=lambda f: (-SEVERITY_RANK.get(f.severity, 0), f.line)
        )
        worst: List[Finding] = sorted_findings[:3]

        # Summary: count by severity
        by_severity: Dict[str, int] = {}
        for f in findings:
            by_severity[f.severity] = by_severity.get(f.severity, 0) + 1

        severity_parts: List[str] = [
            f"{count} {sev}"
            for sev, count in sorted(by_severity.items(), key=lambda x: -SEVERITY_RANK.get(x[0], 0))
        ]
        summary: str = f"{len(findings)} finding(s): {', '.join(severity_parts)}."

        ctx.SetMetricExplanation(metric_name, MetricExplanation(
            summary   = summary,
            offenders = [
                OffenderContext(
                    filepath = ctx.file_path,
                    line     = f.line,
                    detail   = f"'{f.call_name}' - {f.description}",
                    severity = _SEVERITY_MAP[f.severity],
                )
                for f in worst
            ],
            fix = _FIX_ADVICE[group],
        ))

    def _ComputeScore(self, findings: List[Finding], k: float) -> float:
        """
        Compute a 0-100 score via severity-weighted exponential decay.

        Weight is the sum of per-finding severity multipliers, preserving the
        original k tuning:
          info     -> 0.0    no penalty
          low      -> 0.01   near-zero penalty (recorded, barely scored)
          medium   -> 1.0    equivalent to one violation
          high     -> 2.0    equivalent to two violations
          critical -> 4.0    equivalent to four violations
        """
        weight: float = sum(_SEVERITY_WEIGHT.get(f.severity, 1.0) for f in findings)
        return 100.0 * exp(-weight * k)