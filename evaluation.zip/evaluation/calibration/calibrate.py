"""
Calibrate size/complexity thresholds so that saturated metrics discriminate.

Split the 950-package corpus in half (seed 2026): calibration and held-out. Run
PyMetricor at several threshold levels on a 100-package sample of the
calibration half and record, per metric, the share of files scoring exactly 100.

    python calibrate.py split | grid | report
"""
import json, os, random, shutil, subprocess, sys, re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EV = Path(__file__).resolve().parents[1]
S = Path(os.environ.get("EVAL_WORK", EV.parent / ".eval-work"))   # holds venvs/ and scratch output
PM = Path(os.environ.get("PM_DIR", EV.parent))
PY = S / "repro-work/venvs/pymetricor/bin/python"
DRIVER = str(EV / "reproduction/drivers/pymetricor_driver.py")
CORPUS = S / "rq5/corpus/pkgs"
W = S / "v12/calib"

# metric -> list of (yaml key path, candidate values per level)
GRID = {
    "FUNCTION_LENGTH":       [("maintainability.thresholds.max_function_length", [200, 150, 100, 75, 60, 50, 40])],
    "PARAMETER_BLOAT":       [("maintainability.thresholds.max_parameter_bloat", [8, 7, 6, 5, 4, 4, 4])],
    "INHERITANCE_DEPTH":     [("maintainability.thresholds.max_inheritance_depth", [5, 4, 3, 2, 2, 2, 2])],
    "EXCEPTION_HYGIENE":     [("maintainability.thresholds.max_exception_violations", [2, 1, 0, 0, 0, 0, 0])],
    "CLASS_COMPLEXITY":      [("maintainability.thresholds.max_class_methods", [18, 15, 12, 10, 8, 6, 5]),
                              ("maintainability.thresholds.max_class_attributes", [15, 12, 10, 8, 6, 5, 4])],
    "CYCLOMATIC_COMPLEXITY": [("efficiency.thresholds.avg_complexity_base", [10.0, 8.0, 6.0, 5.0, 4.0, 3.0, 2.5])],
    "NESTING_DEPTH":         [("readability.sensitivity.nesting_depth", [1.2, 0.8, 0.6, 0.4, 0.3, 0.2, 0.1])],
}
LEVELS = 7


def set_yaml(text, dotted, value):
    section, group, key = dotted.split(".")
    # replace the first `key:` occurring after `  section:` and its `group:`
    i = text.index(f"\n  {section}:\n"); j = text.index(f"\n    {group}:", i)
    m = re.compile(rf"(\n      {key}:\s*)([^\s#]+)").search(text, j)
    assert m, dotted
    return text[:m.start(2)] + str(value) + text[m.end(2):]


def tree(level):
    d = W / f"L{level}"
    if d.exists():
        shutil.rmtree(d)
    shutil.copytree(PM, d, ignore=shutil.ignore_patterns(".git", "tests", "evaluation", "__pycache__", ".pytest_cache"))
    y = (d / "pymetricor.yml").read_text()
    for metric, knobs in GRID.items():
        for key, vals in knobs:
            y = set_yaml(y, key, vals[level])
    (d / "pymetricor.yml").write_text(y)
    return d


def run(level, pkg):
    out = W / f"L{level}_out" / f"{pkg}.json"
    if out.exists():
        return
    out.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([str(PY), DRIVER, "--pymetricor-dir", str(W / f"L{level}"), "--target", str(CORPUS / pkg),
                    "--out", str(out), "--slim"], capture_output=True, timeout=1800)


def main():
    cmd = sys.argv[1]
    pkgs = sorted(p.name for p in CORPUS.iterdir())
    rng = random.Random(2026); rng.shuffle(pkgs)
    calib, held = sorted(pkgs[:475]), sorted(pkgs[475:])
    if cmd == "split":
        W.mkdir(parents=True, exist_ok=True)
        json.dump({"calibration": calib, "held_out": held}, open(W / "split.json", "w"), indent=0)
        print(len(calib), len(held))
    elif cmd == "grid":
        sample = sorted(random.Random(7).sample(calib, 100))
        json.dump(sample, open(W / "grid_sample.json", "w"))
        for lv in range(LEVELS):
            tree(lv)
        jobs = [(lv, p) for lv in range(LEVELS) for p in sample]
        with ThreadPoolExecutor(4) as ex:
            list(ex.map(lambda j: run(*j), jobs))
    elif cmd == "report":
        sample = json.load(open(W / "grid_sample.json"))
        res = {}
        for lv in range(LEVELS):
            vals = {}
            for p in sample:
                f = W / f"L{lv}_out" / f"{p}.json"
                if not f.exists():
                    continue
                for x in json.load(open(f)).get("files", []):
                    for m, v in (x.get("metrics") or {}).items():
                        vals.setdefault(m, []).append(v)
            res[lv] = {m: (sum(v >= 100 for v in vs) / len(vs), sum(v <= 0 for v in vs) / len(vs)) for m, vs in vals.items()}
        for m in GRID:
            print(m.ljust(24), " ".join(f"L{lv}:{res[lv][m][0]:.2f}/{res[lv][m][1]:.2f}" for lv in range(LEVELS)))
        json.dump(res, open(W / "grid_report.json", "w"), indent=1)


main()
