"""Score one PyMetricor tree on the micro-benchmark, PySASTBench subset and PyVul with score.py's logic.
    python secbench.py <pm-dir> <tag> [bench ...]"""
import json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "security"))
from score import score  # noqa: E402

EV = Path(__file__).resolve().parents[1]
S = Path(os.environ.get("EVAL_WORK", EV.parent / ".eval-work"))   # holds venvs/ and scratch output
PY = S / "repro-work/venvs/pymetricor/bin/python"
BENCH = {"micro": (str(EV / "security") + "/microbench/bench", str(EV / "security") + "/microbench/labels.json"),
         "pysast": (S / "seceval/pysastbench/bench", str(EV / "security") + "/pysastbench/labels.json"),
         "pyvul": (S / "seceval/pyvul-data/bench", S / "seceval/pyvul-data/labels.json")}
pm, tag = sys.argv[1], sys.argv[2]
out = S / "v12/results"; out.mkdir(parents=True, exist_ok=True)
for b in sys.argv[3:] or list(BENCH):
    src, lab = BENCH[b]
    p = subprocess.run([str(PY), str(EV / "security") + "/pymetricor_findings.py", "--pymetricor-dir", pm, str(src)],
                       capture_output=True, text=True)
    rows = []
    for line in p.stdout.splitlines():
        d = json.loads(line)
        if "error" in d:
            print("ERR", d); continue
        d["file"] = str(Path(d["file"]).relative_to(Path(src).resolve()))
        rows.append(d)
    (out / f"{b}_{tag}.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    labels = json.load(open(lab))
    for floor in (None, "medium"):
        s, _ = score(labels, rows, floor)
        keys = ["ALL"] + sorted(k for k in s if k.startswith("CWE-"))
        print(f"{b} {tag} {'any' if not floor else '>=med'}: " + "; ".join(
            f"{k} P{s[k]['precision']} R{s[k]['recall']} F{s[k]['f1']} pair{s[k]['pair_accuracy']}" for k in keys)
            + f"; warn {s['ALL']['warnings']}")
