"""Held-out-half saturation, same file filter as analyse.py (mass > 0, no errors).
    python sat_heldout.py <runs-dir> <split.json> <out.csv>"""
import csv, json, sys
import numpy as np
from pathlib import Path
runs, split, out = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
ho = set(json.load(open(split))["held_out"])
allf = []
for f in sorted((runs / "pymetricor").glob("*.json")):
    if f.name.endswith(".run.json") or f.stem not in ho:
        continue
    try:
        d = json.loads(f.read_text())
    except ValueError:
        continue
    allf += [x for x in d["files"] if x["mass"] > 0 and not x["errors"]]
SEC = {"LINE_LENGTH_DISTRIBUTION": "Readability", "INDENTATION_STABILITY": "Readability", "IDENTIFIER_STYLE": "Readability",
       "COMMENT_DENSITY": "Readability", "NESTING_DEPTH": "Readability", "BLANK_LINE_RHYTHM": "Readability",
       "ANNOTATION_CONSISTENCY": "Readability", "STRING_FORMATTING_CONSISTENCY": "Readability", "IDENTIFIER_LENGTH": "Readability",
       "CYCLOMATIC_COMPLEXITY": "Efficiency", "REDUNDANT_CODE": "Efficiency", "DEAD_CODE": "Efficiency"}
with open(out, "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["metric", "section", "at_0", "at_100", "median"])
    for n in allf[0]["metrics"]:
        v = np.array([x["metrics"].get(n, 100.0) for x in allf])
        sec = SEC.get(n, "Security" if n in ("BROKEN_CRYPTOGRAPHY", "ARBITRARY_CODE_EXECUTION", "UNSAFE_FILE_ACCESS") else "Maintainability")
        w.writerow([n, sec, float(np.mean(v <= .5)), float(np.mean(v >= 99.5)), float(np.median(v))])
print(len(allf), "files")
