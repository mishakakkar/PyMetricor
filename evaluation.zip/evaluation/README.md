# PyMetricor evaluation

Scripts and results behind the paper's five research questions. The paper evaluates
PyMetricor 1.2.0; its results are in the `results/v1.2.0/` folder of each study. Older
folders hold the results for 1.0.1 (security) and 1.1.0 (quality and scale); see `CHANGELOG.md`.
Open `dashboard/index.html` in a browser for a one-page summary.

| Folder | Research question | Entry points | Results |
| --- | --- | --- | --- |
| `reproduction/` | Reproduces the manuscript's Django and HTTPX numbers | `repro.py all` | `results/`, `FINDINGS.md` |
| `security/` | RQ1 detection, RQ2 string-recursion ablation | `run_tools.py`, `score.py`, `microbench/build.py`, `pyvul/build_pyvul.py`, `pysastbench/build.py`, `malware/extract.py`, `malware/analyse.py` | `results/{microbench,pyvul,pysastbench,malware}/` |
| `quality/` | RQ3 readability vs human ratings, RQ4 fix- and change-proneness | `mine.py`, `metrics.py`, `analyse.py`, `readability/*.py` | `results/all`, `results/no_ansible` (1.0.1), `results/v1.1.0/`, `results/rq3_codequal/` |
| `scale/` | RQ5 speed, robustness and weight sensitivity on the top 950 PyPI packages | `fetch.py`, `run.py`, `analyse.py` | `results/tables.md` and CSVs |
| `calibration/` | 1.2.0 threshold calibration and held-out saturation | `calibrate.py` (split, grid, report), `sat_heldout.py`, `secbench.py` | `split.json`, `grid_report.json` |
| `dashboard/` | Summary of all five (1.1.0) | `index.html` | `screenshots/` |
| `paperA/` | Security paper (1.7.0): synthetic benchmarks, PyVul with repository context (path credit, PyFlow, validator ablation and mutation set), malware with benign control | `setup.sh`, `run/rq1_synthetic.sh`, `run/rq2_pyvul.sh`, `run/rq2_validator_mutation.sh`, `run/rq3_malware.sh` (see its README) | `expected/` |

## Setup

The scripts run each tool from its own virtual environment. By default they look in
`.eval-work/` at the repository root (ignored by git); set `EVAL_WORK` to use another folder.

```
.eval-work/repro-work/venvs/pymetricor   # pip install -r requirements.txt
.eval-work/repro-work/venvs/radon        # radon==6.0.1
.eval-work/repro-work/venvs/bandit       # bandit
.eval-work/repro-work/venvs/pylint       # pylint
.eval-work/repro-work/venvs/analysis     # pandas scipy numpy pyyaml tabulate
```

`PM_DIR` (default: this repository) and `PM_DRIVER` (default:
`reproduction/drivers/pymetricor_driver.py`) choose the PyMetricor checkout under test.
SonarQube (RQ4) runs in Docker; `quality/metrics.py` reads `SONAR_TOKEN` and
`SONAR_READ_TOKEN` from the environment.

## Data not included

Third-party data is fetched by the scripts rather than redistributed: the PyVul and
PySASTBench benchmarks, the malicious-PyPI corpus (pypi_malregistry), the BugsInPy and
mined project snapshots, CodeQual (Zenodo 10.5281/zenodo.17765078) and the top-PyPI
package sources. Raw Pylint and Radon outputs for Django are omitted for size. Paths
recorded in result manifests are those of the original run.
