#!/usr/bin/env python3
"""
Reproduction harness for the PyMetricor manuscript (v3) experiments.

    python repro.py all                 # fetch, set up, run every tool, build tables
    python repro.py fetch               # clone pinned PyMetricor, Django, HTTPX
    python repro.py setup               # one venv per tool, pinned versions
    python repro.py run  [--targets django httpx self] [--tools ...]
    python repro.py tables --run results/<run-id>

Every run writes results/<run-id>/ with raw tool output, a manifest.json
(commits, tool versions, pip freezes, config hashes, timings, exit codes)
and tables.md / table4.csv regenerated from the raw output only.
Nothing is typed in by hand; paper_values.json is used only to print deltas.

Stdlib only. Needs git and Python >= 3.12 (PyMetricor imports typing.override).
"""

import argparse
import csv
import datetime as dt
import json
import os
import platform
import shlex
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = Path(os.environ.get("REPRO_WORK", HERE / "work"))
SRC, VENVS, RESULTS = WORK / "src", WORK / "venvs", HERE / "results"

# vvv Pinned inputs: edit here, never inline vvv
REPOS = {
    # Default ref = the latest PyMetricor commit as of 2026-10-26; set to the exact
    # commit the students ran if it differs (check their shell history / dates).
    "pymetricor": {"url": "https://github.com/Altered-commits/PyMetricor", "ref": "91e6867"},
    # The paper says "Django 4.2" without a patch release; 4.2 = the 4.2.0 tag.
    "django":     {"url": "https://github.com/django/django",            "ref": "4.2"},
    # What the paper's numbers actually match: 703 files and the eval at
    # questioner.py:168 only occur on Django main, Mar-May 2026 (4.2 has 679 files,
    # eval at line 162). This is main as of 2026-04-08, two days after PyMetricor 91e6867.
    "django-main-2026-04": {"url": "https://github.com/django/django", "ref": "e2abe321a6f1370e05c1a89a742125c9eafcac8c"},
    # The paper gives no HTTPX version; 0.28.1 is the latest release.
    "httpx":      {"url": "https://github.com/encode/httpx",             "ref": "0.28.1"},
}

# Analysed package dir inside each repo (tests live outside these, as in the paper)
TARGETS = {
    "django": {"repo": "django",     "path": "django"},
    "django-main-2026-04": {"repo": "django-main-2026-04", "path": "django"},
    "httpx":  {"repo": "httpx",      "path": "httpx"},
    "self":   {"repo": "pymetricor", "path": "."},
}

TOOLS = {
    "pymetricor": {"pip": ["astroid==3.3.10", "xxhash==3.5.0", "PyYAML==6.0.2"]},
    "pylint":     {"pip": ["pylint==3.3.7"]},
    "radon":      {"pip": ["radon==6.0.1"]},
    "bandit":     {"pip": ["bandit==1.8.6"]},
    "semgrep":    {"pip": ["semgrep==1.128.1"], "optional": True},
}
DEFAULT_TOOLS = ["pymetricor", "pylint", "radon", "bandit"]

# DPy and PyExamine are not on PyPI in a pinned form; give their commands with
# {src} and {out} placeholders, e.g.
#   REPRO_DPY_CMD='/opt/DPy analyze -i {src} -o {out}'
#   REPRO_PYEXAMINE_CMD='/opt/pyexamine/.venv/bin/analyze_code_quality {src} --output {out}/report'
EXTERNAL_CMDS = {"dpy": "REPRO_DPY_CMD", "pyexamine": "REPRO_PYEXAMINE_CMD"}

TIMEOUT_S = int(os.environ.get("REPRO_TIMEOUT", 3 * 3600))   # PyExamine hung on Django in the paper
MEM_LIMIT_GB = float(os.environ.get("REPRO_MEM_GB", 12))


# vvv Helpers vvv
def sh(cmd, cwd=None, check=True, capture=False):
    print("+", " ".join(map(str, cmd)), flush=True)
    r = subprocess.run(list(map(str, cmd)), cwd=cwd, text=True,
                       capture_output=capture, check=False)
    if check and r.returncode != 0:
        sys.exit(f"command failed ({r.returncode}): {cmd}\n{r.stderr if capture else ''}")
    return r


def J(p: Path) -> Path:
    """p + '.json' (Path.with_suffix would eat the tool name in 'httpx.pylint')."""
    return Path(f"{p}.json")


def venv_py(tool: str) -> Path:
    return VENVS / tool / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def venv_bin(tool: str, exe: str) -> Path:
    return venv_py(tool).parent / exe


def git_head(repo: Path) -> str:
    return sh(["git", "-C", repo, "rev-parse", "HEAD"], capture=True).stdout.strip()


def limit_memory():
    try:
        import resource
        b = int(MEM_LIMIT_GB * 1024 ** 3)
        resource.setrlimit(resource.RLIMIT_AS, (b, b))
    except Exception:
        pass


def timed(cmd, out_log: Path, cwd=None, shell=False):
    """Run a tool, capture stdout/stderr to files, return exit/time/peak-RSS/timeout."""
    out_log.parent.mkdir(parents=True, exist_ok=True)
    print("+", cmd if shell else " ".join(map(str, cmd)), flush=True)
    t0 = time.perf_counter()
    with open(f"{out_log}.stdout", "w") as so, open(f"{out_log}.stderr", "w") as se:
        p = subprocess.Popen(cmd if shell else list(map(str, cmd)), cwd=cwd, stdout=so, stderr=se,
                             shell=shell, preexec_fn=limit_memory if os.name != "nt" else None)
        timed_out = False
        try:
            p.wait(timeout=TIMEOUT_S)
        except subprocess.TimeoutExpired:
            p.kill(); p.wait(); timed_out = True
    peak_mb = None
    try:
        import resource
        peak_mb = round(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024, 1)  # cumulative max
    except Exception:
        pass
    return {"exit": p.returncode, "seconds": round(time.perf_counter() - t0, 2),
            "timed_out": timed_out, "peak_rss_mb_children_max": peak_mb,
            "command": cmd if shell else " ".join(map(str, cmd))}


def load_json(p: Path):
    try:
        return json.loads(p.read_text())
    except Exception:
        return None


# vvv Steps vvv
def cmd_fetch(_):
    SRC.mkdir(parents=True, exist_ok=True)
    for name, r in REPOS.items():
        d = SRC / name
        if not (d / ".git").exists():
            sh(["git", "clone", "--filter=blob:none", r["url"], d])
        sh(["git", "-C", d, "fetch", "--tags", "origin"], check=False)
        sh(["git", "-C", d, "checkout", "--detach", r["ref"]])
        print(f"  {name} @ {git_head(d)}")


def cmd_setup(args):
    VENVS.mkdir(parents=True, exist_ok=True)
    tools = args.tools or DEFAULT_TOOLS
    for t in tools:
        if t not in TOOLS:
            continue
        if not venv_py(t).exists():
            sh([sys.executable, "-m", "venv", VENVS / t])
        sh([venv_py(t), "-m", "pip", "install", "-q", "--upgrade", "pip"])
        sh([venv_py(t), "-m", "pip", "install", "-q", *TOOLS[t]["pip"]])


def run_tool(tool, target, src: Path, raw: Path):
    out = raw / f"{target}.{tool}"
    pm_dir = SRC / "pymetricor"
    if tool == "pymetricor":
        res = timed([venv_py("pymetricor"), HERE / "drivers" / "pymetricor_driver.py",
                     "--pymetricor-dir", pm_dir, "--target", src, "--out", J(out)], out)
    elif tool == "pylint":
        # --output writes the report straight to a file (the paper lost the score line to a redirect)
        res = timed([venv_bin("pylint", "pylint"), src, "--recursive=y", "--exit-zero",
                     "--output-format=json2", f"--output={J(out)}"], out, cwd=src.parent)
    elif tool == "radon":
        r1 = timed([venv_bin("radon", "radon"), "cc", "-j", "-O", out.with_name(out.name + ".cc.json"), src], out.with_name(out.name + ".cc"))
        r2 = timed([venv_bin("radon", "radon"), "mi", "-j", "-O", out.with_name(out.name + ".mi.json"), src], out.with_name(out.name + ".mi"))
        res = {"cc": r1, "mi": r2, "exit": max(r1["exit"], r2["exit"]), "seconds": r1["seconds"] + r2["seconds"],
               "timed_out": r1["timed_out"] or r2["timed_out"], "command": f'{r1["command"]} ; {r2["command"]}'}
    elif tool == "bandit":
        res = timed([venv_bin("bandit", "bandit"), "-r", src, "-f", "json", "-o", J(out),
                     "--exit-zero", "-q"], out)
    elif tool == "semgrep":
        res = timed([venv_bin("semgrep", "semgrep"), "scan", "--config", "p/python", "--json",
                     f"--output={J(out)}", "--metrics=off", src], out)
    elif tool in EXTERNAL_CMDS:
        tmpl = os.environ.get(EXTERNAL_CMDS[tool])
        if not tmpl:
            return {"skipped": f"set {EXTERNAL_CMDS[tool]} to run {tool}"}
        out.mkdir(parents=True, exist_ok=True)
        res = timed(tmpl.format(src=shlex.quote(str(src)), out=shlex.quote(str(out))), out / "log", shell=True)
    else:
        return {"skipped": f"unknown tool {tool}"}
    return res


def pip_freeze(tool):
    if not venv_py(tool).exists():
        return None
    return sh([venv_py(tool), "-m", "pip", "freeze"], capture=True, check=False).stdout.split()


def cmd_run(args):
    tools = args.tools or DEFAULT_TOOLS + [t for t in EXTERNAL_CMDS if os.environ.get(EXTERNAL_CMDS[t])]
    targets = args.targets or list(TARGETS)
    run_id = args.run_id or dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir = RESULTS / run_id
    raw = run_dir / "raw"
    raw.mkdir(parents=True, exist_ok=True)

    manifest = {
        "run_id": run_id, "started": dt.datetime.now().isoformat(timespec="seconds"),
        "host": {"platform": platform.platform(), "python": platform.python_version(),
                 "cpu_count": os.cpu_count()},
        "repos": {n: {"url": r["url"], "ref": r["ref"], "commit": git_head(SRC / n)} for n, r in REPOS.items()},
        "tools": {t: {"pip_freeze": pip_freeze(t)} for t in tools if t in TOOLS},
        "external_cmds": {t: os.environ.get(v) for t, v in EXTERNAL_CMDS.items()},
        "limits": {"timeout_s": TIMEOUT_S, "mem_gb": MEM_LIMIT_GB},
        "runs": {},
    }
    shutil.copy(SRC / "pymetricor" / "pymetricor.yml", run_dir / "pymetricor.yml.used")
    shutil.copy(SRC / "pymetricor" / "schema.yml", run_dir / "schema.yml.used")

    for target in targets:
        t = TARGETS[target]
        src = (SRC / t["repo"] / t["path"]).resolve()
        manifest["runs"][target] = {"src": str(src),
                                    "py_files_non_init": sum(1 for p in src.rglob("*.py") if p.name != "__init__.py")}
        for tool in tools:
            if target == "self" and tool not in ("pymetricor",) and not args.all_tools_on_self:
                continue
            manifest["runs"][target][tool] = run_tool(tool, target, src, raw)
            (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))

    manifest["finished"] = dt.datetime.now().isoformat(timespec="seconds")
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))
    build_tables(run_dir)
    print(f"\nDone: {run_dir}")


# vvv Table generation (raw output -> numbers) vvv
def summarise_pymetricor(p: Path):
    d = load_json(p)
    if not d:
        return None
    worst = [f["path"] for f in d["files"][:3]]
    sec_findings = []
    for f in d["files"]:
        for metric, ex in f.get("explanations", {}).items():
            if metric in ("ARBITRARY_CODE_EXECUTION", "BROKEN_CRYPTOGRAPHY"):
                for o in ex["offenders"]:
                    sec_findings.append({"file": f["path"], "line": o["line"], "metric": metric,
                                         "severity": o["severity"], "detail": o["detail"]})
    metric_avgs = {}
    for f in d["files"]:
        for k, v in f["metrics"].items():
            metric_avgs.setdefault(k, []).append(v)
    metric_avgs = {k: round(sum(v) / len(v), 1) for k, v in metric_avgs.items()}
    return {"final_score": d["final_score"], "file_count": d["file_count"],
            "files_with_errors": d["files_with_errors"],
            "sections_mass": d["section_avg_mass_weighted"], "sections_unweighted": d["section_avg_unweighted"],
            "worst_files": worst, "worst_file_scores": [f["score"] for f in d["files"][:3]],
            "security_findings": sec_findings,
            "worst_metrics": sorted(metric_avgs.items(), key=lambda kv: kv[1])[:5],
            "seconds": d["elapsed_seconds"]}


def summarise_pylint(p: Path):
    d = load_json(p)
    if not d:
        return None
    msgs = d.get("messages", [])
    from collections import Counter
    top = Counter(m["messageId"] for m in msgs).most_common(3)
    return {"score": round(d.get("statistics", {}).get("score", float("nan")), 2),
            "messages": len(msgs), "top": top}


def summarise_radon(cc: Path, mi: Path):
    c, m = load_json(cc), load_json(mi)
    if c is None:
        return None
    comps = []
    for blocks in c.values():
        if isinstance(blocks, list):
            for b in blocks:
                comps.append(b["complexity"])
                comps += [s["complexity"] for s in b.get("closures", [])]
    mi_vals = [v["mi"] for v in (m or {}).values() if isinstance(v, dict) and "mi" in v]
    return {"functions_graded": len(comps),
            "avg_cc": round(sum(comps) / len(comps), 2) if comps else None,
            "max_cc": max(comps) if comps else None,
            "cc_ge_10": sum(1 for x in comps if x >= 10),
            "files_mi": len(mi_vals),
            "avg_mi": round(sum(mi_vals) / len(mi_vals), 1) if mi_vals else None}


def summarise_bandit(p: Path):
    d = load_json(p)
    if not d:
        return None
    res = d.get("results", [])
    from collections import Counter
    sev = Counter(r["issue_severity"] for r in res)
    exec_like = [{"file": r["filename"], "line": r["line_number"], "test": r["test_id"], "severity": r["issue_severity"]}
                 for r in res if r["test_id"] in ("B102", "B307", "B602", "B605", "B604", "B603")]
    return {"findings": len(res), "by_severity": dict(sev), "exec_eval_shell": exec_like,
            "parse_errors": len(d.get("errors", []))}


def cross_check_security(pm, bandit, src_root: str):
    """For every PyMetricor ACE finding, did Bandit flag the same file within +-3 lines?"""
    if not pm or not bandit:
        return []
    out = []
    for f in pm["security_findings"]:
        if f["metric"] != "ARBITRARY_CODE_EXECUTION":
            continue
        hit = [b for b in bandit["exec_eval_shell"]
               if b["file"].endswith(f["file"]) and abs(b["line"] - f["line"]) <= 3]
        out.append({**f, "bandit_also_flagged": [f'{b["test"]}@{b["line"]}' for b in hit]})
    return out


def build_tables(run_dir: Path):
    raw = run_dir / "raw"
    manifest = load_json(run_dir / "manifest.json") or {}
    paper = load_json(HERE / "paper_values.json") or {}
    summary, lines, rows = {}, [], []

    def fmt_secs(s):
        return ", ".join(f"{k[0]} {v}" for k, v in s.items()) if s else "-"

    lines.append(f"# Reproduced results: run {run_dir.name}\n")
    for n, r in manifest.get("repos", {}).items():
        lines.append(f"- {n}: `{r['ref']}` = {r['commit'][:12]}")
    lines.append("")

    for target in manifest.get("runs", {}):
        runs = manifest["runs"][target]
        s = {
            "pymetricor": summarise_pymetricor(raw / f"{target}.pymetricor.json"),
            "pylint": summarise_pylint(raw / f"{target}.pylint.json"),
            "radon": summarise_radon(raw / f"{target}.radon.cc.json", raw / f"{target}.radon.mi.json"),
            "bandit": summarise_bandit(raw / f"{target}.bandit.json"),
        }
        s["security_cross_check"] = cross_check_security(s["pymetricor"], s["bandit"], runs["src"])
        summary[target] = s
        pv = paper.get(target) or paper.get(target.split("-")[0], {})
        pm, pl, ra, ba = s["pymetricor"], s["pylint"], s["radon"], s["bandit"]

        lines.append(f"## {target} ({runs['py_files_non_init']} non-__init__ .py files under `{Path(runs['src']).name}`)\n")
        lines.append("| Item | Reproduced | Paper v3 |")
        lines.append("| --- | --- | --- |")

        def row(item, rep, pap="-"):
            lines.append(f"| {item} | {rep} | {pap} |")
            rows.append([target, item, rep, pap])

        if pm:
            ppm = pv.get("pymetricor", {})
            row("PyMetricor composite (/100)", pm["final_score"], ppm.get("final_score", "-"))
            row("PyMetricor files analysed", pm["file_count"], ppm.get("file_count", "-"))
            row("PyMetricor sections, mass-weighted (R,E,M,S)", fmt_secs(pm["sections_mass"]), fmt_secs(ppm.get("sections")))
            row("PyMetricor sections, unweighted mean (R,E,M,S)", fmt_secs(pm["sections_unweighted"]))
            row("PyMetricor files with errors", pm["files_with_errors"])
            row("PyMetricor worst 3 files", "; ".join(f"{p} ({sc})" for p, sc in zip(pm["worst_files"], pm["worst_file_scores"])),
                "; ".join(ppm.get("worst_files", [])) or "-")
            row("PyMetricor 5 worst metrics (avg)", "; ".join(f"{k} {v}" for k, v in pm["worst_metrics"]))
            row("PyMetricor security offenders", len(pm["security_findings"]), ppm.get("critical_finding", "-"))
            row("PyMetricor runtime (s)", pm["seconds"])
        if pl:
            row("Pylint score (/10)", pl["score"], pv.get("pylint", {}).get("score", "-"))
            row("Pylint messages (top 3)", f'{pl["messages"]} ({", ".join(f"{k}x{v}" for k, v in pl["top"])})',
                pv.get("pylint", {}).get("messages", "-"))
        if ra:
            row("Radon avg CC / max CC / CC>=10", f'{ra["avg_cc"]} / {ra["max_cc"]} / {ra["cc_ge_10"]}',
                f'{pv.get("radon", {}).get("avg_cc", "-")} / {pv.get("radon", {}).get("max_cc", "-")}')
            row("Radon blocks graded / files with MI / avg MI", f'{ra["functions_graded"]} / {ra["files_mi"]} / {ra["avg_mi"]}',
                pv.get("radon", {}).get("functions_graded", "-"))
        if ba:
            row("Bandit findings (by severity)", f'{ba["findings"]} {ba["by_severity"]}', "not run in paper")
            row("Bandit exec/eval/shell findings", len(ba["exec_eval_shell"]), "not run in paper")
        for ext in EXTERNAL_CMDS:
            if ext in runs and "skipped" not in runs[ext]:
                r = runs[ext]
                row(f"{ext} exit / time (s) / timed out", f'{r["exit"]} / {r["seconds"]} / {r["timed_out"]}')
        for tool, r in runs.items():
            if isinstance(r, dict) and "exit" in r and r["exit"] not in (0, None):
                row(f"{tool} non-zero exit", r["exit"])
        lines.append("")

        if s["security_cross_check"]:
            lines.append("PyMetricor arbitrary-code-execution offenders vs Bandit:\n")
            for f in s["security_cross_check"]:
                lines.append(f'- `{f["file"]}:{f["line"]}` [{f["severity"]}] {f["detail"]} '
                             f'-> Bandit: {", ".join(f["bandit_also_flagged"]) or "not flagged"}')
            lines.append("")

    (run_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str))
    (run_dir / "tables.md").write_text("\n".join(lines))
    with open(run_dir / "table4.csv", "w", newline="") as fh:
        csv.writer(fh).writerows([["target", "item", "reproduced", "paper_v3"], *rows])
    print(f"tables -> {run_dir / 'tables.md'}")


def cmd_tables(args):
    build_tables(Path(args.run).resolve())


def cmd_all(args):
    cmd_fetch(args); cmd_setup(args); cmd_run(args)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, fn in [("fetch", cmd_fetch), ("setup", cmd_setup), ("run", cmd_run), ("tables", cmd_tables), ("all", cmd_all)]:
        p = sub.add_parser(name)
        p.set_defaults(fn=fn)
        if name in ("setup", "run", "all"):
            p.add_argument("--tools", nargs="+", choices=list(TOOLS) + list(EXTERNAL_CMDS))
        if name in ("run", "all"):
            p.add_argument("--targets", nargs="+", choices=list(TARGETS))
            p.add_argument("--run-id")
            p.add_argument("--all-tools-on-self", action="store_true")
        if name == "tables":
            p.add_argument("--run", required=True)
    args = ap.parse_args()
    if sys.version_info < (3, 12):
        sys.exit("Python >= 3.12 required (PyMetricor uses typing.override, added in 3.12)")
    args.fn(args)


if __name__ == "__main__":
    main()
