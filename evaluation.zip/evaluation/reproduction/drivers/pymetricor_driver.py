"""
Runs PyMetricor as a library on one target and writes a JSON result.

Run with the PyMetricor venv's interpreter. PyMetricor reads `pymetricor.yml`
from the *current working directory* (and silently creates one from its
built-in defaults if it is missing), so this driver always chdirs into the
PyMetricor checkout first and records the hash of the config actually used.

Besides the composite score it records two kinds of section averages, because
the CLI's `--json` output reports plain per-file means while the composite
uses log-damped mass weighting:
  - section_avg_mass_weighted  (what feeds the composite, Eq. 5 in the paper)
  - section_avg_unweighted     (what `python main.py --json` prints)
"""

import argparse
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else ""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pymetricor-dir", required=True)
    ap.add_argument("--target", required=True, nargs="+")
    ap.add_argument("--ignore", nargs="*", default=[])
    ap.add_argument("--out", required=True)
    ap.add_argument("--slim", action="store_true", help="omit per-file explanations (large corpora)")
    args = ap.parse_args()

    pm_dir = Path(args.pymetricor_dir).resolve()
    targets = [str(Path(t).resolve()) for t in args.target]
    ignore = [str(Path(i).resolve()) for i in args.ignore]
    out = Path(args.out).resolve()

    cfg_path = pm_dir / "pymetricor.yml"
    if not cfg_path.exists():
        print(f"[driver] {cfg_path} missing; refusing to let PyMetricor write defaults", file=sys.stderr)
        return 2

    os.chdir(pm_dir)
    sys.path.insert(0, str(pm_dir))

    from config import Config                      # noqa: E402
    from core import Analyser, S0TokenScan, S1ASTScan, Section  # noqa: E402

    cfg = Config()
    w = cfg.metrics.weights
    section_weights = [w.sections.readability, w.sections.efficiency,
                       w.sections.maintainability, w.sections.security]
    names = ["Readability", "Efficiency", "Maintainability", "Security"]

    t0 = time.perf_counter()
    analyser = Analyser([S0TokenScan(), S1ASTScan()], max_file_errors=10**9)
    ctx, has_errors = analyser.Run(targets, ignore_paths=ignore, progress_callback=lambda *_: None)
    final = ctx.ComputeFinalScore(section_weights) if not ctx.aborted_analysis else None
    elapsed = time.perf_counter() - t0

    files = ctx.GetFileOutputs()
    fc = w.file_composite
    masses, mw_tot, uw_tot = [], [0.0] * 4, [0.0] * 4
    per_file = []
    for f in files:
        m = f.ComputeCompositeMass(fc.loc, fc.tokens, fc.ast_nodes)
        secs = [f.GetSectionScore(Section(i)) for i in range(4)]
        if m > 0 and not f.HasErrors():   # same rule as ComputeFinalScore (1.1.0+)
            masses.append(m)
            for i in range(4):
                mw_tot[i] += secs[i] * m
        for i in range(4):
            uw_tot[i] += secs[i]
        per_file.append({
            "path": os.path.relpath(f.file_path, targets[0]) if len(targets) == 1 else f.file_path,
            "mass": round(m, 4),
            "score": round(sum(s * wt for s, wt in zip(secs, section_weights)), 2),
            "sections": dict(zip(names, (round(s, 2) for s in secs))),
            "metrics": {n: round(s, 2) for n, s in f.GetAllMetricScores()},
            "errors": [e.message for e in f.GetErrors()],
            "explanations": {} if args.slim else {
                k: {"summary": v.summary,
                    "offenders": [{"line": o.line, "detail": o.detail, "severity": o.severity} for o in v.offenders]}
                for k, v in getattr(f, "_explanations", {}).items()
            },
        })

    total_mass = sum(masses) or 1.0
    n = max(len(files), 1)
    result = {
        "tool": "pymetricor",
        "final_score": None if final is None else round(final, 2),
        "aborted": ctx.aborted_analysis,
        "file_count": len(files),
        "files_with_errors": sum(1 for f in files if f.HasErrors()),
        "section_weights": dict(zip(names, section_weights)),
        "section_avg_mass_weighted": dict(zip(names, (round(t / total_mass, 2) for t in mw_tot))),
        "section_avg_unweighted": dict(zip(names, (round(t / n, 2) for t in uw_tot))),
        "elapsed_seconds": round(elapsed, 2),
        "config_sha256": sha256(cfg_path),
        "schema_sha256": sha256(pm_dir / "schema.yml"),
        "python": platform.python_version(),
        "files": sorted(per_file, key=lambda x: x["score"]),
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2))
    print(f"[driver] score={result['final_score']} files={len(files)} "
          f"errors={result['files_with_errors']} time={elapsed:.1f}s -> {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
