# PyMetricor reproduction harness

Reruns the experiments in the PyMetricor manuscript (v3, Sections 4.2 and 4.4) from pinned inputs and regenerates the result tables from raw tool output. Nothing in the tables is typed in by hand.

## Quick start

```bash
# Python >= 3.12 and git required (PyMetricor imports typing.override, added in 3.12,
# so the README's "3.11+" is wrong)
python3 repro.py all                      # fetch + setup + run all targets + tables
# or step by step
python3 repro.py fetch
python3 repro.py setup
python3 repro.py run --targets httpx self --run-id my-run
python3 repro.py tables --run results/my-run
```

Output for each run lands in `results/<run-id>/`:

| File | Contents |
| --- | --- |
| `tables.md`, `table4.csv` | Table 4 and the self-validation numbers, with the paper's v3 values beside them |
| `summary.json` | Parsed numbers per target and tool |
| `manifest.json` | Repo commits, `pip freeze` per tool, host, timings, exit codes, limits |
| `pymetricor.yml.used`, `schema.yml.used` | The exact PyMetricor config and schema used |
| `raw/` | Every tool's untouched output plus stdout/stderr |

Set `REPRO_WORK=/some/fast/disk` to keep clones and venvs off a network drive.

## What is pinned

Edit only the `REPOS`, `TARGETS` and `TOOLS` blocks at the top of `repro.py`.

| Input | Pinned to | Note |
| --- | --- | --- |
| PyMetricor | `91e6867` | Latest commit on 2026-10-26; change it if the students ran an older commit |
| Django (as the paper says) | tag `4.2` (4.2.0) | 679 files; analyses `django/` (tests excluded) |
| Django (as the paper actually ran) | `main` @ `e2abe32` (2026-04-08) | 703 files and `questioner.py:168`, matching the paper; see FINDINGS.md |
| HTTPX | tag `0.28.1` | Not stated in the paper; file count (21) matches |
| Pylint / Radon / Bandit | 3.3.7 / 6.0.1 / 1.8.6 | Each in its own venv, so Pylint's astroid pin cannot clash with PyMetricor's |
| PyMetricor deps | astroid 3.3.10, xxhash 3.5.0, PyYAML 6.0.2 | The repo's `requirements.txt` is unpinned |

Bandit is included on purpose: the paper claims no other tool caught the Django `eval`, but no security scanner was in the comparison.

## Optional tools

- **Semgrep:** `python3 repro.py setup --tools semgrep` then `run --tools ... semgrep` (needs network for `p/python`).
- **DPy and PyExamine:** not pinnable from PyPI. Install them as their READMEs say, then pass the command with `{src}` and `{out}` placeholders:

```bash
export REPRO_DPY_CMD='/path/to/DPy analyze -i {src} -o {out}'
export REPRO_PYEXAMINE_CMD='/path/to/analyze_code_quality {src} --output {out}/report'
python3 repro.py run
```

  Each run is capped by `REPRO_TIMEOUT` (seconds, default 10800) and `REPRO_MEM_GB` (default 12), so a hang like PyExamine's on Django is recorded as `timed_out` instead of blocking the run.

## Things the harness handles that the original runs may not have

- **PyMetricor reads `pymetricor.yml` from the current directory** and silently writes its stale built-in defaults if none is there. The driver always runs from the PyMetricor checkout and refuses to run if the file is missing.
- **Two kinds of section averages.** The composite uses mass-weighted section averages, but `main.py --json` prints plain per-file means. Both are reported. The paper's section numbers match the plain means, so they do not combine into its composite.
- **Pylint writes its report straight to a file** (`--output`), so the score line can't get lost in a redirect the way it did for Django in the paper.
