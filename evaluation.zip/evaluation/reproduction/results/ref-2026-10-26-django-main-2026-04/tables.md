# Reproduced results: run ref-2026-10-26-django-main-2026-04

- pymetricor: `91e6867` = 91e6867cccdc
- django: `4.2` = 879e5d587b84
- django-main-2026-04: `e2abe321a6f1370e05c1a89a742125c9eafcac8c` = e2abe321a6f1
- httpx: `0.28.1` = 26d48e0634e6

## django-main-2026-04 (703 non-__init__ .py files under `django`)

| Item | Reproduced | Paper v3 |
| --- | --- | --- |
| PyMetricor composite (/100) | 94.08 | 93.9 |
| PyMetricor files analysed | 703 | 703 |
| PyMetricor sections, mass-weighted (R,E,M,S) | R 92.3, E 87.78, M 98.07, S 99.62 | R 92.4, E 90.1, M 98.1, S 99.7 |
| PyMetricor sections, unweighted mean (R,E,M,S) | R 92.43, E 90.05, M 98.59, S 99.66 | - |
| PyMetricor files with errors | 0 | - |
| PyMetricor worst 3 files | db/models/query.py (73.46); contrib/admin/options.py (73.6); db/migrations/questioner.py (74.27) | db/models/query.py; contrib/admin/options.py; db/migrations/questioner.py |
| PyMetricor 5 worst metrics (avg) | COMMENT_DENSITY 69.4; DEAD_CODE 76.4; STRING_FORMATTING_CONSISTENCY 87.3; REDUNDANT_CODE 91.8; IDENTIFIER_STYLE 93.9 | - |
| PyMetricor security offenders | 11 | db/migrations/questioner.py:168 |
| PyMetricor runtime (s) | 26.36 | - |
| Pylint score (/10) | 7.67 | 7.69 |
| Pylint messages (top 3) | 14895 (C0209x2193, C0116x2078, W0212x1509) | 14693 |
| Radon avg CC / max CC / CC>=10 | 3.03 / 94 / 518 | 1.84 / 79 |
| Radon blocks graded / files with MI / avg MI | 11307 / 903 / 75.5 | - |
| Bandit findings (by severity) | 276 {'LOW': 105, 'HIGH': 7, 'MEDIUM': 164} | not run in paper |
| Bandit exec/eval/shell findings | 11 | not run in paper |

PyMetricor arbitrary-code-execution offenders vs Bandit:

- `db/migrations/questioner.py:168` [high] 'eval' - User-controlled input is passed directly to exec/eval. An attacker can supply arbitrary Python code for immediate execution. -> Bandit: B307@168
- `db/migrations/questioner.py:168` [low] 'eval' - A string literal is passed to exec/eval. The literal may itself contain dangerous patterns or embedded calls to input/exec. -> Bandit: B307@168
- `utils/autoreload.py:290` [high] 'subprocess.run' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@290
- `utils/autoreload.py:290` [high] 'subprocess.run' - A dynamically-constructed command string is passed to a subprocess. The command cannot be statically verified as safe against injection. -> Bandit: B603@290
- `core/management/commands/shell.py:88` [high] 'compile' - User-controlled input is passed directly to exec/eval. An attacker can supply arbitrary Python code for immediate execution. -> Bandit: B102@88
- `core/management/commands/shell.py:271` [high] 'exec' - User-controlled input is passed directly to exec/eval. An attacker can supply arbitrary Python code for immediate execution. -> Bandit: B102@271
- `core/management/commands/shell.py:88` [medium] 'exec' - A dynamically-constructed string is passed to exec/eval. The source of the string cannot be statically verified as safe. -> Bandit: B102@88
- `db/backends/mysql/creation.py:78` [high] 'subprocess.Popen' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@78, B603@81
- `db/backends/mysql/creation.py:81` [high] 'subprocess.Popen' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@78, B603@81
- `db/backends/base/client.py:31` [high] 'subprocess.run' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@31
- `db/backends/base/client.py:31` [high] 'subprocess.run' - A dynamically-constructed command string is passed to a subprocess. The command cannot be statically verified as safe against injection. -> Bandit: B603@31
