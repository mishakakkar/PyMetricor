# Reproduced results: run ref-2026-10-26-django-4.2

- pymetricor: `91e6867` = 91e6867cccdc
- django: `4.2` = 879e5d587b84
- httpx: `0.28.1` = 26d48e0634e6

## django (679 non-__init__ .py files under `django`)

| Item | Reproduced | Paper v3 |
| --- | --- | --- |
| PyMetricor composite (/100) | 94.42 | 93.9 |
| PyMetricor files analysed | 679 | 703 |
| PyMetricor sections, mass-weighted (R,E,M,S) | R 93.1, E 88.06, M 98.2, S 99.62 | R 92.4, E 90.1, M 98.1, S 99.7 |
| PyMetricor sections, unweighted mean (R,E,M,S) | R 93.06, E 90.24, M 98.68, S 99.65 | - |
| PyMetricor files with errors | 0 | - |
| PyMetricor worst 3 files | db/migrations/questioner.py (73.83); db/models/query.py (75.2); test/testcases.py (76.22) | db/models/query.py; contrib/admin/options.py; db/migrations/questioner.py |
| PyMetricor 5 worst metrics (avg) | COMMENT_DENSITY 69.6; DEAD_CODE 76.2; STRING_FORMATTING_CONSISTENCY 90.8; REDUNDANT_CODE 92.6; IDENTIFIER_STYLE 94.0 | - |
| PyMetricor security offenders | 11 | db/migrations/questioner.py:168 |
| PyMetricor runtime (s) | 24.22 | - |
| Pylint score (/10) | 7.59 | 7.69 |
| Pylint messages (top 3) | 14083 (C0209x2267, C0116x1854, W0212x1337) | 14693 |
| Radon avg CC / max CC / CC>=10 | 2.99 / 87 / 455 | 1.84 / 79 |
| Radon blocks graded / files with MI / avg MI | 10535 / 872 / 75.7 | - |
| Bandit findings (by severity) | 288 {'LOW': 107, 'HIGH': 8, 'MEDIUM': 173} | not run in paper |
| Bandit exec/eval/shell findings | 11 | not run in paper |

PyMetricor arbitrary-code-execution offenders vs Bandit:

- `db/migrations/questioner.py:162` [high] 'eval' - User-controlled input is passed directly to exec/eval. An attacker can supply arbitrary Python code for immediate execution. -> Bandit: B307@162
- `db/migrations/questioner.py:162` [low] 'eval' - A string literal is passed to exec/eval. The literal may itself contain dangerous patterns or embedded calls to input/exec. -> Bandit: B307@162
- `utils/autoreload.py:274` [high] 'subprocess.run' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@274
- `utils/autoreload.py:274` [high] 'subprocess.run' - A dynamically-constructed command string is passed to a subprocess. The command cannot be statically verified as safe against injection. -> Bandit: B603@274
- `core/management/commands/shell.py:78` [high] 'compile' - User-controlled input is passed directly to exec/eval. An attacker can supply arbitrary Python code for immediate execution. -> Bandit: B102@78
- `core/management/commands/shell.py:127` [high] 'exec' - User-controlled input is passed directly to exec/eval. An attacker can supply arbitrary Python code for immediate execution. -> Bandit: B102@127
- `core/management/commands/shell.py:117` [medium] 'exec' - A dynamically-constructed string is passed to exec/eval. The source of the string cannot be statically verified as safe. -> Bandit: B102@117
- `db/backends/base/client.py:28` [high] 'subprocess.run' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@28
- `db/backends/base/client.py:28` [high] 'subprocess.run' - A dynamically-constructed command string is passed to a subprocess. The command cannot be statically verified as safe against injection. -> Bandit: B603@28
- `db/backends/mysql/creation.py:77` [high] 'subprocess.Popen' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@77, B603@80
- `db/backends/mysql/creation.py:80` [high] 'subprocess.Popen' - User-controlled input is passed directly to a subprocess or shell command. An attacker can inject shell metacharacters to execute arbitrary OS commands. -> Bandit: B603@77, B603@80
