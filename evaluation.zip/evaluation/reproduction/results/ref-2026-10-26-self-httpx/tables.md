# Reproduced results: run ref-2026-10-26-self-httpx

- pymetricor: `91e6867` = 91e6867cccdc
- django: `4.2` = 879e5d587b84
- httpx: `0.28.1` = 26d48e0634e6

## self (24 non-__init__ .py files under `pymetricor`)

| Item | Reproduced | Paper v3 |
| --- | --- | --- |
| PyMetricor composite (/100) | 95.52 | 95.2 |
| PyMetricor files analysed | 24 | 24 |
| PyMetricor sections, mass-weighted (R,E,M,S) | R 92.43, E 92.4, M 99.68, S 98.84 | R 91.2, E 94.6, M 98.4, S 97.4 |
| PyMetricor sections, unweighted mean (R,E,M,S) | R 92.5, E 92.65, M 99.72, S 98.11 | - |
| PyMetricor files with errors | 0 | - |
| PyMetricor worst 3 files | test/dummy.py (85.1); core/interface.py (88.14); core/visitors/maintainability.py (91.38) | - |
| PyMetricor 5 worst metrics (avg) | IDENTIFIER_STYLE 73.6; COMMENT_DENSITY 82.0; DEAD_CODE 86.9; ANNOTATION_CONSISTENCY 90.0; REDUNDANT_CODE 91.0 | - |
| PyMetricor security offenders | 5 | - |
| PyMetricor runtime (s) | 2.21 | - |

## httpx (21 non-__init__ .py files under `httpx`)

| Item | Reproduced | Paper v3 |
| --- | --- | --- |
| PyMetricor composite (/100) | 92.33 | 92.3 |
| PyMetricor files analysed | 21 | 21 |
| PyMetricor sections, mass-weighted (R,E,M,S) | R 92.63, E 83.7, M 94.45, S 100.0 | R 92.6, E 84.7, M 95.3, S 100.0 |
| PyMetricor sections, unweighted mean (R,E,M,S) | R 92.55, E 84.65, M 95.28, S 100.0 | - |
| PyMetricor files with errors | 0 | - |
| PyMetricor worst 3 files | _client.py (80.91); _models.py (87.11); _main.py (88.62) | _client.py; _models.py; _main.py |
| PyMetricor 5 worst metrics (avg) | DEAD_CODE 67.2; COMMENT_DENSITY 72.7; REDUNDANT_CODE 81.7; IDENTIFIER_STYLE 88.7; INHERITANCE_DEPTH 89.8 | - |
| PyMetricor security offenders | 0 | - |
| PyMetricor runtime (s) | 2.1 | - |
| Pylint score (/10) | 8.52 | 8.53 |
| Pylint messages (top 3) | 389 (C0116x88, R0913x42, C0115x23) | 387 |
| Radon avg CC / max CC / CC>=10 | 2.79 / 48 / 12 | 3.07 / - |
| Radon blocks graded / files with MI / avg MI | 527 / 23 / 61.5 | 1205 |
| Bandit findings (by severity) | 29 {'LOW': 28, 'HIGH': 1} | not run in paper |
| Bandit exec/eval/shell findings | 0 | not run in paper |
