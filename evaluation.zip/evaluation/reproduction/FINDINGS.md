# What the reproduction showed (26 Oct 2026)

Reference runs are in `results/ref-2026-10-26-*`. PyMetricor was at `91e6867`, Pylint 3.3.7, Radon 6.0.1 and Bandit 1.8.6, on Python 3.13 / Linux.

## The paper's numbers reproduce, but the Django version is wrong

| Target | Item | Paper v3 | Reproduced |
| --- | --- | --- | --- |
| HTTPX 0.28.1 | PyMetricor composite | 92.3 | 92.33 |
| HTTPX 0.28.1 | Sections R/E/M/S | 92.6 / 84.7 / 95.3 / 100.0 | 92.55 / 84.65 / 95.28 / 100.0 (plain mean) |
| HTTPX 0.28.1 | Worst 3 files | _client, _models, _main | _client 80.91, _models 87.11, _main 88.62 (paper also gives 80.9 / 87.1 / 88.6) |
| HTTPX 0.28.1 | Pylint | 8.53, 387 msgs | 8.52, 389 msgs |
| Django main @ 2026-04-08 | Files | 703 | 703 |
| Django main @ 2026-04-08 | PyMetricor composite | 93.9 | 94.08 |
| Django main @ 2026-04-08 | Sections R/E/M/S | 92.4 / 90.1 / 98.1 / 99.7 | 92.43 / 90.05 / 98.59 / 99.66 (plain mean) |
| Django main @ 2026-04-08 | Worst 3 files | query.py, admin/options.py, questioner.py | same order: 73.46 / 73.60 / 74.27 (paper: 73.5 / 73.6 / 74.3) |
| Django main @ 2026-04-08 | Worst metric averages | comment 69.4, dead 76.4, redundant 91.8, identifier 93.9 | identical |
| Django main @ 2026-04-08 | Pylint | 7.69, 14,693 msgs | 7.67, 14,895 msgs |
| Self | PyMetricor composite | 95.2 | 95.52 (repo has changed since; sections differ by 1–2 points) |

1. **The experiments ran on Django's development branch from around April 2026, not Django 4.2.** Django 4.2.0 has 679 non-`__init__` files under `django/` and its `eval` sits at `questioner.py:162`. The 703 files and line 168 occur only on `main` between March and early May 2026. The paper should say "Django main at commit e2abe32 (8 Apr 2026)", or be rerun on a release such as 6.0.
2. **The paper's section scores are plain per-file means, not the mass-weighted averages that make up the composite.** For Django, mass-weighted Efficiency is 87.78, against 90.05 for the plain mean. So the four section numbers in Table 4 do not combine into the reported composite. Pick one definition and say which.
3. **The security claim does not hold.** On Django, PyMetricor raises 11 arbitrary-code-execution findings at 6 call sites. Bandit flags every one of those sites at the same line, including `questioner.py:168` (B307). Bandit also reports 276 findings in total. All 6 sites are developer tooling (`shell`, `makemigrations`, `dbshell`, the autoreloader, MySQL test-database cloning), so none is an attacker-reachable vulnerability.
4. **Small residual gaps** in the composite (Django 94.08 vs 93.9) and Pylint counts are most likely due to tool versions. The students' `pip freeze` and PyMetricor commit, if available, would close them.
5. **Radon numbers differ** (avg CC 3.03 vs 1.84). The paper doesn't say how its average was computed. This harness averages every function, method and class block in `radon cc -j`.

## Engineering issues found while building the harness

- PyMetricor needs Python 3.12+ (`typing.override`), but its README says 3.11+.
- PyMetricor reads `pymetricor.yml` from the current working directory. If that file is missing, it silently writes the stale `_DEFAULT_CONFIG`, which has different weights and metrics that no longer exist. Results therefore depend on the directory it is launched from.
- The repo's `requirements.txt` is unpinned.
- DPy and PyExamine were not rerun here. They hook in via `REPRO_DPY_CMD` and `REPRO_PYEXAMINE_CMD` (see README).
