Packages run per tool: {'bandit': 200, 'pylint': 200, 'pymetricor': 950, 'radon': 200}; finished by every tool: 196

## Speed on the packages every tool finished

| tool       |   packages |    kloc |   cpu_s_per_kloc_pooled |   cpu_s_per_kloc_median |   wall_s_median |   wall_s_p95 |   rss_mb_median |   rss_mb_max |
|:-----------|-----------:|--------:|------------------------:|------------------------:|----------------:|-------------:|----------------:|-------------:|
| bandit     |        196 | 4568.06 |                   0.102 |                   0.138 |           0.644 |       10.806 |          35.705 |      299.5   |
| pylint     |        196 | 4568.06 |                   1.782 |                   1.773 |           8.154 |      212.884 |         131.584 |     4193.29  |
| pymetricor |        196 | 4568.06 |                   0.282 |                   0.617 |           3.701 |       25.234 |          80.201 |      449.02  |
| radon      |        196 | 4568.06 |                   0.118 |                   0.067 |           0.291 |        9.083 |          24.473 |      279.414 |

## Speed, each tool on everything it finished

| tool       |   packages |     kloc |   cpu_s_per_kloc_pooled |   cpu_s_per_kloc_median |   wall_s_median |   wall_s_p95 |   rss_mb_median |   rss_mb_max |
|:-----------|-----------:|---------:|------------------------:|------------------------:|----------------:|-------------:|----------------:|-------------:|
| bandit     |        199 |  7219.51 |                   0.172 |                   0.138 |           0.672 |       17.15  |          35.867 |      537.391 |
| pylint     |        197 |  4630.54 |                   1.781 |                   1.765 |           8.159 |      211.835 |         132.16  |     4193.29  |
| pymetricor |        950 | 35841.5  |                   0.241 |                   0.552 |           3.735 |       32.832 |          79.617 |     1578.46  |
| radon      |        198 |  6210.11 |                   0.096 |                   0.066 |           0.304 |        9.934 |          24.633 |      279.414 |

## Robustness on the packages every tool was run on

| tool       |   packages |   timeouts |   run_failures |   run_failure_rate |   py_files |   file_failures |   file_failure_rate |   files_reported |
|:-----------|-----------:|-----------:|---------------:|-------------------:|-----------:|----------------:|--------------------:|-----------------:|
| bandit     |        200 |          0 |              1 |              0.005 |      28552 |             391 |              0.0137 |            28552 |
| pylint     |        200 |          3 |              3 |              0.015 |      28552 |             392 |              0.0137 |            16425 |
| pymetricor |        200 |          0 |              0 |              0     |      28552 |             407 |              0.0143 |            25142 |
| radon      |        200 |          2 |              2 |              0.01  |      28552 |             411 |              0.0144 |            25341 |

## Robustness, each tool on everything it was run on

| tool       |   packages |   timeouts |   run_failures |   run_failure_rate |   py_files |   file_failures |   file_failure_rate |   files_reported |
|:-----------|-----------:|-----------:|---------------:|-------------------:|-----------:|----------------:|--------------------:|-----------------:|
| bandit     |        200 |          0 |              1 |              0.005 |      28552 |             391 |              0.0137 |            28552 |
| pylint     |        200 |          3 |              3 |              0.015 |      28552 |             392 |              0.0137 |            16425 |
| pymetricor |        950 |          0 |              0 |              0     |     150032 |            1357 |              0.009  |           133553 |
| radon      |        200 |          2 |              2 |              0.01  |      28552 |             411 |              0.0144 |            25341 |

PyMetricor coverage: 133553 of 150032 .py files scored (89.0%); the rest are __init__.py files, which it skips by design, or files it could not read.

## Weight sensitivity

{'packages': 943, 'files': 131907, 'reconstruction_max_err': 0.006275000000002251}

| scheme                |   draws |   pkg_tau_median |   pkg_tau_p5 |   worst_decile_overlap |   file_rho_median |   mean_abs_shift |   max_abs_shift |
|:----------------------|--------:|-----------------:|-------------:|-----------------------:|------------------:|-----------------:|----------------:|
| random +-25%          |    1000 |            0.947 |        0.913 |                  0.947 |             0.994 |            0.39  |           2.14  |
| random +-50%          |    1000 |            0.889 |        0.823 |                  0.883 |             0.982 |            0.807 |           4.425 |
| drop Readability      |       1 |            0.78  |        0.78  |                  0.798 |             0.889 |            1.585 |           7.941 |
| drop Efficiency       |       1 |            0.627 |        0.627 |                  0.638 |             0.761 |            2.234 |           8.976 |
| drop Maintainability  |       1 |            0.912 |        0.912 |                  0.883 |             0.992 |            1.76  |           7.756 |
| drop Security         |       1 |            0.928 |        0.928 |                  0.894 |             1     |            1.673 |           8.288 |
| equal section weights |       1 |            0.96  |        0.96  |                  0.957 |             0.998 |            0.503 |           1.922 |
| all weights equal     |       1 |            0.923 |        0.923 |                  0.915 |             0.991 |            0.478 |           2.764 |

## Metric saturation (share of files scoring 0 or 100)

| metric                             | section         |   at_0 |   at_100 |   median |
|:-----------------------------------|:----------------|-------:|---------:|---------:|
| LINE_LENGTH_DISTRIBUTION           | Readability     |  0.053 |    0.68  |   100    |
| INDENTATION_STABILITY              | Readability     |  0     |    0.92  |   100    |
| IDENTIFIER_STYLE                   | Readability     |  0     |    0.449 |    94.71 |
| COMMENT_DENSITY                    | Readability     |  0     |    0.065 |    83.69 |
| NESTING_DEPTH                      | Readability     |  0.118 |    0.847 |   100    |
| BLANK_LINE_RHYTHM                  | Readability     |  0.009 |    0.985 |   100    |
| ANNOTATION_CONSISTENCY             | Readability     |  0     |    0.749 |   100    |
| STRING_FORMATTING_CONSISTENCY      | Readability     |  0     |    0.957 |   100    |
| IDENTIFIER_LENGTH                  | Readability     |  0     |    0.753 |   100    |
| CYCLOMATIC_COMPLEXITY              | Efficiency      |  0.002 |    0.986 |   100    |
| REDUNDANT_CODE                     | Efficiency      |  0.009 |    0.843 |   100    |
| DEAD_CODE                          | Efficiency      |  0.05  |    0.532 |   100    |
| INHERITANCE_DEPTH                  | Maintainability |  0.005 |    0.983 |   100    |
| METHOD_RECEIVER_NAMING_CONSISTENCY | Maintainability |  0.073 |    0.863 |   100    |
| PARAMETER_BLOAT                    | Maintainability |  0.001 |    0.967 |   100    |
| EXCEPTION_HYGIENE                  | Maintainability |  0.005 |    0.964 |   100    |
| FUNCTION_LENGTH                    | Maintainability |  0     |    0.977 |   100    |
| CLASS_COMPLEXITY                   | Maintainability |  0.001 |    0.94  |   100    |
| BROKEN_CRYPTOGRAPHY                | Security        |  0     |    0.997 |   100    |
| ARBITRARY_CODE_EXECUTION           | Security        |  0     |    0.989 |   100    |
| UNSAFE_FILE_ACCESS                 | Security        |  0     |    0.988 |   100    |
