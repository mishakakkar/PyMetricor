Packages run per tool: {'bandit': 200, 'pylint': 200, 'pymetricor': 950, 'radon': 200}; finished by every tool: 196

## Speed on the packages every tool finished

| tool       |   packages |    kloc |   cpu_s_per_kloc_pooled |   cpu_s_per_kloc_median |   wall_s_median |   wall_s_p95 |   rss_mb_median |   rss_mb_max |
|:-----------|-----------:|--------:|------------------------:|------------------------:|----------------:|-------------:|----------------:|-------------:|
| bandit     |        196 | 4568.06 |                   0.102 |                   0.138 |           0.644 |       10.806 |          35.705 |      299.5   |
| pylint     |        196 | 4568.06 |                   1.782 |                   1.773 |           8.154 |      212.884 |         131.584 |     4193.29  |
| pymetricor |        196 | 4568.06 |                   0.272 |                   0.543 |           3.581 |       25.047 |          80.379 |      449.641 |
| radon      |        196 | 4568.06 |                   0.118 |                   0.067 |           0.291 |        9.083 |          24.473 |      279.414 |

## Speed, each tool on everything it finished

| tool       |   packages |     kloc |   cpu_s_per_kloc_pooled |   cpu_s_per_kloc_median |   wall_s_median |   wall_s_p95 |   rss_mb_median |   rss_mb_max |
|:-----------|-----------:|---------:|------------------------:|------------------------:|----------------:|-------------:|----------------:|-------------:|
| bandit     |        199 |  7219.51 |                   0.172 |                   0.138 |           0.672 |       17.15  |          35.867 |      537.391 |
| pylint     |        197 |  4630.54 |                   1.781 |                   1.765 |           8.159 |      211.835 |         132.16  |     4193.29  |
| pymetricor |        950 | 35841.5  |                   0.236 |                   0.491 |           3.468 |       32.185 |          79.729 |     1597.21  |
| radon      |        198 |  6210.11 |                   0.096 |                   0.066 |           0.304 |        9.934 |          24.633 |      279.414 |

## Robustness on the packages every tool was run on

| tool       |   packages |   timeouts |   run_failures |   run_failure_rate |   py_files |   file_failures |   file_failure_rate |   files_reported |
|:-----------|-----------:|-----------:|---------------:|-------------------:|-----------:|----------------:|--------------------:|-----------------:|
| bandit     |        200 |          0 |              1 |              0.005 |      28552 |             391 |              0.0137 |            28552 |
| pylint     |        200 |          3 |              3 |              0.015 |      28552 |             392 |              0.0137 |            16425 |
| pymetricor |        200 |          0 |              0 |              0     |      28552 |             407 |              0.0143 |            25142 |
| radon      |        200 |          2 |              2 |              0.01  |      28552 |             411 |              0.0144 |            25341 |

## Robustness, each tool on everything it was run on

| tool       |   packages |   timeouts |   run_failures |   run_failure_rate |   py_files |   file_failures |   file_failure_rate |   files_reported |
|:-----------|-----------:|-----------:|---------------:|-------------------:|-----------:|----------------:|--------------------:|-----------------:|
| bandit     |        200 |          0 |              1 |              0.005 |      28552 |             391 |              0.0137 |            28552 |
| pylint     |        200 |          3 |              3 |              0.015 |      28552 |             392 |              0.0137 |            16425 |
| pymetricor |        950 |          0 |              0 |              0     |     150032 |            1357 |              0.009  |           133553 |
| radon      |        200 |          2 |              2 |              0.01  |      28552 |             411 |              0.0144 |            25341 |

PyMetricor coverage: 133553 of 150032 .py files scored (89.0%); the rest are __init__.py files, which it skips by design, or files it could not read.

## Weight sensitivity

{'packages': 943, 'files': 131907, 'reconstruction_max_err': 0.0067450000000022214}

| scheme                |   draws |   pkg_tau_median |   pkg_tau_p5 |   worst_decile_overlap |   file_rho_median |   mean_abs_shift |   max_abs_shift |
|:----------------------|--------:|-----------------:|-------------:|-----------------------:|------------------:|-----------------:|----------------:|
| random +-25%          |    1000 |            0.947 |        0.922 |                  0.947 |             0.994 |            0.443 |           2.519 |
| random +-50%          |    1000 |            0.89  |        0.83  |                  0.883 |             0.98  |            0.95  |           5.309 |
| drop Readability      |       1 |            0.855 |        0.855 |                  0.851 |             0.952 |            1.214 |           8.029 |
| drop Efficiency       |       1 |            0.706 |        0.706 |                  0.745 |             0.809 |            2.95  |          11.872 |
| drop Maintainability  |       1 |            0.785 |        0.785 |                  0.702 |             0.947 |            1.184 |           7.566 |
| drop Security         |       1 |            0.949 |        0.949 |                  0.904 |             1     |            2.412 |           8.14  |
| equal section weights |       1 |            0.972 |        0.972 |                  0.979 |             0.998 |            0.465 |           1.922 |
| all weights equal     |       1 |            0.923 |        0.923 |                  0.915 |             0.987 |            0.823 |           3.501 |

## Metric saturation (share of files scoring 0 or 100)

| metric                             | section         |   at_0 |   at_100 |   median |
|:-----------------------------------|:----------------|-------:|---------:|---------:|
| LINE_LENGTH_DISTRIBUTION           | Readability     |  0.053 |    0.68  |   100    |
| INDENTATION_STABILITY              | Readability     |  0     |    0.92  |   100    |
| IDENTIFIER_STYLE                   | Readability     |  0     |    0.449 |    94.71 |
| COMMENT_DENSITY                    | Readability     |  0     |    0.065 |    83.69 |
| NESTING_DEPTH                      | Readability     |  0.025 |    0.847 |   100    |
| BLANK_LINE_RHYTHM                  | Readability     |  0.009 |    0.985 |   100    |
| ANNOTATION_CONSISTENCY             | Readability     |  0     |    0.749 |   100    |
| STRING_FORMATTING_CONSISTENCY      | Readability     |  0     |    0.957 |   100    |
| IDENTIFIER_LENGTH                  | Readability     |  0     |    0.753 |   100    |
| CYCLOMATIC_COMPLEXITY              | Efficiency      |  0.005 |    0.774 |   100    |
| REDUNDANT_CODE                     | Efficiency      |  0.009 |    0.843 |   100    |
| DEAD_CODE                          | Efficiency      |  0.05  |    0.532 |   100    |
| INHERITANCE_DEPTH                  | Maintainability |  0.019 |    0.917 |   100    |
| METHOD_RECEIVER_NAMING_CONSISTENCY | Maintainability |  0.073 |    0.863 |   100    |
| PARAMETER_BLOAT                    | Maintainability |  0.006 |    0.865 |   100    |
| EXCEPTION_HYGIENE                  | Maintainability |  0.006 |    0.89  |   100    |
| FUNCTION_LENGTH                    | Maintainability |  0.014 |    0.772 |   100    |
| CLASS_COMPLEXITY                   | Maintainability |  0.011 |    0.816 |   100    |
| BROKEN_CRYPTOGRAPHY                | Security        |  0     |    0.997 |   100    |
| ARBITRARY_CODE_EXECUTION           | Security        |  0     |    0.989 |   100    |
| UNSAFE_FILE_ACCESS                 | Security        |  0     |    0.985 |   100    |
