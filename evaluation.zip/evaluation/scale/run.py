"""
RQ5 runner: time each tool on each package of the corpus and record failures.

For every (package, tool) it records wall time, CPU time (user + sys of the tool
process tree), peak RSS, exit code, timeout, and a stderr tail, plus the tool's
own output. Package size is counted once (files, non-blank lines) so that time
can be normalised per KLOC.

Tools
  pymetricor  PyMetricor 1.1.0 via the reproduction driver (--slim)
  bandit      bandit -r -f json
  radon       radon mi -j (maintainability index, which computes Halstead and CC)
  pylint      pylint --recursive=y -j 1 --output-format=json (default rules)

    python -I run.py --corpus corpus --out runs --tools pymetricor bandit radon [--sample 200 --seed 2026] [--workers 4]

Results go to <out>/<tool>/<package>.json (tool output) and <out>/<tool>/<package>.run.json
(timing). Existing .run.json files are skipped, so the runner can be resumed.
"""
import argparse
import json
import os
import random
import resource
import signal
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SCR = Path(os.environ.get("EVAL_WORK", Path(__file__).resolve().parents[2] / ".eval-work"))
VENVS = SCR / "repro-work/venvs"
PM_DIR = os.environ.get("PM_DIR", str(Path(__file__).resolve().parents[2]))
PM_DRIVER = os.environ.get("PM_DRIVER", str(Path(__file__).resolve().parents[1] / "reproduction/drivers/pymetricor_driver.py"))

# The wrapper runs one command and prints the tree's CPU time and peak RSS, so
# concurrent runs do not mix their rusage.
WRAP = r"""
import json, resource, subprocess, sys, time
out = sys.argv[1]; cmd = sys.argv[2:]
t = time.perf_counter()
with open(out, "wb") as fh:
    p = subprocess.run(cmd, stdout=fh, stderr=subprocess.PIPE)
wall = time.perf_counter() - t
ru = resource.getrusage(resource.RUSAGE_CHILDREN)
sys.stderr.buffer.write(p.stderr[-4000:])
print(json.dumps({"exit": p.returncode, "wall": wall, "cpu": ru.ru_utime + ru.ru_stime, "maxrss_mb": ru.ru_maxrss / 1024}))
"""


def cmd(tool, pkg, out_json):
    if tool == "pymetricor":
        return [str(VENVS / "pymetricor/bin/python"), PM_DRIVER, "--pymetricor-dir", PM_DIR,
                "--target", str(pkg), "--out", str(out_json), "--slim"], None
    if tool == "bandit":
        return [str(VENVS / "bandit/bin/bandit"), "-r", "-f", "json", "-q", str(pkg)], out_json
    if tool == "radon":
        return [str(VENVS / "radon/bin/radon"), "mi", "-j", str(pkg)], out_json
    if tool == "pylint":
        return [str(VENVS / "pylint/bin/pylint"), "--recursive=y", "-j", "1", "--output-format=json",
                "--persistent=n", "--score=n", str(pkg)], out_json
    raise ValueError(tool)


def size(pkg):
    files = lines = 0
    for f in pkg.rglob("*.py"):
        if f.is_symlink():
            continue
        files += 1
        try:
            lines += sum(1 for ln in f.read_bytes().splitlines() if ln.strip())
        except OSError:
            pass
    return files, lines


def run_one(tool, pkg, out, timeout):
    d = out / tool
    rj = d / f"{pkg.name}.run.json"
    if rj.exists():
        return json.loads(rj.read_text())
    oj = d / f"{pkg.name}.json"
    c, stdout_to = cmd(tool, pkg, oj)
    sink = stdout_to or (d / f"{pkg.name}.stdout")
    rec = {"tool": tool, "package": pkg.name}
    p = subprocess.Popen([sys.executable, "-I", "-c", WRAP, str(sink), *c], stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, cwd=str(out), start_new_session=True,
                         env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    try:
        so, se = p.communicate(timeout=timeout)
        rec.update(json.loads(so.decode().strip().splitlines()[-1]))
        rec["stderr_tail"] = se.decode("utf-8", "replace")[-1500:]
        rec["timeout"] = False
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        _, se = p.communicate()
        rec.update(exit=None, wall=float(timeout), cpu=None, maxrss_mb=None, timeout=True,
                   stderr_tail=se.decode("utf-8", "replace")[-1500:])
    if stdout_to is None and sink.exists():
        sink.unlink()
    rj.write_text(json.dumps(rec))
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--tools", nargs="+", required=True)
    ap.add_argument("--sample", type=int, default=0)
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--timeout", type=int, default=900)
    a = ap.parse_args()
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    corpus, out = Path(a.corpus).resolve(), Path(a.out).resolve()
    man = json.loads((corpus / "manifest.json").read_text())
    pkgs = [corpus / "pkgs" / r["name"] for r in man["packages"] if r["status"] == "ok"]
    if a.sample:
        pkgs = sorted(random.Random(a.seed).sample(pkgs, a.sample))
    sz = out / "sizes.json"
    out.mkdir(parents=True, exist_ok=True)
    sizes = json.loads(sz.read_text()) if sz.exists() else {}
    for p in pkgs:
        if p.name not in sizes:
            sizes[p.name] = dict(zip(("files", "sloc"), size(p)))
    sz.write_text(json.dumps(sizes, indent=0))
    # Largest first, so the long runs do not end up alone at the tail.
    pkgs.sort(key=lambda p: -sizes[p.name]["sloc"])
    for tool in a.tools:
        (out / tool).mkdir(exist_ok=True)
        t0, done = time.time(), 0
        with ThreadPoolExecutor(a.workers) as ex:
            for r in ex.map(lambda p: run_one(tool, p, out, a.timeout), pkgs):
                done += 1
                if done % 50 == 0 or r.get("timeout"):
                    print(f"{tool} {done}/{len(pkgs)} {time.time() - t0:.0f}s last={r['package']} "
                          f"exit={r.get('exit')} timeout={r.get('timeout')}", flush=True)
        print(f"{tool} done in {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
