"""
RQ5 analysis: speed, robustness and weight sensitivity.

Speed      CPU seconds per KLOC (non-blank lines) per tool: pooled (total CPU / total
           KLOC) and the median over packages, plus peak RSS. Tools are compared
           on the packages every tool finished.
Robustness Run failures (timeout, non-zero exit that is not a findings code, a
           traceback, or unreadable output) and file-level failures (files a tool
           reports it could not analyse), plus PyMetricor's coverage (files scored
           out of .py files present).
Weights    Section and per-metric weights are perturbed and the composite is
           recomputed from the per-file metric scores, which is exact because every
           section is a weighted sum of metric scores and the composite is a
           mass-weighted mean of sections. Reports package-rank Kendall tau,
           within-package file-rank Spearman, top-decile overlap and score shift for
           random multiplicative noise (+-25%, +-50%), leave-one-section-out, and
           equal weights. Also reports how often each metric sits at 0 or 100.

    python -I analyse.py --runs runs --config pymetricor.yml --out results [--draws 1000]
"""
import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
import yaml
from scipy import stats

SECTIONS = ["Readability", "Efficiency", "Maintainability", "Security"]
OK_EXIT = {"pymetricor": {0}, "bandit": {0, 1}, "radon": {0}, "pylint": set(range(0, 32))}


def load_runs(runs, tool):
    rows = []
    for f in sorted((runs / tool).glob("*.run.json")):
        r = json.loads(f.read_text())
        out = runs / tool / f"{r['package']}.json"
        r["output_ok"], r["file_failures"], r["files_reported"] = parse_output(tool, out)
        tb = "Traceback (most recent call last)" in (r.get("stderr_tail") or "")
        r["run_failed"] = bool(r["timeout"] or r["exit"] not in OK_EXIT[tool] or not r["output_ok"]
                               or (tb and tool != "pylint"))
        if tool == "pylint" and r["exit"] is not None and r["exit"] & 1:
            r["run_failed"] = r["run_failed"] or r["file_failures"] == 0   # fatal with no file blamed
        rows.append(r)
    return pd.DataFrame(rows)


def parse_output(tool, path):
    try:
        d = json.loads(path.read_text())
    except (OSError, ValueError):
        return False, 0, 0
    if tool == "pymetricor":
        # "aborted" with no files means the package holds only __init__.py files, which
        # PyMetricor skips by design: nothing to score, not a failure
        return not d.get("aborted") or d.get("file_count", 0) == 0, d.get("files_with_errors", 0), d.get("file_count", 0)
    if tool == "bandit":
        return True, len(d.get("errors", [])), len(d.get("metrics", {})) - 1
    if tool == "radon":
        return True, sum(1 for v in d.values() if isinstance(v, dict) and "error" in v), len(d)
    if tool == "pylint":
        bad = {m["path"] for m in d if m.get("symbol") in ("syntax-error", "astroid-error", "fatal", "parse-error")}
        return True, len(bad), len({m["path"] for m in d})
    return True, 0, 0


def speed_table(df, sizes):
    df = df.join(sizes, on="package")
    ok = df[~df.run_failed & df.cpu.notna()]
    rows = []
    for tool, g in ok.groupby("tool"):
        rows.append({"tool": tool, "packages": len(g), "kloc": g.sloc.sum() / 1000,
                     "cpu_s_per_kloc_pooled": g.cpu.sum() / (g.sloc.sum() / 1000),
                     "cpu_s_per_kloc_median": (g.cpu / (g.sloc / 1000)).median(),
                     "wall_s_median": g.wall.median(), "wall_s_p95": g.wall.quantile(.95),
                     "rss_mb_median": g.maxrss_mb.median(), "rss_mb_max": g.maxrss_mb.max()})
    return pd.DataFrame(rows)


def robust_table(df, sizes):
    df = df.join(sizes, on="package")
    rows = []
    for tool, g in df.groupby("tool"):
        rows.append({"tool": tool, "packages": len(g), "timeouts": int(g.timeout.sum()),
                     "run_failures": int(g.run_failed.sum()), "run_failure_rate": g.run_failed.mean(),
                     "py_files": int(g.files.sum()), "file_failures": int(g.file_failures.sum()),
                     "file_failure_rate": g.file_failures.sum() / g.files.sum(),
                     "files_reported": int(g.files_reported.sum())})
    return pd.DataFrame(rows)


def metric_weights(cfg):
    w = cfg["weights"]
    sec = np.array([w["sections"][s.lower()] for s in SECTIONS])
    per = {s: {k.upper(): v for k, v in w[s.lower()].items()} for s in SECTIONS}
    return sec, per


def load_pm_files(runs):
    """Per package: metric matrix (files x metrics), masses."""
    out = {}
    for f in sorted((runs / "pymetricor").glob("*.json")):
        if f.name.endswith(".run.json"):
            continue
        try:
            d = json.loads(f.read_text())
        except ValueError:
            continue
        files = [x for x in d["files"] if x["mass"] > 0 and not x["errors"]]
        if files:
            out[f.stem] = files
    return out


def composite(pkgs, names, owner, sec_w, met_w):
    """Package composite and per-file composite for one weight setting."""
    # effective weight of every metric in the composite: section weight x metric weight
    eff = np.array([sec_w[SECTIONS.index(owner[n])] * met_w[n] for n in names])
    pk, fl = {}, {}
    for p, (M, m) in pkgs.items():
        fs = M @ eff
        fl[p] = fs
        pk[p] = float((fs * m).sum() / m.sum())
    return pk, fl


def perturb(rng, sec, per, scale):
    s = sec * rng.uniform(1 - scale, 1 + scale, len(sec))
    s /= s.sum()
    mw = {}
    for sname in SECTIONS:
        ks = list(per[sname])
        v = np.array([per[sname][k] for k in ks]) * rng.uniform(1 - scale, 1 + scale, len(ks))
        v /= v.sum()
        mw.update(dict(zip(ks, v)))
    return s, mw


def compare(base_pk, base_fl, pk, fl):
    keys = sorted(base_pk)
    a = np.array([base_pk[k] for k in keys])
    b = np.array([pk[k] for k in keys])
    tau = stats.kendalltau(a, b)[0]
    n10 = max(1, len(keys) // 10)
    top_a, top_b = set(np.argsort(a)[:n10]), set(np.argsort(b)[:n10])   # worst decile
    within = [stats.spearmanr(base_fl[k], fl[k])[0] for k in keys if len(base_fl[k]) >= 10]
    return {"pkg_tau": tau, "worst_decile_overlap": len(top_a & top_b) / n10,
            "file_rho_median": float(np.nanmedian(within)), "mean_abs_shift": float(np.abs(a - b).mean()),
            "max_abs_shift": float(np.abs(a - b).max())}


def sensitivity(runs, cfg, draws):
    sec, per = metric_weights(cfg)
    owner = {n: s for s in SECTIONS for n in per[s]}
    raw = load_pm_files(runs)
    names = list(owner)
    pkgs = {p: (np.array([[x["metrics"][n] for n in names] for x in fs]), np.array([x["mass"] for x in fs]))
            for p, fs in raw.items()}
    # check the reconstruction against the driver's own per-file score
    allf = [x for fs in raw.values() for x in fs]
    base_pk, base_fl = composite(pkgs, names, owner, sec, {n: per[owner[n]][n] for n in names})
    recon = np.concatenate([base_fl[p] for p in pkgs])
    drv = np.array([x["score"] for p in pkgs for x in raw[p]])
    check = float(np.abs(recon - drv).max())
    rng = np.random.default_rng(2026)
    rows = []
    for scale in (0.25, 0.5):
        for i in range(draws):
            s, mw = perturb(rng, sec, per, scale)
            rows.append({"scheme": f"random +-{int(scale * 100)}%", **compare(base_pk, base_fl, *composite(pkgs, names, owner, s, mw))})
    base_mw = {n: per[owner[n]][n] for n in names}
    for i, sname in enumerate(SECTIONS):
        s = sec.copy()
        s[i] = 0
        s /= s.sum()
        rows.append({"scheme": f"drop {sname}", **compare(base_pk, base_fl, *composite(pkgs, names, owner, s, base_mw))})
    eq_mw = {n: 1 / len(per[owner[n]]) for n in names}
    rows.append({"scheme": "equal section weights", **compare(base_pk, base_fl, *composite(pkgs, names, owner, np.full(4, .25), base_mw))})
    rows.append({"scheme": "all weights equal", **compare(base_pk, base_fl, *composite(pkgs, names, owner, np.full(4, .25), eq_mw))})
    res = pd.DataFrame(rows)
    summ = res.groupby("scheme", sort=False).agg(
        draws=("pkg_tau", "size"), pkg_tau_median=("pkg_tau", "median"), pkg_tau_p5=("pkg_tau", lambda x: x.quantile(.05)),
        worst_decile_overlap=("worst_decile_overlap", "median"), file_rho_median=("file_rho_median", "median"),
        mean_abs_shift=("mean_abs_shift", "median"), max_abs_shift=("max_abs_shift", "median")).reset_index()
    sat = pd.DataFrame([{"metric": n, "section": owner[n],
                         "at_0": float(np.mean([x["metrics"][n] <= 0.5 for x in allf])),
                         "at_100": float(np.mean([x["metrics"][n] >= 99.5 for x in allf])),
                         "median": float(np.median([x["metrics"][n] for x in allf]))} for n in names])
    return summ, sat, {"packages": len(pkgs), "files": len(allf), "reconstruction_max_err": check}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--draws", type=int, default=1000)
    a = ap.parse_args()
    runs, out = Path(a.runs), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    sizes = pd.DataFrame(json.loads((runs / "sizes.json").read_text())).T
    tools = [t for t in ("pymetricor", "pylint", "bandit", "radon") if (runs / t).is_dir()]
    df = pd.concat([load_runs(runs, t) for t in tools], ignore_index=True)
    df.to_csv(out / "runs.csv", index=False)
    common = set.intersection(*(set(df[(df.tool == t) & ~df.run_failed].package) for t in tools))
    text = [f"Packages run per tool: {df.groupby('tool').size().to_dict()}; finished by every tool: {len(common)}", ""]
    text += ["## Speed on the packages every tool finished", "", speed_table(df[df.package.isin(common)], sizes).round(3).to_markdown(index=False), ""]
    text += ["## Speed, each tool on everything it finished", "", speed_table(df, sizes).round(3).to_markdown(index=False), ""]
    text += ["## Robustness on the packages every tool was run on", "",
             robust_table(df[df.package.isin(set.intersection(*(set(df[df.tool == t].package) for t in tools)))], sizes).round(4).to_markdown(index=False), ""]
    text += ["## Robustness, each tool on everything it was run on", "", robust_table(df, sizes).round(4).to_markdown(index=False), ""]
    pm = df[df.tool == "pymetricor"].join(sizes, on="package")
    cov = pm.files_reported.sum() / pm.files.sum()
    text += [f"PyMetricor coverage: {pm.files_reported.sum()} of {int(pm.files.sum())} .py files scored ({cov:.1%}); "
             "the rest are __init__.py files, which it skips by design, or files it could not read.", ""]
    fails = df[df.run_failed][["tool", "package", "exit", "timeout"]]
    fails.to_csv(out / "run_failures.csv", index=False)
    summ, sat, info = sensitivity(runs, yaml.safe_load(Path(a.config).read_text()), a.draws)
    summ.to_csv(out / "weight_sensitivity.csv", index=False)
    sat.to_csv(out / "metric_saturation.csv", index=False)
    text += ["## Weight sensitivity", "", f"{info}", "", summ.round(3).to_markdown(index=False), "",
             "## Metric saturation (share of files scoring 0 or 100)", "", sat.round(3).to_markdown(index=False), ""]
    (out / "tables.md").write_text("\n".join(text))
    print("\n".join(text))


if __name__ == "__main__":
    main()
