"""
Score PyMetricor on one half of the CodeQual split.

    python eval_split.py --pymetricor pymetricor.json --ratings ratings.csv --items items.json \
        --split split.json --half dev [--radon radon.json]

Prints Spearman rho with the mean human readability rating within each source,
the n-weighted within-source mean, and the same for every readability metric.
"""
import argparse
import json
from pathlib import Path

import pandas as pd
from scipy import stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pymetricor", required=True)
    ap.add_argument("--ratings", required=True)
    ap.add_argument("--items", required=True)
    ap.add_argument("--split", required=True)
    ap.add_argument("--half", choices=["dev", "test"], required=True)
    ap.add_argument("--radon")
    a = ap.parse_args()
    keep = set(json.loads(Path(a.split).read_text())[a.half])
    src = {m["item"]: m["source"] for m in json.loads(Path(a.items).read_text())}
    human = pd.read_csv(a.ratings).groupby("item").score.mean()
    rows = []
    for f in json.loads(Path(a.pymetricor).read_text())["files"]:
        i = Path(f["path"]).stem
        if i in keep:
            rows.append({"item": i, "source": src[i], "human": human[i], "readability": f["sections"]["Readability"],
                         "composite": f["score"], **{m.lower(): v for m, v in f["metrics"].items()
                                                    if m in READ_METRICS}})
    df = pd.DataFrame(rows)
    if a.radon:
        rad = {Path(k).stem: v.get("mi") for k, v in json.loads(Path(a.radon).read_text()).items()}
        df["radon_mi"] = df.item.map(rad)
    df = df[df.source != "humaneval-x"]
    cols = [c for c in df.columns if c not in ("item", "source", "human")]
    out = []
    for c in cols:
        r, n = {"score": c}, 0
        acc = 0.0
        for s, g in df.groupby("source"):
            rho = stats.spearmanr(g[c], g.human)[0] if g[c].nunique() > 1 else 0.0
            r[s] = round(rho, 3)
            acc += rho * len(g)
            n += len(g)
        r["within"] = round(acc / n, 3)
        out.append(r)
    print(f"{a.half}: {len(df)} items")
    print(pd.DataFrame(out).to_string(index=False))


READ_METRICS = {"LINE_LENGTH_DISTRIBUTION", "INDENTATION_STABILITY", "IDENTIFIER_STYLE", "IDENTIFIER_LENGTH",
                "COMMENT_DENSITY", "NESTING_DEPTH", "BLANK_LINE_RHYTHM", "ANNOTATION_CONSISTENCY",
                "STRING_FORMATTING_CONSISTENCY"}

if __name__ == "__main__":
    main()
