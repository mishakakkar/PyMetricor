"""
Pick the RQ3 survey items from scored candidates.

Stratified on PyMetricor's readability section score: N_PER_STRATUM snippets
from each quintile, at most MAX_PER_PROJECT per project per stratum, so items
span the score range and many projects. Writes items.csv (what raters see) and
key.csv (scores, kept from raters).

    python select_items.py --survey survey [--per-stratum 12 --seed 11]
"""
import argparse
import csv
import json
import random
from collections import Counter, defaultdict
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--survey", required=True)
    ap.add_argument("--per-stratum", type=int, default=12)
    ap.add_argument("--max-per-project", type=int, default=2)
    ap.add_argument("--seed", type=int, default=11)
    a = ap.parse_args()
    sv = Path(a.survey)
    rnd = random.Random(a.seed)
    cands = {c["id"]: c for c in json.loads((sv / "candidates.json").read_text())}
    pm = {f["path"][:-3]: f for f in json.loads((sv / "pymetricor.json").read_text())["files"]}
    rad = {k[:-3]: v for k, v in json.loads((sv / "radon.json").read_text()).items()}
    ids = sorted((i for i in cands if i in pm and "error" not in rad.get(i, {"error": 1})),
                 key=lambda i: pm[i]["sections"]["Readability"])
    q = len(ids) / 5
    chosen = []
    for s in range(5):
        stratum = ids[int(s * q):int((s + 1) * q)]
        rnd.shuffle(stratum)
        per = Counter()
        for i in stratum:
            p = cands[i]["project"]
            if per[p] < a.max_per_project:
                chosen.append((s + 1, i))
                per[p] += 1
            if sum(per.values()) == a.per_stratum:
                break
    rnd.shuffle(chosen)
    with open(sv / "items.csv", "w", newline="") as fi, open(sv / "key.csv", "w", newline="") as fk:
        wi, wk = csv.writer(fi), csv.writer(fk)
        wi.writerow(["item", "code"])
        metric_names = sorted(pm[chosen[0][1]]["metrics"])
        wk.writerow(["item", "candidate", "project", "file", "start", "end", "lines", "stratum",
                     "pm_readability", "pm_score", "radon_mi", "sloc", "cc_sum", *metric_names])
        for n, (s, i) in enumerate(chosen, 1):
            item = f"S{n:02d}"
            wi.writerow([item, (sv / "cands" / f"{i}.py").read_text()])
            c, f, r = cands[i], pm[i], rad[i]
            wk.writerow([item, i, c["project"], c["file"], c["start"], c["end"], c["lines"], s,
                         f["sections"]["Readability"], f["score"], r["mi"], r["sloc"], r["cc_sum"],
                         *[f["metrics"][m] for m in metric_names]])
    print(len(chosen), "items;", dict(Counter(cands[i]["project"] for _, i in chosen)))


if __name__ == "__main__":
    main()
