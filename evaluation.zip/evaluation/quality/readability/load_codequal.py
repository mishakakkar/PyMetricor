"""
Turn the CodeQual human-annotated test set (Brahman et al., ICNLP 2026,
https://doi.org/10.5281/zenodo.17765078) into RQ3 inputs.

Only samples with `human_scores` are used; the train/validation scores are o3-mini
annotations and must not be treated as human data. Each submission that parses
as Python 3 is written to cands/<item>.py; its per-annotator readability scores
go to ratings.csv (rater, item, score) for analyse_survey.py.

    python -I load_codequal.py --data DIR_OR_JSONL... --out codequal

After this, score cands/ with PyMetricor and Radon and build key.csv with
make_key.py, then run analyse_survey.py --min-items 1.
"""
import argparse
import ast
import csv
import json
import re
from pathlib import Path


def records(paths):
    for p in map(Path, paths):
        files = sorted(p.rglob("*.jsonl")) + sorted(p.rglob("*.json")) if p.is_dir() else [p]
        for f in files:
            text = f.read_text(encoding="utf-8")
            if f.suffix == ".json":
                d = json.loads(text)
                yield from (d if isinstance(d, list) else d.get("samples", d.get("data", [])))
            else:
                for line in text.splitlines():
                    if line.strip():
                        yield json.loads(line)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = Path(a.out)
    (out / "cands").mkdir(parents=True, exist_ok=True)
    seen, rows, meta = set(), [], []
    stats = {"records": 0, "with_human": 0, "parse_error": 0, "duplicate": 0}
    for r in records(a.data):
        stats["records"] += 1
        hs = r.get("human_scores") or []
        if not hs:
            continue
        stats["with_human"] += 1
        key = (r.get("source"), r.get("problem_id"), r.get("submission_id"))
        if key in seen:
            stats["duplicate"] += 1
            continue
        seen.add(key)
        code = r["submission"]
        try:
            ast.parse(code)
        except SyntaxError:
            stats["parse_error"] += 1
            continue
        item = f"cq{len(meta):04d}_" + re.sub(r"[^A-Za-z0-9]+", "_", "_".join(map(str, key)))[:60]
        (out / "cands" / f"{item}.py").write_text(code if code.endswith("\n") else code + "\n")
        for h in hs:
            s = (h.get("scores") or {}).get("readability")
            if s is not None:
                rows.append({"rater": h.get("annotator_id"), "item": item, "score": float(s)})
        meta.append({"item": item, "source": r.get("source"), "problem_id": r.get("problem_id"),
                     "submission_id": r.get("submission_id"), "annotators": len(hs)})
    with open(out / "ratings.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, ["rater", "item", "score"])
        w.writeheader()
        w.writerows(rows)
    (out / "items.json").write_text(json.dumps(meta, indent=1))
    stats["items"] = len(meta)
    stats["ratings"] = len(rows)
    (out / "load_stats.json").write_text(json.dumps(stats, indent=1))
    print(stats)


if __name__ == "__main__":
    main()
