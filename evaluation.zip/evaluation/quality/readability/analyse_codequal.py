"""
RQ3 on CodeQual: per-source breakdown and an LLM reference, on top of analyse_survey.py.

CodeQual mixes five sources whose samples differ systematically (competitive-
programming scripts vs documented GitHub functions), so a pooled correlation can
reflect source rather than readability. This reports Spearman rho with the mean
human readability rating (a) pooled, (b) within each source, (c) the size-weighted
mean of within-source rhos, and (d) partial rho controlling for SLOC within source.
The o3-mini readability scores stored in the test records (llm_scores) and the
leave-one-out human agreement are reported as reference points.

    python analyse_codequal.py --data cq_zip --ratings ratings.csv --key key.csv --items items.json --out res
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

MODELS = {"PyMetricor readability": ("pm_readability", 1), "PyMetricor composite": ("pm_score", 1),
          "Radon MI": ("radon_mi", 1), "SLOC (negated)": ("sloc", -1), "CC sum (negated)": ("cc_sum", -1),
          "o3-mini (LLM reference)": ("llm_o3mini", 1)}


def partial(x, y, z):
    rx, ry, rz = (stats.rankdata(v) for v in (x, y, z))
    res = [r - np.polyval(np.polyfit(rz, r, 1), rz) for r in (rx, ry)]
    return stats.pearsonr(*res)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--ratings", required=True)
    ap.add_argument("--key", required=True)
    ap.add_argument("--items", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    meta = pd.DataFrame(json.loads(Path(a.items).read_text()))
    llm = {}
    for f in Path(a.data).rglob("test.jsonl"):
        for line in f.read_text(encoding="utf-8").splitlines():
            r = json.loads(line)
            for s in r.get("llm_scores") or []:
                if s.get("model_name", "").startswith("o3-mini") and s.get("scores"):
                    llm[(r.get("source"), r.get("problem_id"), r.get("submission_id"))] = s["scores"]["readability"]
    meta["llm_o3mini"] = [llm.get((s, p, i)) for s, p, i in zip(meta.source, meta.problem_id, meta.submission_id)]

    r = pd.read_csv(a.ratings)
    human = r.groupby("item").score.mean().rename("human")
    # leave-one-out agreement: each rating vs the mean of the others on that item
    loo = []
    for _, g in r.groupby("item"):
        if len(g) >= 2:
            for i, s in enumerate(g.score):
                loo.append((s, g.score.drop(g.index[i]).mean(), g.item.iloc[0]))
    loo = pd.DataFrame(loo, columns=["one", "rest", "item"])
    df = pd.read_csv(a.key).drop(columns=["source"]).merge(meta, on="item").merge(human, left_on="item", right_index=True)

    rows = []
    groups = [("all", df), *df.groupby("source")]
    for name, (col, sign) in MODELS.items():
        for src, g in groups:
            h = g[list(dict.fromkeys([col, "human", "sloc"]))].dropna()
            if len(h) < 15 or h[col].nunique() < 2:
                continue
            rho, p = stats.spearmanr(sign * h[col], h.human)
            prho, pp = partial(sign * h[col], h.human, h.sloc) if col != "sloc" else (np.nan, np.nan)
            rows.append({"model": name, "source": src, "n": len(h), "rho": rho, "p": p,
                         "partial_rho_sloc": prho, "partial_p": pp})
    res = pd.DataFrame(rows)
    within = (res[res.source != "all"].assign(w=lambda d: d.n * d.rho)
              .groupby("model").apply(lambda d: d.w.sum() / d.n.sum(), include_groups=False).rename("within_source_rho"))
    piv = res.pivot_table(index="model", columns="source", values="rho").join(within)
    piv = piv.reindex([m for m in MODELS if m in piv.index])
    agree_rows = []
    for src, g in [("all", loo), *loo.merge(meta[["item", "source"]], on="item").groupby("source")]:
        agree_rows.append({"source": src, "loo_rho": stats.spearmanr(g.one, g.rest)[0], "ratings": len(g)})
    agree = pd.DataFrame(agree_rows)
    res.round(3).to_csv(out / "codequal_by_source.csv", index=False)
    text = (f"Items: {len(df)} (sources: {df.source.value_counts().to_dict()})\n\n"
            "Spearman rho with mean human readability, pooled and within source "
            "(within_source_rho = n-weighted mean of the per-source rhos)\n\n"
            + piv.round(3).to_markdown() + "\n\nPartial rho controlling for SLOC\n\n"
            + res.pivot_table(index="model", columns="source", values="partial_rho_sloc")
                 .reindex([m for m in MODELS if m != "SLOC (negated)"]).round(3).to_markdown()
            + "\n\nHuman agreement: one rating vs mean of the other raters on the same item\n\n"
            + agree.round(3).to_markdown(index=False) + "\n")
    (out / "codequal_tables.md").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
