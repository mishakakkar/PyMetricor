"""
Extract candidate snippets for the RQ3 readability survey.

Top-level functions and methods of 15-50 lines are taken from the mined
snapshots (quality/<project>/src), dedented, and each written as its own module
(cands/<id>.py) so PyMetricor, Radon and other models can score it as a file.
Docstrings and comments are kept: they are part of what raters judge.

    python -I extract_snippets.py --quality quality --out survey [--per-project 120 --seed 7]
"""
import argparse
import ast
import json
import random
import textwrap
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quality", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--per-project", type=int, default=120)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    rnd = random.Random(a.seed)
    out = Path(a.out)
    (out / "cands").mkdir(parents=True, exist_ok=True)
    meta = []
    for proj in sorted(p for p in Path(a.quality).iterdir() if (p / "src").is_dir()):
        found = []
        for f in sorted((proj / "src").rglob("*.py")):
            try:
                src = f.read_text(encoding="utf-8")
                tree = ast.parse(src)
            except (SyntaxError, UnicodeDecodeError, ValueError):
                continue
            lines = src.splitlines()
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    start = min([d.lineno for d in node.decorator_list] + [node.lineno])
                    n = node.end_lineno - start + 1
                    if 15 <= n <= 50:
                        found.append((f, start, node.end_lineno, node.name))
        rnd.shuffle(found)
        for f, s, e, name in found[: a.per_project]:
            lines = f.read_text(encoding="utf-8").splitlines()[s - 1:e]
            code = textwrap.dedent("\n".join(lines)) + "\n"
            try:
                ast.parse(code)
            except SyntaxError:
                continue
            sid = f"{proj.name}_{len(meta):05d}"
            (out / "cands" / f"{sid}.py").write_text(code)
            meta.append({"id": sid, "project": proj.name, "file": str(f.relative_to(proj / "src")),
                         "start": s, "end": e, "name": name, "lines": e - s + 1})
    (out / "candidates.json").write_text(json.dumps(meta, indent=1))
    print(len(meta), "candidates from", len({m['project'] for m in meta}), "projects")


if __name__ == "__main__":
    main()
