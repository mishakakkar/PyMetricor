"""
Build key.csv (per-item tool scores) for any directory of scored snippets.

    python -I make_key.py --pymetricor pymetricor.json --radon radon.json --meta items.json --out key.csv

pymetricor.json comes from the reproduction driver run on cands/, radon.json from
radon_metrics.py. Items either tool could not score are left out and counted.
"""
import argparse
import csv
import json
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pymetricor", required=True)
    ap.add_argument("--radon", required=True)
    ap.add_argument("--meta", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    pm = {Path(f["path"]).stem: f for f in json.loads(Path(a.pymetricor).read_text())["files"] if not f["errors"]}
    rad = {Path(k).stem: v for k, v in json.loads(Path(a.radon).read_text()).items() if "error" not in v}
    meta = json.loads(Path(a.meta).read_text())
    names = sorted(next(iter(pm.values()))["metrics"])
    kept = 0
    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["item", "source", "pm_readability", "pm_score", "radon_mi", "sloc", "cc_sum", *names])
        for m in meta:
            i = m["item"]
            if i in pm and i in rad:
                f, r = pm[i], rad[i]
                w.writerow([i, m.get("source"), f["sections"]["Readability"], f["score"], r["mi"], r["sloc"],
                            r["cc_sum"], *[f["metrics"][n] for n in names]])
                kept += 1
    print(f"{kept} of {len(meta)} items scored by both tools")


if __name__ == "__main__":
    main()
