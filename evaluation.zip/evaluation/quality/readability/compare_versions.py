"""
Paired bootstrap of the within-source Spearman rho for two PyMetricor versions
(and Radon MI) on one half of the CodeQual split.

    python compare_versions.py --old pm_v1.json --new pm_v2.json --radon radon.json \
        --ratings ratings.csv --items items.json --split split.json --half test
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

B = 2000


def within(df, col):
    acc, n = 0.0, 0
    for _, g in df.groupby("source"):
        if g[col].nunique() > 1 and g.human.nunique() > 1:
            acc += stats.spearmanr(g[col], g.human)[0] * len(g)
        n += len(g)
    return acc / n


def main():
    ap = argparse.ArgumentParser()
    for k in ("old", "new", "radon", "ratings", "items", "split"):
        ap.add_argument(f"--{k}", required=True)
    ap.add_argument("--half", default="test")
    a = ap.parse_args()
    keep = set(json.loads(Path(a.split).read_text())[a.half])
    src = {m["item"]: m["source"] for m in json.loads(Path(a.items).read_text())}
    human = pd.read_csv(a.ratings).groupby("item").score.mean()
    def load(p):
        return {Path(f["path"]).stem: f for f in json.loads(Path(p).read_text())["files"]}
    old, new = load(a.old), load(a.new)
    rad = {Path(k).stem: v.get("mi") for k, v in json.loads(Path(a.radon).read_text()).items()}
    df = pd.DataFrame([{"item": i, "source": src[i], "human": human[i],
                        "old_read": old[i]["sections"]["Readability"], "new_read": new[i]["sections"]["Readability"],
                        "old_comp": old[i]["score"], "new_comp": new[i]["score"], "radon_mi": rad[i]}
                       for i in keep if i in old and i in new and src[i] != "humaneval-x"])
    rng = np.random.default_rng(7)
    cols = ["old_read", "new_read", "old_comp", "new_comp", "radon_mi"]
    point = {c: within(df, c) for c in cols}
    boots = {c: [] for c in cols}
    for _ in range(B):
        # resample within each source so source sizes stay fixed
        s = pd.concat([g.sample(len(g), replace=True, random_state=int(rng.integers(1 << 31)))
                       for _, g in df.groupby("source")])
        for c in cols:
            boots[c].append(within(s, c))
    boots = {c: np.array(v) for c, v in boots.items()}
    rows = [{"score": c, "within_rho": round(point[c], 3),
             "ci_low": round(np.percentile(boots[c], 2.5), 3), "ci_high": round(np.percentile(boots[c], 97.5), 3)}
            for c in cols]
    diffs = [("new_read - old_read", "new_read", "old_read"), ("new_comp - old_comp", "new_comp", "old_comp"),
             ("new_read - radon_mi", "new_read", "radon_mi"), ("new_comp - radon_mi", "new_comp", "radon_mi")]
    for name, x, y in diffs:
        d = boots[x] - boots[y]
        rows.append({"score": name, "within_rho": round(point[x] - point[y], 3),
                     "ci_low": round(np.percentile(d, 2.5), 3), "ci_high": round(np.percentile(d, 97.5), 3)})
    print(f"{a.half}: {len(df)} items, {B} within-source bootstrap resamples")
    print(pd.DataFrame(rows).to_markdown(index=False))


if __name__ == "__main__":
    main()
