# RQ3 readability survey: protocol

**Question.** Does PyMetricor's readability score rank Python code the way developers do? Does it do better than Radon MI, size and complexity?

**Why a survey.** The only human-rated Python readability data is Dorn's set (118 Python snippets, from Dorn 2012). It is distributed through a gated Hugging Face dataset (`rufimelo/Dorn_Code_Readability`) and university sites, none of which this environment can reach. If you can download it, put it in the project folder. `analyse_survey.py` can score it after a small loader. The survey below is designed to stand on its own and to be the paper's main RQ3 evidence either way.

## Items
- **Source.** 60 functions of 15–50 lines (`items/items.csv`), drawn at random from the 23 mined RQ4 projects with a fixed seed.
- **Stratification.** Items are stratified by PyMetricor's readability score: 12 per quintile, at most 2 per project per quintile, from 19 projects in all.
- **Hidden key.** `items/key.csv` holds every tool's score per item. Raters never see it.
- **Rebuilding.** The pool comes from `extract_snippets.py` and `select_items.py`. Run with the same seeds to rebuild it exactly.

## Raters
- **Who.** At least 15 raters with at least one year of Python. Students are acceptable if reported. Record years of Python and whether they work professionally.
- **Power.** 60 items give 80% power to detect ρ = .35 at α = .05 against the mean rating.

## Task
- **Rating.** Each rater sees all 60 items, one at a time, in a fresh random order with syntax highlighting. They answer "How readable is this code?" on a 1–5 scale, from 1 very unreadable to 5 very readable, as in Buse & Weimer and Scalabrino et al.
- **Attention checks.** Add 3 checks: two copies of a clearly obfuscated snippet and one item that says "select 2". A rater who fails any check is dropped (`attention_ok = 0`).
- **Time.** Log seconds per item. The expected total is 25–35 minutes.
- **Ethics.** Get informed consent, collect no names, and seek ethics approval from Amity's committee before running it.

## Analysis (`analyse_survey.py`)
- **Agreement.** ICC(2,k) across raters. The literature on these ratings reports roughly .5–.7.
- **Validity.** Spearman and Kendall correlation of each model with the mean rating, with bootstrap 95% CIs over items.
- **Comparison.** A bootstrap CI for ρ(PyMetricor) − ρ(baseline) for Radon MI, SLOC, cyclomatic complexity and each individual PyMetricor readability metric.
- **Size control.** Partial Spearman controlling for SLOC.

The pipeline was smoke-tested on simulated ratings only. No human data exists yet, and no result may be reported from that test.

## Output format expected
`ratings.csv` with columns `rater,item,score,seconds,experience_years,attention_ok`, one row per rating.
