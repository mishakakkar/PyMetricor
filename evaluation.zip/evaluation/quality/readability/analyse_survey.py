"""
RQ3 analysis: does PyMetricor's readability score agree with human ratings?

Input: ratings.csv with columns rater, item, score (1-5) and optional seconds,
experience_years; key.csv from select_items.py. Raters who fail an attention
check (column attention_ok == 0) or rate fewer than MIN_ITEMS items are dropped.

Reports
  agreement     ICC(2,k) (two-way random, average of k raters) on the item x rater
                matrix, Krippendorff-free approximation using complete raters only
  validity      Spearman and Kendall correlation of each model with the mean rating;
                bootstrap 95% CI over items (2,000 resamples)
  difference    bootstrap CI of rho(PyMetricor) - rho(baseline) for each baseline
  size control  partial Spearman controlling for SLOC

Models: PyMetricor readability section, PyMetricor composite, each PyMetricor
readability metric, Radon MI, SLOC (negated) and cyclomatic complexity (negated).

    python analyse_survey.py --ratings ratings.csv --key key.csv --out results
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

MIN_ITEMS = 20
B = 2000
READ_METRICS = ["LINE_LENGTH_DISTRIBUTION", "INDENTATION_STABILITY", "IDENTIFIER_STYLE", "COMMENT_DENSITY",
                "NESTING_DEPTH", "BLANK_LINE_RHYTHM", "ANNOTATION_CONSISTENCY", "STRING_FORMATTING_CONSISTENCY"]


def icc2k(mat):
    """ICC(2,k) of an items x raters matrix without missing cells (Shrout & Fleiss 1979)."""
    n, k = mat.shape
    gm = mat.mean()
    ssr = k * ((mat.mean(1) - gm) ** 2).sum()
    ssc = n * ((mat.mean(0) - gm) ** 2).sum()
    sse = ((mat - gm) ** 2).sum() - ssr - ssc
    msr, msc, mse = ssr / (n - 1), ssc / (k - 1), sse / ((n - 1) * (k - 1))
    return (msr - mse) / (msr + (msc - mse) / n)


def partial(x, y, z):
    rx, ry, rz = (stats.rankdata(v) for v in (x, y, z))
    res = [r - np.polyval(np.polyfit(rz, r, 1), rz) for r in (rx, ry)]
    return stats.pearsonr(*res)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ratings", required=True)
    ap.add_argument("--key", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--min-items", type=int, default=MIN_ITEMS,
                    help="drop raters with fewer ratings (use 1 for datasets where each rater saw a subset)")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    r = pd.read_csv(a.ratings)
    if "attention_ok" in r:
        r = r[r.attention_ok.astype(int) == 1]
    counts = r.groupby("rater").item.nunique()
    r = r[r.rater.isin(counts[counts >= a.min_items].index)]
    key = pd.read_csv(a.key)
    mean = r.groupby("item").score.mean().rename("human")
    df = key.merge(mean, left_on="item", right_index=True)

    mat = r.pivot_table(index="item", columns="rater", values="score")
    full = mat.dropna(axis=1)
    lines = [f"Raters kept: {r.rater.nunique()}, items: {len(df)}, ratings: {len(r)}"]
    if full.shape[1] >= 2:
        lines.append(f"ICC(2,k) over {full.shape[1]} raters who rated every item: {icc2k(full.values):.3f}")

    models = {"PyMetricor readability": df.pm_readability, "PyMetricor composite": df.pm_score,
              "Radon MI": df.radon_mi, "SLOC (negated)": -df.sloc, "CC sum (negated)": -df.cc_sum,
              **{f"PM {m.lower()}": df[m] for m in READ_METRICS if m in df}}
    rng = np.random.default_rng(1)
    idx = [rng.integers(0, len(df), len(df)) for _ in range(B)]
    rows, boots = [], {}
    models = {n: x for n, x in models.items() if x.nunique() > 1}   # a constant metric has no ranking
    for name, x in models.items():
        x = x.to_numpy(float)
        h = df.human.to_numpy(float)
        rho, p = stats.spearmanr(x, h)
        tau, _ = stats.kendalltau(x, h)
        bs = np.array([stats.spearmanr(x[i], h[i])[0] for i in idx])
        boots[name] = bs
        prho, pp = partial(x, h, df.sloc.to_numpy(float)) if "SLOC" not in name else (np.nan, np.nan)
        rows.append({"model": name, "spearman": rho, "p": p, "kendall": tau,
                     "ci_low": np.nanpercentile(bs, 2.5), "ci_high": np.nanpercentile(bs, 97.5),
                     "partial_rho_sloc": prho, "partial_p": pp})
    res = pd.DataFrame(rows).round(3)
    diffs = []
    for name in models:
        if name == "PyMetricor readability":
            continue
        d = boots["PyMetricor readability"] - boots[name]
        diffs.append({"baseline": name, "rho_diff": round(float(np.nanmean(d)), 3),
                      "ci_low": round(float(np.nanpercentile(d, 2.5)), 3),
                      "ci_high": round(float(np.nanpercentile(d, 97.5)), 3)})
    res.to_csv(out / "readability_validity.csv", index=False)
    pd.DataFrame(diffs).to_csv(out / "readability_differences.csv", index=False)
    text = "\n".join(lines) + "\n\n" + res.to_markdown(index=False) + "\n\nPyMetricor readability minus baseline (bootstrap)\n\n" \
        + pd.DataFrame(diffs).to_markdown(index=False) + "\n"
    (out / "readability_tables.md").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
