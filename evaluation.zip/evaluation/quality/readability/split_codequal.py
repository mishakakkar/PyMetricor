"""
Split the CodeQual RQ3 items into a tuning half (dev) and a held-out half (test).

Stratified by source and grouped by problem_id, so two submissions to the same
problem never straddle the split. Any change to PyMetricor's readability rules
or weights is chosen on dev only; test is scored once per released change.

    python -I split_codequal.py --items items.json --out split.json [--seed 2026]
"""
import argparse
import json
import random
from collections import defaultdict
from pathlib import Path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--items", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=2026)
    a = ap.parse_args()
    rnd = random.Random(a.seed)
    items = json.loads(Path(a.items).read_text())
    groups = defaultdict(lambda: defaultdict(list))
    for it in items:
        groups[it["source"]][it["problem_id"]].append(it["item"])
    split = {"dev": [], "test": [], "seed": a.seed}
    for src in sorted(groups):
        probs = sorted(groups[src])
        rnd.shuffle(probs)
        for n, p in enumerate(probs):
            split["dev" if n % 2 == 0 else "test"].extend(groups[src][p])
    Path(a.out).write_text(json.dumps(split, indent=1))
    print({k: len(v) for k, v in split.items() if k != "seed"})


if __name__ == "__main__":
    main()
