"""
Per-file Radon metrics with a per-file time limit (Radon can hang on huge
generated files). Run with the Radon venv's interpreter:

    python radon_metrics.py SRC_DIR OUT_JSON [--timeout 60]

Output: {relpath: {"mi", "loc", "sloc", "lloc", "comments", "cc_avg", "cc_sum"} or {"error"}}
"""
import argparse
import json
import signal
from pathlib import Path

from radon.complexity import cc_visit
from radon.metrics import mi_visit
from radon.raw import analyze


class Timeout(Exception):
    pass


def _alarm(*_):
    raise Timeout()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("out")
    ap.add_argument("--timeout", type=int, default=60)
    a = ap.parse_args()
    signal.signal(signal.SIGALRM, _alarm)
    src = Path(a.src)
    res = {}
    for f in sorted(src.rglob("*.py")):
        rel = str(f.relative_to(src))
        signal.alarm(a.timeout)
        try:
            code = f.read_text(encoding="utf-8", errors="replace")
            raw = analyze(code)
            blocks = cc_visit(code)
            cc = [b.complexity for b in blocks]
            res[rel] = {"mi": round(mi_visit(code, multi=True), 3), "loc": raw.loc, "sloc": raw.sloc,
                        "lloc": raw.lloc, "comments": raw.comments, "cc_sum": sum(cc),
                        "cc_avg": round(sum(cc) / len(cc), 3) if cc else 0.0}
        except Timeout:
            res[rel] = {"error": "timeout"}
        except Exception as e:
            res[rel] = {"error": f"{type(e).__name__}: {e}"[:200]}
        finally:
            signal.alarm(0)
    Path(a.out).write_text(json.dumps(res))
    print(len(res), "files,", sum(1 for v in res.values() if "error" in v), "errors")


if __name__ == "__main__":
    main()
