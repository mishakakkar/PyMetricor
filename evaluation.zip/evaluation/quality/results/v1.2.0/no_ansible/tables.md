Files: 2042, projects: 22

## Outcome: changed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyExamine code smells          |         15 |        0.511 |        14 |         0.108 |          5 |        0.722 |
| PyExamine severity-weighted    |         15 |        0.583 |        15 |         0.134 |          5 |        0.746 |
| PyExamine smells (all)         |         15 |        0.587 |        14 |         0.161 |          5 |        0.76  |
| PyMetricor composite           |         15 |        0.55  |        13 |         0.128 |          4 |        0.793 |
| PyMetricor efficiency          |         15 |        0.405 |        11 |         0.154 |          4 |        0.714 |
| PyMetricor maintainability     |         15 |        0.601 |        14 |         0.091 |          6 |        0.756 |
| PyMetricor readability         |         15 |        0.433 |        12 |         0.084 |          2 |        0.718 |
| PyMetricor security            |         14 |        0.178 |         5 |         0.033 |          2 |        0.54  |
| Radon CC (sum)                 |         15 |        0.561 |        12 |         0.046 |          4 |        0.818 |
| Radon MI                       |         15 |        0.542 |        15 |         0.099 |          4 |        0.803 |
| SLOC                           |         15 |        0.599 |        15 |       nan     |          0 |        0.823 |
| SonarQube code smells          |         15 |        0.168 |         5 |         0.05  |          1 |        0.535 |
| SonarQube cognitive complexity |         15 |        0.581 |        13 |         0.163 |          4 |        0.772 |
| SonarQube debt (min)           |         15 |        0.166 |         5 |         0.046 |          2 |        0.535 |
| SonarQube debt ratio (%)       |         14 |        0.116 |         2 |         0.034 |          2 |        0.529 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    2019 |  1393 |         20 |              2.0641 | 0      |     0.8569 |     0.8619 |     0.005  |
| PyMetricor readability         |    2019 |  1393 |         20 |              1.4914 | 0      |     0.8569 |     0.8586 |     0.0017 |
| PyMetricor efficiency          |    2019 |  1393 |         20 |              1.4024 | 0.0001 |     0.8569 |     0.8595 |     0.0026 |
| PyMetricor maintainability     |    2019 |  1393 |         20 |              2.3942 | 0      |     0.8569 |     0.8603 |     0.0034 |
| PyMetricor security            |    2019 |  1393 |         20 |              1.0105 | 0.884  |     0.8569 |     0.8565 |    -0.0004 |
| Radon MI                       |    2019 |  1393 |         20 |              2.0863 | 0      |     0.8569 |     0.8657 |     0.0088 |
| Radon CC (sum)                 |    2019 |  1393 |         20 |             12.7413 | 0      |     0.8569 |     0.8654 |     0.0085 |
| SonarQube debt (min)           |    2019 |  1393 |         20 |              1.382  | 0.1534 |     0.8569 |     0.8569 |     0      |
| SonarQube code smells          |    2019 |  1393 |         20 |              1.4198 | 0.0724 |     0.8569 |     0.8571 |     0.0002 |
| SonarQube cognitive complexity |    2019 |  1393 |         20 |              9.1631 | 0      |     0.8569 |     0.8646 |     0.0077 |
| SonarQube debt ratio (%)       |    2019 |  1393 |         20 |              1.0015 | 0.9781 |     0.8569 |     0.8563 |    -0.0006 |
| PyExamine smells (all)         |    2019 |  1393 |         20 |              4.6524 | 0      |     0.8569 |     0.8608 |     0.0039 |
| PyExamine code smells          |    2019 |  1393 |         20 |              3.5965 | 0      |     0.8569 |     0.8595 |     0.0025 |
| PyExamine severity-weighted    |    2019 |  1393 |         20 |              4.3305 | 0      |     0.8569 |     0.8604 |     0.0035 |

## Outcome: fixed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyExamine code smells          |         14 |        0.425 |        12 |         0.136 |          4 |        0.701 |
| PyExamine severity-weighted    |         14 |        0.475 |        11 |         0.144 |          5 |        0.732 |
| PyExamine smells (all)         |         14 |        0.461 |        12 |         0.155 |          5 |        0.724 |
| PyMetricor composite           |         14 |        0.528 |        11 |         0.164 |          6 |        0.755 |
| PyMetricor efficiency          |         14 |        0.509 |        10 |         0.187 |          6 |        0.746 |
| PyMetricor maintainability     |         14 |        0.487 |        12 |         0.15  |          6 |        0.716 |
| PyMetricor readability         |         14 |        0.386 |        10 |         0.119 |          2 |        0.705 |
| PyMetricor security            |         13 |        0.131 |         3 |         0.062 |          0 |        0.531 |
| Radon CC (sum)                 |         14 |        0.524 |        11 |         0.055 |          4 |        0.77  |
| Radon MI                       |         14 |        0.514 |        12 |         0.119 |          4 |        0.759 |
| SLOC                           |         14 |        0.543 |        13 |       nan     |          0 |        0.767 |
| SonarQube code smells          |         14 |        0.191 |         5 |         0.112 |          3 |        0.537 |
| SonarQube cognitive complexity |         14 |        0.53  |        12 |         0.226 |          8 |        0.778 |
| SonarQube debt (min)           |         14 |        0.19  |         5 |         0.112 |          3 |        0.537 |
| SonarQube debt ratio (%)       |         13 |        0.123 |         2 |         0.052 |          3 |        0.518 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    2007 |   751 |         20 |              1.975  | 0      |     0.8277 |     0.8355 |     0.0078 |
| PyMetricor readability         |    2007 |   751 |         20 |              1.2448 | 0.0034 |     0.8277 |     0.8289 |     0.0012 |
| PyMetricor efficiency          |    2007 |   751 |         20 |              1.5426 | 0      |     0.8277 |     0.8337 |     0.006  |
| PyMetricor maintainability     |    2007 |   751 |         20 |              1.9087 | 0      |     0.8277 |     0.8339 |     0.0062 |
| PyMetricor security            |    2007 |   751 |         20 |              1.0154 | 0.7819 |     0.8277 |     0.8272 |    -0.0005 |
| Radon MI                       |    2007 |   751 |         20 |              2.1116 | 0      |     0.8277 |     0.8375 |     0.0098 |
| Radon CC (sum)                 |    2007 |   751 |         20 |              3.4929 | 0      |     0.8277 |     0.8363 |     0.0086 |
| SonarQube debt (min)           |    2007 |   751 |         20 |              1.2459 | 0.1108 |     0.8277 |     0.8273 |    -0.0003 |
| SonarQube code smells          |    2007 |   751 |         20 |              1.2499 | 0.0571 |     0.8277 |     0.8274 |    -0.0003 |
| SonarQube cognitive complexity |    2007 |   751 |         20 |              3.3157 | 0      |     0.8277 |     0.8373 |     0.0096 |
| SonarQube debt ratio (%)       |    2007 |   751 |         20 |              1.0381 | 0.607  |     0.8277 |     0.8273 |    -0.0004 |
| PyExamine smells (all)         |    2007 |   751 |         20 |              2.2532 | 0      |     0.8277 |     0.8316 |     0.0039 |
| PyExamine code smells          |    2007 |   751 |         20 |              1.5943 | 0.0001 |     0.8277 |     0.829  |     0.0013 |
| PyExamine severity-weighted    |    2007 |   751 |         20 |              2.2548 | 0      |     0.8277 |     0.8313 |     0.0037 |

## Outcome: bugsinpy

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyExamine code smells          |         10 |        0.276 |         6 |         0.084 |          3 |        0.767 |
| PyExamine severity-weighted    |         10 |        0.269 |         7 |         0.096 |          2 |        0.802 |
| PyExamine smells (all)         |         10 |        0.263 |         7 |         0.094 |          1 |        0.799 |
| PyMetricor composite           |         10 |        0.276 |         9 |         0.155 |          3 |        0.836 |
| PyMetricor efficiency          |         10 |        0.223 |         7 |         0.115 |          4 |        0.821 |
| PyMetricor maintainability     |         10 |        0.273 |         8 |         0.074 |          3 |        0.77  |
| PyMetricor readability         |         10 |        0.254 |         8 |         0.066 |          0 |        0.756 |
| PyMetricor security            |          9 |        0.101 |         3 |         0.015 |          3 |        0.537 |
| Radon CC (sum)                 |         10 |        0.293 |        10 |         0.089 |          1 |        0.831 |
| Radon MI                       |         10 |        0.336 |         9 |         0.1   |          2 |        0.847 |
| SLOC                           |         10 |        0.271 |         9 |       nan     |          0 |        0.819 |
| SonarQube code smells          |         10 |        0.198 |         4 |         0.142 |          3 |        0.593 |
| SonarQube cognitive complexity |         10 |        0.275 |         9 |         0.088 |          3 |        0.847 |
| SonarQube debt (min)           |         10 |        0.195 |         4 |         0.136 |          3 |        0.591 |
| SonarQube debt ratio (%)       |          9 |        0.075 |         2 |         0.025 |          1 |        0.529 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    1872 |   148 |         16 |              1.8128 | 0      |     0.8814 |     0.8904 |     0.009  |
| PyMetricor readability         |    1872 |   148 |         16 |              1.2586 | 0.1263 |     0.8814 |     0.882  |     0.0006 |
| PyMetricor efficiency          |    1872 |   148 |         16 |              1.7225 | 0      |     0.8814 |     0.8906 |     0.0093 |
| PyMetricor maintainability     |    1872 |   148 |         16 |              1.3316 | 0.0125 |     0.8814 |     0.8835 |     0.0021 |
| PyMetricor security            |    1872 |   148 |         16 |              1.0241 | 0.7493 |     0.8814 |     0.88   |    -0.0014 |
| Radon MI                       |    1872 |   148 |         16 |              2.9413 | 0      |     0.8814 |     0.8946 |     0.0132 |
| Radon CC (sum)                 |    1872 |   148 |         16 |              1.5106 | 0.0002 |     0.8814 |     0.8883 |     0.0069 |
| SonarQube debt (min)           |    1872 |   148 |         16 |              1.0111 | 0.853  |     0.8814 |     0.8804 |    -0.001  |
| SonarQube code smells          |    1872 |   148 |         16 |              1.0463 | 0.4066 |     0.8814 |     0.8812 |    -0.0002 |
| SonarQube cognitive complexity |    1872 |   148 |         16 |              1.5289 | 0.0001 |     0.8814 |     0.8888 |     0.0074 |
| SonarQube debt ratio (%)       |    1872 |   148 |         16 |              0.9642 | 0.8255 |     0.8814 |     0.8804 |    -0.001  |
| PyExamine smells (all)         |    1872 |   148 |         16 |              1.3307 | 0.0107 |     0.8814 |     0.8838 |     0.0024 |
| PyExamine code smells          |    1872 |   148 |         16 |              1.2029 | 0.0326 |     0.8814 |     0.8877 |     0.0064 |
| PyExamine severity-weighted    |    1872 |   148 |         16 |              1.3418 | 0.0076 |     0.8814 |     0.8844 |     0.003  |

