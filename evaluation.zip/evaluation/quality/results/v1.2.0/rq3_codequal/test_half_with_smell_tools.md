test: 296 items, 2000 within-source bootstrap resamples
| score                |   within_rho |   ci_low |   ci_high |
|:---------------------|-------------:|---------:|----------:|
| old_read             |       -0.001 |   -0.117 |     0.116 |
| new_read             |        0.112 |    0     |     0.221 |
| old_comp             |        0.14  |    0.021 |     0.255 |
| new_comp             |        0.25  |    0.136 |     0.349 |
| radon_mi             |        0.181 |    0.07  |     0.286 |
| pyexamine            |        0.163 |    0.053 |     0.249 |
| dpy                  |        0.112 |    0.011 |     0.212 |
| new_read - old_read  |        0.113 |    0.018 |     0.207 |
| new_comp - old_comp  |        0.11  |    0.008 |     0.212 |
| new_read - radon_mi  |       -0.069 |   -0.192 |     0.054 |
| new_comp - radon_mi  |        0.069 |   -0.029 |     0.168 |
| new_read - pyexamine |       -0.051 |   -0.171 |     0.092 |
| new_comp - pyexamine |        0.087 |   -0.02  |     0.21  |
| new_read - dpy       |       -0.001 |   -0.137 |     0.137 |
| new_comp - dpy       |        0.138 |    0.02  |     0.255 |
