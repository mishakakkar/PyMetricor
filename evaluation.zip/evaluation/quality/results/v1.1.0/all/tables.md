Files: 6719, projects: 23

## Outcome: changed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyMetricor composite           |         16 |        0.49  |        14 |         0.114 |          6 |        0.756 |
| PyMetricor efficiency          |         16 |        0.336 |        10 |         0.108 |          5 |        0.64  |
| PyMetricor maintainability     |         15 |        0.373 |        11 |         0.092 |          4 |        0.61  |
| PyMetricor readability         |         16 |        0.402 |        13 |         0.095 |          4 |        0.706 |
| PyMetricor security            |         15 |        0.175 |         6 |         0.016 |          2 |        0.536 |
| Radon CC (sum)                 |         16 |        0.544 |        13 |         0.057 |          5 |        0.792 |
| Radon MI                       |         16 |        0.535 |        16 |         0.097 |          5 |        0.791 |
| SLOC                           |         16 |        0.598 |        16 |       nan     |          0 |        0.828 |
| SonarQube code smells          |         16 |        0.164 |         6 |         0.048 |          1 |        0.533 |
| SonarQube cognitive complexity |         16 |        0.566 |        14 |         0.129 |          5 |        0.768 |
| SonarQube debt (min)           |         16 |        0.163 |         6 |         0.045 |          2 |        0.533 |
| SonarQube debt ratio (%)       |         15 |        0.107 |         3 |         0.038 |          3 |        0.527 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    6696 |  5939 |         21 |              1.0983 | 0.2278 |     0.9188 |     0.9183 |    -0.0005 |
| PyMetricor readability         |    6696 |  5939 |         21 |              1.2212 | 0.0021 |     0.9188 |     0.9174 |    -0.0014 |
| PyMetricor efficiency          |    6696 |  5939 |         21 |              0.9569 | 0.5482 |     0.9188 |     0.9186 |    -0.0001 |
| PyMetricor maintainability     |    6696 |  5939 |         21 |              1.1055 | 0.3151 |     0.9188 |     0.9187 |    -0.0001 |
| PyMetricor security            |    6696 |  5939 |         21 |              0.994  | 0.9022 |     0.9188 |     0.9187 |    -0.0001 |
| Radon MI                       |    6696 |  5939 |         21 |              1.7962 | 0      |     0.9188 |     0.9198 |     0.001  |
| Radon CC (sum)                 |    6696 |  5939 |         21 |              1.9484 | 0.0001 |     0.9188 |     0.9189 |     0.0001 |
| SonarQube debt (min)           |    6696 |  5939 |         21 |              0.9832 | 0.9128 |     0.9188 |     0.9186 |    -0.0002 |
| SonarQube code smells          |    6696 |  5939 |         21 |              0.9581 | 0.7254 |     0.9188 |     0.9185 |    -0.0003 |
| SonarQube cognitive complexity |    6696 |  5939 |         21 |              1.5738 | 0.0112 |     0.9188 |     0.918  |    -0.0007 |
| SonarQube debt ratio (%)       |    6696 |  5939 |         21 |              0.9981 | 0.9553 |     0.9188 |     0.9185 |    -0.0003 |

## Outcome: fixed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyMetricor composite           |         15 |        0.492 |        12 |         0.169 |          8 |        0.76  |
| PyMetricor efficiency          |         15 |        0.379 |        10 |         0.143 |          7 |        0.694 |
| PyMetricor maintainability     |         14 |        0.318 |        10 |         0.11  |          6 |        0.632 |
| PyMetricor readability         |         15 |        0.368 |        12 |         0.112 |          4 |        0.705 |
| PyMetricor security            |         14 |        0.129 |         4 |         0.065 |          2 |        0.538 |
| Radon CC (sum)                 |         15 |        0.481 |        12 |         0.059 |          5 |        0.757 |
| Radon MI                       |         15 |        0.485 |        12 |         0.108 |          5 |        0.757 |
| SLOC                           |         15 |        0.54  |        13 |       nan     |          0 |        0.765 |
| SonarQube code smells          |         15 |        0.185 |         5 |         0.111 |          4 |        0.531 |
| SonarQube cognitive complexity |         15 |        0.519 |        13 |         0.183 |          9 |        0.778 |
| SonarQube debt (min)           |         15 |        0.184 |         5 |         0.112 |          4 |        0.531 |
| SonarQube debt ratio (%)       |         14 |        0.079 |         2 |         0.036 |          3 |        0.518 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    6684 |  1049 |         21 |              1.7535 | 0      |      0.793 |     0.8241 |     0.0311 |
| PyMetricor readability         |    6684 |  1049 |         21 |              1.5711 | 0      |      0.793 |     0.8191 |     0.0261 |
| PyMetricor efficiency          |    6684 |  1049 |         21 |              1.3941 | 0      |      0.793 |     0.8058 |     0.0129 |
| PyMetricor maintainability     |    6684 |  1049 |         21 |              1.3084 | 0      |      0.793 |     0.8003 |     0.0073 |
| PyMetricor security            |    6684 |  1049 |         21 |              1.1415 | 0      |      0.793 |     0.7976 |     0.0046 |
| Radon MI                       |    6684 |  1049 |         21 |              1.5335 | 0      |      0.793 |     0.8017 |     0.0087 |
| Radon CC (sum)                 |    6684 |  1049 |         21 |              1.4412 | 0      |      0.793 |     0.8032 |     0.0103 |
| SonarQube debt (min)           |    6684 |  1049 |         21 |              0.9894 | 0.7586 |      0.793 |     0.7929 |    -0      |
| SonarQube code smells          |    6684 |  1049 |         21 |              1.0009 | 0.9793 |      0.793 |     0.7928 |    -0.0002 |
| SonarQube cognitive complexity |    6684 |  1049 |         21 |              1.2584 | 0      |      0.793 |     0.8003 |     0.0074 |
| SonarQube debt ratio (%)       |    6684 |  1049 |         21 |              1.0133 | 0.7513 |      0.793 |     0.7928 |    -0.0002 |

## Outcome: bugsinpy

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyMetricor composite           |         11 |        0.302 |         9 |         0.109 |          4 |        0.823 |
| PyMetricor efficiency          |         11 |        0.234 |         8 |         0.137 |          3 |        0.808 |
| PyMetricor maintainability     |         10 |        0.233 |         6 |         0.048 |          4 |        0.686 |
| PyMetricor readability         |         11 |        0.273 |         9 |         0.03  |          1 |        0.759 |
| PyMetricor security            |         10 |        0.089 |         3 |         0.029 |          4 |        0.544 |
| Radon CC (sum)                 |         11 |        0.267 |        11 |         0.063 |          2 |        0.814 |
| Radon MI                       |         11 |        0.327 |         9 |         0.068 |          2 |        0.847 |
| SLOC                           |         11 |        0.238 |         9 |       nan     |          0 |        0.805 |
| SonarQube code smells          |         11 |        0.185 |         5 |         0.13  |          4 |        0.593 |
| SonarQube cognitive complexity |         11 |        0.247 |        10 |         0.086 |          4 |        0.843 |
| SonarQube debt (min)           |         11 |        0.184 |         5 |         0.123 |          4 |        0.592 |
| SonarQube debt ratio (%)       |         10 |        0.053 |         2 |         0.022 |          1 |        0.53  |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    6549 |   155 |         17 |              1.5917 | 0      |     0.9469 |     0.9505 |     0.0036 |
| PyMetricor readability         |    6549 |   155 |         17 |              1.321  | 0.0352 |     0.9469 |     0.9469 |    -0      |
| PyMetricor efficiency          |    6549 |   155 |         17 |              1.4578 | 0.0005 |     0.9469 |     0.95   |     0.0031 |
| PyMetricor maintainability     |    6549 |   155 |         17 |              1.187  | 0.0091 |     0.9469 |     0.9482 |     0.0013 |
| PyMetricor security            |    6549 |   155 |         17 |              1.0108 | 0.8397 |     0.9469 |     0.9466 |    -0.0003 |
| Radon MI                       |    6549 |   155 |         17 |              2.751  | 0      |     0.9469 |     0.953  |     0.0061 |
| Radon CC (sum)                 |    6549 |   155 |         17 |              1.3456 | 0.0001 |     0.9469 |     0.9495 |     0.0026 |
| SonarQube debt (min)           |    6549 |   155 |         17 |              1.0206 | 0.749  |     0.9469 |     0.9471 |     0.0002 |
| SonarQube code smells          |    6549 |   155 |         17 |              1.048  | 0.3764 |     0.9469 |     0.947  |     0.0001 |
| SonarQube cognitive complexity |    6549 |   155 |         17 |              1.2881 | 0.0005 |     0.9469 |     0.9481 |     0.0011 |
| SonarQube debt ratio (%)       |    6549 |   155 |         17 |              0.9976 | 0.9743 |     0.9469 |     0.9466 |    -0.0004 |

