Files: 2042, projects: 22

## Outcome: changed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyMetricor composite           |         15 |        0.492 |        13 |         0.126 |          5 |        0.773 |
| PyMetricor efficiency          |         15 |        0.343 |         9 |         0.159 |          4 |        0.655 |
| PyMetricor maintainability     |         14 |        0.395 |        10 |         0.088 |          3 |        0.619 |
| PyMetricor readability         |         15 |        0.411 |        12 |         0.093 |          3 |        0.711 |
| PyMetricor security            |         14 |        0.178 |         5 |         0.009 |          1 |        0.537 |
| Radon CC (sum)                 |         15 |        0.561 |        12 |         0.046 |          4 |        0.818 |
| Radon MI                       |         15 |        0.542 |        15 |         0.099 |          4 |        0.803 |
| SLOC                           |         15 |        0.599 |        15 |       nan     |          0 |        0.823 |
| SonarQube code smells          |         15 |        0.168 |         5 |         0.05  |          1 |        0.535 |
| SonarQube cognitive complexity |         15 |        0.581 |        13 |         0.163 |          4 |        0.772 |
| SonarQube debt (min)           |         15 |        0.166 |         5 |         0.046 |          2 |        0.535 |
| SonarQube debt ratio (%)       |         14 |        0.116 |         2 |         0.034 |          2 |        0.529 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    2019 |  1393 |         20 |              1.9684 | 0      |     0.8569 |     0.8614 |     0.0045 |
| PyMetricor readability         |    2019 |  1393 |         20 |              1.627  | 0      |     0.8569 |     0.8601 |     0.0031 |
| PyMetricor efficiency          |    2019 |  1393 |         20 |              1.4544 | 0      |     0.8569 |     0.8594 |     0.0025 |
| PyMetricor maintainability     |    2019 |  1393 |         20 |              1.6067 | 0.003  |     0.8569 |     0.8585 |     0.0016 |
| PyMetricor security            |    2019 |  1393 |         20 |              1.0089 | 0.9011 |     0.8569 |     0.8564 |    -0.0005 |
| Radon MI                       |    2019 |  1393 |         20 |              2.0863 | 0      |     0.8569 |     0.8657 |     0.0088 |
| Radon CC (sum)                 |    2019 |  1393 |         20 |             12.7413 | 0      |     0.8569 |     0.8654 |     0.0085 |
| SonarQube debt (min)           |    2019 |  1393 |         20 |              1.382  | 0.1534 |     0.8569 |     0.8569 |     0      |
| SonarQube code smells          |    2019 |  1393 |         20 |              1.4198 | 0.0724 |     0.8569 |     0.8571 |     0.0002 |
| SonarQube cognitive complexity |    2019 |  1393 |         20 |              9.1631 | 0      |     0.8569 |     0.8646 |     0.0077 |
| SonarQube debt ratio (%)       |    2019 |  1393 |         20 |              1.0015 | 0.9781 |     0.8569 |     0.8563 |    -0.0006 |

## Outcome: fixed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyMetricor composite           |         14 |        0.498 |        11 |         0.171 |          7 |        0.761 |
| PyMetricor efficiency          |         14 |        0.424 |         9 |         0.151 |          6 |        0.719 |
| PyMetricor maintainability     |         13 |        0.416 |         9 |         0.108 |          5 |        0.633 |
| PyMetricor readability         |         14 |        0.37  |        11 |         0.111 |          3 |        0.71  |
| PyMetricor security            |         13 |        0.12  |         3 |         0.055 |          1 |        0.531 |
| Radon CC (sum)                 |         14 |        0.524 |        11 |         0.055 |          4 |        0.77  |
| Radon MI                       |         14 |        0.514 |        12 |         0.119 |          4 |        0.759 |
| SLOC                           |         14 |        0.543 |        13 |       nan     |          0 |        0.767 |
| SonarQube code smells          |         14 |        0.191 |         5 |         0.112 |          3 |        0.537 |
| SonarQube cognitive complexity |         14 |        0.53  |        12 |         0.226 |          8 |        0.778 |
| SonarQube debt (min)           |         14 |        0.19  |         5 |         0.112 |          3 |        0.537 |
| SonarQube debt ratio (%)       |         13 |        0.123 |         2 |         0.052 |          3 |        0.518 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    2007 |   751 |         20 |              1.8711 | 0      |     0.8277 |     0.8341 |     0.0064 |
| PyMetricor readability         |    2007 |   751 |         20 |              1.359  | 0      |     0.8277 |     0.8299 |     0.0022 |
| PyMetricor efficiency          |    2007 |   751 |         20 |              1.6119 | 0      |     0.8277 |     0.833  |     0.0054 |
| PyMetricor maintainability     |    2007 |   751 |         20 |              1.495  | 0      |     0.8277 |     0.8299 |     0.0022 |
| PyMetricor security            |    2007 |   751 |         20 |              1.0096 | 0.863  |     0.8277 |     0.8274 |    -0.0003 |
| Radon MI                       |    2007 |   751 |         20 |              2.1116 | 0      |     0.8277 |     0.8375 |     0.0098 |
| Radon CC (sum)                 |    2007 |   751 |         20 |              3.4929 | 0      |     0.8277 |     0.8363 |     0.0086 |
| SonarQube debt (min)           |    2007 |   751 |         20 |              1.2459 | 0.1108 |     0.8277 |     0.8273 |    -0.0003 |
| SonarQube code smells          |    2007 |   751 |         20 |              1.2499 | 0.0571 |     0.8277 |     0.8274 |    -0.0003 |
| SonarQube cognitive complexity |    2007 |   751 |         20 |              3.3157 | 0      |     0.8277 |     0.8373 |     0.0096 |
| SonarQube debt ratio (%)       |    2007 |   751 |         20 |              1.0381 | 0.607  |     0.8277 |     0.8273 |    -0.0004 |

## Outcome: bugsinpy

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyMetricor composite           |         10 |        0.305 |         8 |         0.111 |          3 |        0.837 |
| PyMetricor efficiency          |         10 |        0.239 |         7 |         0.155 |          2 |        0.797 |
| PyMetricor maintainability     |          9 |        0.237 |         5 |         0.058 |          3 |        0.672 |
| PyMetricor readability         |         10 |        0.274 |         9 |         0.062 |          1 |        0.76  |
| PyMetricor security            |          9 |        0.109 |         2 |         0.015 |          3 |        0.544 |
| Radon CC (sum)                 |         10 |        0.293 |        10 |         0.089 |          1 |        0.831 |
| Radon MI                       |         10 |        0.336 |         9 |         0.1   |          2 |        0.847 |
| SLOC                           |         10 |        0.271 |         9 |       nan     |          0 |        0.819 |
| SonarQube code smells          |         10 |        0.198 |         4 |         0.142 |          3 |        0.593 |
| SonarQube cognitive complexity |         10 |        0.275 |         9 |         0.088 |          3 |        0.847 |
| SonarQube debt (min)           |         10 |        0.195 |         4 |         0.136 |          3 |        0.591 |
| SonarQube debt ratio (%)       |          9 |        0.075 |         2 |         0.025 |          1 |        0.529 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    1872 |   148 |         16 |              1.6046 | 0.0002 |     0.8814 |     0.8902 |     0.0088 |
| PyMetricor readability         |    1872 |   148 |         16 |              1.3865 | 0.03   |     0.8814 |     0.8831 |     0.0017 |
| PyMetricor efficiency          |    1872 |   148 |         16 |              1.3867 | 0.0024 |     0.8814 |     0.8843 |     0.0029 |
| PyMetricor maintainability     |    1872 |   148 |         16 |              1.2046 | 0.0191 |     0.8814 |     0.883  |     0.0016 |
| PyMetricor security            |    1872 |   148 |         16 |              1.0148 | 0.8448 |     0.8814 |     0.8802 |    -0.0011 |
| Radon MI                       |    1872 |   148 |         16 |              2.9413 | 0      |     0.8814 |     0.8946 |     0.0132 |
| Radon CC (sum)                 |    1872 |   148 |         16 |              1.5106 | 0.0002 |     0.8814 |     0.8883 |     0.0069 |
| SonarQube debt (min)           |    1872 |   148 |         16 |              1.0111 | 0.853  |     0.8814 |     0.8804 |    -0.001  |
| SonarQube code smells          |    1872 |   148 |         16 |              1.0463 | 0.4066 |     0.8814 |     0.8812 |    -0.0002 |
| SonarQube cognitive complexity |    1872 |   148 |         16 |              1.5289 | 0.0001 |     0.8814 |     0.8888 |     0.0074 |
| SonarQube debt ratio (%)       |    1872 |   148 |         16 |              0.9642 | 0.8255 |     0.8814 |     0.8804 |    -0.001  |

