dev: 337 items, 2000 within-source bootstrap resamples
| score               |   within_rho |   ci_low |   ci_high |
|:--------------------|-------------:|---------:|----------:|
| old_read            |        0.089 |   -0.02  |     0.198 |
| new_read            |        0.217 |    0.115 |     0.314 |
| old_comp            |        0.237 |    0.133 |     0.338 |
| new_comp            |        0.262 |    0.164 |     0.359 |
| radon_mi            |        0.23  |    0.131 |     0.325 |
| new_read - old_read |        0.127 |    0.031 |     0.227 |
| new_comp - old_comp |        0.025 |   -0.051 |     0.102 |
| new_read - radon_mi |       -0.013 |   -0.128 |     0.101 |
| new_comp - radon_mi |        0.032 |   -0.076 |     0.141 |
