test: 296 items, 2000 within-source bootstrap resamples
| score               |   within_rho |   ci_low |   ci_high |
|:--------------------|-------------:|---------:|----------:|
| old_read            |       -0.001 |   -0.117 |     0.111 |
| new_read            |        0.127 |    0.017 |     0.234 |
| old_comp            |        0.14  |    0.023 |     0.254 |
| new_comp            |        0.21  |    0.093 |     0.318 |
| radon_mi            |        0.181 |    0.07  |     0.291 |
| new_read - old_read |        0.128 |    0.033 |     0.219 |
| new_comp - old_comp |        0.069 |   -0.006 |     0.151 |
| new_read - radon_mi |       -0.054 |   -0.177 |     0.065 |
| new_comp - radon_mi |        0.029 |   -0.086 |     0.139 |
