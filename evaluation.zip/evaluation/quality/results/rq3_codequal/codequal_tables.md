Items: 637 (sources: {'codesearchnet': 238, 'codenet': 221, 'mbpp': 98, 'codeeval': 76, 'humaneval-x': 4})

Spearman rho with mean human readability, pooled and within source (within_source_rho = n-weighted mean of the per-source rhos)

| model                   |    all |   codeeval |   codenet |   codesearchnet |   mbpp |   within_source_rho |
|:------------------------|-------:|-----------:|----------:|----------------:|-------:|--------------------:|
| PyMetricor readability  | -0.025 |      0.068 |    -0.011 |          -0.011 |  0.283 |               0.044 |
| PyMetricor composite    |  0.116 |      0.185 |     0.013 |           0.317 |  0.327 |               0.197 |
| Radon MI                |  0.436 |     -0.18  |    -0.004 |           0.419 |  0.462 |               0.206 |
| SLOC (negated)          |  0.256 |     -0.273 |    -0.036 |           0.454 |  0.428 |               0.192 |
| CC sum (negated)        | -0.174 |     -0.137 |    -0.067 |           0.423 |  0.459 |               0.19  |
| o3-mini (LLM reference) |  0.468 |      0.541 |     0.11  |           0.41  |  0.502 |               0.342 |

Partial rho controlling for SLOC

| model                   |    all |   codeeval |   codenet |   codesearchnet |   mbpp |
|:------------------------|-------:|-----------:|----------:|----------------:|-------:|
| PyMetricor readability  |  0.015 |      0.113 |    -0.014 |           0.068 |  0.003 |
| PyMetricor composite    |  0.096 |      0.207 |     0.017 |           0.261 |  0.058 |
| Radon MI                |  0.384 |     -0.105 |     0.029 |           0.215 |  0.232 |
| CC sum (negated)        | -0.327 |      0.082 |    -0.057 |           0.195 |  0.22  |
| o3-mini (LLM reference) |  0.426 |      0.508 |     0.119 |           0.317 |  0.408 |

Human agreement: one rating vs mean of the other raters on the same item

| source        |   loo_rho |   ratings |
|:--------------|----------:|----------:|
| all           |     0.507 |      2157 |
| codeeval      |     0.367 |       253 |
| codenet       |     0.391 |       884 |
| codesearchnet |     0.35  |       714 |
| humaneval-x   |     0.186 |        12 |
| mbpp          |     0.26  |       294 |
