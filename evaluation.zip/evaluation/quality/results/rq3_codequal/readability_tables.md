Raters kept: 5, items: 637, ratings: 2157
ICC(2,k) over 3 raters who rated every item: 0.602

| model                            |   spearman |     p |   kendall |   ci_low |   ci_high |   partial_rho_sloc |   partial_p |
|:---------------------------------|-----------:|------:|----------:|---------:|----------:|-------------------:|------------:|
| PyMetricor readability           |     -0.025 | 0.537 |    -0.017 |   -0.097 |     0.049 |              0.015 |       0.71  |
| PyMetricor composite             |      0.116 | 0.003 |     0.085 |    0.04  |     0.193 |              0.096 |       0.016 |
| Radon MI                         |      0.436 | 0     |     0.311 |    0.373 |     0.496 |              0.384 |       0     |
| SLOC (negated)                   |      0.256 | 0     |     0.186 |    0.185 |     0.328 |            nan     |     nan     |
| CC sum (negated)                 |     -0.174 | 0     |    -0.121 |   -0.251 |    -0.089 |             -0.327 |       0     |
| PM line_length_distribution      |      0.11  | 0.005 |     0.094 |    0.038 |     0.172 |              0.106 |       0.007 |
| PM indentation_stability         |     -0.141 | 0     |    -0.111 |   -0.212 |    -0.066 |             -0.217 |       0     |
| PM identifier_style              |      0.079 | 0.045 |     0.064 |    0.005 |     0.16  |              0.026 |       0.505 |
| PM comment_density               |      0.07  | 0.077 |     0.055 |   -0.003 |     0.146 |              0.233 |       0     |
| PM blank_line_rhythm             |      0.01  | 0.8   |     0.009 |   -0.065 |     0.084 |              0.045 |       0.26  |
| PM string_formatting_consistency |      0.024 | 0.541 |     0.021 |   -0.048 |     0.108 |              0.004 |       0.925 |

PyMetricor readability minus baseline (bootstrap)

| baseline                         |   rho_diff |   ci_low |   ci_high |
|:---------------------------------|-----------:|---------:|----------:|
| PyMetricor composite             |     -0.142 |   -0.199 |    -0.085 |
| Radon MI                         |     -0.461 |   -0.547 |    -0.369 |
| SLOC (negated)                   |     -0.281 |   -0.387 |    -0.171 |
| CC sum (negated)                 |      0.149 |    0.035 |     0.262 |
| PM line_length_distribution      |     -0.133 |   -0.227 |    -0.035 |
| PM indentation_stability         |      0.117 |    0.032 |     0.204 |
| PM identifier_style              |     -0.105 |   -0.204 |    -0.007 |
| PM comment_density               |     -0.094 |   -0.177 |    -0.01  |
| PM blank_line_rhythm             |     -0.035 |   -0.099 |     0.033 |
| PM string_formatting_consistency |     -0.05  |   -0.16  |     0.057 |
