"""
Mine file-level change- and defect-proneness labels for RQ4.

For each project a snapshot commit T is chosen, every non-test .py file present
at T is listed, and the commits in the window (T, T + WINDOW_MONTHS] are mined:

  changes        first-parent commits (a merged PR = one) touching the file
  fixes          those whose message looks like a bug fix (FIX_RE, not NOT_FIX_RE)
  bugsinpy       BugsInPy bugs (manually validated) whose fix touched the file,
                 counting every BugsInPy bug fixed after T (no window; few per project)

Snapshot rule
  BugsInPy projects: the first-parent commit just before the median BugsInPy fix date,
                     so that half of the validated bugs fall after T.
  Mined projects:    the first-parent commit just before MINED_SNAPSHOT.

The snapshot tree is exported (non-test .py files only) to <out>/<project>/src/ so
every metric tool sees exactly the same files. Output: <out>/<project>/labels.csv
and <out>/snapshots.json.

    python mine.py --repos qrepos --bugsinpy BugsInPy --list qrepos.txt --out quality
"""
import argparse
import csv
import datetime as dt
import json
import re
import statistics
import subprocess
from collections import Counter
from pathlib import Path

WINDOW_MONTHS = 12
MINED_SNAPSHOT = "2024-07-01"
MAX_BYTES = 300_000
FIX_RE = re.compile(r"\b(fix(e[sd]|ing)?|bugs?|bugfix|defect|fault|crash(es|ed)?|regression|incorrect|wrong)\b", re.I)
NOT_FIX_RE = re.compile(r"\b(typo|docs?|documentation|readme|changelog|lint|flake8|whitespace|spelling)\b", re.I)
TEST_RE = re.compile(r"(^|/)(tests?|testing|test_utils|docs?|examples?|benchmarks?|asv_bench|profiling|scripts|ci|tools|\.github)(/|$)|(^|/)(test_[^/]*|[^/]*_test|conftest|setup)\.py$")


def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], capture_output=True, text=True, check=True).stdout


def bugsinpy_bugs(bdir, project):
    out = []
    pdir = Path(bdir) / "projects" / project / "bugs"
    if not pdir.exists():
        return out
    for b in sorted((d for d in pdir.iterdir() if d.is_dir() and d.name.isdigit()), key=lambda p: int(p.name)):
        info = dict(re.findall(r'(\w+)\s*=\s*"([^"]*)"', (b / "bug.info").read_text()))
        files = re.findall(r"^diff --git a/(\S+) b/", (b / "bug_patch.txt").read_text(errors="replace"), re.M)
        if info.get("fixed_commit_id"):
            out.append({"bug": b.name, "fixed": info["fixed_commit_id"], "files": files})
    return out


def add_months(d, m):
    y, mo = divmod(d.month - 1 + m, 12)
    return d.replace(year=d.year + y, month=mo + 1, day=min(d.day, 28))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repos", required=True)
    ap.add_argument("--bugsinpy", required=True)
    ap.add_argument("--list", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    snaps_path = out / "snapshots.json"
    snaps = json.loads(snaps_path.read_text()) if snaps_path.exists() else {}

    for line in open(a.list):
        project, url = line.split()
        if a.only and project not in a.only:
            continue
        repo = Path(a.repos) / project
        bugs = bugsinpy_bugs(a.bugsinpy, project)
        for b in bugs:
            try:
                b["date"] = git(repo, "show", "-s", "--format=%cI", b["fixed"]).strip()
            except subprocess.CalledProcessError:
                b["date"] = None
        dated = [b for b in bugs if b["date"]]
        if dated:
            cut = statistics.median_low(sorted(b["date"] for b in dated))
            rule = "median BugsInPy fix date"
        else:
            cut = MINED_SNAPSHOT
            rule = "fixed date"
        T = git(repo, "rev-list", "-1", "--first-parent", f"--before={cut}", "HEAD").strip()
        t_date = dt.datetime.fromisoformat(git(repo, "show", "-s", "--format=%cI", T).strip())
        end = add_months(t_date, WINDOW_MONTHS)

        files = [f for f in git(repo, "ls-tree", "-r", "--name-only", T).split()
                 if f.endswith(".py") and not TEST_RE.search(f)]
        fileset = set(files)

        # first-parent history with merges diffed against their first parent, so a merged
        # pull request counts as one change (its subject + body are used for fix detection)
        log = git(repo, "log", "--first-parent", "--diff-merges=first-parent", "--format=%x1d%H%x09%s %b%x1e", "--name-only",
                  f"--since={t_date.isoformat()}", f"--until={end.isoformat()}", "HEAD")
        changes, fixes, commits, fix_commits = Counter(), Counter(), 0, 0
        for block in log.split("\x1d")[1:]:
            head, _, rest = block.partition("\x1e")
            paths = rest.split()
            sha, _, subj = head.strip().partition("\t")
            touched = [p for p in paths if p in fileset]
            commits += 1
            is_fix = bool(FIX_RE.search(subj)) and not NOT_FIX_RE.search(subj)
            fix_commits += is_fix
            for p in touched:
                changes[p] += 1
                if is_fix:
                    fixes[p] += 1
        bip = Counter()
        later = [b for b in dated if dt.datetime.fromisoformat(b["date"]) > t_date]
        for b in later:
            for p in set(b["files"]):
                if p in fileset:
                    bip[p] += 1

        pdir = out / project
        src = pdir / "src"
        if src.exists():
            subprocess.run(["rm", "-rf", str(src)], check=True)
        src.mkdir(parents=True)
        # export only the selected files at T (blobs are fetched on demand)
        arch = subprocess.run(["git", "-C", str(repo), "archive", "--format=tar", T, "--", *files],
                              capture_output=True, check=True).stdout
        subprocess.run(["tar", "-x", "-C", str(src)], input=arch, check=True)
        # drop very large (usually generated) files from the study
        # (and symlinks, which may dangle outside the export)
        big = {f for f in files if (src / f).is_symlink() or not (src / f).is_file()
               or (src / f).stat().st_size > MAX_BYTES}
        for f in big:
            (src / f).unlink(missing_ok=True)
        files = [f for f in files if f not in big]
        with open(pdir / "labels.csv", "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["path", "changes", "fixes", "bugsinpy"])
            for f in files:
                w.writerow([f, changes[f], fixes[f], bip[f]])
        snaps[project] = {"url": url, "snapshot": T, "snapshot_date": t_date.isoformat(), "rule": rule,
                          "window_end": end.isoformat(), "files": len(files), "dropped_large": len(big), "window_commits": commits,
                          "window_fix_commits": fix_commits, "bugsinpy_bugs_after_T": len(later),
                          "files_changed": sum(1 for f in files if changes[f]),
                          "files_fixed": sum(1 for f in files if fixes[f]),
                          "files_bugsinpy": sum(1 for f in files if bip[f])}
        print(project, snaps[project], flush=True)
        snaps_path.write_text(json.dumps(snaps, indent=1))


if __name__ == "__main__":
    main()
