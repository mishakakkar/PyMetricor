"""
RQ4: do PyMetricor's file scores predict change- and defect-proneness beyond size?

Joins labels.csv (mine.py) with metrics/ (metrics.py) per project and reports, for
each metric and outcome:

  rho        Spearman correlation with the outcome count, per project
  prho       partial Spearman controlling for size (log SLOC): ranks of metric and
             outcome are each residualised on the rank of SLOC
  AUC        per-project ROC AUC of the metric alone for the binary outcome
             (oriented so that higher = more defect-prone)
  pooled     logistic regression on all files with project fixed effects:
               base:  outcome ~ log1p(SLOC) + project
               full:  base + z(metric)
             likelihood-ratio test p, odds ratio per SD of the metric, and the
             10-fold cross-validated AUC gain of full over base

Projects enter the per-project summaries only with >= MIN_FILES files and
>= MIN_POS positive files for that outcome; medians and the number of projects
with p < .05 are reported.

    python analyse.py --quality quality --out results
"""
import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

MIN_FILES, MIN_POS = 20, 5
OUTCOMES = {"changed": "changes", "fixed": "fixes", "bugsinpy": "bugsinpy"}
# metric name -> (column, sign): sign -1 means "higher value = better quality"
METRICS = {
    "PyMetricor composite": ("pm_score", -1),
    "PyMetricor readability": ("pm_Readability", -1),
    "PyMetricor efficiency": ("pm_Efficiency", -1),
    "PyMetricor maintainability": ("pm_Maintainability", -1),
    "PyMetricor security": ("pm_Security", -1),
    "Radon MI": ("mi", -1),
    "Radon CC (sum)": ("cc_sum", 1),
    "SonarQube debt (min)": ("sqale_index", 1),
    "SonarQube code smells": ("code_smells", 1),
    "SonarQube cognitive complexity": ("cognitive_complexity", 1),
    "SonarQube debt ratio (%)": ("sqale_debt_ratio", 1),
    "SLOC": ("sloc", 1),
}


def load_project(p):
    lab = pd.read_csv(p / "labels.csv")
    m = p / "metrics"
    pm = json.loads((m / "pymetricor.json").read_text())
    pmf = pd.DataFrame([{"path": f["path"], "pm_score": f["score"], "pm_mass": f["mass"],
                         "pm_errors": len(f["errors"]),
                         **{f"pm_{k}": v for k, v in f["sections"].items()}} for f in pm["files"]])
    rad = json.loads((m / "radon.json").read_text())
    radf = pd.DataFrame([{"path": k, **v} for k, v in rad.items() if "error" not in v])
    df = lab.merge(pmf, on="path", how="left").merge(radf, on="path", how="left")
    sq = m / "sonar.json"
    if sq.exists():
        sqf = pd.DataFrame(json.loads(sq.read_text()))
        cols = ["sqale_index", "code_smells", "cognitive_complexity", "sqale_debt_ratio"]
        for c in cols:
            if c not in sqf:
                sqf[c] = np.nan
        sqf[cols] = sqf[cols].fillna(0.0)          # absent = best value (0) in the Sonar API
        df = df.merge(sqf[["path", *cols]], on="path", how="left")
    df["project"] = p.name
    for o, c in OUTCOMES.items():
        df[o] = (df[c] > 0).astype(int)
    return df


def partial_spearman(x, y, z):
    rx, ry, rz = (stats.rankdata(v) for v in (x, y, z))
    res = []
    for r in (rx, ry):
        b = np.polyfit(rz, r, 1)
        res.append(r - np.polyval(b, rz))
    return stats.pearsonr(*res)


def per_project(df):
    rows = []
    for (proj, g) in df.groupby("project"):
        for o, cnt in OUTCOMES.items():
            if len(g) < MIN_FILES or g[o].sum() < MIN_POS:
                continue
            for name, (col, sign) in METRICS.items():
                if col not in g:
                    continue
                h = g[list(dict.fromkeys([col, cnt, o, "sloc"]))].dropna()
                if len(h) < MIN_FILES or h[o].sum() < MIN_POS or h[col].nunique() < 2:
                    continue
                rho, p = stats.spearmanr(sign * h[col], h[cnt])
                if col == "sloc":
                    prho, pp = float("nan"), float("nan")
                else:
                    prho, pp = partial_spearman(sign * h[col], h[cnt], h["sloc"])
                auc = roc_auc_score(h[o], sign * h[col]) if 0 < h[o].sum() < len(h) else float("nan")
                rows.append({"project": proj, "outcome": o, "metric": name, "n": len(h), "pos": int(h[o].sum()),
                             "rho": rho, "p": p, "prho": prho, "pp": pp, "auc": auc})
    return pd.DataFrame(rows)


def pooled(df):
    rows = []
    for o in OUTCOMES:
        for name, (col, sign) in METRICS.items():
            if col == "sloc" or col not in df:
                continue
            h = df[[col, "sloc", "project", o]].dropna().copy()
            # keep projects that have both classes for this outcome
            ok = h.groupby("project")[o].transform(lambda s: 0 < s.sum() < len(s))
            h = h[ok]
            if h[o].sum() < 20:
                continue
            h["lsloc"] = np.log1p(h["sloc"])
            h["z"] = sign * (h[col] - h[col].mean()) / (h[col].std() or 1)
            fe = pd.get_dummies(h["project"], drop_first=True, dtype=float)
            Xb = sm.add_constant(pd.concat([h[["lsloc"]], fe], axis=1))
            Xf = pd.concat([Xb, h[["z"]]], axis=1)
            try:
                mb = sm.Logit(h[o], Xb).fit(disp=0, maxiter=200)
                mf = sm.Logit(h[o], Xf).fit(disp=0, maxiter=200)
            except Exception as e:  # separation etc.
                rows.append({"outcome": o, "metric": name, "error": str(e)[:100]})
                continue
            lr = 2 * (mf.llf - mb.llf)
            p = stats.chi2.sf(lr, 1)
            # cross-validated AUC, base vs full
            skf = StratifiedKFold(10, shuffle=True, random_state=1)
            pb, pf = np.zeros(len(h)), np.zeros(len(h))
            for tr, te in skf.split(Xf, h[o]):
                for X, pred in ((Xb, pb), (Xf, pf)):
                    clf = LogisticRegression(max_iter=2000, C=1e6).fit(X.iloc[tr], h[o].iloc[tr])
                    pred[te] = clf.predict_proba(X.iloc[te])[:, 1]
            rows.append({"outcome": o, "metric": name, "files": len(h), "pos": int(h[o].sum()),
                         "projects": h["project"].nunique(),
                         "odds_ratio_per_sd": math.exp(mf.params["z"]), "lr_p": p,
                         "auc_base": roc_auc_score(h[o], pb), "auc_full": roc_auc_score(h[o], pf)})
    out = pd.DataFrame(rows)
    if "auc_full" in out:
        out["auc_gain"] = out["auc_full"] - out["auc_base"]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quality", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--exclude", nargs="*", default=[], help="projects to leave out (sensitivity runs)")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    frames = []
    for p in sorted(Path(a.quality).iterdir()):
        if p.name in a.exclude:
            continue
        if (p / "metrics" / "pymetricor.json").exists() and (p / "metrics" / "radon.json").exists():
            frames.append(load_project(p))
    df = pd.concat(frames, ignore_index=True)
    df.to_csv(out / "files_all.csv", index=False)
    # compare tools on the same files: PyMetricor skips __init__.py, Radon can fail on a few
    df = df.dropna(subset=["pm_score", "mi", "sqale_index"]).reset_index(drop=True)
    df.to_csv(out / "files.csv", index=False)
    pp = per_project(df)
    pp.to_csv(out / "per_project.csv", index=False)
    summ = (pp.groupby(["outcome", "metric"])
              .agg(projects=("project", "nunique"), median_rho=("rho", "median"),
                   sig_rho=("p", lambda s: int((s < .05).sum())), median_prho=("prho", "median"),
                   sig_prho=("pp", lambda s: int((s < .05).sum())), median_auc=("auc", "median"))
              .reset_index())
    summ.to_csv(out / "summary_per_project.csv", index=False)
    po = pooled(df)
    po.to_csv(out / "pooled.csv", index=False)
    with open(out / "tables.md", "w") as fh:
        fh.write(f"Files: {len(df)}, projects: {df['project'].nunique()}\n\n")
        for o in OUTCOMES:
            fh.write(f"## Outcome: {o}\n\nPer project (median over projects; sig = projects with p < .05)\n\n")
            fh.write(summ[summ.outcome == o].drop(columns="outcome").round(3).to_markdown(index=False) + "\n\n")
            if len(po) and "auc_gain" in po:
                fh.write("Pooled logistic regression with project fixed effects and log SLOC\n\n")
                fh.write(po[po.outcome == o].drop(columns="outcome").round(4).to_markdown(index=False) + "\n\n")
    print((out / "tables.md").read_text())


if __name__ == "__main__":
    main()
