"""
Compute per-file quality metrics on mined snapshots (RQ4).

For each <quality>/<project>/src produced by mine.py this writes
<quality>/<project>/metrics/{pymetricor.json, radon.json, sonar.json}. Tools:

  PyMetricor  1.0.1 via the reproduction driver (per-file composite, sections, metrics)
  Radon       6.0.1: maintainability index, raw LOC/SLOC, cyclomatic complexity
  SonarQube   Community Build in Docker (server on localhost:9000), scanned with
              sonar-scanner-cli; per-file measures pulled from the web API

    python metrics.py --quality quality [--tools pymetricor radon sonar] [--only black]

Environment: PM_PY, PM_DIR, PM_DRIVER, RADON, SONAR_TOKEN, SONAR_READ_TOKEN (see defaults below).
"""
import argparse
import base64
import json
import os
import subprocess
import time
import urllib.parse
import urllib.request
from pathlib import Path

SCR = Path(os.environ.get("EVAL_WORK", Path(__file__).resolve().parents[2] / ".eval-work"))   # holds venvs/ and scratch output
PM_PY = os.environ.get("PM_PY", str(SCR / "repro-work/venvs/pymetricor/bin/python"))
PM_DIR = os.environ.get("PM_DIR", str(Path(__file__).resolve().parents[2]))
PM_DRIVER = os.environ.get("PM_DRIVER", str(Path(__file__).resolve().parents[1] / "reproduction/drivers/pymetricor_driver.py"))
RADON = os.environ.get("RADON", str(SCR / "repro-work/venvs/radon/bin/radon"))
SONAR = os.environ.get("SONAR_URL", "http://localhost:9000")
SONAR_TOKEN = os.environ.get("SONAR_TOKEN", "")            # analysis token (scanner)
SONAR_READ_TOKEN = os.environ.get("SONAR_READ_TOKEN", "")  # user token (web API reads)
SONAR_METRICS = ["ncloc", "complexity", "cognitive_complexity", "code_smells", "sqale_index",
                 "sqale_debt_ratio", "sqale_rating", "bugs", "reliability_rating", "duplicated_lines_density",
                 "comment_lines_density"]


def sh(cmd, out=None, **kw):
    t0 = time.perf_counter()
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if out:
        Path(out).write_text(r.stdout)
    return r, round(time.perf_counter() - t0, 1)


def api(path, **params):
    req = urllib.request.Request(f"{SONAR}{path}?{urllib.parse.urlencode(params)}")
    req.add_header("Authorization", "Basic " + base64.b64encode(f"{SONAR_READ_TOKEN}:".encode()).decode())
    return json.load(urllib.request.urlopen(req))


def run_pymetricor(p, m):
    r, s = sh([PM_PY, PM_DRIVER, "--pymetricor-dir", PM_DIR, "--target", str(p / "src"), "--out", str(m / "pymetricor.json")])
    return {"exit": r.returncode, "seconds": s, "stderr": r.stderr[-500:]}


def run_radon(p, m):
    py = str(Path(RADON).parent / "python")
    r, s = sh([py, "-I", str(Path(__file__).parent / "radon_metrics.py"), str(p / "src"), str(m / "radon.json")])
    return {"exit": r.returncode, "seconds": s, "stdout": r.stdout.strip(), "stderr": r.stderr[-300:]}


def run_sonar(p, m):
    key = f"pm-{p.name}"
    r, s = sh(["docker", "run", "--rm", "--network", "host", "-v", f"{p / 'src'}:/usr/src",
               "-e", f"SONAR_HOST_URL={SONAR}", "-e", f"SONAR_TOKEN={SONAR_TOKEN}",
               "sonarsource/sonar-scanner-cli:latest",
               f"-Dsonar.projectKey={key}", "-Dsonar.sources=.", "-Dsonar.python.version=3",
               "-Dsonar.scm.disabled=true", "-Dsonar.qualitygate.wait=true", "-Dsonar.qualitygate.timeout=1800"])
    (m / "sonar_scanner.log").write_text(r.stdout[-20000:] + r.stderr[-5000:])
    return {"exit": r.returncode, "seconds": s, **fetch_sonar(p, m)}


def fetch_sonar(p, m):
    """Measures absent from a component are at their best value (0) in SonarQube's API."""
    key = f"pm-{p.name}"
    rows, page = [], 1
    while True:
        d = api("/api/measures/component_tree", component=key, metricKeys=",".join(SONAR_METRICS),
                qualifiers="FIL", ps=500, p=page)
        for c in d["components"]:
            rows.append({"path": c["path"], **{x["metric"]: float(x["value"]) for x in c["measures"] if "value" in x}})
        if page * 500 >= d["paging"]["total"]:
            break
        page += 1
    (m / "sonar.json").write_text(json.dumps(rows))
    return {"files": len(rows)}


RUN = {"pymetricor": run_pymetricor, "radon": run_radon, "sonar": run_sonar,
       "sonar_fetch": lambda p, m: fetch_sonar(p, m)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quality", required=True)
    ap.add_argument("--tools", nargs="+", default=["pymetricor", "radon", "sonar"])
    ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    q = Path(a.quality)
    for p in sorted(x for x in q.iterdir() if (x / "labels.csv").exists()):
        if a.only and p.name not in a.only:
            continue
        m = p / "metrics"
        m.mkdir(exist_ok=True)
        meta_path = m / "runs.json"
        meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
        for t in a.tools:
            try:
                meta[t] = RUN[t](p, m)
            except Exception as e:
                meta[t] = {"failed": f"{type(e).__name__}: {e}"}
            print(p.name, t, meta[t], flush=True)
            meta_path.write_text(json.dumps(meta, indent=1))


if __name__ == "__main__":
    main()
