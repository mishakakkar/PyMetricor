op = input()
if op in {"+", "-", "*"}:
    print(eval("3 " + op + " 4"))
