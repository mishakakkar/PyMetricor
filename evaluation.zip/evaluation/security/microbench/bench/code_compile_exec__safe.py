src = "x = 1 + 1"
obj = compile(src, "<const>", "exec")
exec(obj)
