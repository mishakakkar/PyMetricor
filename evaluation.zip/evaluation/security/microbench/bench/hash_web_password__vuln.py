import hashlib
from flask import Flask, request
app = Flask(__name__)

@app.route("/register", methods=["POST"])
def register():
    pw = request.form["password"]
    return hashlib.md5(pw.encode()).hexdigest()
