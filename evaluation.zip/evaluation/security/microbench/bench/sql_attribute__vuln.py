import sqlite3

class Report:
    def __init__(self, where):
        self.where = where

    def run(self, conn):
        return conn.execute("SELECT * FROM sales WHERE " + self.where).fetchall()

Report(input("filter: ")).run(sqlite3.connect("sales.db"))
