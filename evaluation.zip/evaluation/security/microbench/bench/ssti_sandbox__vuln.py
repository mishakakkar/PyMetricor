from jinja2 import Environment
from flask import Flask, request
app = Flask(__name__)
env = Environment()

@app.route("/preview", methods=["POST"])
def preview():
    return env.from_string(request.form["body"]).render()
