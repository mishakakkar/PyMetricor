from pathlib import Path
base = Path("/srv/data")
name = input()
print(open(base / name).read())
