import os
host = input("host: ")
os.system(f"ping -c 1 {host}")
