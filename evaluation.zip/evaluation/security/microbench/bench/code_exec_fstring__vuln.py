name = input()
exec(f"result = {name}")
