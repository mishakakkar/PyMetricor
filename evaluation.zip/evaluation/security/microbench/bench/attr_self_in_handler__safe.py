from flask import Flask, request
app = Flask(__name__)

FILES = {"a": "/srv/data/a.txt", "b": "/srv/data/b.txt"}

class Reader:
    def load(self):
        self.path = FILES.get(request.args["f"], "/srv/data/a.txt")
        return self.read()

    def read(self):
        with open(self.path) as fh:
            return fh.read()

@app.route("/read")
def read():
    return Reader().load()
