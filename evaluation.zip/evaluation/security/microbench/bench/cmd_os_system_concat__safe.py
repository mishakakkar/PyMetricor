import os
import sys
import shlex
os.system("ls " + shlex.quote(sys.argv[1]))
