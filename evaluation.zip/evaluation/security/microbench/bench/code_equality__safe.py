name = input()
if name == "math":
    exec("import " + name)
