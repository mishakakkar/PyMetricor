op = input()
print(eval("3 " + op + " 4"))
