from flask import Flask, request
from db import cursor
app = Flask(__name__)

@app.route("/item")
def item():
    cursor.execute("SELECT * FROM items WHERE id = " + request.args["id"])
    return str(cursor.fetchone())
