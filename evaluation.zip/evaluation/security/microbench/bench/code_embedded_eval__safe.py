exec("import os; os.system('date')")
