from flask import Flask, request
from sqlalchemy import text
from models import engine
app = Flask(__name__)

@app.route("/search")
def search():
    q = request.args["q"]
    with engine.connect() as conn:
        return str(conn.execute(text(f"SELECT * FROM posts WHERE title LIKE '%{q}%'")).all())
