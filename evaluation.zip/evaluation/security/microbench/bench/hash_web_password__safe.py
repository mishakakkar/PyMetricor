import hashlib
import os
from flask import Flask, request
app = Flask(__name__)

@app.route("/register", methods=["POST"])
def register():
    pw = request.form["password"]
    salt = os.urandom(16)
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 600_000).hex()
