from django.http import HttpResponse
from django.template import Template, Context

def page(request):
    tpl = Template("<p>" + request.GET["msg"] + "</p>")
    return HttpResponse(tpl.render(Context({})))
