code = input()
print(code)
