import hashlib
h = hashlib.new("md5", b"data")
