import os
cmd = "date"
for _ in range(2):
    os.system(cmd)
    print(input())
