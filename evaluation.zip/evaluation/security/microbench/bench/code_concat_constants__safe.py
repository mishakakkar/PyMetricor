exec("print(" + "'hello'" + ")")
