import requests
from flask import Flask, request
app = Flask(__name__)
session = requests.Session()

@app.route("/hook", methods=["POST"])
def hook():
    session.post("https://hooks.example.org/notify", json={"ok": True, "callback": request.json["callback"]})
    return "sent"
