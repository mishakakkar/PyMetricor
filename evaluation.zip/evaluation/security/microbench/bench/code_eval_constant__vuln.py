import os
print(eval(os.environ["FORMULA"]))
