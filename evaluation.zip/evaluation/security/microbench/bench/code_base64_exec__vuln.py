import base64
payload = input()
exec(base64.b64decode(payload))
