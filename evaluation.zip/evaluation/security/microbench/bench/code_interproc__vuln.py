def calc(e):
    return eval(e)

print(calc(input()))
