import hashlib
password = input()
print(hashlib.md5(password.encode()).hexdigest())
