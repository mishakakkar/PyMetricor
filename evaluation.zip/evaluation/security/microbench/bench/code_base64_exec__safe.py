import base64
payload = input()
print(base64.b64decode(payload))
