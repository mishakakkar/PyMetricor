from urllib.request import urlopen
from flask import Flask, request
app = Flask(__name__)
HOSTS = {"eu": "eu.cdn.example.org", "us": "us.cdn.example.org"}

@app.route("/avatar")
def avatar():
    host = HOSTS.get(request.args["region"], "eu.cdn.example.org")
    return urlopen("http://" + host + "/avatar.png").read()
