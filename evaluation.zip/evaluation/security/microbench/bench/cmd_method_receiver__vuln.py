import subprocess
args = input().split()
subprocess.run(" ".join(args), shell=True)
