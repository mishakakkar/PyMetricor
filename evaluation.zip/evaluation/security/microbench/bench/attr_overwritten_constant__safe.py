import os

class Job:
    pass

job = Job()
job.cmd = input("command: ")
job.cmd = "uptime"
os.system(job.cmd)
