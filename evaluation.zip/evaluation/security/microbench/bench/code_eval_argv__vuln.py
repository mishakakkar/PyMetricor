import sys
value = eval(sys.argv[1])
print(value)
