import hashlib
token = hashlib.sha1(b"secret-key").hexdigest()
