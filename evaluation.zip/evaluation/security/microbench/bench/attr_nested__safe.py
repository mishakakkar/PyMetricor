import os
import shlex

class Config:
    pass

class App:
    def __init__(self):
        self.config = Config()

app = App()
app.config.editor = shlex.quote(os.environ["EDITOR"])
os.system(app.config.editor + " notes.txt")
