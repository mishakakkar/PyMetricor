import sqlite3

class Report:
    def __init__(self, region):
        self.region = region

    def run(self, conn):
        return conn.execute("SELECT * FROM sales WHERE region = ?", (self.region,)).fetchall()

Report(input("region: ")).run(sqlite3.connect("sales.db"))
