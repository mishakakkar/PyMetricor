import hashlib as hl
sig = hl.sha1(b"msg").hexdigest()
