class Rule:
    def __init__(self):
        self.expr = "True"

    def set_expr(self, expr):
        self.expr = expr

    def check(self):
        return eval(self.expr)

r = Rule()
r.set_expr(input("rule: "))
r.check()
