from os import system
system("rm -rf /tmp/" + input())
