import hashlib
token = hashlib.sha512(b"secret-key").hexdigest()
