import requests
from flask import Flask, request
app = Flask(__name__)

@app.route("/preview")
def preview():
    return requests.get("https://api.example.org/preview", params={"u": request.args["url"]}, timeout=5).text[:200]
