import ast
expr = input()
print(ast.literal_eval(expr))
