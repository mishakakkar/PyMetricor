from flask import Flask, request
app = Flask(__name__)

@app.route("/run", methods=["POST"])
def run():
    print(request.form["code"])
    return "done"
