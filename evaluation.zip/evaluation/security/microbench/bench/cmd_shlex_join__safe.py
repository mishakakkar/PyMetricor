import os
import sys
import shlex
os.system("convert " + shlex.join(sys.argv[1:]))
