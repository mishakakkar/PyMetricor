import requests
from flask import Flask, request, abort
app = Flask(__name__)

@app.route("/fetch")
def fetch():
    url = request.args["url"]
    if not url.startswith("http"):
        abort(400)
    return requests.get(url).content
