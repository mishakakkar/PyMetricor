print(eval("2 ** 10"))
