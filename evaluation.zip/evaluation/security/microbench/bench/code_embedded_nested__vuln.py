exec("exec(\"eval(input())\")")
