from flask import Flask, request
from sqlalchemy import text
from models import engine
app = Flask(__name__)

@app.route("/search")
def search():
    q = request.args["q"]
    with engine.connect() as conn:
        return str(conn.execute(text("SELECT * FROM posts WHERE title LIKE :q"), {"q": f"%{q}%"}).all())
