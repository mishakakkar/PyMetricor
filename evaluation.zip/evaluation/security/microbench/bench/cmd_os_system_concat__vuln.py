import os
import sys
os.system("ls " + sys.argv[1])
