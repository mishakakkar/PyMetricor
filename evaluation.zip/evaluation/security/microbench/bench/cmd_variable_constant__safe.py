import os
flags = "-la"
cmd = "ls " + flags
os.system(cmd)
