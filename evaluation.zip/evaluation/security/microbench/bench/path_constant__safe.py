print(open("/etc/app/config.ini").read())
