from flask import Flask, request
app = Flask(__name__)

@app.route("/file")
def file():
    return open("static/" + request.args["name"]).read()
