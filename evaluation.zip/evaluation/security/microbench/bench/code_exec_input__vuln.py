code = input()
exec(code)
