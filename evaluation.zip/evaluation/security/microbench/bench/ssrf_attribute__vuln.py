import requests
from flask import Flask, request
app = Flask(__name__)

class Feed:
    def __init__(self, url):
        self.url = url

    def fetch(self):
        return requests.get(self.url).text

@app.route("/feed")
def feed():
    return Feed(request.args["url"]).fetch()
