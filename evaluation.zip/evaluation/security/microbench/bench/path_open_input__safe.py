import os
name = input()
print(open(os.path.join("/srv/data", os.path.basename(name))).read())
