import requests
from flask import Flask, request, abort
from django.utils.http import url_has_allowed_host_and_scheme
app = Flask(__name__)

@app.route("/fetch")
def fetch():
    url = request.args["url"]
    if not url_has_allowed_host_and_scheme(url, allowed_hosts={"static.example.org"}):
        abort(400)
    return requests.get(url).content
