from flask import Flask, request
from jinja2 import Template
app = Flask(__name__)

def render(src, **ctx):
    return Template(src).render(**ctx)

@app.route("/card", methods=["POST"])
def card():
    return render(request.form["layout"], title="Card")
