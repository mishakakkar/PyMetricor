import subprocess
args = input().split()
subprocess.run(["echo", *args])
