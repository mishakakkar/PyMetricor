exec("import os; os.system(input())")
