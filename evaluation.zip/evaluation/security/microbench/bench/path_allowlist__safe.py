name = input()
if name in {"q1.txt", "q2.txt"}:
    print(open("reports/" + name).read())
