import os
import shlex
host = input("host: ")
os.system(f"ping -c 1 {shlex.quote(host)}")
