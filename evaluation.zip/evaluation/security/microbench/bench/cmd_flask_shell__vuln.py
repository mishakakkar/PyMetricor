import subprocess
from flask import Flask, request
app = Flask(__name__)

@app.route("/log")
def log():
    name = request.args["name"]
    out = subprocess.check_output("cat logs/" + name, shell=True)
    return out
