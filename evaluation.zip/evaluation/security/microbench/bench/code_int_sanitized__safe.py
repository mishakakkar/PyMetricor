n = int(input())
print(eval("2 ** " + str(n)))
