import hashlib
h = hashlib.new("sha256", b"data")
