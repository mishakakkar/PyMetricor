import os
os.system("vi notes.txt")
