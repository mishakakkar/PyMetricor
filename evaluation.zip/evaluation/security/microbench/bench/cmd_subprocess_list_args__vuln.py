import subprocess
script = input()
subprocess.run(["sh", "-c", script])
