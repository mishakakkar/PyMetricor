import os
user = input()
print(os.popen("id " + user).read())
