import os

class Job:
    pass

job = Job()
job.cmd = "uptime"
job.cmd = input("command: ")
os.system(job.cmd)
