from jinja2.sandbox import SandboxedEnvironment
from flask import Flask, request
app = Flask(__name__)
env = SandboxedEnvironment()

@app.route("/preview", methods=["POST"])
def preview():
    return env.from_string(request.form["body"]).render()
