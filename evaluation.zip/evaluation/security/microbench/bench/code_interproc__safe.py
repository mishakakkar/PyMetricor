def calc(e):
    return eval(e)

print(calc("6 * 7"))
