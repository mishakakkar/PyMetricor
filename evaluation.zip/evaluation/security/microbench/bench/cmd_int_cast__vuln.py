import os
pid = input()
os.system("kill -9 " + pid)
