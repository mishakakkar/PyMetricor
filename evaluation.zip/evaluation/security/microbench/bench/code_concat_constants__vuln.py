import sys
exec("print(" + sys.argv[1] + ")")
