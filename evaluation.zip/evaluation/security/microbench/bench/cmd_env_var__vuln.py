import os
editor = os.environ.get("EDITOR")
os.system(editor + " notes.txt")
