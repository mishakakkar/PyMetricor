from flask import Flask, request
from db import cursor
app = Flask(__name__)

def find(table, key):
    cursor.execute("SELECT * FROM %s WHERE key = ?" % table, (key,))
    return cursor.fetchall()

@app.route("/find")
def handler():
    return str(find("items", request.args["key"]))
