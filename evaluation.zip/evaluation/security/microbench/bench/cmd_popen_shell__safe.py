import subprocess
import os
target = os.environ["TARGET"]
subprocess.Popen(["tar", "czf", "backup.tgz", target])
