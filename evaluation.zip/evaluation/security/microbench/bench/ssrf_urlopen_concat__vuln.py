from urllib.request import urlopen
from flask import Flask, request
app = Flask(__name__)

@app.route("/avatar")
def avatar():
    host = request.args["host"]
    return urlopen("http://" + host + "/avatar.png").read()
