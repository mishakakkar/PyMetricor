import os
pid = int(input())
os.system("kill -9 " + str(pid))
