import os
tool = input()
os.system(tool + " --version")
