from hashlib import sha256
digest = sha256(b"data").hexdigest()
