import subprocess as sp
cmd = input()
sp.call(["echo", cmd])
