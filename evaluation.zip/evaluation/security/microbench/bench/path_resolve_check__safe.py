from pathlib import Path
base = Path("/srv/data").resolve()
name = input()
target = (base / name).resolve()
if target.is_relative_to(base):
    print(open(target).read())
