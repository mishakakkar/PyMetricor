from django.http import HttpResponse
from .models import Book

def books(request):
    author = request.GET["author"]
    qs = Book.objects.raw("SELECT * FROM books WHERE author = %s", [author])
    return HttpResponse(len(list(qs)))
