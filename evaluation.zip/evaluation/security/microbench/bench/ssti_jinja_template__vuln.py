from jinja2 import Template
from flask import Flask, request
app = Flask(__name__)

@app.route("/greet", methods=["POST"])
def greet():
    return Template(request.form["tpl"]).render(user="guest")
