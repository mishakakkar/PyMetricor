import hashlib
key = hashlib.md5(b"cache-key", usedforsecurity=False).hexdigest()
