import sqlite3
from flask import Flask, request
app = Flask(__name__)

@app.route("/user")
def user():
    db = sqlite3.connect("app.db")
    name = request.args["name"]
    rows = db.execute("SELECT * FROM users WHERE name = '%s'" % name).fetchall()
    return str(rows)
