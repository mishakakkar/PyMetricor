import hashlib

def checksum(data):
    return hashlib.md5(data).hexdigest()
