import hashlib

def checksum(data):
    return hashlib.blake2b(data).hexdigest()
