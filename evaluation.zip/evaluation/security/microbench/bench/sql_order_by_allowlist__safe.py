from flask import Flask, request
from db import cursor
app = Flask(__name__)

@app.route("/list")
def listing():
    col = request.args.get("sort", "name")
    if col not in ("name", "price", "created"):
        col = "name"
    cursor.execute("SELECT * FROM items ORDER BY " + col)
    return str(cursor.fetchall())
