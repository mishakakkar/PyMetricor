import os
from flask import Flask, request
app = Flask(__name__)

class Upload:
    def __init__(self, name):
        self.name = name

@app.route("/delete")
def delete():
    up = Upload(request.args["name"])
    os.remove(os.path.join("/srv/uploads", up.name))
    return "ok"
