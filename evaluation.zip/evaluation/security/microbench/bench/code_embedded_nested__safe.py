exec("exec(\"print(1)\")")
