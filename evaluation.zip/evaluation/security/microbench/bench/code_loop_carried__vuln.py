stmt = "pass"
while True:
    exec(stmt)
    stmt = input()
