import ast
from flask import Flask, request
app = Flask(__name__)

@app.route("/calc")
def calc():
    return str(ast.literal_eval(request.args.get("expr")))
