from hashlib import md5
digest = md5(b"data").hexdigest()
