import os
from flask import Flask, request
app = Flask(__name__)

@app.route("/file")
def file():
    return open("static/" + os.path.basename(request.args["name"])).read()
