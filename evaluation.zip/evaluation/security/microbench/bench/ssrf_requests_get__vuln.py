import requests
from flask import Flask, request
app = Flask(__name__)

@app.route("/preview")
def preview():
    return requests.get(request.args["url"], timeout=5).text[:200]
