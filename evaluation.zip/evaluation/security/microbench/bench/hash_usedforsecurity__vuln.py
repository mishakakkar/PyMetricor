import hashlib
session_signature = hashlib.md5(b"session-secret" + b"user-42").hexdigest()
