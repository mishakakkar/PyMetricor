from django.http import HttpResponse
from django.template import Template, Context

def page(request):
    tpl = Template("<p>{{ msg }}</p>")
    return HttpResponse(tpl.render(Context({"msg": request.GET["msg"]})))
