import requests
from flask import Flask, request
app = Flask(__name__)
session = requests.Session()

@app.route("/hook", methods=["POST"])
def hook():
    session.post(request.json["callback"], json={"ok": True})
    return "sent"
