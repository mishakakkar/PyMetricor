import os
print(os.popen("id").read())
