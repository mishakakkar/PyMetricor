from flask import Flask, request
app = Flask(__name__)

class Reader:
    def load(self):
        self.path = "/srv/data/" + request.args["f"]
        return self.read()

    def read(self):
        with open(self.path) as fh:
            return fh.read()

@app.route("/read")
def read():
    return Reader().load()
