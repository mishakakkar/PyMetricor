stmt = "pass"
while True:
    exec(stmt)
    print(input())
