from os import system
import shlex
system("rm -rf /tmp/" + shlex.quote(input()))
