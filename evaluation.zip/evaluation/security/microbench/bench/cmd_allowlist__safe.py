import os
tool = input()
if tool in {"git", "python3", "gcc"}:
    os.system(tool + " --version")
