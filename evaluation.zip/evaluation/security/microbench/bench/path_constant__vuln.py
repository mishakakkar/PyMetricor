import os
print(open(os.environ["CONFIG_PATH"]).read())
