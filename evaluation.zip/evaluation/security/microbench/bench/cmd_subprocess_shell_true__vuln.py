import subprocess
name = input()
subprocess.run("grep " + name + " log.txt", shell=True)
