import os
mode = input()
if mode == "release":
    os.system("make " + mode)
