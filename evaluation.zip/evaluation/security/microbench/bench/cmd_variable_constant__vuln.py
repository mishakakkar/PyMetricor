import os
flags = input()
cmd = "ls " + flags
os.system(cmd)
