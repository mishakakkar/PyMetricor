import sqlite3
conn = sqlite3.connect("app.db")
cur = conn.cursor()
uid = input("id: ")
cur.execute("DELETE FROM sessions WHERE user_id = ?", [uid])
