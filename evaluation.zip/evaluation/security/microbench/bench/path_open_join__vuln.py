import os
name = input()
with open(os.path.join("/srv/data", name)) as f:
    print(f.read())
