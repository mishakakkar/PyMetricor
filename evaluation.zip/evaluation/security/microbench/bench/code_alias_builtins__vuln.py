from builtins import eval as evaluate
print(evaluate(input()))
