import httpx
from flask import Flask, request
app = Flask(__name__)

def download(url):
    return httpx.get(url).content

@app.route("/import")
def do_import():
    return download("https://data.example.org/export/" + str(int(request.args["id"])))
