src = input()
obj = compile(src, "<user>", "exec")
exec(obj)
