import shlex
import subprocess

class Pinger:
    def __init__(self, host):
        self.host = host

    def run(self):
        subprocess.run("ping -c 1 " + shlex.quote(self.host), shell=True)

Pinger(input("host: ")).run()
