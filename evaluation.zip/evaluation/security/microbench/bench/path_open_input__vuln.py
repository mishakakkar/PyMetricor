name = input()
print(open(name).read())
