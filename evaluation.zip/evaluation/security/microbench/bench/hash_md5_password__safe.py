import hashlib
password = input()
print(hashlib.sha256(password.encode()).hexdigest())
