import hashlib as hl
sig = hl.sha3_256(b"msg").hexdigest()
