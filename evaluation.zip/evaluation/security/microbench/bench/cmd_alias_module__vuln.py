import subprocess as sp
cmd = input()
sp.call(cmd, shell=True)
