import sys
value = float(sys.argv[1])
print(value)
