name = input()
print(open("reports/" + name).read())
