import os

def run(c):
    os.system(c)

run("uptime")
