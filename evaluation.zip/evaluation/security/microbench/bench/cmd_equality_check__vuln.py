import os
mode = input()
os.system("make " + mode)
