name = input()
exec("import " + name)
