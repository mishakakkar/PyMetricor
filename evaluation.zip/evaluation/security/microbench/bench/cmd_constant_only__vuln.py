import os
import sys
os.system("echo " + " ".join(sys.argv[1:]))
