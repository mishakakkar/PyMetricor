exec("a = input(); exec(a)")
