import subprocess
pattern = input()
subprocess.run(["grep", "--", pattern, "log.txt"])
