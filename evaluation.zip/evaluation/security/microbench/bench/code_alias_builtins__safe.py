from builtins import eval as evaluate
print(evaluate("1 + 1"))
