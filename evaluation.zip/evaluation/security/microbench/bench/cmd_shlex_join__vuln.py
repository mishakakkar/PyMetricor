import os
import sys
os.system("convert " + " ".join(sys.argv[1:]))
