def load(p):
    return open(p).read()

print(load(input()))
