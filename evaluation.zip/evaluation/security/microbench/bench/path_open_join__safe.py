import os
name = input()
with open(os.path.join("/srv/data", os.path.basename(name))) as f:
    print(f.read())
