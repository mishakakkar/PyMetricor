# PyFlow (Gu, Yan, Yao, arXiv:2608.07026, Aug 2026) and what it means for the PyMetricor paper

## What PyFlow is
- A generic IFDS interprocedural dataflow framework for Python (ZJU, open source at github.com/ZJU-PL/pyflow).
- Multi-level IR (AST, CFG/SSA, PDG/CPG), an LLVM-style pass manager, 1-CFA pointer analysis, and clients for taint, nullness and typestate.
- Evaluated against DevSkim, Dlint, Bandit, Bearer, CodeQL, Pysa, Semgrep and Snyk on **PySASTBench** (Liu et al., ICSE 2026). It is graded at method level across six CWEs: 77, 502, 94, 79, 22 and 89.

| Benchmark | PyFlow P | PyFlow R | PyFlow F1 | Best baseline |
| --- | --- | --- | --- | --- |
| Synthetic (240 programs) | .837 | .858 | .848 | Snyk, F1 .795 |
| Real world (108 CVEs, 206 versions) | .712 | .481 | .575 | Semgrep, F1 .503 |

- On real-world code, 45 of the 206 versions timed out at 600 s.

## Why it matters for us
1. **Reviewers will name it.** PyFlow is now the closest academic comparator for "a Python static-analysis framework with a security engine". It goes into related work. The paper must not claim the PyMetricor engine is a state-of-the-art taint analysis, because it is intraprocedural and PyFlow is not.
2. **PySASTBench is the benchmark reviewers expect.** Results on it are directly comparable to the ICSE 2026 study and to PyFlow, so it should be added to RQ1 alongside PyVul and our micro-benchmark. This has been done for the synthetic part; see below.
3. **It independently confirms the Pysa result.** PyFlow reports Pysa at 2.5% recall on the synthetic set and 0% on real-world code. This matches our finding that Pysa produced nothing usable here, and the paper can cite it.
4. **It points to positioning that survives.** PyMetricor is a quality-metrics tool whose security section is one of several scored dimensions. It runs in about 2 s on 120 files, where PyFlow takes a median 6.8 s per program with timeouts. It also analyses code inside exec/eval strings, which PyFlow does not model. The paper's novelty has to rest on the integration (metrics, composite score, lightweight lattice engine, recursion into dynamic code), not on detection rates.

## PySASTBench synthetic subset, run 2026-10-26
- **Scope:** only the CWEs PyMetricor's schema covers: 77→78, 94→95 and 22→22, giving 60 vulnerable/fixed pairs. 502, 79 and 89 have no PyMetricor capability, so a fair six-CWE comparison with PyFlow's table is not possible without new capabilities.
- **Grading:** scoring is file level, which is more lenient than PySASTBench's method level. The numbers are therefore not directly comparable to PyFlow's Table 3.
- **Results:** files are in results/pysastbench/ (tables.md, per-tool JSONL).

| Tool | P | R | F1 | Pair acc. |
| --- | --- | --- | --- | --- |
| PyMetricor 1.0.1, any severity | .74 | .63 | .69 | .43 |
| PyMetricor 1.0.1, ≥medium | .83 | .48 | .61 | .40 |
| PyMetricor 91e6867 (the paper version) | .78 | .42 | .54 | .38 |
| Bandit, ≥medium | 1.00 | .67 | .80 | .67 |
| Semgrep | .77 | .67 | .71 | .47 |
| CodeQL, local+remote sources | .72 | .92 | .81 | .57 |

### Per CWE
- **Code injection (94):** PyMetricor is strong, with F1 .97.
- **Command injection (77):** PyMetricor is middling, with F1 .59.
- **Path traversal (22):** PyMetricor fails, with pair accuracy .05.
  - The vulnerable and fixed versions both call `os.path.join` and `open` on a dynamic path, and the fix is a containment guard: `abspath(...).startswith(BASE_DIR)`.
  - PyMetricor has no notion of guard conditions as sanitisers, so it flags both versions at low severity.
  - It also has no model of `BaseHTTPRequestHandler.path` or other web-request sources.
  - These are the two concrete engine gaps to fix or to report as limitations.

### Takeaway
On a public benchmark PyMetricor's detector sits mid-pack: below CodeQL and Bandit at medium severity or higher, close to Semgrep. The 1.0.0/1.0.1 fixes raised its recall from .42 to .63. The chained-call fix (1.0.1) makes no difference on this set, which is reassuring evidence that it was not overfitted to the micro-benchmark.

## Suggested additions to the plan
- **RQ1:** add PySASTBench synthetic (done, 3 CWEs) and real world (the Zenodo record 17936545; not downloaded yet). Report PyFlow's published numbers as a reference row, clearly marked as not re-run.
- **Optional:** run PyFlow itself on our micro-benchmark and PyVul subset, since it is open source.
- **Engine work, if the security section is to hold up:**
  - path-containment guards as sanitisers
  - http.server, Flask and Django request sources
  - and possibly a pickle/yaml deserialization capability (CWE-502), so that four of the six PySASTBench CWEs are covered
