| Tool | P | R | F1 | Pair acc. | TP/FP/FN/TN | Warnings (off-target) |
| --- | --- | --- | --- | --- | --- | --- |
| PyMetricor 1.0.0 (any) | 0.74 | 0.63 | 0.69 | 0.43 | 38/13/22/47 | 125 (28) |
| PyMetricor 1.0.0 (>=medium) | 0.83 | 0.48 | 0.61 | 0.40 | 29/6/31/54 | 63 (0) |
| PyMetricor 1.0.1 (any) | 0.74 | 0.63 | 0.69 | 0.43 | 38/13/22/47 | 130 (33) |
| PyMetricor 1.0.1 (>=medium) | 0.83 | 0.48 | 0.61 | 0.40 | 29/6/31/54 | 66 (3) |
| PyMetricor 91e6867 (any) | 0.78 | 0.42 | 0.54 | 0.38 | 25/7/35/53 | 64 (8) |
| PyMetricor 91e6867 (>=medium) | 0.78 | 0.42 | 0.54 | 0.38 | 25/7/35/53 | 60 (8) |
| PyMetricor 1.0.1, no string recursion (>=medium) | 0.83 | 0.48 | 0.61 | 0.40 | 29/6/31/54 | 66 (3) |
| Bandit (any) | 0.67 | 0.67 | 0.67 | 0.33 | 40/20/20/40 | 269 (85) |
| Bandit (>=medium) | 1.00 | 0.67 | 0.80 | 0.67 | 40/0/20/60 | 134 (75) |
| Semgrep | 0.77 | 0.67 | 0.71 | 0.47 | 40/12/20/48 | 326 (214) |
| CodeQL (remote sources) | 0.78 | 0.58 | 0.67 | 0.42 | 35/10/25/50 | 251 (98) |
| CodeQL (local+remote sources) | 0.72 | 0.92 | 0.81 | 0.57 | 55/21/5/39 | 376 (180) |

F1 by CWE (pair accuracy in brackets)

| Tool | CWE-78 | CWE-95 | CWE-22 | CWE-327 |
| --- | --- | --- | --- | --- |
| PyMetricor 1.0.0 (any) | 0.59 (0.30) | 0.97 (0.95) | 0.46 (0.05) | - |
| PyMetricor 1.0.0 (>=medium) | 0.59 (0.30) | 0.95 (0.90) | 0.00 (0.00) | - |
| PyMetricor 1.0.1 (any) | 0.59 (0.30) | 0.97 (0.95) | 0.46 (0.05) | - |
| PyMetricor 1.0.1 (>=medium) | 0.59 (0.30) | 0.95 (0.90) | 0.00 (0.00) | - |
| PyMetricor 91e6867 (any) | 0.27 (0.15) | 0.97 (0.95) | 0.17 (0.05) | - |
| PyMetricor 91e6867 (>=medium) | 0.27 (0.15) | 0.97 (0.95) | 0.17 (0.05) | - |
| PyMetricor 1.0.1, no string recursion (>=medium) | 0.59 (0.30) | 0.95 (0.90) | 0.00 (0.00) | - |
| Bandit (any) | 0.67 (0.00) | 1.00 (1.00) | 0.00 (0.00) | - |
| Bandit (>=medium) | 1.00 (1.00) | 1.00 (1.00) | 0.00 (0.00) | - |
| Semgrep | 0.77 (0.40) | 1.00 (1.00) | 0.00 (0.00) | - |
| CodeQL (remote sources) | 0.00 (0.00) | 0.86 (0.75) | 0.80 (0.50) | - |
| CodeQL (local+remote sources) | 0.78 (0.45) | 0.86 (0.75) | 0.80 (0.50) | - |

Pair accuracy by feature tag

| Tool | CWE-22 | CWE-77 | CWE-94 |
| --- | --- | --- | --- |
| PyMetricor 1.0.0 (any) | 0.05 | 0.30 | 0.95 |
| PyMetricor 1.0.0 (>=medium) | 0.00 | 0.30 | 0.90 |
| PyMetricor 1.0.1 (any) | 0.05 | 0.30 | 0.95 |
| PyMetricor 1.0.1 (>=medium) | 0.00 | 0.30 | 0.90 |
| PyMetricor 91e6867 (any) | 0.05 | 0.15 | 0.95 |
| PyMetricor 91e6867 (>=medium) | 0.05 | 0.15 | 0.95 |
| PyMetricor 1.0.1, no string recursion (>=medium) | 0.00 | 0.30 | 0.90 |
| Bandit (any) | 0.00 | 0.00 | 1.00 |
| Bandit (>=medium) | 0.00 | 1.00 | 1.00 |
| Semgrep | 0.00 | 0.40 | 1.00 |
| CodeQL (remote sources) | 0.50 | 0.00 | 0.75 |
| CodeQL (local+remote sources) | 0.50 | 0.45 | 0.75 |
