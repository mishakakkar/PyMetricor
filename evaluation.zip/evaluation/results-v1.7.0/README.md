# PyMetricor 1.7.0: attribute taint, SQL injection, SSRF, template injection

_The scripts here use absolute paths from the machine the evaluation ran on; adjust them to rerun. Data sets that cannot be redistributed (PyVul repository snapshots, malware packages) are referenced by commit or name, not included._

Local branch `v1.7-fields` in `/home/claude/altered-commits/pymetricor`, commits 6cdeb29 + dbf5c0e (patch `pymetricor-fixes/0021-...patch`). Frozen evaluation copy: `scratchpad/pm17_frozen` (= dbf5c0e). Nothing has been pushed.

## What changed

- **Attribute (field-sensitive) taint.** `self.x = ...`, `obj.x = ...` and `self.a.b = ...` are tracked on the variable's value (2 levels, 32 fields). Constructors return the object with the attributes `__init__` set. Method summaries take the receiver's attributes and hand back the ones they set (setters). Guards and validators work on attributes.
- **Three new vulnerability classes**, each scored on the statement, URL or template argument only (`sink_args`):
  - SQL injection (CWE-89): `execute`/`raw`/`extra`, `sqlalchemy.text`, `RawSQL`, `pandas.read_sql`. Quoting helpers are validators.
  - SSRF (CWE-918): `requests`, `httpx`, `urllib`, `aiohttp`, `urllib3`, `http.client`, plus client-session methods. Network responses count as external data. URL allowlist checks act as guards.
  - Template injection (CWE-1336): Jinja `Template` and `from_string` (not in a sandbox), Flask `render_template_string`, and Django, Mako and Tornado templates.
- **Scoring (MK's choice, 2 Nov).**
  - New fourth security metric `INJECTION_AND_REQUEST_FORGERY` (SQLi + SSRF), with sensitivity 0.5 like the other three.
  - Security weights: code execution .40, cryptography .20, file access .20, injection and request forgery .20.
  - Template injection counts as code execution.
  - The model now has 27 metrics.
- **Bug fix found on the new micro cases.** `request.args.get(...)` lost its taint when `request` was imported from Flask, because the attribute was typed as a module.
- Tests: 173 pass (28 new).

## RQ1: security

**Old PyVul held-out half** (81 pairs, CWE-78/95/22/327, function level, evaluated once):

| Version | Severity | P | R | F1 | Pair acc. |
|---|---|---|---|---|---|
| 1.6.0 | any | .61 | .42 | .50 | .17 |
| 1.7.0 | any | .61 | .42 | .50 | .17 |
| 1.6.0 | ≥ medium | .61 | .31 | .41 | .14 |
| 1.7.0 | ≥ medium | .61 | .33 | .43 | .15 |

- The ≥ medium gain is two path-traversal cases, from the `request.args.get` fix.
- Attribute taint changed nothing on either PyVul half. The misses come from framework sources (Tornado and aiohttp handlers) and factory-built objects, not attribute flows.
- Baselines are unchanged: CodeQL .28 F1, Semgrep .24, Bandit .21.

**New PyVul set for CWE-89/918/1336** (built here: 73 cases from 23 repositories, split by repository, `results/pyvul_new/split.json`).

- Development half: 42 cases (20 SQLi, 16 SSRF, 6 template).
- Held-out half: 31 cases (10 SQLi, 16 SSRF, 5 template), evaluated once.

| Tool (held-out, ≥ medium) | P | R | F1 | Pair acc. | SQLi recall | SSRF recall | SSTI recall |
|---|---|---|---|---|---|---|---|
| PyMetricor 1.7.0 | .57 | .13 | .21 | .03 | .10 | .19 | .00 |
| PyMetricor 1.7.0 (any severity) | .61 | .35 | .45 | .13 | .60 | .31 | .00 |
| CodeQL | .57 | .13 | .21 | .03 | .20 | .13 | .00 |
| Semgrep | .58 | .23 | .33 | .07 | .70 | .00 | .00 |
| Bandit | .75 | .10 | .17 | .07 | .30 | .00 | .00 |

- On real code, at ≥ medium, PyMetricor ties CodeQL and is below Semgrep. Semgrep's lead comes from SQL-formatting patterns that flag any string-built query.
- At any severity (where low "built-at-runtime query" findings count), PyMetricor has the highest recall.
- n = 31, so none of these differences can be significant.
- Most development-half cases are framework-internal validation (Django ORM alias checks, Matrix hostname checks) that no taint tool can see. All three baselines found nothing at all on that half.

**Micro-benchmark** (now 81 pairs; 25 new: 6 attribute, 8 SQLi, 6 SSRF, 5 template; all tools rerun, `results/microbench/tables.md`):

| Tool | F1 (all 81) | Pair acc. (all) | F1 (19 new-class pairs) | Pair acc. (new) |
|---|---|---|---|---|
| PyMetricor 1.7.0, ≥ medium | .88 | .73 | .93 | .84 |
| CodeQL (local + remote sources) | .78 | .58 | .67 | .47 |
| Semgrep | .73 | .44 | .61 | .26 |
| Bandit, ≥ medium | .69 | .37 | .53 | .26 |

The new pairs were written by us while building the feature, so they show that it works, not how it compares on real code. The paper must say so.

**PySASTBench** (≥ medium): F1 .85 → .86, recall .88 → .90.

## RQ2: malware (10,229 packages)

| Measure | 1.6.0 | 1.7.0 |
|---|---|---|
| High/critical | 13.5% | 15.4% |
| Warnings | 26,640 | 40,329 |

- Bandit is unchanged: 11.4% high/critical, 172,280 warnings.
- The rise comes from network responses now being external, so download-and-exec code becomes high/critical, and from the new low-severity SSRF/SQL warnings.
- The run is now split into chunks of 400 packages. One process for all packages ran out of memory because the parser's module cache grows across packages. The engine is not the cause: the largest package needs 1.2 GB in both 1.6.0 and 1.7.0.
- The 1,553-package exec/eval subset figure was not recomputed.

## RQ3

Not affected. Readability is unchanged, and the composite changes only through security, which is near 100 on CodeQual files. Not rerun.

## RQ4: 23 projects, fixed outcome

| Score | Version | Partial ρ (sig.) | OR | ΔAUC |
|---|---|---|---|---|
| Composite | 1.6.0 | .153 (7/15) | 2.04 | +.037 |
| Composite | 1.7.0 | .146 (7/15) | 1.98 | +.034 |
| Security | 1.6.0 | .087 | 1.28 | +.009 |
| Security | 1.7.0 | .025 | 1.18 | +.004 |

- Against the BugsInPy outcome, the composite OR rose from 2.01 to 2.05.
- The security dimension's association with fixes weakened. This is consistent with the new SQL sinks flagging test code, where `.data`/`.values` attribute names count as sources. For example, SQLAlchemy's own tests get 142 high SQL findings, all in test files.

## RQ5: 950 PyPI packages

| Measure | 1.6.0 | 1.7.0 |
|---|---|---|
| CPU s/KLOC, all packages | 0.32 | 0.38 |
| CPU s/KLOC, 196 shared packages | 0.339 | 0.407 |
| Pylint ratio | 5.3× slower than PyMetricor | 4.4× slower |
| Max RSS | 2.1 GB | 2.2 GB |
| Weight ±25% τ | .955 | .955 |

- 0 run failures.
- Saturated metrics on the held-out half: 9 of 27, up from 8. The new metric is 100 on almost every file.

## Case study

- Django: 88.18 → 88.22. HTTPX: 86.70 → 86.75. The security section rose because the weights now spread over four metrics, most of them at 100.
- Django gains 1 high SSRF/SQL offender and 92 low ones.

## Threats to disclose if 1.7.0 goes in the paper

- The old PyVul held-out half had now been looked at for a second engine version. It was still evaluated once per version with a frozen copy, and nothing was tuned on it.
- The new PyVul set's split keeps repositories from the 1.4.0 split in their half. Django's 20 SQL cases are therefore all in the development half.
- The new micro pairs were written by the tool authors.
