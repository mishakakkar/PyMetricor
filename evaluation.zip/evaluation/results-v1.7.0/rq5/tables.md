Packages run per tool: {'bandit': 200, 'pylint': 200, 'pymetricor': 950, 'radon': 200}; finished by every tool: 196

## Speed on the packages every tool finished

| tool       |   packages |    kloc |   cpu_s_per_kloc_pooled |   cpu_s_per_kloc_median |   wall_s_median |   wall_s_p95 |   rss_mb_median |   rss_mb_max |
|:-----------|-----------:|--------:|------------------------:|------------------------:|----------------:|-------------:|----------------:|-------------:|
| bandit     |        196 | 4568.06 |                   0.102 |                   0.138 |           0.644 |       10.806 |          35.705 |      299.5   |
| pylint     |        196 | 4568.06 |                   1.782 |                   1.773 |           8.154 |      212.884 |         131.584 |     4193.29  |
| pymetricor |        196 | 4568.06 |                   0.407 |                   0.672 |           3.681 |       39.259 |          90.752 |      919.129 |
| radon      |        196 | 4568.06 |                   0.118 |                   0.067 |           0.291 |        9.083 |          24.473 |      279.414 |

## Speed, each tool on everything it finished

| tool       |   packages |     kloc |   cpu_s_per_kloc_pooled |   cpu_s_per_kloc_median |   wall_s_median |   wall_s_p95 |   rss_mb_median |   rss_mb_max |
|:-----------|-----------:|---------:|------------------------:|------------------------:|----------------:|-------------:|----------------:|-------------:|
| bandit     |        199 |  7219.51 |                   0.172 |                   0.138 |           0.672 |       17.15  |          35.867 |      537.391 |
| pylint     |        197 |  4630.54 |                   1.781 |                   1.765 |           8.159 |      211.835 |         132.16  |     4193.29  |
| pymetricor |        950 | 35841.5  |                   0.378 |                   0.612 |           3.951 |       52.055 |          91.217 |     2229.95  |
| radon      |        198 |  6210.11 |                   0.096 |                   0.066 |           0.304 |        9.934 |          24.633 |      279.414 |

## Robustness on the packages every tool was run on

| tool       |   packages |   timeouts |   run_failures |   run_failure_rate |   py_files |   file_failures |   file_failure_rate |   files_reported |
|:-----------|-----------:|-----------:|---------------:|-------------------:|-----------:|----------------:|--------------------:|-----------------:|
| bandit     |        200 |          0 |              1 |              0.005 |      28552 |             391 |              0.0137 |            28552 |
| pylint     |        200 |          3 |              3 |              0.015 |      28552 |             392 |              0.0137 |            16425 |
| pymetricor |        200 |          0 |              0 |              0     |      28552 |             407 |              0.0143 |            25142 |
| radon      |        200 |          2 |              2 |              0.01  |      28552 |             411 |              0.0144 |            25341 |

## Robustness, each tool on everything it was run on

| tool       |   packages |   timeouts |   run_failures |   run_failure_rate |   py_files |   file_failures |   file_failure_rate |   files_reported |
|:-----------|-----------:|-----------:|---------------:|-------------------:|-----------:|----------------:|--------------------:|-----------------:|
| bandit     |        200 |          0 |              1 |              0.005 |      28552 |             391 |              0.0137 |            28552 |
| pylint     |        200 |          3 |              3 |              0.015 |      28552 |             392 |              0.0137 |            16425 |
| pymetricor |        950 |          0 |              0 |              0     |     150032 |            1357 |              0.009  |           133553 |
| radon      |        200 |          2 |              2 |              0.01  |      28552 |             411 |              0.0144 |            25341 |

PyMetricor coverage: 133553 of 150032 .py files scored (89.0%); the rest are __init__.py files, which it skips by design, or files it could not read.

## Weight sensitivity

{'packages': 943, 'files': 131907, 'reconstruction_max_err': 0.006683499999994069}

| scheme                |   draws |   pkg_tau_median |   pkg_tau_p5 |   worst_decile_overlap |   file_rho_median |   mean_abs_shift |   max_abs_shift |
|:----------------------|--------:|-----------------:|-------------:|-----------------------:|------------------:|-----------------:|----------------:|
| random +-25%          |    1000 |            0.955 |        0.932 |                  0.936 |             0.995 |            0.436 |           2.476 |
| random +-50%          |    1000 |            0.907 |        0.855 |                  0.872 |             0.985 |            0.889 |           5.104 |
| drop Readability      |       1 |            0.861 |        0.861 |                  0.787 |             0.96  |            1.058 |           6.316 |
| drop Efficiency       |       1 |            0.775 |        0.775 |                  0.798 |             0.87  |            2.669 |          10.131 |
| drop Maintainability  |       1 |            0.836 |        0.836 |                  0.787 |             0.966 |            1.214 |           7.695 |
| drop Security         |       1 |            0.921 |        0.921 |                  0.83  |             0.996 |            2.33  |           8.992 |
| equal section weights |       1 |            0.972 |        0.972 |                  0.968 |             0.998 |            0.536 |           1.894 |
| all weights equal     |       1 |            0.885 |        0.885 |                  0.84  |             0.976 |            0.9   |           5.968 |

## Metric saturation (share of files scoring 0 or 100)

| metric                             | section         |   at_0 |   at_100 |   median |
|:-----------------------------------|:----------------|-------:|---------:|---------:|
| LINE_LENGTH_DISTRIBUTION           | Readability     |  0.053 |    0.68  |   100    |
| INDENTATION_STABILITY              | Readability     |  0     |    0.92  |   100    |
| IDENTIFIER_STYLE                   | Readability     |  0     |    0.449 |    94.71 |
| COMMENT_DENSITY                    | Readability     |  0     |    0.065 |    83.69 |
| NESTING_DEPTH                      | Readability     |  0.025 |    0.847 |   100    |
| BLANK_LINE_RHYTHM                  | Readability     |  0.009 |    0.985 |   100    |
| ANNOTATION_CONSISTENCY             | Readability     |  0     |    0.749 |   100    |
| STRING_FORMATTING_CONSISTENCY      | Readability     |  0     |    0.957 |   100    |
| IDENTIFIER_LENGTH                  | Readability     |  0     |    0.753 |   100    |
| COGNITIVE_COMPLEXITY               | Readability     |  0.004 |    0.711 |   100    |
| LINE_DENSITY                       | Readability     |  0.001 |    0.44  |    98.76 |
| IDENTIFIER_QUALITY                 | Readability     |  0     |    0.256 |    70.83 |
| FORMATTING_CONSISTENCY             | Readability     |  0     |    0.308 |    67.03 |
| CYCLOMATIC_COMPLEXITY              | Efficiency      |  0.005 |    0.774 |   100    |
| REDUNDANT_CODE                     | Efficiency      |  0.009 |    0.843 |   100    |
| DEAD_CODE                          | Efficiency      |  0.05  |    0.532 |   100    |
| INHERITANCE_DEPTH                  | Maintainability |  0.02  |    0.916 |   100    |
| METHOD_RECEIVER_NAMING_CONSISTENCY | Maintainability |  0.073 |    0.863 |   100    |
| PARAMETER_BLOAT                    | Maintainability |  0.006 |    0.865 |   100    |
| EXCEPTION_HYGIENE                  | Maintainability |  0.006 |    0.89  |   100    |
| FUNCTION_LENGTH                    | Maintainability |  0.014 |    0.772 |   100    |
| CLASS_COMPLEXITY                   | Maintainability |  0.011 |    0.816 |   100    |
| MODULE_COUPLING                    | Maintainability |  0.002 |    0.732 |   100    |
| BROKEN_CRYPTOGRAPHY                | Security        |  0     |    0.996 |   100    |
| ARBITRARY_CODE_EXECUTION           | Security        |  0.01  |    0.968 |   100    |
| UNSAFE_FILE_ACCESS                 | Security        |  0.002 |    0.949 |   100    |
| INJECTION_AND_REQUEST_FORGERY      | Security        |  0     |    0.988 |   100    |
