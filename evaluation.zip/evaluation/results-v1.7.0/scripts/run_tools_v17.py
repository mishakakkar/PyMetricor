"""run_tools.py with the 1.7.0 CWE groups (SQL injection, SSRF, template injection) added."""
import sys
sys.path.insert(0, "/mnt/project-files/pymetricor-seceval")
import run_tools  # noqa: E402
run_tools.CWE_GROUP.update({89: 89, 564: 89, 918: 918, 1336: 1336})
run_tools.BANDIT_CWE.update({"B608": 89})
if __name__ == "__main__":
    run_tools.main()
