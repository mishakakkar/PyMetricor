# 1.7.0 reruns on the frozen copy (/tmp/claude-0/-home-claude/9ad13d27-9a01-51c6-9a84-0ffe8617858b/scratchpad/pm17_frozen = commit dbf5c0e)
S=/tmp/claude-0/-home-claude/9ad13d27-9a01-51c6-9a84-0ffe8617858b/scratchpad
PY=$S/repro-work/venvs/pymetricor/bin/python; APY=$S/repro-work/venvs/analysis/bin/python
cd $S
PM_DIR=$S/pm17_frozen PM_PY=$PY python3 -I /mnt/project-files/pymetricor-quality/metrics.py --quality $S/quality-v17 --tools pymetricor > $S/v17/rq4_metrics.log 2>&1
$APY /mnt/project-files/pymetricor-v15/scripts/rq4_analyse.py --quality $S/quality-v17 --out $S/v17/rq4_all > $S/v17/rq4_all.log 2>&1
$APY /mnt/project-files/pymetricor-v15/scripts/rq4_analyse.py --quality $S/quality-v17 --out $S/v17/rq4_noans --exclude ansible > $S/v17/rq4_noans.log 2>&1
echo RQ4DONE
R=$S/repro-work/src
$PY /mnt/project-files/pymetricor-repro/drivers/pymetricor_driver.py --pymetricor-dir $S/pm17_frozen --target $R/django-main-2026-04/django --out $S/v17/case/django-drv.json > $S/v17/case/django.log 2>&1
$PY /mnt/project-files/pymetricor-repro/drivers/pymetricor_driver.py --pymetricor-dir $S/pm17_frozen --target $R/httpx/httpx --out $S/v17/case/httpx-drv.json > $S/v17/case/httpx.log 2>&1
echo CASEDONE
bash /mnt/project-files/pymetricor-v17/scripts/rq2_malware.sh > $S/v17/rq2.log 2>&1
echo RQ2DONE
until [ -f $S/bl_new.done ]; do sleep 30; done
sh /mnt/project-files/pymetricor-v17/scripts/run_rq5.sh
echo ALLDONE
