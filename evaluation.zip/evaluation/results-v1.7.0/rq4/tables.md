Files: 6719, projects: 23

## Outcome: changed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyExamine code smells          |         16 |        0.491 |        15 |         0.103 |          6 |        0.702 |
| PyExamine dependency smells    |         16 |        0.25  |        10 |         0.13  |          4 |        0.553 |
| PyExamine severity-weighted    |         16 |        0.573 |        16 |         0.132 |          6 |        0.745 |
| PyExamine smells (all)         |         16 |        0.581 |        15 |         0.15  |          6 |        0.752 |
| PyMetricor composite           |         16 |        0.512 |        15 |         0.143 |          7 |        0.782 |
| PyMetricor efficiency          |         16 |        0.395 |        12 |         0.119 |          5 |        0.708 |
| PyMetricor maintainability     |         16 |        0.557 |        15 |         0.239 |         10 |        0.752 |
| PyMetricor module coupling     |         16 |        0.379 |        15 |         0.158 |          7 |        0.605 |
| PyMetricor readability         |         16 |        0.51  |        14 |         0.127 |          6 |        0.8   |
| PyMetricor security            |         15 |        0.159 |         7 |         0.066 |          3 |        0.579 |
| Radon CC (sum)                 |         16 |        0.544 |        13 |         0.057 |          5 |        0.792 |
| Radon MI                       |         16 |        0.535 |        16 |         0.097 |          5 |        0.791 |
| SLOC                           |         16 |        0.598 |        16 |       nan     |          0 |        0.828 |
| SonarQube code smells          |         16 |        0.164 |         6 |         0.048 |          1 |        0.533 |
| SonarQube cognitive complexity |         16 |        0.566 |        14 |         0.129 |          5 |        0.768 |
| SonarQube debt (min)           |         16 |        0.163 |         6 |         0.045 |          2 |        0.533 |
| SonarQube debt ratio (%)       |         15 |        0.107 |         3 |         0.038 |          3 |        0.527 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    6696 |  5939 |         21 |              1.2266 | 0.0185 |     0.9188 |     0.9171 |    -0.0017 |
| PyMetricor readability         |    6696 |  5939 |         21 |              1.4333 | 0      |     0.9188 |     0.9159 |    -0.0029 |
| PyMetricor efficiency          |    6696 |  5939 |         21 |              0.967  | 0.6306 |     0.9188 |     0.9186 |    -0.0002 |
| PyMetricor maintainability     |    6696 |  5939 |         21 |              1.4929 | 0.0001 |     0.9188 |     0.9191 |     0.0003 |
| PyMetricor security            |    6696 |  5939 |         21 |              1.0602 | 0.4194 |     0.9188 |     0.918  |    -0.0007 |
| PyMetricor module coupling     |    6696 |  5939 |         21 |              1.0819 | 0.2008 |     0.9188 |     0.9184 |    -0.0004 |
| Radon MI                       |    6696 |  5939 |         21 |              1.7962 | 0      |     0.9188 |     0.9198 |     0.001  |
| Radon CC (sum)                 |    6696 |  5939 |         21 |              1.9484 | 0.0001 |     0.9188 |     0.9189 |     0.0001 |
| SonarQube debt (min)           |    6696 |  5939 |         21 |              0.9832 | 0.9128 |     0.9188 |     0.9186 |    -0.0002 |
| SonarQube code smells          |    6696 |  5939 |         21 |              0.9581 | 0.7254 |     0.9188 |     0.9185 |    -0.0003 |
| SonarQube cognitive complexity |    6696 |  5939 |         21 |              1.5738 | 0.0112 |     0.9188 |     0.918  |    -0.0007 |
| SonarQube debt ratio (%)       |    6696 |  5939 |         21 |              0.9981 | 0.9553 |     0.9188 |     0.9185 |    -0.0003 |
| PyExamine smells (all)         |    6696 |  5939 |         21 |              1.744  | 0.0015 |     0.9188 |     0.9186 |    -0.0002 |
| PyExamine code smells          |    6696 |  5939 |         21 |              1.9797 | 0.0049 |     0.9188 |     0.9189 |     0.0002 |
| PyExamine severity-weighted    |    6696 |  5939 |         21 |              1.6499 | 0.0033 |     0.9188 |     0.9185 |    -0.0002 |
| PyExamine dependency smells    |    6696 |  5939 |         21 |              1.103  | 0.1093 |     0.9188 |     0.9183 |    -0.0005 |

## Outcome: fixed

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyExamine code smells          |         15 |        0.422 |        13 |         0.112 |          5 |        0.683 |
| PyExamine dependency smells    |         15 |        0.328 |        10 |         0.248 |          7 |        0.578 |
| PyExamine severity-weighted    |         15 |        0.472 |        12 |         0.145 |          6 |        0.723 |
| PyExamine smells (all)         |         15 |        0.441 |        13 |         0.148 |          6 |        0.718 |
| PyMetricor composite           |         15 |        0.528 |        13 |         0.146 |          7 |        0.777 |
| PyMetricor efficiency          |         15 |        0.507 |        11 |         0.16  |          7 |        0.74  |
| PyMetricor maintainability     |         15 |        0.528 |        14 |         0.206 |          9 |        0.715 |
| PyMetricor module coupling     |         15 |        0.352 |        13 |         0.172 |          8 |        0.653 |
| PyMetricor readability         |         15 |        0.446 |        13 |         0.167 |          7 |        0.769 |
| PyMetricor security            |         14 |        0.114 |         6 |         0.025 |          3 |        0.554 |
| Radon CC (sum)                 |         15 |        0.481 |        12 |         0.059 |          5 |        0.757 |
| Radon MI                       |         15 |        0.485 |        12 |         0.108 |          5 |        0.757 |
| SLOC                           |         15 |        0.54  |        13 |       nan     |          0 |        0.765 |
| SonarQube code smells          |         15 |        0.185 |         5 |         0.111 |          4 |        0.531 |
| SonarQube cognitive complexity |         15 |        0.519 |        13 |         0.183 |          9 |        0.778 |
| SonarQube debt (min)           |         15 |        0.184 |         5 |         0.112 |          4 |        0.531 |
| SonarQube debt ratio (%)       |         14 |        0.079 |         2 |         0.036 |          3 |        0.518 |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    6684 |  1049 |         21 |              1.9774 | 0      |      0.793 |     0.8274 |     0.0344 |
| PyMetricor readability         |    6684 |  1049 |         21 |              1.8257 | 0      |      0.793 |     0.8253 |     0.0323 |
| PyMetricor efficiency          |    6684 |  1049 |         21 |              1.5029 | 0      |      0.793 |     0.8123 |     0.0193 |
| PyMetricor maintainability     |    6684 |  1049 |         21 |              1.7636 | 0      |      0.793 |     0.8155 |     0.0226 |
| PyMetricor security            |    6684 |  1049 |         21 |              1.1762 | 0      |      0.793 |     0.7966 |     0.0037 |
| PyMetricor module coupling     |    6684 |  1049 |         21 |              1.6673 | 0      |      0.793 |     0.8219 |     0.029  |
| Radon MI                       |    6684 |  1049 |         21 |              1.5335 | 0      |      0.793 |     0.8017 |     0.0087 |
| Radon CC (sum)                 |    6684 |  1049 |         21 |              1.4412 | 0      |      0.793 |     0.8032 |     0.0103 |
| SonarQube debt (min)           |    6684 |  1049 |         21 |              0.9894 | 0.7586 |      0.793 |     0.7929 |    -0      |
| SonarQube code smells          |    6684 |  1049 |         21 |              1.0009 | 0.9793 |      0.793 |     0.7928 |    -0.0002 |
| SonarQube cognitive complexity |    6684 |  1049 |         21 |              1.2584 | 0      |      0.793 |     0.8003 |     0.0074 |
| SonarQube debt ratio (%)       |    6684 |  1049 |         21 |              1.0133 | 0.7513 |      0.793 |     0.7928 |    -0.0002 |
| PyExamine smells (all)         |    6684 |  1049 |         21 |              1.4611 | 0      |      0.793 |     0.8038 |     0.0109 |
| PyExamine code smells          |    6684 |  1049 |         21 |              1.1586 | 0.0017 |      0.793 |     0.7949 |     0.0019 |
| PyExamine severity-weighted    |    6684 |  1049 |         21 |              1.4691 | 0      |      0.793 |     0.8042 |     0.0112 |
| PyExamine dependency smells    |    6684 |  1049 |         21 |              1.4125 | 0      |      0.793 |     0.7999 |     0.007  |

## Outcome: bugsinpy

Per project (median over projects; sig = projects with p < .05)

| metric                         |   projects |   median_rho |   sig_rho |   median_prho |   sig_prho |   median_auc |
|:-------------------------------|-----------:|-------------:|----------:|--------------:|-----------:|-------------:|
| PyExamine code smells          |         11 |        0.218 |         7 |         0.064 |          4 |        0.767 |
| PyExamine dependency smells    |         11 |        0.149 |         5 |         0.145 |          3 |        0.547 |
| PyExamine severity-weighted    |         11 |        0.23  |         8 |         0.087 |          3 |        0.795 |
| PyExamine smells (all)         |         11 |        0.219 |         8 |         0.084 |          2 |        0.792 |
| PyMetricor composite           |         11 |        0.233 |        10 |         0.096 |          4 |        0.834 |
| PyMetricor efficiency          |         11 |        0.189 |         8 |         0.072 |          5 |        0.794 |
| PyMetricor maintainability     |         11 |        0.29  |         8 |         0.096 |          4 |        0.807 |
| PyMetricor module coupling     |         11 |        0.241 |         9 |         0.21  |          7 |        0.797 |
| PyMetricor readability         |         11 |        0.284 |         9 |         0.07  |          3 |        0.78  |
| PyMetricor security            |         10 |        0.031 |         1 |        -0.015 |          0 |        0.513 |
| Radon CC (sum)                 |         11 |        0.267 |        11 |         0.063 |          2 |        0.814 |
| Radon MI                       |         11 |        0.327 |         9 |         0.068 |          2 |        0.847 |
| SLOC                           |         11 |        0.238 |         9 |       nan     |          0 |        0.805 |
| SonarQube code smells          |         11 |        0.185 |         5 |         0.13  |          4 |        0.593 |
| SonarQube cognitive complexity |         11 |        0.247 |        10 |         0.086 |          4 |        0.843 |
| SonarQube debt (min)           |         11 |        0.184 |         5 |         0.123 |          4 |        0.592 |
| SonarQube debt ratio (%)       |         10 |        0.053 |         2 |         0.022 |          1 |        0.53  |

Pooled logistic regression with project fixed effects and log SLOC

| metric                         |   files |   pos |   projects |   odds_ratio_per_sd |   lr_p |   auc_base |   auc_full |   auc_gain |
|:-------------------------------|--------:|------:|-----------:|--------------------:|-------:|-----------:|-----------:|-----------:|
| PyMetricor composite           |    6549 |   155 |         17 |              2.0534 | 0      |     0.9469 |     0.9527 |     0.0058 |
| PyMetricor readability         |    6549 |   155 |         17 |              1.911  | 0      |     0.9469 |     0.9513 |     0.0044 |
| PyMetricor efficiency          |    6549 |   155 |         17 |              1.787  | 0      |     0.9469 |     0.9517 |     0.0048 |
| PyMetricor maintainability     |    6549 |   155 |         17 |              1.4915 | 0      |     0.9469 |     0.9501 |     0.0031 |
| PyMetricor security            |    6549 |   155 |         17 |              0.9232 | 0.3713 |     0.9469 |     0.9469 |    -0      |
| PyMetricor module coupling     |    6549 |   155 |         17 |              1.5059 | 0      |     0.9469 |     0.9517 |     0.0048 |
| Radon MI                       |    6549 |   155 |         17 |              2.751  | 0      |     0.9469 |     0.953  |     0.0061 |
| Radon CC (sum)                 |    6549 |   155 |         17 |              1.3456 | 0.0001 |     0.9469 |     0.9495 |     0.0026 |
| SonarQube debt (min)           |    6549 |   155 |         17 |              1.0206 | 0.749  |     0.9469 |     0.9471 |     0.0002 |
| SonarQube code smells          |    6549 |   155 |         17 |              1.048  | 0.3764 |     0.9469 |     0.947  |     0.0001 |
| SonarQube cognitive complexity |    6549 |   155 |         17 |              1.2881 | 0.0005 |     0.9469 |     0.9481 |     0.0011 |
| SonarQube debt ratio (%)       |    6549 |   155 |         17 |              0.9976 | 0.9743 |     0.9469 |     0.9466 |    -0.0004 |
| PyExamine smells (all)         |    6549 |   155 |         17 |              1.1529 | 0.0152 |     0.9469 |     0.9478 |     0.0008 |
| PyExamine code smells          |    6549 |   155 |         17 |              1.0728 | 0.1096 |     0.9469 |     0.9473 |     0.0004 |
| PyExamine severity-weighted    |    6549 |   155 |         17 |              1.1794 | 0.0082 |     0.9469 |     0.948  |     0.0011 |
| PyExamine dependency smells    |    6549 |   155 |         17 |              1.1598 | 0.0003 |     0.9469 |     0.948  |     0.0011 |

