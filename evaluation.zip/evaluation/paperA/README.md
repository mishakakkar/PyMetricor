# Paper A evaluation setup (PyMetricor 1.7.0 security engine)

This package reruns every experiment in Paper A, "Policy as data: a schema-driven security engine for Python" (Goel, Lalith, Kakkar and Mehrotra, 2026). It holds the scripts, the fixed inputs (case lists, development/held-out splits, case labels, the benign sample) and the numbers each step should reproduce.

This folder sits in the PyMetricor repository at `evaluation/paperA/`; check out tag v1.7.0 and `PM_DIR` points at the repository by default. (If you copy the folder elsewhere, set `PM_DIR` to a v1.7.0 checkout.)

## Rules for the held-out halves

The PyVul sets are split by repository into a development half and a held-out half (`data/*/split.json`). The paper's numbers come from the held-out halves, evaluated once with frozen code. If you change PyMetricor or its schema, tune on the `dev` split only and do not report a tuned result on `test` as a replication.

## Requirements

- Linux x86_64, Python 3.12, git, curl, unzip and `patch`.
- About 40 GB of free disk and 16 GB of RAM. CodeQL uses about 3.5 GB per worker.
- Internet access, to download GitHub repositories, PyPI and the CodeQL bundle.

Tool versions (`setup.sh` installs all of them):

| Tool | Version |
|---|---|
| PyMetricor | 1.7.0 (tag v1.7.0, commit 9962819); astroid 3.3.10, PyYAML 6.0.2, xxhash 3.5.0 |
| Bandit | 1.8.6 |
| Semgrep | 1.128.1, community rules `semgrep-rules` at 16b9e6d (`python/` folder) |
| CodeQL | CLI bundle 2.27.3, suite `python-security-extended`, threat model `local` |
| PyFlow | 0.1.2, commit e19bb9e |
| Analysis | scipy 1.16.2, numpy 2.5.4 |

Datasets, cloned by the scripts:

| Dataset | Source | Commit |
|---|---|---|
| PyVul | github.com/billquan/PyVul | 1172bfd |
| PySASTBench | github.com/Victor725/PySASTBench | 3ad04b7 |
| pypi_malregistry | github.com/lxyeternal/pypi_malregistry | archives listed in `data/malware/archives.txt` |
| Benign control | PyPI, 200 packages at the releases in `data/benign/sample200.json` | ranking of 2026-10-01 |

## Setup

```bash
git clone https://github.com/Altered-commits/PyMetricor && cd PyMetricor && git checkout v1.7.0
cd evaluation/paperA
# optional: export PM_WORK=/big/disk/pm-work  (defaults to ./work)
bash setup.sh
source env.sh          # do this in every new shell
```

All scripts read their paths from `env.sh`:

| Variable | Meaning |
|---|---|
| `PM_EVAL` | this package |
| `PM_WORK` | tools, datasets and trees |
| `PM_RESULTS` | outputs |
| `PM_DIR` | the PyMetricor checkout |
| `PM_PY` | the PyMetricor Python |
| `PY_AN` | the analysis Python |

## Running

Each script can be run on its own once `setup.sh` has finished. Every script ends by printing the tables it reproduces.

| Step | Command | Time (4 cores) | Reproduces |
|---|---|---|---|
| RQ1 synthetic benchmarks | `bash run/rq1_synthetic.sh` | ~15 min | Table 5 (Micro, PySASTBench columns), Table 6 (Micro column) |
| RQ2 PyVul with repository context | `bash run/rq2_pyvul.sh` | 6–10 h (CodeQL, PyFlow) | Tables 5–8 (PyVul columns), validator ablation |
| Validator-mutation set | `bash run/rq2_validator_mutation.sh` | ~5 min | validator-mutation table |
| RQ3 malware and benign control | `bash run/rq3_malware.sh` | 3–5 h | Table 9 |

**Malware safety.** `run/rq3_malware.sh` downloads 10,229 real malicious packages. Never `pip install`, build, import or execute anything from them. `extract.py` copies only the `.py` members out of the archives, as text. Run it on a machine or VM that you can wipe, and never on a laptop that holds credentials.

## What each script does

| Script | Purpose |
|---|---|
| `seceval/microbench/cases.py`, `build.py` | The 81-pair micro-benchmark (seven classes) |
| `seceval/pysastbench/build.py` | The 60-pair PySASTBench subset (CWE-77→78, 94→95, 22) |
| `scripts/secbench.py` | Runs PyMetricor on the synthetic sets |
| `scripts/run_tools_v17.py` | Runs Bandit, Semgrep and CodeQL with the CWE mapping |
| `scripts/rq1_tables.py` | Scores the synthetic sets at file level |
| `seceval/pyvul/build_pyvul.py`, `scripts/build_pyvul_ctx.py`, `scripts/build_pyvul_ctx_new.py` | Rebuild the two repository-context PyVul sets. Each case's parent commit is the vulnerable twin; the parent with the fix's files applied is the safe twin. The shipped `labels_ctx_ok.json` fixes the case list (162 and 73 cases). |
| `scripts/eval_pyvul_ctx.py` | Runs PyMetricor with `--project` set to the whole tree, and grades at function level by reported line |
| `scripts/baselines_pyvul_ctx.py` | Bandit, Semgrep and CodeQL on the same cases. CodeQL keeps its SARIF for path credit. |
| `scripts/baselines_paths.py` | Semgrep with `--dataflow-traces` |
| `scripts/pyflow_pyvul.py` | PyFlow with its own harness options, 600 s per run |
| `scripts/path_credit.py` | Path-credit grading, McNemar tests, repository bootstrap, Holm adjustment, and the case-kind table for the new set |
| `scripts/test_stats.py`, `scripts/test_stats_new.py` | The same tests under by-line grading |
| `scripts/eval_pyvul_ctx_rev.py` | Validator ablation, using `$PM_WORK/pm17_noval` (1.7.0 with `data/pm17_noval.patch`) |
| `scripts/valmut/build.py`, `scripts/valmut_grade.py` | The validator-mutation set |
| `seceval/malware/extract.py`, `seceval/malware/analyse.py` | The malware study |
| `scripts/benign_fetch_pinned.py`, `scripts/benign_run.py`, `scripts/benign_control.py` | The benign control |

## Expected results

The tables the scripts write are in `expected/` (`synthetic/`, `pyvul_ctx/`, `pyvul_new/`, `benign_control.md`, `validator_mutation.md`). They are the files behind the paper's tables, and your outputs should match them. The headline numbers are below.

**RQ1, file level.** F1 with pair accuracy in brackets.

| Tool | Micro (81 pairs) | PySASTBench (60) |
|---|---|---|
| PyMetricor, any finding | .81 (.54) | .82 (.58) |
| PyMetricor, ≥ medium | .88 (.73) | .86 (.70) |
| Bandit, ≥ medium | .69 (.37) | .80 (.67) |
| Semgrep | .73 (.44) | .71 (.47) |
| CodeQL, local + remote | .78 (.58) | .81 (.57) |

**RQ2, held-out recall with path credit.** Precision in brackets. See `expected/pyvul_*/path_credit.md`.

| Tool | CWE-78/95/22/327 (81 cases) | CWE-89/918/1336 (31 cases) |
|---|---|---|
| PyMetricor, any finding | .42 (.61) | .35 (.61) |
| PyMetricor, ≥ medium | .35 (.61) | .13 (.57) |
| CodeQL, local + remote | .23 (.68) | .19 (.55) |
| Semgrep | .15 (.60) | .23 (.58) |
| Bandit, ≥ medium | .12 (.71) | .10 (.75) |
| PyFlow | .07 (.55) | .03 (.50) |

Statistical tests:

- First set: PyMetricor (any finding) against CodeQL gives +.185, McNemar p = .004, Holm p = .008. At ≥ medium the difference is +.11 with p = .093, which is not significant.
- Second set: the only significant difference is PyMetricor (any finding) against PyFlow, Holm p = .016.

Case kinds in the second held-out set (`data/pyvul_new/case_categories.json`, one rater): 5 external flows, 11 unknown-origin flows, 9 no flow, 6 other class. Of the 5 external flows, PyMetricor finds 4 (at any severity and at ≥ medium) and CodeQL with path credit finds 5.

**Validator ablation.** Removing the name patterns adds 5 false alarms on the fixed twins (3 in the first set, 2 in the second). It recovers one missed case, `sanitized_join` in xmpp-http-upload.

**Validator mutation.** PyMetricor misses all 5 gutted helpers and flags all 5 neutral ones. CodeQL and Semgrep flag all 15 files; Bandit flags 12.

**RQ3.** See `expected/benign_control.md`.

| Measure | PyMetricor, malicious | PyMetricor, benign | Bandit, malicious | Bandit, benign |
|---|---|---|---|---|
| Packages with a high/critical finding | 15.4% | 44.5% | 11.4% | 21.5% |
| Files with a high/critical finding | 5.4% | 2.3% | 4.2% | 0.6% |
| Total warnings | 40,329 | 15,202 | 172,280 | 189,112 |

## Known sources of small differences

- **PyFlow.** 87 of its 160 runs stop with status "partial" when they hit an analysis budget. On a slower or faster machine a few findings can change.
- **CodeQL.** Peak memory depends on `--ram` and the number of workers. A run killed for lack of memory counts as no finding, so check `*.runs.json` for errors.
- **Benign corpus.** If a pinned release has been yanked from PyPI, `benign_fetch_pinned.py` reports it, and the benign column will differ slightly.
- **pypi_malregistry.** If upstream removes an archive, the package count drops below 10,229.

## Second-rater task (open)

The four case kinds in `data/pyvul_new/case_categories.json` were assigned by one rater. A second, independent rater should label the 31 held-out cases with the rubric in that file. The rater must not look at the first rater's labels or at any tool output. Then report Cohen's κ.
