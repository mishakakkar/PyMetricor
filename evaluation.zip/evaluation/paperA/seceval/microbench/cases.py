"""
Vulnerable/safe twin micro-benchmark for Python SAST tools.

Each case is a pair of small, self-contained programs that differ only in
whether untrusted data can reach a dangerous sink. Labels are true by
construction: the `vuln` program is exploitable under the stated threat
model, and the `safe` program is not.

Fields:
  id    : unique, used as file name stem
  cwe   : 78 (OS command), 95 (code injection), 22 (path traversal), 327 (weak hash),
          89 (SQL injection), 918 (server-side request forgery), 1336 (template injection)
  tags  : features exercised, used to slice results
          source : cli (input/argv/environ) | web (Flask request) | none
          other  : alias, sanitizer, allowlist, loop, interproc, embedded, encoded,
                   list_args, shell_true, constant, refinement, usedforsecurity, method,
                   attribute (taint carried by an object attribute), parameterised
  vuln / safe : program text

Generate files with:  python build.py
"""

from textwrap import dedent

CASES = []


def case(id, cwe, tags, vuln, safe):
    CASES.append({"id": id, "cwe": cwe, "tags": tags, "vuln": dedent(vuln).lstrip(), "safe": dedent(safe).lstrip()})


# ---------------------------------------------------------------- CWE-78 OS command injection
case("cmd_os_system_fstring", 78, ["cli"], """
    import os
    host = input("host: ")
    os.system(f"ping -c 1 {host}")
""", """
    import os
    import shlex
    host = input("host: ")
    os.system(f"ping -c 1 {shlex.quote(host)}")
""")

case("cmd_os_system_concat", 78, ["cli", "sanitizer"], """
    import os
    import sys
    os.system("ls " + sys.argv[1])
""", """
    import os
    import sys
    import shlex
    os.system("ls " + shlex.quote(sys.argv[1]))
""")

case("cmd_subprocess_shell_true", 78, ["cli", "shell_true"], """
    import subprocess
    name = input()
    subprocess.run("grep " + name + " log.txt", shell=True)
""", """
    import subprocess
    name = input()
    subprocess.run(["grep", name, "log.txt"])
""")

case("cmd_subprocess_list_args", 78, ["cli", "list_args"], """
    import subprocess
    script = input()
    subprocess.run(["sh", "-c", script])
""", """
    import subprocess
    pattern = input()
    subprocess.run(["grep", "--", pattern, "log.txt"])
""")

case("cmd_popen_shell", 78, ["cli", "shell_true"], """
    import subprocess
    import os
    target = os.environ["TARGET"]
    subprocess.Popen("tar czf backup.tgz " + target, shell=True)
""", """
    import subprocess
    import os
    target = os.environ["TARGET"]
    subprocess.Popen(["tar", "czf", "backup.tgz", target])
""")

case("cmd_os_popen", 78, ["cli"], """
    import os
    user = input()
    print(os.popen("id " + user).read())
""", """
    import os
    print(os.popen("id").read())
""")

case("cmd_alias_module", 78, ["cli", "alias"], """
    import subprocess as sp
    cmd = input()
    sp.call(cmd, shell=True)
""", """
    import subprocess as sp
    cmd = input()
    sp.call(["echo", cmd])
""")

case("cmd_from_import", 78, ["cli", "alias"], """
    from os import system
    system("rm -rf /tmp/" + input())
""", """
    from os import system
    import shlex
    system("rm -rf /tmp/" + shlex.quote(input()))
""")

case("cmd_allowlist", 78, ["cli", "allowlist"], """
    import os
    tool = input()
    os.system(tool + " --version")
""", """
    import os
    tool = input()
    if tool in {"git", "python3", "gcc"}:
        os.system(tool + " --version")
""")

case("cmd_equality_check", 78, ["cli", "refinement"], """
    import os
    mode = input()
    os.system("make " + mode)
""", """
    import os
    mode = input()
    if mode == "release":
        os.system("make " + mode)
""")

case("cmd_int_cast", 78, ["cli", "sanitizer"], """
    import os
    pid = input()
    os.system("kill -9 " + pid)
""", """
    import os
    pid = int(input())
    os.system("kill -9 " + str(pid))
""")

case("cmd_loop_carried", 78, ["cli", "loop"], """
    import os
    cmd = "date"
    for _ in range(2):
        os.system(cmd)
        cmd = input()
""", """
    import os
    cmd = "date"
    for _ in range(2):
        os.system(cmd)
        print(input())
""")

case("cmd_interproc", 78, ["cli", "interproc"], """
    import os

    def run(c):
        os.system(c)

    run(input())
""", """
    import os

    def run(c):
        os.system(c)

    run("uptime")
""")

case("cmd_flask", 78, ["web"], """
    import os
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/ping")
    def ping():
        host = request.args.get("host")
        os.system("ping -c 1 " + host)
        return "ok"
""", """
    import subprocess
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/ping")
    def ping():
        host = request.args.get("host")
        subprocess.run(["ping", "-c", "1", host])
        return "ok"
""")

case("cmd_flask_shell", 78, ["web", "shell_true"], """
    import subprocess
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/log")
    def log():
        name = request.args["name"]
        out = subprocess.check_output("cat logs/" + name, shell=True)
        return out
""", """
    import subprocess
    import shlex
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/log")
    def log():
        name = request.args["name"]
        out = subprocess.check_output("cat logs/" + shlex.quote(name), shell=True)
        return out
""")

case("cmd_constant_only", 78, ["constant"], """
    import os
    import sys
    os.system("echo " + " ".join(sys.argv[1:]))
""", """
    import os
    os.system("echo hello")
""")

case("cmd_variable_constant", 78, ["constant"], """
    import os
    flags = input()
    cmd = "ls " + flags
    os.system(cmd)
""", """
    import os
    flags = "-la"
    cmd = "ls " + flags
    os.system(cmd)
""")

case("cmd_shlex_join", 78, ["cli", "sanitizer"], """
    import os
    import sys
    os.system("convert " + " ".join(sys.argv[1:]))
""", """
    import os
    import sys
    import shlex
    os.system("convert " + shlex.join(sys.argv[1:]))
""")

case("cmd_method_receiver", 78, ["cli", "method"], """
    import subprocess
    args = input().split()
    subprocess.run(" ".join(args), shell=True)
""", """
    import subprocess
    args = input().split()
    subprocess.run(["echo", *args])
""")

case("cmd_env_var", 78, ["cli"], """
    import os
    editor = os.environ.get("EDITOR")
    os.system(editor + " notes.txt")
""", """
    import os
    os.system("vi notes.txt")
""")

# ---------------------------------------------------------------- CWE-95 code injection
case("code_eval_input", 95, ["cli"], """
    expr = input()
    print(eval(expr))
""", """
    import ast
    expr = input()
    print(ast.literal_eval(expr))
""")

case("code_exec_input", 95, ["cli"], """
    code = input()
    exec(code)
""", """
    code = input()
    print(code)
""")

case("code_eval_argv", 95, ["cli"], """
    import sys
    value = eval(sys.argv[1])
    print(value)
""", """
    import sys
    value = float(sys.argv[1])
    print(value)
""")

case("code_compile_exec", 95, ["cli"], """
    src = input()
    obj = compile(src, "<user>", "exec")
    exec(obj)
""", """
    src = "x = 1 + 1"
    obj = compile(src, "<const>", "exec")
    exec(obj)
""")

case("code_eval_constant", 95, ["constant"], """
    import os
    print(eval(os.environ["FORMULA"]))
""", """
    print(eval("2 ** 10"))
""")

case("code_exec_fstring", 95, ["cli"], """
    name = input()
    exec(f"result = {name}")
""", """
    name = input()
    result = name
    print(result)
""")

case("code_eval_allowlist", 95, ["cli", "allowlist"], """
    op = input()
    print(eval("3 " + op + " 4"))
""", """
    op = input()
    if op in {"+", "-", "*"}:
        print(eval("3 " + op + " 4"))
""")

case("code_embedded_string", 95, ["embedded"], """
    exec("a = input(); exec(a)")
""", """
    exec("a = 1; print(a)")
""")

case("code_embedded_eval", 95, ["embedded"], """
    exec("import os; os.system(input())")
""", """
    exec("import os; os.system('date')")
""")

case("code_embedded_nested", 95, ["embedded"], """
    exec("exec(\\"eval(input())\\")")
""", """
    exec("exec(\\"print(1)\\")")
""")

case("code_base64_exec", 95, ["encoded", "cli"], """
    import base64
    payload = input()
    exec(base64.b64decode(payload))
""", """
    import base64
    payload = input()
    print(base64.b64decode(payload))
""")

case("code_alias_builtins", 95, ["cli", "alias"], """
    from builtins import eval as evaluate
    print(evaluate(input()))
""", """
    from builtins import eval as evaluate
    print(evaluate("1 + 1"))
""")

case("code_loop_carried", 95, ["cli", "loop"], """
    stmt = "pass"
    while True:
        exec(stmt)
        stmt = input()
""", """
    stmt = "pass"
    while True:
        exec(stmt)
        print(input())
""")

case("code_interproc", 95, ["cli", "interproc"], """
    def calc(e):
        return eval(e)

    print(calc(input()))
""", """
    def calc(e):
        return eval(e)

    print(calc("6 * 7"))
""")

case("code_flask_eval", 95, ["web"], """
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/calc")
    def calc():
        return str(eval(request.args.get("expr")))
""", """
    import ast
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/calc")
    def calc():
        return str(ast.literal_eval(request.args.get("expr")))
""")

case("code_flask_exec", 95, ["web"], """
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/run", methods=["POST"])
    def run():
        exec(request.form["code"])
        return "done"
""", """
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/run", methods=["POST"])
    def run():
        print(request.form["code"])
        return "done"
""")

case("code_int_sanitized", 95, ["cli", "sanitizer"], """
    n = input()
    print(eval("2 ** " + n))
""", """
    n = int(input())
    print(eval("2 ** " + str(n)))
""")

case("code_equality", 95, ["cli", "refinement"], """
    name = input()
    exec("import " + name)
""", """
    name = input()
    if name == "math":
        exec("import " + name)
""")

case("code_file_contents", 95, ["cli"], """
    import sys
    with open(sys.argv[1]) as f:
        exec(f.read())
""", """
    import sys
    with open(sys.argv[1]) as f:
        print(f.read())
""")

case("code_concat_constants", 95, ["constant"], """
    import sys
    exec("print(" + sys.argv[1] + ")")
""", """
    exec("print(" + "'hello'" + ")")
""")

# ---------------------------------------------------------------- CWE-22 path traversal
case("path_open_input", 22, ["cli"], """
    name = input()
    print(open(name).read())
""", """
    import os
    name = input()
    print(open(os.path.join("/srv/data", os.path.basename(name))).read())
""")

case("path_open_join", 22, ["cli"], """
    import os
    name = input()
    with open(os.path.join("/srv/data", name)) as f:
        print(f.read())
""", """
    import os
    name = input()
    with open(os.path.join("/srv/data", os.path.basename(name))) as f:
        print(f.read())
""")

case("path_open_write", 22, ["cli"], """
    import sys
    with open(sys.argv[1], "w") as f:
        f.write("data")
""", """
    with open("output.txt", "w") as f:
        f.write("data")
""")

case("path_resolve_check", 22, ["cli", "sanitizer"], """
    from pathlib import Path
    base = Path("/srv/data")
    name = input()
    print(open(base / name).read())
""", """
    from pathlib import Path
    base = Path("/srv/data").resolve()
    name = input()
    target = (base / name).resolve()
    if target.is_relative_to(base):
        print(open(target).read())
""")

case("path_allowlist", 22, ["cli", "allowlist"], """
    name = input()
    print(open("reports/" + name).read())
""", """
    name = input()
    if name in {"q1.txt", "q2.txt"}:
        print(open("reports/" + name).read())
""")

case("path_flask", 22, ["web"], """
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/file")
    def file():
        return open("static/" + request.args["name"]).read()
""", """
    import os
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/file")
    def file():
        return open("static/" + os.path.basename(request.args["name"])).read()
""")

case("path_constant", 22, ["constant"], """
    import os
    print(open(os.environ["CONFIG_PATH"]).read())
""", """
    print(open("/etc/app/config.ini").read())
""")

case("path_interproc", 22, ["cli", "interproc"], """
    def load(p):
        return open(p).read()

    print(load(input()))
""", """
    def load(p):
        return open(p).read()

    print(load("settings.ini"))
""")

# ---------------------------------------------------------------- CWE-327/328 weak hash
case("hash_md5_password", 327, ["cli"], """
    import hashlib
    password = input()
    print(hashlib.md5(password.encode()).hexdigest())
""", """
    import hashlib
    password = input()
    print(hashlib.sha256(password.encode()).hexdigest())
""")

case("hash_sha1_token", 327, ["none"], """
    import hashlib
    token = hashlib.sha1(b"secret-key").hexdigest()
""", """
    import hashlib
    token = hashlib.sha512(b"secret-key").hexdigest()
""")

case("hash_from_import", 327, ["alias"], """
    from hashlib import md5
    digest = md5(b"data").hexdigest()
""", """
    from hashlib import sha256
    digest = sha256(b"data").hexdigest()
""")

case("hash_new_md5", 327, ["method"], """
    import hashlib
    h = hashlib.new("md5", b"data")
""", """
    import hashlib
    h = hashlib.new("sha256", b"data")
""")

case("hash_usedforsecurity", 327, ["usedforsecurity"], """
    import hashlib
    session_signature = hashlib.md5(b"session-secret" + b"user-42").hexdigest()
""", """
    import hashlib
    key = hashlib.md5(b"cache-key", usedforsecurity=False).hexdigest()
""")

case("hash_alias_module", 327, ["alias"], """
    import hashlib as hl
    sig = hl.sha1(b"msg").hexdigest()
""", """
    import hashlib as hl
    sig = hl.sha3_256(b"msg").hexdigest()
""")

case("hash_web_password", 327, ["web"], """
    import hashlib
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/register", methods=["POST"])
    def register():
        pw = request.form["password"]
        return hashlib.md5(pw.encode()).hexdigest()
""", """
    import hashlib
    import os
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/register", methods=["POST"])
    def register():
        pw = request.form["password"]
        salt = os.urandom(16)
        return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 600_000).hex()
""")

case("hash_in_function", 327, ["none"], """
    import hashlib

    def checksum(data):
        return hashlib.md5(data).hexdigest()
""", """
    import hashlib

    def checksum(data):
        return hashlib.blake2b(data).hexdigest()
""")


# ---------------------------------------------------------------- attribute flows (CWE-78/95/22)
case("attr_self_command", 78, ["cli", "attribute"], """
    import subprocess

    class Pinger:
        def __init__(self, host):
            self.host = host

        def run(self):
            subprocess.run("ping -c 1 " + self.host, shell=True)

    Pinger(input("host: ")).run()
""", """
    import shlex
    import subprocess

    class Pinger:
        def __init__(self, host):
            self.host = host

        def run(self):
            subprocess.run("ping -c 1 " + shlex.quote(self.host), shell=True)

    Pinger(input("host: ")).run()
""")

case("attr_constructor_field_read", 22, ["web", "attribute"], """
    import os
    from flask import Flask, request
    app = Flask(__name__)

    class Upload:
        def __init__(self, name):
            self.name = name

    @app.route("/delete")
    def delete():
        up = Upload(request.args["name"])
        os.remove(os.path.join("/srv/uploads", up.name))
        return "ok"
""", """
    import os
    from flask import Flask, request
    app = Flask(__name__)

    class Upload:
        def __init__(self, name):
            self.name = os.path.basename(name)

    @app.route("/delete")
    def delete():
        up = Upload(request.args["name"])
        os.remove(os.path.join("/srv/uploads", up.name))
        return "ok"
""")

case("attr_setter", 95, ["cli", "attribute"], """
    class Rule:
        def __init__(self):
            self.expr = "True"

        def set_expr(self, expr):
            self.expr = expr

        def check(self):
            return eval(self.expr)

    r = Rule()
    r.set_expr(input("rule: "))
    r.check()
""", """
    import ast

    class Rule:
        def __init__(self):
            self.expr = "True"

        def set_expr(self, expr):
            self.expr = expr

        def check(self):
            return ast.literal_eval(self.expr)

    r = Rule()
    r.set_expr(input("rule: "))
    r.check()
""")

case("attr_overwritten_constant", 78, ["cli", "attribute", "constant"], """
    import os

    class Job:
        pass

    job = Job()
    job.cmd = "uptime"
    job.cmd = input("command: ")
    os.system(job.cmd)
""", """
    import os

    class Job:
        pass

    job = Job()
    job.cmd = input("command: ")
    job.cmd = "uptime"
    os.system(job.cmd)
""")

case("attr_self_in_handler", 22, ["web", "attribute", "method"], """
    from flask import Flask, request
    app = Flask(__name__)

    class Reader:
        def load(self):
            self.path = "/srv/data/" + request.args["f"]
            return self.read()

        def read(self):
            with open(self.path) as fh:
                return fh.read()

    @app.route("/read")
    def read():
        return Reader().load()
""", """
    from flask import Flask, request
    app = Flask(__name__)

    FILES = {"a": "/srv/data/a.txt", "b": "/srv/data/b.txt"}

    class Reader:
        def load(self):
            self.path = FILES.get(request.args["f"], "/srv/data/a.txt")
            return self.read()

        def read(self):
            with open(self.path) as fh:
                return fh.read()

    @app.route("/read")
    def read():
        return Reader().load()
""")

case("attr_nested", 78, ["cli", "attribute"], """
    import os

    class Config:
        pass

    class App:
        def __init__(self):
            self.config = Config()

    app = App()
    app.config.editor = os.environ["EDITOR"]
    os.system(app.config.editor + " notes.txt")
""", """
    import os
    import shlex

    class Config:
        pass

    class App:
        def __init__(self):
            self.config = Config()

    app = App()
    app.config.editor = shlex.quote(os.environ["EDITOR"])
    os.system(app.config.editor + " notes.txt")
""")

# ---------------------------------------------------------------- CWE-89 SQL injection
case("sql_format_web", 89, ["web"], """
    import sqlite3
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/user")
    def user():
        db = sqlite3.connect("app.db")
        name = request.args["name"]
        rows = db.execute("SELECT * FROM users WHERE name = '%s'" % name).fetchall()
        return str(rows)
""", """
    import sqlite3
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/user")
    def user():
        db = sqlite3.connect("app.db")
        name = request.args["name"]
        rows = db.execute("SELECT * FROM users WHERE name = ?", (name,)).fetchall()
        return str(rows)
""")

case("sql_fstring_cursor", 89, ["cli", "parameterised"], """
    import sqlite3
    conn = sqlite3.connect("app.db")
    cur = conn.cursor()
    uid = input("id: ")
    cur.execute(f"DELETE FROM sessions WHERE user_id = {uid}")
""", """
    import sqlite3
    conn = sqlite3.connect("app.db")
    cur = conn.cursor()
    uid = input("id: ")
    cur.execute("DELETE FROM sessions WHERE user_id = ?", [uid])
""")

case("sql_int_cast", 89, ["web", "sanitizer"], """
    from flask import Flask, request
    from db import cursor
    app = Flask(__name__)

    @app.route("/item")
    def item():
        cursor.execute("SELECT * FROM items WHERE id = " + request.args["id"])
        return str(cursor.fetchone())
""", """
    from flask import Flask, request
    from db import cursor
    app = Flask(__name__)

    @app.route("/item")
    def item():
        cursor.execute("SELECT * FROM items WHERE id = " + str(int(request.args["id"])))
        return str(cursor.fetchone())
""")

case("sql_order_by_allowlist", 89, ["web", "allowlist"], """
    from flask import Flask, request
    from db import cursor
    app = Flask(__name__)

    @app.route("/list")
    def listing():
        col = request.args.get("sort", "name")
        cursor.execute("SELECT * FROM items ORDER BY " + col)
        return str(cursor.fetchall())
""", """
    from flask import Flask, request
    from db import cursor
    app = Flask(__name__)

    @app.route("/list")
    def listing():
        col = request.args.get("sort", "name")
        if col not in ("name", "price", "created"):
            col = "name"
        cursor.execute("SELECT * FROM items ORDER BY " + col)
        return str(cursor.fetchall())
""")

case("sql_sqlalchemy_text", 89, ["web"], """
    from flask import Flask, request
    from sqlalchemy import text
    from models import engine
    app = Flask(__name__)

    @app.route("/search")
    def search():
        q = request.args["q"]
        with engine.connect() as conn:
            return str(conn.execute(text(f"SELECT * FROM posts WHERE title LIKE '%{q}%'")).all())
""", """
    from flask import Flask, request
    from sqlalchemy import text
    from models import engine
    app = Flask(__name__)

    @app.route("/search")
    def search():
        q = request.args["q"]
        with engine.connect() as conn:
            return str(conn.execute(text("SELECT * FROM posts WHERE title LIKE :q"), {"q": f"%{q}%"}).all())
""")

case("sql_django_raw", 89, ["web", "method"], """
    from django.http import HttpResponse
    from .models import Book

    def books(request):
        author = request.GET["author"]
        qs = Book.objects.raw("SELECT * FROM books WHERE author = '" + author + "'")
        return HttpResponse(len(list(qs)))
""", """
    from django.http import HttpResponse
    from .models import Book

    def books(request):
        author = request.GET["author"]
        qs = Book.objects.raw("SELECT * FROM books WHERE author = %s", [author])
        return HttpResponse(len(list(qs)))
""")

case("sql_interproc", 89, ["web", "interproc"], """
    from flask import Flask, request
    from db import cursor
    app = Flask(__name__)

    def find(table, key):
        cursor.execute("SELECT * FROM %s WHERE key = '%s'" % (table, key))
        return cursor.fetchall()

    @app.route("/find")
    def handler():
        return str(find("items", request.args["key"]))
""", """
    from flask import Flask, request
    from db import cursor
    app = Flask(__name__)

    def find(table, key):
        cursor.execute("SELECT * FROM %s WHERE key = ?" % table, (key,))
        return cursor.fetchall()

    @app.route("/find")
    def handler():
        return str(find("items", request.args["key"]))
""")

case("sql_attribute", 89, ["cli", "attribute"], """
    import sqlite3

    class Report:
        def __init__(self, where):
            self.where = where

        def run(self, conn):
            return conn.execute("SELECT * FROM sales WHERE " + self.where).fetchall()

    Report(input("filter: ")).run(sqlite3.connect("sales.db"))
""", """
    import sqlite3

    class Report:
        def __init__(self, region):
            self.region = region

        def run(self, conn):
            return conn.execute("SELECT * FROM sales WHERE region = ?", (self.region,)).fetchall()

    Report(input("region: ")).run(sqlite3.connect("sales.db"))
""")

# ---------------------------------------------------------------- CWE-918 server-side request forgery
case("ssrf_requests_get", 918, ["web"], """
    import requests
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/preview")
    def preview():
        return requests.get(request.args["url"], timeout=5).text[:200]
""", """
    import requests
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/preview")
    def preview():
        return requests.get("https://api.example.org/preview", params={"u": request.args["url"]}, timeout=5).text[:200]
""")

case("ssrf_urlopen_concat", 918, ["web"], """
    from urllib.request import urlopen
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/avatar")
    def avatar():
        host = request.args["host"]
        return urlopen("http://" + host + "/avatar.png").read()
""", """
    from urllib.request import urlopen
    from flask import Flask, request
    app = Flask(__name__)
    HOSTS = {"eu": "eu.cdn.example.org", "us": "us.cdn.example.org"}

    @app.route("/avatar")
    def avatar():
        host = HOSTS.get(request.args["region"], "eu.cdn.example.org")
        return urlopen("http://" + host + "/avatar.png").read()
""")

case("ssrf_session", 918, ["web", "method"], """
    import requests
    from flask import Flask, request
    app = Flask(__name__)
    session = requests.Session()

    @app.route("/hook", methods=["POST"])
    def hook():
        session.post(request.json["callback"], json={"ok": True})
        return "sent"
""", """
    import requests
    from flask import Flask, request
    app = Flask(__name__)
    session = requests.Session()

    @app.route("/hook", methods=["POST"])
    def hook():
        session.post("https://hooks.example.org/notify", json={"ok": True, "callback": request.json["callback"]})
        return "sent"
""")

case("ssrf_allowlist_check", 918, ["web", "allowlist"], """
    import requests
    from flask import Flask, request, abort
    app = Flask(__name__)

    @app.route("/fetch")
    def fetch():
        url = request.args["url"]
        if not url.startswith("http"):
            abort(400)
        return requests.get(url).content
""", """
    import requests
    from flask import Flask, request, abort
    from django.utils.http import url_has_allowed_host_and_scheme
    app = Flask(__name__)

    @app.route("/fetch")
    def fetch():
        url = request.args["url"]
        if not url_has_allowed_host_and_scheme(url, allowed_hosts={"static.example.org"}):
            abort(400)
        return requests.get(url).content
""")

case("ssrf_interproc", 918, ["web", "interproc"], """
    import httpx
    from flask import Flask, request
    app = Flask(__name__)

    def download(url):
        return httpx.get(url).content

    @app.route("/import")
    def do_import():
        return download(request.args["src"])
""", """
    import httpx
    from flask import Flask, request
    app = Flask(__name__)

    def download(url):
        return httpx.get(url).content

    @app.route("/import")
    def do_import():
        return download("https://data.example.org/export/" + str(int(request.args["id"])))
""")

case("ssrf_attribute", 918, ["web", "attribute"], """
    import requests
    from flask import Flask, request
    app = Flask(__name__)

    class Feed:
        def __init__(self, url):
            self.url = url

        def fetch(self):
            return requests.get(self.url).text

    @app.route("/feed")
    def feed():
        return Feed(request.args["url"]).fetch()
""", """
    import requests
    from flask import Flask, request
    app = Flask(__name__)
    FEEDS = {"news": "https://example.org/news.xml"}

    class Feed:
        def __init__(self, url):
            self.url = url

        def fetch(self):
            return requests.get(self.url).text

    @app.route("/feed")
    def feed():
        return Feed(FEEDS.get(request.args["name"], FEEDS["news"])).fetch()
""")

# ---------------------------------------------------------------- CWE-1336 template injection
case("ssti_render_template_string", 1336, ["web"], """
    from flask import Flask, request, render_template_string
    app = Flask(__name__)

    @app.route("/hello")
    def hello():
        return render_template_string("<h1>Hello " + request.args["name"] + "</h1>")
""", """
    from flask import Flask, request, render_template_string
    app = Flask(__name__)

    @app.route("/hello")
    def hello():
        return render_template_string("<h1>Hello {{ name }}</h1>", name=request.args["name"])
""")

case("ssti_jinja_template", 1336, ["web"], """
    from jinja2 import Template
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/greet", methods=["POST"])
    def greet():
        return Template(request.form["tpl"]).render(user="guest")
""", """
    from jinja2 import Template
    from flask import Flask, request
    app = Flask(__name__)

    @app.route("/greet", methods=["POST"])
    def greet():
        return Template("Hello {{ user }}").render(user=request.form["tpl"])
""")

case("ssti_sandbox", 1336, ["web", "sanitizer"], """
    from jinja2 import Environment
    from flask import Flask, request
    app = Flask(__name__)
    env = Environment()

    @app.route("/preview", methods=["POST"])
    def preview():
        return env.from_string(request.form["body"]).render()
""", """
    from jinja2.sandbox import SandboxedEnvironment
    from flask import Flask, request
    app = Flask(__name__)
    env = SandboxedEnvironment()

    @app.route("/preview", methods=["POST"])
    def preview():
        return env.from_string(request.form["body"]).render()
""")

case("ssti_django_template", 1336, ["web"], """
    from django.http import HttpResponse
    from django.template import Template, Context

    def page(request):
        tpl = Template("<p>" + request.GET["msg"] + "</p>")
        return HttpResponse(tpl.render(Context({})))
""", """
    from django.http import HttpResponse
    from django.template import Template, Context

    def page(request):
        tpl = Template("<p>{{ msg }}</p>")
        return HttpResponse(tpl.render(Context({"msg": request.GET["msg"]})))
""")

case("ssti_interproc", 1336, ["web", "interproc"], """
    from flask import Flask, request
    from jinja2 import Template
    app = Flask(__name__)

    def render(src, **ctx):
        return Template(src).render(**ctx)

    @app.route("/card", methods=["POST"])
    def card():
        return render(request.form["layout"], title="Card")
""", """
    from flask import Flask, request
    from jinja2 import Template
    app = Flask(__name__)

    def render(src, **ctx):
        return Template(src).render(**ctx)

    @app.route("/card", methods=["POST"])
    def card():
        return render("<div>{{ title }}</div>", title=request.form["layout"])
""")
