"""Write the benchmark files and labels.json from cases.py."""
import json
import shutil
from pathlib import Path

from cases import CASES

HERE = Path(__file__).resolve().parent
OUT = HERE / "bench"


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir()
    labels = []
    seen = set()
    for c in CASES:
        assert c["id"] not in seen, c["id"]
        seen.add(c["id"])
        for variant in ("vuln", "safe"):
            name = f"{c['id']}__{variant}.py"
            src = c[variant]
            compile(src, name, "exec")  # every file must be valid Python
            (OUT / name).write_text(src)
            labels.append({"file": name, "case": c["id"], "cwe": c["cwe"], "tags": c["tags"],
                           "vulnerable": variant == "vuln"})
    (HERE / "labels.json").write_text(json.dumps(labels, indent=1))
    by_cwe = {}
    for c in CASES:
        by_cwe[c["cwe"]] = by_cwe.get(c["cwe"], 0) + 1
    print(f"{len(CASES)} pairs, {len(labels)} files; pairs per CWE: {by_cwe}")


if __name__ == "__main__":
    main()
