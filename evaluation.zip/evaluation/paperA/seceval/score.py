#!/usr/bin/env python3
"""
Score normalised findings against twin-benchmark labels.

    python score.py --labels microbench/labels.json --results results/microbench --out results/microbench/scores

A file counts as *flagged* by a tool when the tool reports at least one finding
in that file whose CWE matches the file's labelled CWE (findings of other CWEs
are noise and only count toward warning volume). Optional severity floors
give a second operating point per tool (e.g. PyMetricor >= medium).

Metrics per tool (overall, per CWE, per tag):
  precision, recall, F1                 file level
  pair accuracy                         vuln twin flagged AND safe twin not flagged
  warnings                              all findings, any CWE
  off-target warnings                   findings whose CWE is not the file's CWE
"""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

SEV_RANK = {"info": 0, "note": 0, "low": 1, "warning": 2, "medium": 2, "error": 3, "high": 3, "critical": 4, "": 1}

# (display name, findings file, minimum severity or None)
VARIANTS = [
    ("PyMetricor 1.0.0 (any)",        "pymetricor",       None),
    ("PyMetricor 1.0.0 (>=medium)",   "pymetricor",       "medium"),
    ("PyMetricor 1.0.1 (any)",        "pymetricor_101",   None),
    ("PyMetricor 1.0.1 (>=medium)",   "pymetricor_101",   "medium"),
    ("PyMetricor 91e6867 (any)",      "pymetricor_orig",  None),
    ("PyMetricor 91e6867 (>=medium)", "pymetricor_orig",  "medium"),
    ("PyMetricor 1.0.1, no string recursion (>=medium)", "pymetricor_norec", "medium"),
    ("Bandit (any)",                  "bandit",           None),
    ("Bandit (>=medium)",             "bandit",           "medium"),
    ("Semgrep",                       "semgrep",          None),
    ("CodeQL (remote sources)",       "codeql",           None),
    ("CodeQL (local+remote sources)", "codeql_local",     None),
    ("Pysa",                          "pysa",             None),
]


def load(path):
    return [json.loads(l) for l in open(path)] if path.exists() else None


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return round(p, 3), round(r, 3), round(f, 3)


def score(labels, findings, floor):
    flagged_files = defaultdict(set)   # file -> set of cwe
    by_file_total = defaultdict(int)
    for x in findings:
        if floor and SEV_RANK.get(str(x.get("severity", "")).lower(), 1) < SEV_RANK[floor]:
            continue
        by_file_total[x["file"]] += 1
        if x.get("cwe") is not None:
            flagged_files[x["file"]].add(x["cwe"])

    label_by_file = {l["file"]: l for l in labels}
    groups = defaultdict(lambda: {"tp": 0, "fp": 0, "fn": 0, "tn": 0, "pairs": 0, "pairs_ok": 0})
    per_case = defaultdict(dict)
    for l in labels:
        hit = l["cwe"] in flagged_files.get(l["file"], set())
        per_case[l["case"]]["vuln" if l["vulnerable"] else "safe"] = hit
        keys = ["ALL", f"CWE-{l['cwe']}", *[f"tag:{t}" for t in l["tags"]]]
        for k in keys:
            g = groups[k]
            if l["vulnerable"]:
                g["tp" if hit else "fn"] += 1
            else:
                g["fp" if hit else "tn"] += 1

    case_meta = {l["case"]: l for l in labels}
    for case, r in per_case.items():
        ok = r.get("vuln") and not r.get("safe")
        l = case_meta[case]
        for k in ["ALL", f"CWE-{l['cwe']}", *[f"tag:{t}" for t in l["tags"]]]:
            groups[k]["pairs"] += 1
            groups[k]["pairs_ok"] += int(bool(ok))

    off_target = sum(1 for x in findings
                     if (not floor or SEV_RANK.get(str(x.get("severity", "")).lower(), 1) >= SEV_RANK[floor])
                     and x["file"] in label_by_file and x.get("cwe") != label_by_file[x["file"]]["cwe"])
    total = sum(by_file_total.values())

    out = {}
    for k, g in groups.items():
        p, r, f = prf(g["tp"], g["fp"], g["fn"])
        out[k] = {**g, "precision": p, "recall": r, "f1": f,
                  "pair_accuracy": round(g["pairs_ok"] / g["pairs"], 3) if g["pairs"] else None}
    out["ALL"]["warnings"] = total
    out["ALL"]["off_target_warnings"] = off_target
    return out, per_case


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--labels", required=True)
    ap.add_argument("--results", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    labels = json.load(open(a.labels))
    res = Path(a.results)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    table, all_cases = {}, {}
    for name, stem, floor in VARIANTS:
        f = load(res / f"{stem}.jsonl")
        if f is None:
            continue
        table[name], all_cases[name] = score(labels, f, floor)

    (out / "scores.json").write_text(json.dumps(table, indent=1))
    (out / "per_case.json").write_text(json.dumps(all_cases, indent=1))

    groups = ["ALL", "CWE-78", "CWE-95", "CWE-22", "CWE-327"]
    lines = ["| Tool | P | R | F1 | Pair acc. | TP/FP/FN/TN | Warnings (off-target) |", "| --- | --- | --- | --- | --- | --- | --- |"]
    for name, s in table.items():
        g = s["ALL"]
        lines.append(f"| {name} | {g['precision']:.2f} | {g['recall']:.2f} | {g['f1']:.2f} | {g['pair_accuracy']:.2f} | "
                     f"{g['tp']}/{g['fp']}/{g['fn']}/{g['tn']} | {g['warnings']} ({g['off_target_warnings']}) |")
    lines += ["", "F1 by CWE (pair accuracy in brackets)", "",
              "| Tool | " + " | ".join(groups[1:]) + " |", "| --- |" + " --- |" * (len(groups) - 1)]
    for name, s in table.items():
        cells = [f"{s[g]['f1']:.2f} ({s[g]['pair_accuracy']:.2f})" if g in s else "-" for g in groups[1:]]
        lines.append(f"| {name} | " + " | ".join(cells) + " |")
    tags = sorted({k for s in table.values() for k in s if k.startswith("tag:")})
    lines += ["", "Pair accuracy by feature tag", "", "| Tool | " + " | ".join(t[4:] for t in tags) + " |",
              "| --- |" + " --- |" * len(tags)]
    for name, s in table.items():
        lines.append(f"| {name} | " + " | ".join(f"{s[t]['pair_accuracy']:.2f}" if t in s else "-" for t in tags) + " |")
    (out / "tables.md").write_text("\n".join(lines) + "\n")

    with open(out / "per_case.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        names = list(all_cases)
        w.writerow(["case", "cwe", "tags"] + [f"{n} [vuln,safe]" for n in names])
        meta = {l["case"]: l for l in labels}
        for case in sorted(meta):
            w.writerow([case, meta[case]["cwe"], " ".join(meta[case]["tags"])] +
                       [f"{int(bool(all_cases[n][case].get('vuln')))},{int(bool(all_cases[n][case].get('safe')))}" for n in names])
    print((out / "tables.md").read_text())


if __name__ == "__main__":
    main()
