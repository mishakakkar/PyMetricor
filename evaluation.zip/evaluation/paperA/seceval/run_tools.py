#!/usr/bin/env python3
"""
Run SAST tools on a directory of Python files and write normalised findings.

    python run_tools.py --src microbench/bench --out results/microbench [--tools ...]

Every tool writes results/<name>/<tool>.raw.* (untouched output) and
<tool>.jsonl (one finding per line: file, line, rule, severity, cwe).
Mapping from tool rules to CWE lives in this file so it is auditable.

Tool locations come from environment variables (defaults are the scratch
install used on 2026-10-26):
  SECEVAL_TOOLS   dir containing semgrep/, codeql/, pysa/ installs
  PM_PY           python of a venv with astroid/xxhash/PyYAML
  PM_FIXED        PyMetricor checkout with the week 1-2 fixes (1.0.0)
  PM_ORIG         PyMetricor checkout at 91e6867 (paper version)
  BANDIT          bandit executable
"""
import os as _os  # paths come from env.sh (PM_EVAL, PM_WORK, PM_RESULTS, PM_PY, PM_DIR, PYFLOW)
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCR = Path(_os.environ["PM_WORK"])
TOOLS = Path(os.environ.get("SECEVAL_TOOLS", SCR / "tools"))
PM_PY = os.environ.get("PM_PY", str(SCR / "repro-work/venvs/pymetricor/bin/python"))
PM_FIXED = os.environ.get("PM_FIXED", str(SCR / "pm-1.0.0"))                     # tag-to-be v1.0.0 (f0326b6)
PM_101 = os.environ.get("PM_101", _os.environ.get("PM_DIR", ""))     # 1.0.1: + chained-call fix
PM_ORIG = os.environ.get("PM_ORIG", str(SCR / "repro-work/src/pymetricor"))
BANDIT = os.environ.get("BANDIT", str(SCR / "repro-work/venvs/bandit/bin/bandit"))

# vvv Rule -> CWE mappings vvv
BANDIT_CWE = {
    "B102": 95, "B307": 95,                                        # exec, eval
    "B602": 78, "B603": 78, "B604": 78, "B605": 78, "B606": 78, "B607": 78, "B609": 78,
    "B404": 78,                                                    # import subprocess (LOW)
    "B303": 327, "B324": 327,                                      # md5/sha1, hashlib.new weak
}
CWE_RE = re.compile(r"cwe[-_/ ]?0*(\d+)", re.I)
CWE_GROUP = {78: 78, 77: 78, 88: 78, 94: 95, 95: 95, 22: 22, 23: 22, 36: 22, 73: 22, 99: 22,
             327: 327, 328: 327, 916: 327, 470: 470}


def norm_cwe(texts):
    for t in texts:
        for m in CWE_RE.finditer(str(t)):
            c = CWE_GROUP.get(int(m.group(1)))
            if c:
                return c
    return None


def run(cmd, log, cwd=None, env=None):
    t0 = time.perf_counter()
    with open(f"{log}.stdout", "w") as so, open(f"{log}.stderr", "w") as se:
        r = subprocess.run(cmd, cwd=cwd, stdout=so, stderr=se, env=env)
    return {"exit": r.returncode, "seconds": round(time.perf_counter() - t0, 2), "cmd": " ".join(map(str, cmd))}


def write_jsonl(path, rows):
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")


def rel(src, f):
    try:
        return str(Path(f).resolve().relative_to(src))
    except ValueError:
        return str(f)


# vvv Tools vvv
def t_pymetricor(src, out, variant):
    pm = {"pymetricor": PM_FIXED, "pymetricor_101": PM_101, "pymetricor_orig": PM_ORIG,
          "pymetricor_norec": PM_101}[variant]
    extra = ["--max-depth", "0"] if variant == "pymetricor_norec" else []
    log = out / variant
    meta = run([PM_PY, HERE / "pymetricor_findings.py", "--pymetricor-dir", pm, *extra, src], log)
    rows, errors = [], 0
    for line in open(f"{log}.stdout"):
        d = json.loads(line)
        if "error" in d:
            errors += 1
            continue
        rows.append({"file": rel(src, d["file"]), "line": d["line"], "rule": d["rule"],
                     "severity": d["severity"], "cwe": d["cwe"]})
    meta["file_errors"] = errors
    return rows, meta


def t_bandit(src, out):
    raw = out / "bandit.raw.json"
    meta = run([BANDIT, "-r", src, "-f", "json", "-o", raw, "--exit-zero", "-q"], out / "bandit")
    d = json.load(open(raw))
    rows = [{"file": rel(src, r["filename"]), "line": r["line_number"], "rule": r["test_id"],
             "severity": r["issue_severity"].lower(), "cwe": BANDIT_CWE.get(r["test_id"]) or norm_cwe([r.get("issue_cwe", {}).get("id")])}
            for r in d["results"]]
    meta["file_errors"] = len(d.get("errors", []))
    return rows, meta


def t_semgrep(src, out):
    raw = out / "semgrep.raw.json"
    exe = TOOLS / "semgrep/bin/semgrep"
    # semgrep.dev (p/python) is not reachable from the eval host, so the python/ rules of
    # github.com/semgrep/semgrep-rules are used instead (a superset of the p/python pack).
    config = os.environ.get("SEMGREP_CONFIG", str(TOOLS / "semgrep-python-rules"))
    meta = run([exe, "scan", "--config", config, "--json", f"--output={raw}", "--metrics=off",
                "--disable-version-check", src], out / "semgrep")
    d = json.load(open(raw))
    rows = []
    for r in d.get("results", []):
        md = r.get("extra", {}).get("metadata", {})
        rows.append({"file": rel(src, r["path"]), "line": r["start"]["line"], "rule": r["check_id"],
                     "severity": r.get("extra", {}).get("severity", "").lower(),
                     "cwe": norm_cwe(md.get("cwe", []) if isinstance(md.get("cwe"), list) else [md.get("cwe")])})
    meta["file_errors"] = len(d.get("errors", []))
    return rows, meta


def t_codeql(src, out, threat_model):
    cq = TOOLS / "codeql/codeql"
    db = out / "codeql-db"
    if not db.exists():
        run([cq, "database", "create", db, "--language=python", f"--source-root={src}", "--overwrite"], out / "codeql-create")
    name = "codeql" if threat_model == "remote" else "codeql_local"
    raw = out / f"{name}.raw.sarif"
    tm = [] if threat_model == "remote" else ["--threat-model=local"]
    meta = run([cq, "database", "analyze", db, "codeql/python-queries:codeql-suites/python-security-extended.qls",
                "--format=sarif-latest", f"--output={raw}", *tm, "--threads=0", "--rerun"], out / name)
    d = json.load(open(raw))
    rows = []
    for runobj in d["runs"]:
        rules = {}
        for comp in [runobj["tool"]["driver"], *runobj["tool"].get("extensions", [])]:
            for rd in comp.get("rules", []):
                rules[rd["id"]] = rd
        for r in runobj["results"]:
            rd = rules.get(r["ruleId"], {})
            loc = r["locations"][0]["physicalLocation"]
            rows.append({"file": loc["artifactLocation"]["uri"], "line": loc["region"]["startLine"],
                         "rule": r["ruleId"], "severity": rd.get("properties", {}).get("problem.severity", r.get("level", "")),
                         "cwe": norm_cwe(rd.get("properties", {}).get("tags", []))})
    meta["file_errors"] = 0
    return rows, meta


def t_pysa(src, out):
    """Pysa needs a project dir with .pyre_configuration; we create one around a copy of src."""
    exe = TOOLS / "pysa/bin/pyre"
    proj = out / "pysa-project"
    if proj.exists():
        shutil.rmtree(proj)
    shutil.copytree(src, proj / "src")
    # pyre-check installs its models and typeshed under <venv>/lib/pyre_check; flask is
    # installed in the same venv so `flask.request` resolves for the web cases
    site = next((TOOLS / "pysa/lib").glob("python3*/site-packages"))
    typeshed = TOOLS / "pysa/lib/pyre_check/typeshed"
    taint = TOOLS / "pysa/lib/pyre_check/taint"
    # third_party_taint holds the Flask/Django source models; Pysa ships no models that
    # treat input()/sys.argv/os.environ as sources (remote threat model only)
    cfg = {"source_directories": ["src"], "taint_models_path": [str(taint), str(TOOLS / "pysa/lib/pyre_check/third_party_taint")],
           "search_path": [str(site)], "typeshed": str(typeshed)}
    (proj / ".pyre_configuration").write_text(json.dumps(cfg, indent=1))
    raw = out / "pysa-results"
    env = {**os.environ, "PATH": f"{exe.parent}:{os.environ.get('PATH', '')}"}  # pyre finds pyre.bin/pyrefly on PATH
    meta = run([exe, "--noninteractive", "analyze", "--no-verify", "--save-results-to", raw], out / "pysa", cwd=proj, env=env)
    rows = []
    errs = raw / "errors.json"
    if errs.exists():
        for r in json.load(open(errs)):
            cwe = {5001: 89, 5005: 95, 5006: 22, 5007: 78, 5008: 95, 5011: 22, 5012: 78}.get(r.get("code"))
            name = (r.get("name") or "") + " " + (r.get("description") or "")
            if cwe is None:
                low = name.lower()
                cwe = 78 if ("shell" in low or "command" in low) else 95 if ("code execution" in low or "eval" in low) \
                    else 22 if ("file system" in low or "path" in low) else None
            rows.append({"file": rel(proj / "src", proj / r["path"]) if not r["path"].startswith("src/") else r["path"][4:],
                         "line": r["line"], "rule": str(r.get("code")), "severity": "", "cwe": cwe})
    meta["file_errors"] = 0
    return rows, meta


RUNNERS = {
    "pymetricor":       lambda s, o: t_pymetricor(s, o, "pymetricor"),
    "pymetricor_101":   lambda s, o: t_pymetricor(s, o, "pymetricor_101"),
    "pymetricor_orig":  lambda s, o: t_pymetricor(s, o, "pymetricor_orig"),
    "pymetricor_norec": lambda s, o: t_pymetricor(s, o, "pymetricor_norec"),
    "bandit":           t_bandit,
    "semgrep":          t_semgrep,
    "codeql":           lambda s, o: t_codeql(s, o, "remote"),
    "codeql_local":     lambda s, o: t_codeql(s, o, "local"),
    "pysa":             t_pysa,
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--tools", nargs="+", default=list(RUNNERS))
    a = ap.parse_args()
    src, out = Path(a.src).resolve(), Path(a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    meta_path = out / "runs.json"
    metas = json.load(open(meta_path)) if meta_path.exists() else {}
    for t in a.tools:
        print(f"== {t}", flush=True)
        try:
            rows, meta = RUNNERS[t](src, out)
        except Exception as e:
            print(f"   failed: {type(e).__name__}: {e}", flush=True)
            metas[t] = {"failed": f"{type(e).__name__}: {e}"}
            continue
        write_jsonl(out / f"{t}.jsonl", rows)
        meta["findings"] = len(rows)
        metas[t] = meta
        print(f"   {len(rows)} findings, exit {meta['exit']}, {meta['seconds']}s", flush=True)
        meta_path.write_text(json.dumps(metas, indent=1))


if __name__ == "__main__":
    main()
