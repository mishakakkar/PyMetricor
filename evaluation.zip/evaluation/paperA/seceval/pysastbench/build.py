"""
Build a twin benchmark from the PySASTBench synthetic set (Liu et al., ICSE 2026,
https://github.com/Victor725/PySASTBench), the set PyFlow (arXiv:2608.07026) reports on.

Only the three CWE folders PyMetricor's schema covers are used:
  77 -> 78 (command injection), 94 -> 95 (code injection), 22 -> 22 (path traversal).
502, 79 and 89 have no PyMetricor capability and are left out.

Files are copied as <id>__vuln.py / <id>__safe.py with labels.json in the
micro-benchmark format, so run_tools.py and score.py work unchanged. Scoring
is file level; PySASTBench grades at method level, so our numbers are an upper
bound on theirs for the same tool.

    python build.py --pysastbench /path/to/PySASTBench --out bench
"""
import argparse
import csv
import json
import shutil
from pathlib import Path

GROUP = {"77": 78, "94": 95, "22": 22}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pysastbench", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    root = Path(a.pysastbench)
    pos = {r["TestCase"]: r["Vul Position"]
           for r in csv.DictReader(open(root / "SyntheticDataset.csv", encoding="utf-8-sig"))}
    out = Path(a.out)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    labels = []
    for folder, cwe in GROUP.items():
        for vul in sorted((root / "SyntheticDataset" / folder).glob("*_vul.py")):
            case = vul.name[:-len("_vul.py")]
            fix = vul.with_name(f"{case}_fix.py")
            cid = "ps_" + case.replace("-", "_")
            for variant, src in (("vuln", vul), ("safe", fix)):
                name = f"{cid}__{variant}.py"
                shutil.copy(src, out / name)
                labels.append({"file": name, "case": cid, "cwe": cwe, "tags": [f"CWE-{folder}"],
                               "vulnerable": variant == "vuln", "position": pos.get(case)})
    (out.parent / "labels.json").write_text(json.dumps(labels, indent=1))
    print(len(labels) // 2, "pairs")


if __name__ == "__main__":
    main()
