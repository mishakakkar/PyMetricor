"""
Build a twin benchmark from PyVul's function-level dataset (Quan et al., MSR 2026,
https://github.com/billquan/PyVul).

Each PyVul function-level sample has `code_before` (vulnerable, pre-fix) and
`code_after` (post-fix). We keep Python samples whose commit-level CWE falls in
the four groups every compared tool claims to cover:
  78  <- CWE-77, CWE-78, CWE-88
  95  <- CWE-94, CWE-95
  22  <- CWE-22, CWE-23, CWE-36, CWE-73
  327 <- CWE-327, CWE-328, CWE-916
and write <id>__vuln.py / <id>__safe.py plus labels.json in the same format as the
micro-benchmark, so run_tools.py and score.py work unchanged.

Functions are dedented so methods parse on their own. Samples where either side
fails to parse, or where before == after, are dropped and counted.

    python build_pyvul.py --pyvul /path/to/PyVul --out bench
"""
import argparse
import ast
import collections
import json
import re
import shutil
import textwrap
from pathlib import Path

GROUP = {"CWE-77": 78, "CWE-78": 78, "CWE-88": 78, "CWE-94": 95, "CWE-95": 95,
         "CWE-22": 22, "CWE-23": 22, "CWE-36": 22, "CWE-73": 22,
         "CWE-327": 327, "CWE-328": 327, "CWE-916": 327}


def clean(src):
    src = textwrap.dedent(src.expandtabs(4)).strip("\n") + "\n"
    ast.parse(src)
    return src


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pyvul", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    ds = Path(a.pyvul) / "dataset"
    cwe_map = json.load(open(ds / "commits_cwe_map.json"))
    out = Path(a.out)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    stats = collections.Counter()
    labels, seen = [], set()
    for line in open(ds / "function_level_dataset.out"):
        r = json.loads(line)
        if r.get("programming_language") != "Python":
            continue
        stats["python_functions"] += 1
        cwe = cwe_map.get(r["commit"])
        if cwe not in GROUP:
            stats["out_of_scope_cwe"] += 1
            continue
        stats["in_scope"] += 1
        try:
            before, after = clean(r["code_before"]), clean(r["code_after"])
        except SyntaxError:
            stats["dropped_parse_error"] += 1
            continue
        if before == after:
            stats["dropped_identical"] += 1
            continue
        key = (before, after)
        if key in seen:
            stats["dropped_duplicate"] += 1
            continue
        seen.add(key)
        repo = re.sub(r"https://github.com/([^/]+/[^/]+)/commit/.*", r"\1", r["commit"])
        cid = f"pv{len(seen):04d}_{re.sub(r'[^A-Za-z0-9]+', '_', r['function_name'])[:40]}"
        for variant, src in (("vuln", before), ("safe", after)):
            name = f"{cid}__{variant}.py"
            (out / name).write_text(src)
            labels.append({"file": name, "case": cid, "cwe": GROUP[cwe], "tags": [cwe, f"repo:{repo}"],
                           "vulnerable": variant == "vuln", "commit": r["commit"]})
    stats["pairs"] = len(seen)
    (out.parent / "labels.json").write_text(json.dumps(labels, indent=1))
    (out.parent / "build_stats.json").write_text(json.dumps(stats, indent=1))
    by = collections.Counter(l["cwe"] for l in labels if l["vulnerable"])
    print(dict(stats), "pairs per group:", dict(by))


if __name__ == "__main__":
    main()
