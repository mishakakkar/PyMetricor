#!/usr/bin/env bash
# RQ1: micro-benchmark (81 twin pairs) and PySASTBench synthetic subset (60 pairs), file-level grading.
# Paper A Tables 5 and 6 (micro-benchmark column). About 15 minutes.
set -euo pipefail
source "$(dirname "$0")/../env.sh"; cd "$PM_EVAL/scripts"
python3 ../seceval/microbench/build.py                                  # writes seceval/microbench/bench
python3 ../seceval/pysastbench/build.py --pysastbench "$PM_WORK/data/pysastbench" --out "$PM_WORK/seceval/pysastbench/bench"
$PY_AN secbench.py "$PM_DIR" v170 micro pysast                           # PyMetricor -> results/security/
for b in micro pysast; do
  src="$PM_EVAL/seceval/microbench/bench"; out="$PM_RESULTS/microbench"
  [ $b = pysast ] && src="$PM_WORK/seceval/pysastbench/bench" && out="$PM_RESULTS/pysastbench"
  $PY_AN run_tools_v17.py --src "$src" --out "$out" --tools bandit semgrep codeql codeql_local
  $PY_AN rq1_tables.py $b
done
