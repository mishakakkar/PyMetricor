#!/usr/bin/env bash
# Validator-mutation set: 5 classes x {real, gutted, neutral} helper. Paper A, Section 5 (validators). A few minutes.
set -euo pipefail
source "$(dirname "$0")/../env.sh"; cd "$PM_EVAL/scripts"
D="$PM_WORK/valmut"; mkdir -p "$D"
python3 valmut/build.py "$D/src"
$PM_PY findings.py --pymetricor-dir "$PM_DIR" --project "$D/src" "$D/src" > "$D/pm.jsonl"
$BANDIT -r "$D/src" -f json -o "$D/bandit.json" --exit-zero -q
"$SECEVAL_TOOLS/semgrep/bin/semgrep" scan --config "$SECEVAL_TOOLS/semgrep-python-rules" --json --output "$D/sg.json" --metrics=off "$D/src"
CQ="$SECEVAL_TOOLS/codeql/codeql"
$CQ database create "$D/db" --language=python --source-root "$D/src" --overwrite -q
$CQ database analyze "$D/db" codeql/python-queries:codeql-suites/python-security-extended.qls --threat-model=local \
   --format=sarif-latest --output "$D/cq.sarif" -q
$PY_AN valmut_grade.py "$D"
