#!/usr/bin/env bash
# RQ2: PyVul with repository context, both sets, held-out halves only. Paper A Tables 5-8.
# Building the trees clones about 90 repositories (an hour or two); CodeQL is the slow step (several hours).
set -euo pipefail
source "$(dirname "$0")/../env.sh"; cd "$PM_EVAL/scripts"
W=4   # parallel workers; lower it if memory is short (CodeQL uses about 3.5 GB per worker)

# 1. Build the twin trees. The shipped labels_ctx_ok.json and split.json fix the cases and the split.
python3 ../seceval/pyvul/build_pyvul.py --pyvul "$PM_WORK/data/PyVul" --out "$PM_WORK/seceval/pyvul-data/bench"
python3 build_pyvul_ctx.py --pyvul "$PM_WORK/data/PyVul" --labels "$PM_WORK/seceval/pyvul-data/labels.json" --out "$PM_WORK/pvctx"
python3 build_pyvul_ctx_new.py --pyvul "$PM_WORK/data/PyVul" --out "$PM_WORK/pvctx_new"
cp "$PM_EVAL/data/pyvul_ctx/labels_ctx_ok.json" "$PM_WORK/pvctx/"
cp "$PM_EVAL/data/pyvul_new/labels_ctx_ok.json" "$PM_WORK/pvctx_new/"

for B in old new; do
  BF=""; [ $B = new ] && BF="--bench new"
  # 2. PyMetricor 1.7.0 and the baselines on the held-out half
  $PY_AN eval_pyvul_ctx.py run --pm "$PM_DIR" --name test_v170 --split test --workers $W $BF
  for t in bandit semgrep codeql; do $PY_AN baselines_pyvul_ctx.py --tool $t --split test --workers $W $BF; done
  $PY_AN baselines_paths.py --tool semgrep --split test --workers $W $BF   # Semgrep with --dataflow-traces
  $PY_AN pyflow_pyvul.py $B                                                  # PyFlow, 600 s per run
  # 3. Grading by line, then with path credit + McNemar/bootstrap/Holm (the primary comparison)
  $PY_AN eval_pyvul_ctx.py score --names test_v170,test_codeql,test_semgrep,test_bandit --split test $BF
  [ $B = old ] && $PY_AN test_stats.py || $PY_AN test_stats_new.py
  $PY_AN path_credit.py $B
  # 4. Validator ablation: 1.7.0 without validator name patterns
  $PY_AN eval_pyvul_ctx_rev.py run --pm "$PM_WORK/pm17_noval" --name test_noval --split test --workers $W $BF
  $PY_AN eval_pyvul_ctx_rev.py score --names test_noval --split test $BF
done
