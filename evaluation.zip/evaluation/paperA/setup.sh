#!/usr/bin/env bash
# One-off setup: tools at the versions used in the paper, the datasets at fixed commits, and PyMetricor.
# Needs: Linux x86_64, Python 3.12 (python3.12 on PATH), git, curl, unzip, about 40 GB of disk.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$PM_WORK"
V=repro-work/venvs; mkdir -p $V tools data

# Python environments
python3.12 -m venv $V/pymetricor && $V/pymetricor/bin/pip install -q PyYAML==6.0.2 astroid==3.3.10 xxhash==3.5.0
python3.12 -m venv $V/bandit && $V/bandit/bin/pip install -q bandit==1.8.6
python3.12 -m venv $V/analysis && $V/analysis/bin/pip install -q scipy==1.16.2 numpy==2.5.4 matplotlib==3.11.2 pandas==2.3.3
python3.12 -m venv tools/semgrep && tools/semgrep/bin/pip install -q semgrep==1.128.1

# Semgrep community rules at the commit used (python/ only)
[ -d tools/semgrep-rules ] || git clone -q https://github.com/semgrep/semgrep-rules tools/semgrep-rules
git -C tools/semgrep-rules checkout -q 16b9e6d
rm -rf tools/semgrep-python-rules && cp -r tools/semgrep-rules/python tools/semgrep-python-rules

# CodeQL CLI bundle 2.27.3 (includes the python query packs)
if [ ! -x tools/codeql/codeql ]; then
  curl -sSL -o codeql.tgz https://github.com/github/codeql-action/releases/download/codeql-bundle-v2.27.3/codeql-bundle-linux64.tar.gz
  tar -xzf codeql.tgz -C tools && rm codeql.tgz
fi

# PyFlow 0.1.2 at commit e19bb9e
[ -d data/pyflow ] || git clone -q https://github.com/ZJU-PL/pyflow data/pyflow
git -C data/pyflow checkout -q e19bb9e
python3.12 -m venv venv-pyflow && venv-pyflow/bin/pip install -q -e data/pyflow

# Datasets
[ -d data/PyVul ] || git clone -q https://github.com/billquan/PyVul data/PyVul
git -C data/PyVul checkout -q 1172bfd
[ -d data/pysastbench ] || git clone -q https://github.com/Victor725/PySASTBench data/pysastbench
git -C data/pysastbench checkout -q 3ad04b7

# PyMetricor 1.7.0
if [ ! -d "$PM_DIR" ]; then
  git clone -q https://github.com/Altered-commits/PyMetricor "$PM_DIR" && git -C "$PM_DIR" checkout -q v1.7.0
fi
# The validator ablation uses a copy of 1.7.0 with the validator name patterns removed (data/pm17_noval.patch)
rm -rf pm17_noval && cp -r "$PM_DIR" pm17_noval && patch -s -p0 -d pm17_noval < "$PM_EVAL/data/pm17_noval.patch"

echo "Setup done. Versions:"; $BANDIT --version | head -1; tools/semgrep/bin/semgrep --version; tools/codeql/codeql version | head -1
