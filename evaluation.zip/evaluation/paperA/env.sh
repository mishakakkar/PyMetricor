# Source this file before any step:  source env.sh
# Edit PM_DIR (and PM_WORK if you want the large data elsewhere); the rest follows.
export PM_EVAL="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"   # this package
export PM_WORK="${PM_WORK:-$PM_EVAL/work}"                        # tools, datasets, trees (tens of GB)
export PM_RESULTS="${PM_RESULTS:-$PM_EVAL/results}"               # everything the runs write
export PM_DIR="${PM_DIR:-$(cd "$PM_EVAL/../.." && pwd)}"            # this repository (check out tag v1.7.0)
export PM_PY="$PM_WORK/repro-work/venvs/pymetricor/bin/python"     # runs PyMetricor
export PY_AN="$PM_WORK/repro-work/venvs/analysis/bin/python"       # runs the evaluation scripts (scipy)
export BANDIT="$PM_WORK/repro-work/venvs/bandit/bin/bandit"
export SECEVAL_TOOLS="$PM_WORK/tools"                              # semgrep/, codeql/, semgrep-python-rules/
export PYFLOW="$PM_WORK/venv-pyflow/bin/pyflow"
export PM_101="$PM_DIR"; export PM_PY
mkdir -p "$PM_WORK" "$PM_RESULTS"
