"""RQ1 tables (Table 5 and the micro-benchmark column of Table 6): score PyMetricor 1.7.0 and the
baselines on a synthetic twin benchmark at file level with score.py's logic.

    python rq1_tables.py micro|pysast
Reads $PM_RESULTS/security/<bench>_v170.jsonl (from secbench.py) and the baseline findings in
$PM_RESULTS/<bench>/ (from run_tools_v17.py); writes $PM_RESULTS/<bench>/tables_v170.md.
"""
import json
import os
import sys
from pathlib import Path

E = os.environ
sys.path.insert(0, E["PM_EVAL"] + "/seceval")
from score import score  # noqa: E402

b = sys.argv[1]
lab = {"micro": E["PM_EVAL"] + "/seceval/microbench/labels.json", "pysast": E["PM_EVAL"] + "/seceval/pysastbench/labels.json"}[b]
res = Path(E["PM_RESULTS"]) / ("microbench" if b == "micro" else "pysastbench")
labels = json.load(open(lab))
load = lambda p: [json.loads(l) for l in open(p)] if Path(p).exists() else None
V = [("PyMetricor 1.7.0 (any)", Path(E["PM_RESULTS"]) / "security" / f"{b}_v170.jsonl", None),
     ("PyMetricor 1.7.0 (>=medium)", Path(E["PM_RESULTS"]) / "security" / f"{b}_v170.jsonl", "medium"),
     ("Bandit (>=medium)", res / "bandit.jsonl", "medium"), ("Semgrep", res / "semgrep.jsonl", None),
     ("CodeQL (remote sources)", res / "codeql.jsonl", None), ("CodeQL (local+remote)", res / "codeql_local.jsonl", None)]
groups = [("All pairs", None), ("New classes: CWE-89/918/1336", {89, 918, 1336})]
out = []
for title, keep in groups:
    L = [l for l in labels if keep is None or l["cwe"] in keep]
    if not L:
        continue
    out += [f"### {title} ({len(L) // 2} pairs)", "", "| Tool | P | R | F1 | Pair acc. | warnings |", "|---|---|---|---|---|---|"]
    for name, f, floor in V:
        rows = load(f)
        if rows is None:
            out.append(f"| {name} | missing {f.name} |||||"); continue
        files = {l["file"] for l in L}
        s = score(L, [r for r in rows if r["file"] in files], floor)[0]["ALL"]
        out.append(f"| {name} | {s['precision']:.2f} | {s['recall']:.2f} | {s['f1']:.2f} | {s['pair_accuracy']:.2f} | {s['warnings']} |")
    out.append("")
res.mkdir(parents=True, exist_ok=True)
(res / "tables_v170.md").write_text("\n".join(out))
print("\n".join(out))
