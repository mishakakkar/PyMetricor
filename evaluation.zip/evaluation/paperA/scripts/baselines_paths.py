"""
Bandit, Semgrep and CodeQL on PyVul with repository context, in the same output
format as eval_pyvul_ctx.py so the same function-level grading applies.

    python baselines_pyvul_ctx.py --tool bandit|semgrep|codeql --split test [--bench new]

Bandit and Semgrep analyse the target files (they do not follow calls across files).
CodeQL builds a database of the target file's top-level folder in the tree (the
package it belongs to), so its interprocedural taint tracking can follow calls into
the rest of that package, and runs python-security-extended with the local threat
model (as codeql_local in the single-function benchmark).
"""
import os as _os  # paths come from env.sh (PM_EVAL, PM_WORK, PM_RESULTS, PM_PY, PM_DIR, PYFLOW)
import argparse
import json
import subprocess
import sys
import tempfile
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, _os.environ["PM_EVAL"] + "/seceval")
sys.path.insert(0, str(Path(__file__).parent))
import run_tools  # noqa: E402
sys.path.insert(0, _os.environ["PM_EVAL"] + "/scripts")
from eval_pyvul_ctx import CTX, OUT, cases, safe_tree  # noqa: E402
OUT = Path(_os.environ["PM_RESULTS"] + "/rev") / OUT.name
OUT.mkdir(parents=True, exist_ok=True)

# 1.7.0 vulnerability classes: SQL injection, SSRF, template injection
run_tools.CWE_GROUP.update({89: 89, 564: 89, 918: 918, 1336: 1336})
run_tools.BANDIT_CWE.update({"B608": 89})

TOOLS = run_tools.TOOLS


def norm(rows, root, tree, variant):
    out = []
    for r in rows:
        f = Path(r["file"])
        f = f.relative_to(root) if f.is_absolute() else f
        out.append({**r, "file": str(f), "tree": tree, "variant": variant})
    return out


def bandit(root, paths):
    with tempfile.TemporaryDirectory() as t:
        raw = Path(t) / "b.json"
        subprocess.run([run_tools.BANDIT, "-f", "json", "-o", str(raw), "--exit-zero", "-q", *[str(root / p) for p in paths]],
                       capture_output=True, timeout=900)
        d = json.load(open(raw))
    return [{"file": r["filename"], "line": r["line_number"], "rule": r["test_id"], "severity": r["issue_severity"].lower(),
             "cwe": run_tools.BANDIT_CWE.get(r["test_id"]) or run_tools.norm_cwe([r.get("issue_cwe", {}).get("id")])}
            for r in d["results"]]


def semgrep(root, paths):
    with tempfile.TemporaryDirectory() as t:
        raw = Path(t) / "s.json"
        proc = subprocess.run([str(TOOLS / "semgrep/bin/semgrep"), "scan", "--config", str(TOOLS / "semgrep-python-rules"), "--json", "--dataflow-traces",
                        f"--output={raw}", "--metrics=off", "--disable-version-check", *[str(root / p) for p in paths]],
                       capture_output=True, timeout=1800, text=True)
        if not raw.exists():
            raise RuntimeError(proc.stderr[-400:])
        d = json.load(open(raw))
    rows = []
    for r in d.get("results", []):
        md = r.get("extra", {}).get("metadata", {})
        tr = r.get("extra", {}).get("dataflow_trace") or {}
        locs = []
        def walk(o):
            if isinstance(o, dict):
                if "start" in o and "path" in o and isinstance(o["start"], dict):
                    locs.append([o["path"], o["start"].get("line")])
                for v in o.values(): walk(v)
            elif isinstance(o, list):
                for v in o: walk(v)
        walk(tr)
        rows.append({"path": locs, "file": r["path"], "line": r["start"]["line"], "rule": r["check_id"],
                     "severity": r.get("extra", {}).get("severity", "").lower(),
                     "cwe": run_tools.norm_cwe(md.get("cwe", []) if isinstance(md.get("cwe"), list) else [md.get("cwe")])})
    return rows


def codeql(root, paths, work):
    rows = []
    for top in sorted({Path(p).parts[0] if len(Path(p).parts) > 1 else "." for p in paths}):
        src = root / top
        db = work / f"db_{top.replace('.', '_root')}"
        cq = TOOLS / "codeql/codeql"
        subprocess.run([str(cq), "database", "create", str(db), "--language=python", f"--source-root={src}", "--overwrite",
                        "--threads=1"], capture_output=True, timeout=3600)
        raw = work / f"{db.name}.sarif"
        subprocess.run([str(cq), "database", "analyze", str(db), "codeql/python-queries:codeql-suites/python-security-extended.qls",
                        "--format=sarif-latest", f"--output={raw}", "--threat-model=local", "--threads=1", "--ram=3500", "--rerun"],
                       capture_output=True, timeout=3600)
        if not raw.exists():
            continue
        d = json.load(open(raw))
        for runobj in d["runs"]:
            rules = {}
            for comp in [runobj["tool"]["driver"], *runobj["tool"].get("extensions", [])]:
                for rd in comp.get("rules", []):
                    rules[rd["id"]] = rd
            for r in runobj["results"]:
                rd = rules.get(r["ruleId"], {})
                loc = r["locations"][0]["physicalLocation"]
                pre = (lambda u: str(Path(top) / u) if top != "." else u)
                locs = []
                for cf in r.get("codeFlows", []):
                    for tf in cf.get("threadFlows", []):
                        for st in tf.get("locations", []):
                            pl = st.get("location", {}).get("physicalLocation", {})
                            if "artifactLocation" in pl and "region" in pl:
                                locs.append([pre(pl["artifactLocation"]["uri"]), pl["region"].get("startLine")])
                rows.append({"path": locs, "file": str(Path(top) / loc["artifactLocation"]["uri"]) if top != "." else loc["artifactLocation"]["uri"],
                             "line": loc["region"]["startLine"], "rule": r["ruleId"],
                             "severity": rd.get("properties", {}).get("problem.severity", r.get("level", "")),
                             "cwe": run_tools.norm_cwe(rd.get("properties", {}).get("tags", []))})
        subprocess.run(["rm", "-rf", str(db)])
    return rows


def job(tool, tree, variant, paths):
    root = CTX / "trees" / tree / ("base" if variant == "vuln" else "safe")
    t0 = time.time()
    err = ""
    try:
        if tool == "codeql":
            work = CTX / "codeql" / f"{tree}_{variant}"
            work.mkdir(parents=True, exist_ok=True)
            rows = codeql(root, paths, work)
        else:
            rows = {"bandit": bandit, "semgrep": semgrep}[tool](root, paths)
    except Exception as e:
        rows, err = [], f"{type(e).__name__}: {e}"
    return norm(rows, root, tree, variant), {"tree": tree, "variant": variant, "seconds": round(time.time() - t0, 1), "error": err}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tool", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--bench", default="old")
    a = ap.parse_args()
    jobs = defaultdict(set)
    for c in cases(a.split):
        jobs[(c["tree"], "vuln")].add(c["vuln"]["path"])
        jobs[(c["tree"], "safe")].add(c["safe"]["path"])
        safe_tree(c["tree"])
    items = sorted(jobs.items())[: a.limit]
    rows, meta = [], []
    with ThreadPoolExecutor(a.workers) as ex:
        for r, m in ex.map(lambda kv: job(a.tool, kv[0][0], kv[0][1], kv[1]), items):
            rows += r
            meta.append(m)
            print(m, flush=True)
    name = f"{a.split}_{a.tool}" + (f"_first{a.limit}" if a.limit else "")
    with open(OUT / f"{name}.jsonl", "w") as fh:
        for x in rows:
            fh.write(json.dumps(x) + "\n")
    json.dump(meta, open(OUT / f"{name}.runs.json", "w"), indent=1)


if __name__ == "__main__":
    main()
