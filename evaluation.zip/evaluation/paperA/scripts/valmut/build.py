"""Validator-mutation set: five classes x three variants of a project validation helper.
 real    : helper named like a validator, body really checks and raises  -> safe
 gutted  : same name, body does nothing                                   -> vulnerable
 neutral : body really checks, helper given a neutral name                -> safe
Each file is a Flask view that passes request data through the helper to a sink."""
import sys
from pathlib import Path
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
C = {
 "path": ("validate_path", 'if ".." in v or v.startswith("/"):\n        raise ValueError(v)', "import os", 'return open(os.path.join("data", name)).read()', "name"),
 "cmd": ("ensure_safe_command", 'if not re.fullmatch(r"[a-z0-9_]+", v):\n        raise ValueError(v)', "import re, subprocess", 'return subprocess.check_output("ls " + name, shell=True)', "name"),
 "code": ("validate_expression", 'if not re.fullmatch(r"[0-9+*/ -]+", v):\n        raise ValueError(v)', "import re", 'return str(eval(name))', "name"),
 "sql": ("validate_table", 'if v not in ("users", "orders"):\n        raise ValueError(v)', "import sqlite3", 'return sqlite3.connect("db").cursor().execute("SELECT * FROM " + name).fetchall()', "name"),
 "ssrf": ("validate_url", 'if urlparse(v).hostname not in ("api.example.com",):\n        raise ValueError(v)', "import requests\nfrom urllib.parse import urlparse", 'return requests.get(name).text', "name"),
}
for cls, (vname, body, imp, sink, var) in C.items():
    for variant in ("real", "gutted", "neutral"):
        fn = vname if variant != "neutral" else "normalise_input"
        b = body if variant != "gutted" else "return None"
        src = f'''{imp}
from flask import Flask, request
import re
app = Flask(__name__)


def {fn}(v):
    {b}


@app.route("/{cls}")
def view():
    {var} = request.args.get("q")
    {fn}({var})
    {sink}
'''
        (out / f"{cls}_{variant}.py").write_text(src)
print("ok")
