"""Paired comparisons on the held-out PyVul cases: exact McNemar on vulnerable-twin detection and a
repository-clustered bootstrap CI for the recall difference (function-level grading)."""
import json, random, sys
from collections import defaultdict
from scipy.stats import binomtest
sys.path.insert(0, ".")
from eval_pyvul_ctx import OUT, cases, grade

cs = cases("test")
def flags(name, floor, measure="recall"):
    f = [json.loads(l) for l in open(OUT / f"{name}.jsonl")]
    per = grade(cs, f, floor, "function")[1]
    if measure == "pair":   # vulnerable twin flagged and safe twin not
        return {k: v["vuln"] and not v["safe"] for k, v in per.items()}
    return {k: v["vuln"] for k, v in per.items()}
repo = {c["case"]: c["repo"] for c in cs}
rows = []
for measure, floor in [(m, f) for m in ("recall", "pair") for f in (None, "medium")]:
    base = flags("test_v170", floor, measure)
    for other in ("test_codeql", "test_semgrep", "test_bandit"):
        o = flags(other, floor, measure)
        b = sum(base[k] and not o[k] for k in base); c = sum(o[k] and not base[k] for k in base)
        p = binomtest(b, b + c, 0.5).pvalue if b + c else 1.0
        by = defaultdict(list)
        for k in base: by[repo[k]].append(base[k] - o[k])
        reps = list(by); rnd = random.Random(2026); diffs = []
        for _ in range(5000):
            s = [x for r in (rnd.choice(reps) for _ in reps) for x in by[r]]
            diffs.append(sum(s) / len(s))
        diffs.sort()
        d = sum(base[k] - o[k] for k in base) / len(base)
        rows.append(f"| {measure} | {floor or 'any'} | 1.7.0 vs {other[5:]} | {d:+.3f} [{diffs[125]:+.3f}, {diffs[4874]:+.3f}] | {b} / {c} | {p:.3g} |")
out = ["| Measure | Severity | Comparison | Difference [95% CI, repo bootstrap] | Only 1.7.0 / only other | McNemar p |", "|---|---|---|---|---|---|", *rows]
(OUT / "test_paired.md").write_text("\n".join(out) + "\n"); print("\n".join(out))
