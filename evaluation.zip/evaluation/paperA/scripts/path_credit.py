"""Path-credit grading for the repository-context PyVul sets (editor review, Paper A).

Default grading credits a finding only if its reported line lies inside the vulnerable function.
Tools report flows at different points: CodeQL and Semgrep at the sink, PyMetricor at the call in the
function where the external value enters (with the chain of calls down to the sink). Path credit counts
a finding of the case's CWE if ANY step of its reported flow lies in the vulnerable function:
  - CodeQL: any location of any code flow in the SARIF result (same file, line inside the function);
  - Semgrep: any location of its dataflow trace (run with --dataflow-traces);
  - PyMetricor: the reported line, or any function of its call chain whose qualified name is the
    vulnerable function's (name match; the chain does not carry files);
  - Bandit: no flows; reported line only (unchanged).

    python path_credit.py old|new
"""
import os as _os  # paths come from env.sh (PM_EVAL, PM_WORK, PM_RESULTS, PM_PY, PM_DIR, PYFLOW)
import ast
import json
import random
import sys
from collections import defaultdict
from pathlib import Path

from scipy.stats import binomtest

BENCH = sys.argv[1]
sys.argv = [sys.argv[0]] + (["--bench", "new"] if BENCH == "new" else [])
sys.path.insert(0, _os.environ["PM_EVAL"] + "/scripts")
sys.path.insert(0, _os.environ["PM_EVAL"] + "/seceval")
import run_tools  # noqa: E402
from eval_pyvul_ctx import CTX, OUT, SEV, cases  # noqa: E402

run_tools.CWE_GROUP.update({89: 89, 564: 89, 918: 918, 1336: 1336})
REV = Path(_os.environ["PM_RESULTS"] + "/rev") / OUT.name
cs = cases("test")


def qualname(root, rel, start):
    try:
        tree = ast.parse((root / rel).read_text(errors="replace"))
    except Exception:
        return None
    hit = []

    def walk(node, prefix):
        for ch in ast.iter_child_nodes(node):
            if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                lines = [ch.lineno] + [d.lineno for d in ch.decorator_list]
                q = prefix + [ch.name]
                if not isinstance(ch, ast.ClassDef) and start in lines:
                    hit.append(".".join(q))
                walk(ch, q)
            else:
                walk(ch, prefix)
    walk(tree, [])
    return hit[0] if hit else None


QN = {}
for c in cs:
    for v in ("vuln", "safe"):
        root = CTX / "trees" / c["tree"] / ("base" if v == "vuln" else "safe")
        QN[(c["case"], v)] = qualname(root, c[v]["path"], c[v]["start"])


def load(name, d=OUT):
    return [json.loads(l) for l in open(d / f"{name}.jsonl")]


def codeql_rows():
    rows = []
    trees = {c["tree"] for c in cs}
    for t in sorted(trees):
        for v in ("vuln", "safe"):
            for sar in sorted((CTX / "codeql" / f"{t}_{v}").glob("db_*.sarif")):
                top = sar.stem[3:]
                top = "." if top == "_root" else top
                pre = (lambda u: str(Path(top) / u) if top != "." else u)
                d = json.load(open(sar))
                for runobj in d["runs"]:
                    rules = {}
                    for comp in [runobj["tool"]["driver"], *runobj["tool"].get("extensions", [])]:
                        for rd in comp.get("rules", []):
                            rules[rd["id"]] = rd
                    for r in runobj["results"]:
                        rd = rules.get(r["ruleId"], {})
                        loc = r["locations"][0]["physicalLocation"]
                        path = []
                        for cf in r.get("codeFlows", []):
                            for tf in cf.get("threadFlows", []):
                                for st in tf.get("locations", []):
                                    pl = st.get("location", {}).get("physicalLocation", {})
                                    if "artifactLocation" in pl and "region" in pl:
                                        path.append([pre(pl["artifactLocation"]["uri"]), pl["region"].get("startLine")])
                        rows.append({"file": pre(loc["artifactLocation"]["uri"]), "line": loc["region"]["startLine"],
                                     "rule": r["ruleId"], "path": path, "tree": t, "variant": v,
                                     "severity": rd.get("properties", {}).get("problem.severity", r.get("level", "")),
                                     "cwe": run_tools.norm_cwe(rd.get("properties", {}).get("tags", []))})
    return rows


def chain_hits(chain, qn):
    if not qn or not chain:
        return False
    for el in chain.split("→"):
        if el == qn or el.endswith("." + qn):
            return True
    return False


def grade(findings, floor, mode):
    by = defaultdict(list)
    for x in findings:
        if "error" in x or x.get("cwe") is None:
            continue
        if floor and SEV.get(str(x.get("severity", "")).lower(), 1) < SEV[floor]:
            continue
        by[(x["tree"], x["variant"])].append(x)
    per = {}
    for c in cs:
        hit = {}
        for v in ("vuln", "safe"):
            sp = c[v]
            inside = lambda f, l: f == sp["path"] and l is not None and sp["start"] <= l <= sp["end"]
            ok = False
            for x in by[(c["tree"], v)]:
                if x["cwe"] != c["cwe"]:
                    continue
                if inside(x["file"], x["line"]):
                    ok = True
                elif mode == "path":
                    if any(inside(f, l) for f, l in x.get("path") or []):
                        ok = True
                    elif "call" in x and chain_hits(x["call"], QN[(c["case"], v)]):
                        ok = True  # the call chain passes through the vulnerable function
                if ok:
                    break
            hit[v] = ok
        per[c["case"]] = hit
    tp = sum(h["vuln"] for h in per.values()); fp = sum(h["safe"] for h in per.values())
    n = len(per)
    pr = tp / (tp + fp) if tp + fp else 0
    rc = tp / n
    f1 = 2 * pr * rc / (pr + rc) if pr + rc else 0
    pair = sum(h["vuln"] and not h["safe"] for h in per.values()) / n
    return {"recall": rc, "precision": pr, "f1": f1, "pair": pair, "tp": tp, "fp": fp}, per


def main():
    pm = load("test_v170")
    tools = {"PyMetricor": pm, "CodeQL": codeql_rows(), "Semgrep": load("test_semgrep", REV if (REV / "test_semgrep.jsonl").exists() else OUT), "Bandit": load("test_bandit")}
    if (REV / "test_pyflow.jsonl").exists():
        tools["PyFlow"] = load("test_pyflow", REV)
    # check: CodeQL from SARIF reproduces the stored sink-only CodeQL results
    stored = load("test_codeql")
    for floor in (None, "medium"):
        a = grade(stored, floor, "line")[0]["recall"]; b = grade(tools["CodeQL"], floor, "line")[0]["recall"]
        print("codeql check", floor, round(a, 3), round(b, 3))
    out = ["| Tool | Severity | Grading | Recall | Precision | F1 | Pair acc. | Safe twins flagged |", "|---|---|---|---|---|---|---|---|"]
    per = {}
    for t, f in tools.items():
        for floor in (None, "medium"):
            for mode in ("line", "path"):
                s, p = grade(f, floor, mode)
                per[(t, floor, mode)] = p
                out.append(f"| {t} | {floor or 'any'} | {mode} | {s['recall']:.3f} | {s['precision']:.3f} | {s['f1']:.3f} | {s['pair']:.3f} | {s['fp']} |")
    repo = {c["case"]: c["repo"] for c in cs}
    out += ["", "| Severity (PyMetricor) | Comparison (path credit for all) | Recall difference [95% CI, repo bootstrap] | Only PM / only other | McNemar p |", "|---|---|---|---|---|"]
    tests = []
    for floor in (None, "medium"):
        base = {k: v["vuln"] for k, v in per[("PyMetricor", floor, "path")].items()}
        for o in [x for x in ("CodeQL", "Semgrep", "Bandit", "PyFlow") if x in tools]:
            ofl = floor if o == "Bandit" else None  # comparators at their default reporting (as in the paper)
            oth = {k: v["vuln"] for k, v in per[(o, ofl, "path")].items()}
            b = sum(base[k] and not oth[k] for k in base); c = sum(oth[k] and not base[k] for k in base)
            pv = binomtest(b, b + c, .5).pvalue if b + c else 1.0
            by = defaultdict(list)
            for k in base:
                by[repo[k]].append(base[k] - oth[k])
            reps = list(by); rnd = random.Random(2026); ds = []
            for _ in range(5000):
                s = [x for r in (rnd.choice(reps) for _ in reps) for x in by[r]]
                ds.append(sum(s) / len(s))
            ds.sort()
            d = sum(base[k] - oth[k] for k in base) / len(base)
            tests.append([floor, o, d, ds[125], ds[4874], b, c, pv])
    # Holm over the six tests
    order = sorted(range(len(tests)), key=lambda i: tests[i][7])
    m = len(tests); adj = [0] * m; run = 0
    for rank, i in enumerate(order):
        run = max(run, min(1, (m - rank) * tests[i][7])); adj[i] = run
    for t, a in zip(tests, adj):
        out.append(f"| {t[0] or 'any'} | PM vs {t[1]} | {t[2]:+.3f} [{t[3]:+.3f}, {t[4]:+.3f}] | {t[5]} / {t[6]} | {t[7]:.3g} (Holm {a:.3g}) |")
    # where do the newly credited findings come from
    gained = {t: sorted(k for k in per[(t, None, 'path')] if per[(t, None, 'path')][k]['vuln'] and not per[(t, None, 'line')][k]['vuln']) for t in tools}
    out += ["", "Cases gained by path credit (any severity): " + "; ".join(f"{t} {len(g)}" for t, g in gained.items())]
    out += ["Functions not resolved by name: " + str(sum(1 for c in cs if QN[(c['case'], 'vuln')] is None))]
    if BENCH == "new":
        kinds = json.load(open(_os.environ["PM_EVAL"] + "/data/pyvul_new/case_categories.json"))["cases"]
        order = ["external_flow", "unknown_origin_flow", "no_flow", "other_class"]
        out += ["", "| Tool | Grading | " + " | ".join(f"{k} ({sum(1 for v in kinds.values() if v == k)})" for k in order) + " |", "|---|---|" + "---|" * 4]
        for t in tools:
            for floor in ((None, "medium") if t in ("PyMetricor", "Bandit") else (None,)):
                for mode in ("line", "path"):
                    p = per[(t, floor, mode)]
                    out.append(f"| {t} {floor or 'any'} | {mode} | " + " | ".join(str(sum(1 for c, h in p.items() if h["vuln"] and kinds[c] == k)) for k in order) + " |")
    (REV / "path_credit.md").write_text("\n".join(out) + "\n")
    json.dump({t: g for t, g in gained.items()}, open(REV / "path_credit_gained.json", "w"), indent=1)
    print("\n".join(out))


main()
