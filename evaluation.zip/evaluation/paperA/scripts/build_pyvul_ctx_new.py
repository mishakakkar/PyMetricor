"""
Build PyVul twin cases with repository context for the vulnerability classes added in
PyMetricor 1.7.0: SQL injection (CWE-89), server-side request forgery (CWE-918) and
template injection (CWE-1336). Same procedure as build_pyvul_ctx.py (v14), applied to
these CWEs; case ids are numbered within this set ("pn...").

The original build (pymetricor-seceval/pyvul/build_pyvul.py) keeps only the changed
function, so a flow that passes through a helper defined elsewhere can never be seen.
Here every fixing commit is fetched (depth 2), and for each case we keep

  base/   every .py file of the repository at the parent commit (vulnerable)
  fix/    the post-fix version of each .py file the commit changed (safe)

plus the location of the PyVul function in both versions, so grading can be done at
function level: a twin counts as flagged when a finding of the case's CWE lies inside
that function's lines. Test, doc and example folders are left out unless the commit
changed a file there.

    python build_pyvul_ctx_new.py --pyvul DATA/PyVul --out pvctx_new
"""
import argparse
import ast
import difflib
import json
import re
import subprocess
import sys
import textwrap
from pathlib import Path

GROUP_OLD = {"CWE-77": 78, "CWE-78": 78, "CWE-88": 78, "CWE-94": 95, "CWE-95": 95,
         "CWE-22": 22, "CWE-23": 22, "CWE-36": 22, "CWE-73": 22,
         "CWE-327": 327, "CWE-328": 327, "CWE-916": 327}
GROUP = {"CWE-89": 89, "CWE-918": 918, "CWE-1336": 1336}
SKIP_DIR = re.compile(r"(^|/)(tests?|testing|docs?|examples?|benchmarks?)/")


def clean(src):
    src = textwrap.dedent(src.expandtabs(4)).strip("\n") + "\n"
    ast.parse(src)
    return src


def cases(pyvul):
    """Re-run the original selection so case ids match labels.json."""
    ds = Path(pyvul) / "dataset"
    cwe_map = json.load(open(ds / "commits_cwe_map.json"))
    seen, out = set(), []
    for line in open(ds / "function_level_dataset.out"):
        r = json.loads(line)
        if r.get("programming_language") != "Python" or cwe_map.get(r["commit"]) not in GROUP:
            continue
        try:
            before, after = clean(r["code_before"]), clean(r["code_after"])
        except SyntaxError:
            continue
        if before == after or (before, after) in seen:
            continue
        seen.add((before, after))
        cid = f"pn{len(seen):04d}_{re.sub(r'[^A-Za-z0-9]+', '_', r['function_name'])[:40]}"
        out.append({"case": cid, "commit": r["commit"], "function": r["function_name"],
                    "before": before, "after": after, "cwe": GROUP[cwe_map[r["commit"]]]})
    return out


def git(repo, *args, text=True):
    return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True, text=text).stdout


def norm(s):
    return "\n".join(l.rstrip() for l in s.splitlines() if l.strip())


def locate(src, name, want):
    """Line span of the function called `name` whose source best matches `want`."""
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return None
    lines, short, best = src.splitlines(), name.rsplit(".", 1)[-1], None
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == short:
            seg = textwrap.dedent("\n".join(lines[n.lineno - 1:n.end_lineno]).expandtabs(4))
            ratio = difflib.SequenceMatcher(None, norm(seg), norm(want)).ratio()
            if best is None or ratio > best[0]:
                best = (ratio, n.lineno, n.end_lineno)
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pyvul", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = Path(a.out)
    (out / "git").mkdir(parents=True, exist_ok=True)
    todo = cases(a.pyvul)
    print(len(todo), "cases", flush=True)

    labels, failures, done_commits = [], [], {}
    for c in todo:
        m = re.match(r"https://github.com/([^/]+)/([^/]+)/commit/([0-9a-f]+)", c["commit"])
        owner, name, sha = m.groups()
        repo = out / "git" / f"{owner}__{name}"
        tree = out / "trees" / sha[:12]
        try:
            if sha not in done_commits:
                if not repo.exists():
                    repo.mkdir(parents=True)
                    git(repo, "init", "-q")
                    git(repo, "remote", "add", "origin", f"https://github.com/{owner}/{name}")
                git(repo, "fetch", "-q", "--depth", "2", "origin", sha)
                parent = git(repo, "rev-parse", f"{sha}^").strip()
                changed = [p for p in git(repo, "diff", "--name-only", parent, sha, "--", "*.py").split("\n") if p]
                files = [p for p in git(repo, "ls-tree", "-r", "--name-only", parent).split("\n")
                         if p.endswith(".py") and (not SKIP_DIR.search(p) or p in changed)]
                (tree / "base").mkdir(parents=True, exist_ok=True)
                archive = subprocess.run(["git", "-C", str(repo), "archive", "--format=tar", parent, "--", *files],
                                         check=True, capture_output=True).stdout
                subprocess.run(["tar", "-x", "-C", str(tree / "base")], input=archive, check=True)
                for p in changed:
                    try:
                        data = git(repo, "show", f"{sha}:{p}", text=False)
                    except subprocess.CalledProcessError:
                        continue  # deleted by the fix
                    dst = tree / "fix" / p
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    dst.write_bytes(data)
                done_commits[sha] = {"parent": parent, "changed": changed, "files": len(files)}
            info = done_commits[sha]
            spans = {}
            for variant, side, want in (("vuln", "base", c["before"]), ("safe", "fix", c["after"])):
                hits = []
                for p in info["changed"]:
                    f = tree / side / p
                    if f.exists():
                        loc = locate(f.read_text(encoding="utf-8", errors="replace"), c["function"], want)
                        if loc:
                            hits.append((loc[0], p, loc[1], loc[2]))
                if hits:
                    r, p, lo, hi = max(hits)
                    spans[variant] = {"path": p, "start": lo, "end": hi, "match": round(r, 3)}
            if len(spans) < 2:
                failures.append({"case": c["case"], "reason": "function not found", "spans": spans})
                continue
            labels.append({"case": c["case"], "cwe": c["cwe"], "repo": f"{owner}/{name}", "commit": sha,
                           "parent": info["parent"], "tree": sha[:12], **spans})
            print(c["case"], spans["vuln"]["path"], spans["vuln"]["match"], spans["safe"]["match"], flush=True)
        except subprocess.CalledProcessError as e:
            failures.append({"case": c["case"], "reason": (e.stderr or b"")[-300:].decode() if isinstance(e.stderr, bytes) else str(e.stderr)[-300:]})
            print("FAIL", c["case"], failures[-1]["reason"], file=sys.stderr, flush=True)

    (out / "labels_ctx.json").write_text(json.dumps(labels, indent=1))
    (out / "build_failures.json").write_text(json.dumps(failures, indent=1))
    (out / "commits.json").write_text(json.dumps(done_commits, indent=1))
    print(len(labels), "cases with context,", len(failures), "failed,", len(done_commits), "commits")


if __name__ == "__main__":
    main()
