"""
RQ5 corpus: the latest release of the top-N PyPI packages, Python sources only.

The ranking is hugovk/top-pypi-packages (30-day downloads). For each package the
latest release's sdist is preferred, then a pure-Python wheel, then any wheel
(compiled wheels still ship their .py files). Archives over --max-mb are skipped.
Only *.py members are extracted, to <out>/pkgs/<name>/. Archives are never
executed or installed. A manifest records what was taken and why anything was
skipped.

    python -I fetch.py --top top.json --n 1000 --out corpus [--max-mb 60]
"""
import argparse
import io
import json
import tarfile
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path, PurePosixPath


def pick(files):
    sd = [f for f in files if f["packagetype"] == "sdist" and f["filename"].endswith((".tar.gz", ".zip", ".tgz"))]
    pure = [f for f in files if f["filename"].endswith("-none-any.whl")]
    whl = [f for f in files if f["filename"].endswith(".whl")]
    whl.sort(key=lambda f: ("manylinux" not in f["filename"] or "x86_64" not in f["filename"], f["size"]))
    for group in (sd, pure, whl):
        if group:
            return group[0]
    return None


def safe(name):
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts


def extract(blob, filename, dest):
    n = 0
    if filename.endswith(".whl") or filename.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            for i in z.infolist():
                if i.filename.endswith(".py") and not i.is_dir() and safe(i.filename):
                    t = dest / i.filename
                    t.parent.mkdir(parents=True, exist_ok=True)
                    t.write_bytes(z.read(i))
                    n += 1
    else:
        with tarfile.open(fileobj=io.BytesIO(blob)) as tf:
            for m in tf.getmembers():
                if m.isfile() and m.name.endswith(".py") and safe(m.name):
                    t = dest / m.name
                    t.parent.mkdir(parents=True, exist_ok=True)
                    t.write_bytes(tf.extractfile(m).read())
                    n += 1
    return n


def get(url, timeout=120):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return r.read()


def one(name, out, max_bytes):
    rec = {"name": name}
    try:
        meta = json.loads(get(f"https://pypi.org/pypi/{name}/json", 60))
        rec["version"] = meta["info"]["version"]
        f = pick(meta.get("urls") or [])
        if not f:
            return {**rec, "status": "no_files"}
        rec.update(file=f["filename"], kind=f["packagetype"], bytes=f["size"])
        if f["size"] > max_bytes:
            return {**rec, "status": "too_large"}
        dest = out / "pkgs" / name
        if dest.exists() and any(dest.rglob("*.py")):
            return {**rec, "status": "ok", "py_files": sum(1 for _ in dest.rglob("*.py"))}
        n = extract(get(f["url"]), f["filename"], dest)
        return {**rec, "status": "ok" if n else "no_py", "py_files": n}
    except Exception as e:  # noqa: BLE001 - recorded in the manifest
        return {**rec, "status": "error", "error": f"{type(e).__name__}: {e}"[:300]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", required=True)
    ap.add_argument("--n", type=int, default=1000)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-mb", type=float, default=60)
    ap.add_argument("--workers", type=int, default=12)
    a = ap.parse_args()
    out = Path(a.out)
    (out / "pkgs").mkdir(parents=True, exist_ok=True)
    top = json.loads(Path(a.top).read_text())
    names = [r["project"] for r in top["rows"][: a.n]]
    with ThreadPoolExecutor(a.workers) as ex:
        recs = list(ex.map(lambda n: one(n, out, a.max_mb * 2**20), names))
    for rank, r in enumerate(recs, 1):
        r["rank"] = rank
    (out / "manifest.json").write_text(json.dumps({"ranking_date": top.get("last_update"), "packages": recs}, indent=1))
    st = {}
    for r in recs:
        st[r["status"]] = st.get(r["status"], 0) + 1
    print(st)


if __name__ == "__main__":
    main()
