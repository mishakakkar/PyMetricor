"""Download the exact releases of the 200-package benign control (data/benign/sample200.json) from PyPI.
Only *.py members are extracted, to <out>/pkgs/<name>/; nothing is installed or executed.
Writes <out>/manifest.json in the format benign_run.py expects.

    python -I benign_fetch_pinned.py --sample $PM_EVAL/data/benign/sample200.json --out $PM_WORK/rq5/corpus
"""
import argparse
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from benign_fetch import extract, get  # noqa: E402


def one(rec, out):
    name, ver, fn = rec["name"], rec["version"], rec["file"]
    dest = out / "pkgs" / name
    try:
        if not (dest.exists() and any(dest.rglob("*.py"))):
            meta = json.loads(get(f"https://pypi.org/pypi/{name}/{ver}/json", 60))
            f = [u for u in meta["urls"] if u["filename"] == fn]
            if not f:
                return {**rec, "status": "file_not_found"}
            extract(get(f[0]["url"]), fn, dest)
        n = sum(1 for _ in dest.rglob("*.py"))
        return {**rec, "status": "ok" if n else "no_py", "py_files": n}
    except Exception as e:  # noqa: BLE001
        return {**rec, "status": "error", "error": f"{type(e).__name__}: {e}"[:300]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = Path(a.out); (out / "pkgs").mkdir(parents=True, exist_ok=True)
    recs = json.load(open(a.sample))
    with ThreadPoolExecutor(8) as ex:
        res = list(ex.map(lambda r: one(r, out), recs))
    (out / "manifest.json").write_text(json.dumps({"packages": res}, indent=1))
    bad = [r for r in res if r["status"] != "ok"]
    print(f"{len(res) - len(bad)} ok, {len(bad)} failed", *[f"{r['name']}: {r['status']}" for r in bad], sep="\n")


main()
