"""PyFlow (IFDS engine, github.com/ZJU-PL/pyflow) on the held-out PyVul cases with repository context.

Invoked as in PyFlow's own PySASTBench real-world harness (evaluation/pysastbench/bench_realworld.py):
`pyflow security <repo> --engine ifds --recursive --framework --entry <target file>`, plus
`--ifds-trace-mode findings --json-schema unified` so the code flow of each finding is kept for path credit.
Per-run timeout 600 s (PyFlow's harness uses 60 s); a timeout counts as no finding.

    python pyflow_pyvul.py old|new
"""
import os as _os  # paths come from env.sh (PM_EVAL, PM_WORK, PM_RESULTS, PM_PY, PM_DIR, PYFLOW)
import json
import re
import subprocess
import sys
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

BENCH = sys.argv[1]
sys.argv = [sys.argv[0]] + (["--bench", "new"] if BENCH == "new" else [])
sys.path.insert(0, _os.environ["PM_EVAL"] + "/scripts")
from eval_pyvul_ctx import CTX, OUT, cases, safe_tree  # noqa: E402

S = Path(_os.environ["PM_WORK"])
PF = Path(_os.environ["PYFLOW"])
REV = Path(_os.environ["PM_RESULTS"] + "/rev") / OUT.name
REV.mkdir(parents=True, exist_ok=True)


def cwe(v):
    m = re.search(r"(\d+)", str(v or ""))
    if not m:
        return None
    n = int(m.group(1))
    return {77: 78, 88: 78, 94: 95, 23: 22, 36: 22, 328: 327, 564: 89}.get(n, n)


def run(tree, variant, path):
    root = CTX / "trees" / tree / ("base" if variant == "vuln" else "safe")
    cmd = [str(PF), "security", str(root), "--engine", "ifds", "--recursive", "--format", "json",
           "--exit-code-policy", "report", "--framework", "--entry", path,
           "--ifds-trace-mode", "findings", "--json-schema", "unified"]
    t0 = time.time()
    err = ""
    rows = []
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=600, cwd=str(S))
        d = json.loads(p.stdout)
        for f in d.get("findings", []):
            loc = f.get("location", {})
            pr = f.get("properties", {})
            pl = []
            for st in pr.get("code_flow", []) or []:
                l = st.get("location") or {}
                if l.get("uri"):
                    pl.append([str(Path(l["uri"]).resolve().relative_to(root.resolve())) if l["uri"].startswith(str(root)) else l["uri"], l.get("start_line")])
            fn = loc.get("filename", "")
            rel = str(Path(fn).resolve().relative_to(root.resolve())) if fn.startswith(str(root)) else fn
            rows.append({"file": rel, "line": loc.get("line"), "rule": f.get("rule_id"), "severity": f.get("severity", ""),
                         "cwe": cwe(f.get("cwe")), "path": pl, "tree": tree, "variant": variant})
        if d.get("status") not in (None, "complete", "ok"):
            err = f"status {d.get('status')}"
    except subprocess.TimeoutExpired:
        err = "timeout"
    except Exception as e:  # noqa: BLE001
        err = f"{type(e).__name__}: {str(e)[:200]}"
    return rows, {"tree": tree, "variant": variant, "path": path, "seconds": round(time.time() - t0, 1), "error": err}


def main():
    jobs = set()
    for c in cases("test"):
        safe_tree(c["tree"])
        jobs.add((c["tree"], "vuln", c["vuln"]["path"]))
        jobs.add((c["tree"], "safe", c["safe"]["path"]))
    rows, meta = [], []
    with ThreadPoolExecutor(3) as ex:
        for r, m in ex.map(lambda j: run(*j), sorted(jobs)):
            rows += r
            meta.append(m)
            print(m, flush=True)
    with open(REV / "test_pyflow.jsonl", "w") as fh:
        for x in rows:
            fh.write(json.dumps(x) + "\n")
    json.dump(meta, open(REV / "test_pyflow.runs.json", "w"), indent=1)


main()
