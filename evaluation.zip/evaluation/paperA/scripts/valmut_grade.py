"""Grade the validator-mutation set (Section 5 of Paper A): which tools flag each of the 15 files.
real and neutral helpers really validate (safe); gutted helpers do nothing (vulnerable).

    python valmut_grade.py $PM_WORK/valmut
Expects in that folder: pm.jsonl (findings.py), bandit.json, sg.json (Semgrep --json), cq.sarif (CodeQL,
python-security-extended, local threat model); writes $PM_RESULTS/rev/validator_mutation.md.
"""
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

d = Path(sys.argv[1])
SEV = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
hits = defaultdict(lambda: defaultdict(set))
for l in open(d / "pm.jsonl"):
    x = json.loads(l)
    if "error" in x:
        continue
    f = Path(x["file"]).stem
    hits[f]["PyMetricor any"].add(x["rule"])
    if SEV.get(x["severity"], 1) >= 2:
        hits[f]["PyMetricor >=med"].add(x["rule"])
for r in json.load(open(d / "sg.json"))["results"]:
    if r["extra"].get("metadata", {}).get("category") == "security":  # leave out best-practice rules
        hits[Path(r["path"]).stem]["Semgrep"].add(r["check_id"].split(".")[-1])
for r in json.load(open(d / "bandit.json"))["results"]:
    if SEV[r["issue_severity"].lower()] >= 2:
        hits[Path(r["filename"]).stem]["Bandit >=med"].add(r["test_id"])
for run in json.load(open(d / "cq.sarif"))["runs"]:
    for r in run["results"]:
        hits[Path(r["locations"][0]["physicalLocation"]["artifactLocation"]["uri"]).stem]["CodeQL"].add(r["ruleId"])
cols = ["PyMetricor any", "PyMetricor >=med", "CodeQL", "Semgrep", "Bandit >=med"]
files = [f"{c}_{v}" for c in ("path", "cmd", "code", "sql", "ssrf") for v in ("real", "gutted", "neutral")]
out = ["| File | " + " | ".join(cols) + " |", "|---|" + "---|" * len(cols)]
for f in files:
    out.append(f"| {f} | " + " | ".join(", ".join(sorted(hits[f][c])) or "—" for c in cols) + " |")
o = Path(os.environ["PM_RESULTS"]) / "rev"; o.mkdir(parents=True, exist_ok=True)
(o / "validator_mutation.md").write_text("\n".join(out) + "\n")
print("\n".join(out))
