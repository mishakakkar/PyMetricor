"""
Run PyMetricor's security engine on files and print normalised findings as JSON lines.

Usage (with the PyMetricor venv interpreter):
  python pymetricor_findings.py --pymetricor-dir DIR [--max-depth N] FILE_OR_DIR...

--max-depth sets string_analyzer.MAX_DEPTH (0 disables recursive analysis of
code inside exec/eval strings; the shipped value is 5). Used for the RQ2 ablation.

--project ROOT (1.4.0 and later) indexes every .py file under ROOT so that calls
into other project files are followed; one summary engine is shared by all files.
--no-summaries turns function summaries off (the 1.3.0 behaviour), for ablations.
--project-each DIR treats every subdirectory of DIR as its own project (one index and
summary engine each), in one process; used for the 10,229 malware packages (RQ2).
"""
import argparse
import json
import os
import sys
from pathlib import Path

CAP_TO_CWE = {"SPAWN_PROCESS": 78, "INVOKE_DYNAMIC": 95, "MODIFY_FILESYSTEM": 22,
              "PERFORM_CRYPTO": 327, "PERFORM_REFLECTION": 470,
              "DESERIALIZE": 502, "EXTRACT_ARCHIVE": 22,  # these two from 1.5.0
              "EXECUTE_QUERY": 89, "SEND_REQUEST": 918, "RENDER_TEMPLATE": 1336}  # from 1.7.0


def iter_files(paths):
    for p in map(Path, paths):
        if p.is_dir():
            yield from sorted(p.rglob("*.py"))
        else:
            yield p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pymetricor-dir", required=True)
    ap.add_argument("--max-depth", type=int, default=None)
    ap.add_argument("--project", default=None)
    ap.add_argument("--no-summaries", action="store_true")
    ap.add_argument("--project-each", default=None)
    ap.add_argument("paths", nargs="*")
    a = ap.parse_args()

    pm = Path(a.pymetricor_dir).resolve()
    if a.project_each:
        groups = [(d, [str(f.resolve()) for f in iter_files([d])]) for d in sorted(Path(a.project_each).iterdir()) if d.is_dir()]
    else:
        groups = [(Path(a.project).resolve() if a.project else None, [str(Path(f).resolve()) for f in iter_files(a.paths)])]
    os.chdir(pm)  # the original 91e6867 reads pymetricor.yml from cwd
    sys.path.insert(0, str(pm))

    from astroid import builder  # noqa: E402
    from core.reasoning import string_analyzer  # noqa: E402
    from core.reasoning.loader import LoadSchema  # noqa: E402
    from core.reasoning.interpreter import Interpreter  # noqa: E402
    from core.reasoning.queries import EvaluateAll  # noqa: E402

    if a.max_depth is not None:
        string_analyzer.MAX_DEPTH = a.max_depth
    schema = LoadSchema(pm / "schema.yml")
    if a.project or a.no_summaries or a.project_each:
        from core.reasoning import summaries  # noqa: E402
        from core.reasoning.project import ProjectIndex  # noqa: E402
        if a.no_summaries:
            summaries.MAX_CALL_DEPTH = 0

    for root, files in groups:
        engine = None
        if a.project or a.no_summaries or a.project_each:
            index = ProjectIndex.FromPaths([str(root)]) if root is not None else None
            engine = summaries.SummaryEngine(schema, index)
        analyse(files, schema, engine, Interpreter, EvaluateAll, builder)


def analyse(files, schema, engine, Interpreter, EvaluateAll, builder):
    for f in files:
        try:
            src = Path(f).read_text(encoding="utf-8", errors="replace")
            module = builder.parse(src, path=f)
            findings = EvaluateAll((Interpreter(schema, engine) if engine else Interpreter(schema)).Analyze(module), schema)
        except Exception as e:  # report, never crash the batch
            print(json.dumps({"file": f, "error": f"{type(e).__name__}: {e}"}))
            continue
        for x in findings:
            print(json.dumps({"file": f, "line": x.line, "rule": x.query_name, "severity": x.severity,
                              "cwe": CAP_TO_CWE.get(x.capability), "call": x.call_name}))


if __name__ == "__main__":
    main()
