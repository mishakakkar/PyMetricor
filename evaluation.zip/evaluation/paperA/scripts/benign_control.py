"""Benign control for the malware study (editor review, Paper A).

The 200-package random sample of the top-1000 PyPI packages (seed 2026; the sample Bandit already ran on
in the scale study) analysed by PyMetricor 1.7.0 with each package as its own project. Reports, for both
tools, the share of packages and of files with a finding at each severity, and warnings per KLOC, next to
the same figures on the 10,229 malicious packages.

    python benign_control.py
"""
import os as _os  # paths come from env.sh (PM_EVAL, PM_WORK, PM_RESULTS, PM_PY, PM_DIR, PYFLOW)
import json
import os
from collections import defaultdict
from pathlib import Path

S = Path(_os.environ["PM_WORK"])
B = S / "benign"
RQ5 = S / "rq5"
MAL = S / "seceval/malware_v17/combined"
MALM = S / "seceval/malware_full/manifest.json"
OUT = Path(_os.environ["PM_RESULTS"] + "/rev/benign_control.md")
SEV = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}

names = sorted(f[:-5] for f in os.listdir(RQ5 / "runs/bandit") if f.endswith(".json") and not f.endswith(".run.json"))
sizes = json.load(open(RQ5 / "runs/sizes.json"))
sloc = sum(sizes[n]["sloc"] for n in names)
nfiles = sum(sizes[n]["files"] for n in names)


def pkg_of(path):
    p = Path(path).parts
    i = p.index("chunks")
    return p[i + 2]


def summarise(rows, npk, nfi, kloc):
    pk = defaultdict(int)
    fi = defaultdict(int)
    for (p, f), s in rows.items():
        pk[p] = max(pk[p], s)
    for key, s in rows.items():
        fi[key] = s
    def share(d, n, t):
        return sum(1 for v in d.values() if v >= t) / n
    return {"any_pkg": share(pk, npk, 1), "med_pkg": share(pk, npk, 2), "high_pkg": share(pk, npk, 3),
            "any_file": share(fi, nfi, 1), "high_file": share(fi, nfi, 3)}


# PyMetricor, benign
pm = {}
pm_warn = 0
for f in sorted((B / "raw").glob("*.jsonl")):
    for line in open(f):
        d = json.loads(line)
        if "error" in d:
            continue
        pm_warn += 1
        key = (pkg_of(d["file"]), d["file"])
        pm[key] = max(pm.get(key, 0), SEV.get(d["severity"], 1))
# Bandit, benign
bd = {}
bd_warn = 0
for n in names:
    d = json.load(open(RQ5 / "runs/bandit" / f"{n}.json"))
    for r in d.get("results", []):
        bd_warn += 1
        key = (n, r["filename"])
        bd[key] = max(bd.get(key, 0), SEV.get(r["issue_severity"].lower(), 1))
b_pm = summarise(pm, len(names), nfiles, sloc / 1000)
b_bd = summarise(bd, len(names), nfiles, sloc / 1000)

# malware: same measures from the RQ3 run
man = json.load(open(MALM))
npk_m = 10229
nfi_m = 38853
def mal(name):
    rows = {}
    w = 0
    for line in open(MAL / name):
        d = json.loads(line)
        w += 1
        p = Path(d["file"]).parts[0]
        key = (p, d["file"])
        rows[key] = max(rows.get(key, 0), SEV.get(str(d["severity"]).lower(), 1))
    return rows, w
m_pm_rows, m_pm_w = mal("pymetricor_101.jsonl")
m_bd_rows, m_bd_w = mal("bandit.jsonl")
m_pm = summarise(m_pm_rows, npk_m, nfi_m, None)
m_bd = summarise(m_bd_rows, npk_m, nfi_m, None)

def pc(x):
    return f"{100 * x:.1f}%"
out = [f"Benign sample: {len(names)} packages, {nfiles:,} files, {sloc:,} SLOC. Malicious: {npk_m:,} packages, {nfi_m:,} files.", "",
       "| Measure | PyMetricor, malicious | PyMetricor, benign | Bandit, malicious | Bandit, benign |", "|---|---|---|---|---|"]
for k, lab in [("any_pkg", "Packages with any finding"), ("med_pkg", "Packages with a finding ≥ medium"), ("high_pkg", "Packages with a high/critical finding"),
               ("any_file", "Files with any finding"), ("high_file", "Files with a high/critical finding")]:
    out.append(f"| {lab} | {pc(m_pm[k])} | {pc(b_pm[k])} | {pc(m_bd[k])} | {pc(b_bd[k])} |")
out.append(f"| Warnings | {m_pm_w:,} | {pm_warn:,} ({pm_warn / (sloc / 1000):.2f} per KLOC) | {m_bd_w:,} | {bd_warn:,} ({bd_warn / (sloc / 1000):.2f} per KLOC) |")
# discrimination at file level: high/critical file rate ratio
out.append("")
out.append(f"File-level high/critical rate ratio (malicious / benign): PyMetricor {m_pm['high_file'] / b_pm['high_file']:.1f}x, Bandit {m_bd['high_file'] / b_bd['high_file']:.1f}x")
OUT.write_text("\n".join(out) + "\n")
print("\n".join(out))
