"""
Run PyMetricor on PyVul with repository context and grade at function level.

    python eval_pyvul_ctx.py run   --pm DIR --name NAME [--split dev|test|all] [--flags "..."]
    python eval_pyvul_ctx.py score --names A,B,... [--split dev|test|all] [--floor medium]

`run` analyses, for every case in the split, the file holding the PyVul function in
the vulnerable tree (parent commit) and in the safe tree (parent + the fix's files),
with --project set to that tree so calls into the rest of the repository can be
followed. Findings go to results/<NAME>.jsonl.

`score` counts a twin as flagged when a finding of the case's CWE lies inside the
function's line span (function-level grading, as in PySASTBench), and also reports
file-level grading for comparison with the single-function benchmark.
"""
import os as _os  # paths come from env.sh (PM_EVAL, PM_WORK, PM_RESULTS, PM_PY, PM_DIR, PYFLOW)
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

S = Path(_os.environ["PM_WORK"])
# --bench old: the 1.4.0 benchmark (CWE-78/95/22/327); --bench new: CWE-89/918/1336 (1.7.0)
BENCH = "new" if "--bench=new" in sys.argv or ("--bench" in sys.argv and sys.argv[sys.argv.index("--bench") + 1] == "new") else "old"
CTX = S / ("pvctx_new" if BENCH == "new" else "pvctx")
CWES = (89, 918, 1336) if BENCH == "new" else (78, 95, 22, 327)
PY = Path(_os.environ["PM_PY"])
FINDINGS = Path(_os.environ["PM_EVAL"] + "/scripts/findings.py")
OUT = Path(_os.environ["PM_RESULTS"] + "/rev") / ("pyvul_new" if BENCH == "new" else "pyvul_ctx")
OLD = Path(_os.environ["PM_EVAL"] + "/data/pyvul_ctx")   # earlier versions' runs and the old split
OUT.mkdir(parents=True, exist_ok=True)
SPLIT = json.load(open(Path(_os.environ["PM_EVAL"]) / "data" / ("pyvul_new" if BENCH == "new" else "pyvul_ctx") / "split.json"))
LABELS = json.load(open(CTX / "labels_ctx_ok.json"))
SEV = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4, "warning": 2, "error": 3, "note": 0}


def cases(split):
    keep = set(SPLIT["dev_cases"] if split == "dev" else SPLIT["test_cases"] if split == "test"
               else SPLIT["dev_cases"] + SPLIT["test_cases"])
    return [l for l in LABELS if l["case"] in keep]


def safe_tree(tree):
    base, safe = CTX / "trees" / tree / "base", CTX / "trees" / tree / "safe"
    if not safe.exists():
        tmp = safe.with_name("safe.tmp")
        shutil.rmtree(tmp, ignore_errors=True)
        shutil.copytree(base, tmp, copy_function=os.link)
        fix = CTX / "trees" / tree / "fix"
        changed = json.load(open(CTX / "commits.json"))
        for f in fix.rglob("*.py"):
            dst = tmp / f.relative_to(fix)
            dst.parent.mkdir(parents=True, exist_ok=True)
            if dst.exists():
                dst.unlink()
            shutil.copyfile(f, dst)
        # files the fix deleted
        sha = next(k for k in changed if k.startswith(tree))
        for p in changed[sha]["changed"]:
            if not (fix / p).exists() and (tmp / p).exists():
                (tmp / p).unlink()
        tmp.rename(safe)
    return safe


def run_one(pm, flags, tree, variant, paths, timeout):
    root = CTX / "trees" / tree / ("base" if variant == "vuln" else "safe")
    files = [str(root / p) for p in sorted(paths) if (root / p).exists()]
    cmd = [str(PY), str(FINDINGS), "--pymetricor-dir", pm, *flags, "--project", str(root), *files]
    if "--single" in flags:  # no project context: the 1.3.0 way of running on these files
        cmd = [str(PY), str(FINDINGS), "--pymetricor-dir", pm, *[f for f in flags if f != "--single"], *files]
    t0 = time.time()
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        lines, err = p.stdout.splitlines(), p.stderr[-500:] if p.returncode else ""
    except subprocess.TimeoutExpired:
        lines, err = [], "timeout"
    out = []
    for l in lines:
        x = json.loads(l)
        x["file"] = str(Path(x["file"]).relative_to(root))
        x.update(tree=tree, variant=variant)
        out.append(x)
    return out, {"tree": tree, "variant": variant, "seconds": round(time.time() - t0, 1), "error": err}


def cmd_run(a):
    flags = a.flags.split() if a.flags else []
    jobs = defaultdict(set)
    for c in cases(a.split):
        jobs[(c["tree"], "vuln")].add(c["vuln"]["path"])
        jobs[(c["tree"], "safe")].add(c["safe"]["path"])
        safe_tree(c["tree"])
    results, meta = [], []
    with ThreadPoolExecutor(a.workers) as ex:
        futs = [ex.submit(run_one, a.pm, flags, t, v, ps, a.timeout) for (t, v), ps in sorted(jobs.items())]
        for f in futs:
            r, m = f.result()
            results += r
            meta.append(m)
            print(m, flush=True)
    with open(OUT / f"{a.name}.jsonl", "w") as fh:
        for x in results:
            fh.write(json.dumps(x) + "\n")
    json.dump(meta, open(OUT / f"{a.name}.runs.json", "w"), indent=1)


def grade(cs, findings, floor, level):
    by = defaultdict(list)
    for x in findings:
        if "error" in x or x.get("cwe") is None:
            continue
        if floor and SEV.get(str(x.get("severity", "")).lower(), 1) < SEV[floor]:
            continue
        by[(x["tree"], x["variant"], x["file"])].append(x)
    tp = fp = fn = tn = ok = 0
    per = {}
    for c in cs:
        hit = {}
        for v in ("vuln", "safe"):
            span = c[v]
            hit[v] = any(x["cwe"] == c["cwe"] and (level == "file" or span["start"] <= x["line"] <= span["end"])
                         for x in by[(c["tree"], v, span["path"])])
        tp += hit["vuln"]; fn += not hit["vuln"]; fp += hit["safe"]; tn += not hit["safe"]
        ok += hit["vuln"] and not hit["safe"]
        per[c["case"]] = hit
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * p * r / (p + r) if p + r else 0.0
    return {"n": len(cs), "precision": round(p, 3), "recall": round(r, 3), "f1": round(f1, 3),
            "pair_accuracy": round(ok / len(cs), 3) if cs else None, "tp": tp, "fp": fp, "fn": fn, "tn": tn}, per


def cmd_score(a):
    cs = cases(a.split)
    rows = {}
    for name in a.names.split(","):
        src = OUT / f"{name}.jsonl"
        f = [json.loads(l) for l in open(src if src.exists() else OLD / f"{name}.jsonl")]
        for level in ("function", "file"):
            for floor in (None, "medium"):
                g, _ = grade(cs, f, floor, level)
                rows[(name, level, floor or "any")] = g
                byc = {}
                for cwe in CWES:
                    sub = [c for c in cs if c["cwe"] == cwe]
                    if sub:
                        byc[cwe] = grade(sub, f, floor, level)[0]
                g["by_cwe"] = {k: (v["recall"], v["pair_accuracy"]) for k, v in byc.items()}
    for (name, level, floor), g in rows.items():
        print(f"{name:28s} {level:8s} {floor:6s} P {g['precision']:.2f} R {g['recall']:.2f} F1 {g['f1']:.2f} "
              f"pair {g['pair_accuracy']:.2f}  {g['tp']}/{g['fp']}/{g['fn']}/{g['tn']}  {g['by_cwe']}")
    if a.out:
        json.dump({"|".join(k): v for k, v in rows.items()}, open(a.out, "w"), indent=1)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--pm", required=True)
    r.add_argument("--name", required=True)
    r.add_argument("--split", default="dev")
    r.add_argument("--flags", default="")
    r.add_argument("--workers", type=int, default=6)
    r.add_argument("--timeout", type=int, default=900)
    r.add_argument("--bench", default="old")
    s = sub.add_parser("score")
    s.add_argument("--names", required=True)
    s.add_argument("--split", default="dev")
    s.add_argument("--out", default=None)
    s.add_argument("--bench", default="old")
    a = ap.parse_args()
    {"run": cmd_run, "score": cmd_score}[a.cmd](a)


if __name__ == "__main__":
    main()
