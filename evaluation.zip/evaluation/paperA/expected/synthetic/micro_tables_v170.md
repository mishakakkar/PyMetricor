### All pairs (81 pairs)

| Tool | P | R | F1 | Pair acc. | warnings |
|---|---|---|---|---|---|
| PyMetricor 1.7.0 (any) | 0.69 | 0.97 | 0.81 | 0.54 | 173 |
| PyMetricor 1.7.0 (>=medium) | 0.81 | 0.95 | 0.88 | 0.73 | 129 |
| Bandit (>=medium) | 0.67 | 0.72 | 0.69 | 0.37 | 93 |
| Semgrep | 0.71 | 0.74 | 0.73 | 0.44 | 182 |
| CodeQL (remote sources) | 0.77 | 0.21 | 0.33 | 0.15 | 36 |
| CodeQL (local+remote) | 0.81 | 0.75 | 0.78 | 0.58 | 96 |

### New classes: CWE-89/918/1336 (19 pairs)

| Tool | P | R | F1 | Pair acc. | warnings |
|---|---|---|---|---|---|
| PyMetricor 1.7.0 (any) | 0.76 | 1.00 | 0.86 | 0.68 | 33 |
| PyMetricor 1.7.0 (>=medium) | 0.86 | 1.00 | 0.93 | 0.84 | 23 |
| Bandit (>=medium) | 0.73 | 0.42 | 0.53 | 0.26 | 18 |
| Semgrep | 0.65 | 0.58 | 0.61 | 0.26 | 66 |
| CodeQL (remote sources) | 0.89 | 0.42 | 0.57 | 0.37 | 23 |
| CodeQL (local+remote) | 0.91 | 0.53 | 0.67 | 0.47 | 25 |
