### All pairs (60 pairs)

| Tool | P | R | F1 | Pair acc. | warnings |
|---|---|---|---|---|---|
| PyMetricor 1.7.0 (any) | 0.72 | 0.95 | 0.82 | 0.58 | 339 |
| PyMetricor 1.7.0 (>=medium) | 0.82 | 0.90 | 0.86 | 0.70 | 176 |
| Bandit (>=medium) | 1.00 | 0.67 | 0.80 | 0.67 | 134 |
| Semgrep | 0.77 | 0.67 | 0.71 | 0.47 | 326 |
| CodeQL (remote sources) | 0.78 | 0.58 | 0.67 | 0.42 | 251 |
| CodeQL (local+remote) | 0.72 | 0.92 | 0.81 | 0.57 | 376 |
