| Measure | Severity | Comparison | Difference [95% CI, repo bootstrap] | Only 1.7.0 / only other | McNemar p |
|---|---|---|---|---|---|
| recall | any | 1.7.0 vs codeql | +0.247 [+0.125, +0.379] | 20 / 0 | 1.91e-06 |
| recall | any | 1.7.0 vs semgrep | +0.272 [+0.120, +0.414] | 25 / 3 | 2.74e-05 |
| recall | any | 1.7.0 vs bandit | +0.284 [+0.114, +0.440] | 27 / 4 | 3.4e-05 |
| recall | medium | 1.7.0 vs codeql | +0.160 [+0.035, +0.294] | 15 / 2 | 0.00235 |
| recall | medium | 1.7.0 vs semgrep | +0.185 [+0.043, +0.324] | 18 / 3 | 0.00149 |
| recall | medium | 1.7.0 vs bandit | +0.210 [+0.052, +0.360] | 20 / 3 | 0.000488 |
| pair | any | 1.7.0 vs codeql | +0.086 [+0.024, +0.169] | 7 / 0 | 0.0156 |
| pair | any | 1.7.0 vs semgrep | +0.123 [+0.030, +0.236] | 11 / 1 | 0.00635 |
| pair | any | 1.7.0 vs bandit | +0.123 [+0.000, +0.257] | 13 / 3 | 0.0213 |
| pair | medium | 1.7.0 vs codeql | +0.062 [+0.000, +0.143] | 6 / 1 | 0.125 |
| pair | medium | 1.7.0 vs semgrep | +0.099 [+0.023, +0.203] | 8 / 0 | 0.00781 |
| pair | medium | 1.7.0 vs bandit | +0.062 [-0.062, +0.186] | 9 / 4 | 0.267 |
