| Tool | Severity | Grading | Recall | Precision | F1 | Pair acc. | Safe twins flagged |
|---|---|---|---|---|---|---|---|
| PyMetricor | any | line | 0.420 | 0.607 | 0.496 | 0.173 | 22 |
| PyMetricor | any | path | 0.420 | 0.607 | 0.496 | 0.173 | 22 |
| PyMetricor | medium | line | 0.333 | 0.614 | 0.432 | 0.148 | 17 |
| PyMetricor | medium | path | 0.346 | 0.609 | 0.441 | 0.148 | 18 |
| CodeQL | any | line | 0.173 | 0.667 | 0.275 | 0.086 | 7 |
| CodeQL | any | path | 0.235 | 0.679 | 0.349 | 0.123 | 9 |
| CodeQL | medium | line | 0.173 | 0.667 | 0.275 | 0.086 | 7 |
| CodeQL | medium | path | 0.235 | 0.679 | 0.349 | 0.123 | 9 |
| Semgrep | any | line | 0.148 | 0.600 | 0.238 | 0.049 | 8 |
| Semgrep | any | path | 0.148 | 0.600 | 0.238 | 0.049 | 8 |
| Semgrep | medium | line | 0.148 | 0.600 | 0.238 | 0.049 | 8 |
| Semgrep | medium | path | 0.148 | 0.600 | 0.238 | 0.049 | 8 |
| Bandit | any | line | 0.136 | 0.579 | 0.220 | 0.049 | 8 |
| Bandit | any | path | 0.136 | 0.579 | 0.220 | 0.049 | 8 |
| Bandit | medium | line | 0.123 | 0.714 | 0.211 | 0.086 | 4 |
| Bandit | medium | path | 0.123 | 0.714 | 0.211 | 0.086 | 4 |
| PyFlow | any | line | 0.062 | 0.556 | 0.111 | 0.012 | 4 |
| PyFlow | any | path | 0.074 | 0.545 | 0.130 | 0.012 | 5 |
| PyFlow | medium | line | 0.062 | 0.556 | 0.111 | 0.012 | 4 |
| PyFlow | medium | path | 0.074 | 0.545 | 0.130 | 0.012 | 5 |

| Severity (PyMetricor) | Comparison (path credit for all) | Recall difference [95% CI, repo bootstrap] | Only PM / only other | McNemar p |
|---|---|---|---|---|
| any | PM vs CodeQL | +0.185 [+0.033, +0.337] | 20 / 5 | 0.00408 (Holm 0.00815) |
| any | PM vs Semgrep | +0.272 [+0.120, +0.414] | 25 / 3 | 2.74e-05 (Holm 0.000165) |
| any | PM vs Bandit | +0.284 [+0.114, +0.440] | 27 / 4 | 3.4e-05 (Holm 0.00017) |
| any | PM vs PyFlow | +0.346 [+0.207, +0.487] | 29 / 1 | 5.77e-08 (Holm 4.62e-07) |
| medium | PM vs CodeQL | +0.111 [-0.043, +0.258] | 16 / 7 | 0.0931 (Holm 0.0931) |
| medium | PM vs Semgrep | +0.198 [+0.053, +0.333] | 19 / 3 | 0.000855 (Holm 0.00257) |
| medium | PM vs Bandit | +0.222 [+0.060, +0.370] | 21 / 3 | 0.000277 (Holm 0.00111) |
| medium | PM vs PyFlow | +0.272 [+0.139, +0.408] | 23 / 1 | 2.98e-06 (Holm 2.09e-05) |

Cases gained by path credit (any severity): PyMetricor 0; CodeQL 5; Semgrep 0; Bandit 0; PyFlow 1
Functions not resolved by name: 0
