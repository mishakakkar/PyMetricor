Benign sample: 200 packages, 28,552 files, 7,281,994 SLOC. Malicious: 10,229 packages, 38,853 files.

| Measure | PyMetricor, malicious | PyMetricor, benign | Bandit, malicious | Bandit, benign |
|---|---|---|---|---|
| Packages with any finding | 38.4% | 81.0% | 88.0% | 91.0% |
| Packages with a finding ≥ medium | 16.2% | 56.0% | 32.2% | 54.0% |
| Packages with a high/critical finding | 15.4% | 44.5% | 11.4% | 21.5% |
| Files with any finding | 16.4% | 7.8% | 41.0% | 26.1% |
| Files with a high/critical finding | 5.4% | 2.3% | 4.2% | 0.6% |
| Warnings | 40,329 | 15,202 (2.09 per KLOC) | 172,280 | 189,112 (25.97 per KLOC) |

File-level high/critical rate ratio (malicious / benign): PyMetricor 2.4x, Bandit 7.6x
