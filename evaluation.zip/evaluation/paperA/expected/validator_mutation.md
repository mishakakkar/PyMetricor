| File | PyMetricor any | PyMetricor >=med | CodeQL | Semgrep | Bandit >=med |
|---|---|---|---|---|---|
| path_real | filesystem_dynamic_path | — | py/path-injection, py/reflective-xss | path-traversal-join, path-traversal-open | — |
| path_gutted | filesystem_dynamic_path | — | py/path-injection, py/reflective-xss | path-traversal-join, path-traversal-open | — |
| path_neutral | filesystem_dynamic_path, filesystem_external_input | filesystem_external_input | py/path-injection, py/reflective-xss | path-traversal-join, path-traversal-open | — |
| cmd_real | — | — | py/command-line-injection | dangerous-subprocess-use, dangerous-subprocess-use-audit, subprocess-injection, subprocess-shell-true | B602 |
| cmd_gutted | — | — | py/command-line-injection | dangerous-subprocess-use, dangerous-subprocess-use-audit, subprocess-injection, subprocess-shell-true | B602 |
| cmd_neutral | spawn_dynamic_command, spawn_external_command | spawn_dynamic_command, spawn_external_command | py/command-line-injection | dangerous-subprocess-use, dangerous-subprocess-use-audit, subprocess-injection, subprocess-shell-true | B602 |
| code_real | — | — | py/code-injection | eval-detected, eval-injection, user-eval | B307 |
| code_gutted | — | — | py/code-injection | eval-detected, eval-injection, user-eval | B307 |
| code_neutral | dynamic_execution_external | dynamic_execution_external | py/code-injection | eval-detected, eval-injection, user-eval | B307 |
| sql_real | — | — | py/sql-injection | sql-injection-db-cursor-execute, sqlalchemy-execute-raw-query, tainted-sql-string | B608 |
| sql_gutted | — | — | py/sql-injection | sql-injection-db-cursor-execute, sqlalchemy-execute-raw-query, tainted-sql-string | B608 |
| sql_neutral | sql_external_query | sql_external_query | py/sql-injection | sql-injection-db-cursor-execute, sqlalchemy-execute-raw-query, tainted-sql-string | B608 |
| ssrf_real | — | — | py/full-ssrf, py/reflective-xss | ssrf-injection-requests, ssrf-requests | B113 |
| ssrf_gutted | — | — | py/full-ssrf, py/reflective-xss | ssrf-injection-requests, ssrf-requests | B113 |
| ssrf_neutral | ssrf_external_url | ssrf_external_url | py/full-ssrf, py/reflective-xss | ssrf-injection-requests, ssrf-requests | B113 |
