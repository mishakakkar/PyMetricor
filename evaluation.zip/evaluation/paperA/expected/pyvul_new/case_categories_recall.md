| Tool | external_flow (n=5) | unknown_origin_flow (n=11) | no_flow (n=9) | other_class (n=6) |
|---|---|---|---|---|
| PyMetricor, any | 4/5 | 6/11 | 1/9 | 0/6 |
| PyMetricor, ≥ medium | 4/5 | 0/11 | 0/9 | 0/6 |
| CodeQL | 3/5 | 1/11 | 0/9 | 0/6 |
| Semgrep | 1/5 | 6/11 | 0/9 | 0/6 |
| Bandit | 0/5 | 3/11 | 0/9 | 0/6 |
