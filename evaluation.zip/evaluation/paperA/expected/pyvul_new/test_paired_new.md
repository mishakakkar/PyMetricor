| Measure | Severity | Comparison | Difference [95% CI, repo bootstrap] | Only 1.7.0 / only other | McNemar p |
|---|---|---|---|---|---|
| recall | any | 1.7.0 vs codeql | +0.226 [+0.049, +0.462] | 7 / 0 | 0.0156 |
| recall | any | 1.7.0 vs semgrep | +0.129 [-0.030, +0.333] | 5 / 1 | 0.219 |
| recall | any | 1.7.0 vs bandit | +0.258 [+0.065, +0.481] | 9 / 1 | 0.0215 |
| recall | medium | 1.7.0 vs codeql | +0.000 [-0.100, +0.100] | 1 / 1 | 1 |
| recall | medium | 1.7.0 vs semgrep | -0.097 [-0.370, +0.148] | 3 / 6 | 0.508 |
| recall | medium | 1.7.0 vs bandit | +0.032 [-0.148, +0.214] | 4 / 3 | 1 |
| pair | any | 1.7.0 vs codeql | +0.097 [+0.000, +0.242] | 3 / 0 | 0.25 |
| pair | any | 1.7.0 vs semgrep | +0.065 [+0.000, +0.207] | 2 / 0 | 0.5 |
| pair | any | 1.7.0 vs bandit | +0.065 [-0.080, +0.229] | 3 / 1 | 0.625 |
| pair | medium | 1.7.0 vs codeql | +0.000 [+0.000, +0.000] | 0 / 0 | 1 |
| pair | medium | 1.7.0 vs semgrep | -0.032 [-0.111, +0.000] | 0 / 1 | 1 |
| pair | medium | 1.7.0 vs bandit | -0.032 [-0.160, +0.077] | 1 / 2 | 1 |
