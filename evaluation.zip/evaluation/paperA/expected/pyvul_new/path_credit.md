| Tool | Severity | Grading | Recall | Precision | F1 | Pair acc. | Safe twins flagged |
|---|---|---|---|---|---|---|---|
| PyMetricor | any | line | 0.355 | 0.611 | 0.449 | 0.129 | 7 |
| PyMetricor | any | path | 0.355 | 0.611 | 0.449 | 0.129 | 7 |
| PyMetricor | medium | line | 0.129 | 0.571 | 0.211 | 0.032 | 3 |
| PyMetricor | medium | path | 0.129 | 0.571 | 0.211 | 0.032 | 3 |
| CodeQL | any | line | 0.129 | 0.571 | 0.211 | 0.032 | 3 |
| CodeQL | any | path | 0.194 | 0.545 | 0.286 | 0.032 | 5 |
| CodeQL | medium | line | 0.129 | 0.571 | 0.211 | 0.032 | 3 |
| CodeQL | medium | path | 0.194 | 0.545 | 0.286 | 0.032 | 5 |
| Semgrep | any | line | 0.226 | 0.583 | 0.326 | 0.065 | 5 |
| Semgrep | any | path | 0.226 | 0.583 | 0.326 | 0.065 | 5 |
| Semgrep | medium | line | 0.226 | 0.583 | 0.326 | 0.065 | 5 |
| Semgrep | medium | path | 0.226 | 0.583 | 0.326 | 0.065 | 5 |
| Bandit | any | line | 0.097 | 0.750 | 0.171 | 0.065 | 1 |
| Bandit | any | path | 0.097 | 0.750 | 0.171 | 0.065 | 1 |
| Bandit | medium | line | 0.097 | 0.750 | 0.171 | 0.065 | 1 |
| Bandit | medium | path | 0.097 | 0.750 | 0.171 | 0.065 | 1 |
| PyFlow | any | line | 0.032 | 0.500 | 0.061 | 0.000 | 1 |
| PyFlow | any | path | 0.032 | 0.500 | 0.061 | 0.000 | 1 |
| PyFlow | medium | line | 0.032 | 0.500 | 0.061 | 0.000 | 1 |
| PyFlow | medium | path | 0.032 | 0.500 | 0.061 | 0.000 | 1 |

| Severity (PyMetricor) | Comparison (path credit for all) | Recall difference [95% CI, repo bootstrap] | Only PM / only other | McNemar p |
|---|---|---|---|---|
| any | PM vs CodeQL | +0.161 [-0.034, +0.400] | 6 / 1 | 0.125 (Holm 0.75) |
| any | PM vs Semgrep | +0.129 [-0.030, +0.333] | 5 / 1 | 0.219 (Holm 1) |
| any | PM vs Bandit | +0.258 [+0.065, +0.481] | 9 / 1 | 0.0215 (Holm 0.15) |
| any | PM vs PyFlow | +0.323 [+0.133, +0.565] | 10 / 0 | 0.00195 (Holm 0.0156) |
| medium | PM vs CodeQL | -0.065 [-0.167, +0.000] | 0 / 2 | 0.5 (Holm 1) |
| medium | PM vs Semgrep | -0.097 [-0.370, +0.148] | 3 / 6 | 0.508 (Holm 1) |
| medium | PM vs Bandit | +0.032 [-0.148, +0.214] | 4 / 3 | 1 (Holm 1) |
| medium | PM vs PyFlow | +0.097 [+0.000, +0.222] | 3 / 0 | 0.25 (Holm 1) |

Cases gained by path credit (any severity): PyMetricor 0; CodeQL 2; Semgrep 0; Bandit 0; PyFlow 0
Functions not resolved by name: 0

| Tool | Grading | external_flow (5) | unknown_origin_flow (11) | no_flow (9) | other_class (6) |
|---|---|---|---|---|---|
| PyMetricor any | line | 4 | 6 | 1 | 0 |
| PyMetricor any | path | 4 | 6 | 1 | 0 |
| PyMetricor medium | line | 4 | 0 | 0 | 0 |
| PyMetricor medium | path | 4 | 0 | 0 | 0 |
| CodeQL any | line | 3 | 1 | 0 | 0 |
| CodeQL any | path | 5 | 1 | 0 | 0 |
| Semgrep any | line | 1 | 6 | 0 | 0 |
| Semgrep any | path | 1 | 6 | 0 | 0 |
| Bandit any | line | 0 | 3 | 0 | 0 |
| Bandit any | path | 0 | 3 | 0 | 0 |
| Bandit medium | line | 0 | 3 | 0 | 0 |
| Bandit medium | path | 0 | 3 | 0 | 0 |
| PyFlow any | line | 1 | 0 | 0 | 0 |
| PyFlow any | path | 1 | 0 | 0 | 0 |
