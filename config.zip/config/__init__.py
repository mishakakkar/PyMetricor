# config/__init__.py

from .config import Config, ConfigNamespace

__all__ = ["Config", "ConfigNamespace"]