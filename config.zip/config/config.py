from utils.logger import logger
import copy
import os
import yaml
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeVar, Union

T = TypeVar("T", bound="Config")

# Tool root (where main.py, pymetricor.yml and schema.yml live).
# Config is resolved relative to this, never the current working directory,
# so results do not depend on where the tool is launched from.
TOOL_ROOT: Path           = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH: Path = TOOL_ROOT / "pymetricor.yml"
CONFIG_ENV_VAR: str       = "PYMETRICOR_CONFIG"

# -----------------------------------------
# Built-in defaults
# NOTE: Must stay identical to the shipped 'pymetricor.yml' (enforced by test/test_config.py).
#       Used when no config file is found so the tool still runs with the documented values.
# -----------------------------------------
_DEFAULT_CONFIG: Dict[str, Any] = {
    "weights": {
        "sections": {"readability": 0.30, "efficiency": 0.25, "maintainability": 0.25, "security": 0.20},
        "file_composite": {"loc": 0.2, "tokens": 0.4, "ast_nodes": 0.4},
        "readability": {
            "line_length_distribution": 0.036, "indentation_stability": 0.036,
            "identifier_style": 0.03, "comment_density": 0.045, "nesting_depth": 0.03,
            "blank_line_rhythm": 0.03, "annotation_consistency": 0.027,
            "string_formatting_consistency": 0.03, "identifier_length": 0.036,
            "cognitive_complexity": 0.30, "line_density": 0.30,
            "identifier_quality": 0.05, "formatting_consistency": 0.05,
        },
        "efficiency": {"cyclomatic_complexity": 0.4, "redundant_code": 0.3, "dead_code": 0.3},
        "maintainability": {
            "inheritance_depth": 0.085, "method_receiver_naming_consistency": 0.085,
            "parameter_bloat": 0.17, "exception_hygiene": 0.13,
            "function_length": 0.13, "class_complexity": 0.25, "module_coupling": 0.15,
        },
        "security": {"broken_cryptography": 0.20, "arbitrary_code_execution": 0.40, "unsafe_file_access": 0.20,
                     "injection_and_request_forgery": 0.20},
    },
    "tuning": {
        "readability": {
            "thresholds": {
                "preferred_line_length": 100, "ideal_comment_ratio": 0.06, "comment_ratio_tolerance": 0.135,
                "max_blank_lines": 2, "blank_lines_tolerance": 4, "max_feasible_nesting": 4,
                "min_function_size": 10, "min_identifier_length": 2,
                "max_cognitive_complexity": 5, "max_tokens_per_line": 15,
            },
            "sensitivity": {
                "line_length": 0.05, "indent_stability": 1.0, "comment_density": 2.2,
                "blank_rhythm": 0.15, "nesting_depth": 0.4, "identifier_style": 2.5,
                "identifier_length": 2.0, "docstring_quality": 0.5, "annotation_consistency": 0.8, "string_format_consistency": 1.8,
                "cognitive_complexity": 0.05, "line_density": 0.25, "identifier_quality": 2.0,
                "formatting_consistency": 2.0,
            },
            "identifier_style": {
                "function_def": "SNAKE_CASE", "async_function_def": "SNAKE_CASE", "class_def": "PASCAL_CASE",
                "instance_attr": "SNAKE_CASE", "variable": "SNAKE_CASE",
            },
        },
        "efficiency": {
            "thresholds": {"avg_complexity_base": 3.0, "min_mass_for_duplication": 3},
            "sensitivity": {"cyclomatic_complexity": 0.45, "redundant_code": 0.3, "dead_code": 0.35},
            "flags": {"flag_globals": False, "flag_class_public": False},
        },
        "maintainability": {
            "thresholds": {
                "max_parameter_bloat": 4, "max_function_length": 50, "max_inheritance_depth": 2,
                "max_exception_violations": 0, "max_class_methods": 6, "max_class_attributes": 5,
                "max_class_bases": 3, "max_fan_out": 4, "max_fan_in": 12,
            },
            "sensitivity": {
                "parameter_bloat": 0.4, "method_receiver_naming": 2.0, "function_length": 0.5,
                "inheritance_depth": 1.2, "exception_violations": 0.5, "class_complexity": 0.5,
                "fan_out": 0.03, "fan_in": 0.013, "import_cycle": 0.2,
            },
        },
        "security": {
            "sensitivity": {"broken_cryptography": 0.5, "arbitrary_code_execution": 0.5, "unsafe_file_access": 0.5,
                            "injection_and_request_forgery": 0.5},
        },
    },
}

# Weight groups that must each sum to 1.0
_WEIGHT_GROUPS: List[str] = [
    "sections", "file_composite", "readability", "efficiency", "maintainability", "security",
]

# -----------------------------------------
# Dot-access wrapper
# -----------------------------------------
class ConfigNamespace:
    __slots__ = ("_data",)

    def __init__(self, data: Dict[str, Any]):
        self._data: Dict[str, Any] = data

    def __getattr__(self, key: str) -> Any:
        val: Union[Dict[str, Any], Any] = self._data.get(key)
        if isinstance(val, dict):
            # Wrap dict lazily, no extra memory upfront
            ns: ConfigNamespace = ConfigNamespace(val) # type: ignore
            self._data[key] = ns  # Replace dict with namespace in-place
            return ns

        if val is not None:
            return val

        raise AttributeError(f"No attribute '{key}' in config")

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

# -----------------------------------------
# Main Config Singleton
# -----------------------------------------
class Config:
    '''
    Thread-safe singleton configuration manager.

    Resolution order for the config file:
      1. explicit path passed to the first Config(path) call (main.py --config)
      2. $PYMETRICOR_CONFIG
      3. <tool root>/pymetricor.yml
    A missing file is never created. A missing explicit path is a fatal error;
    a missing default file falls back to the built-in defaults (identical values).

    Access metrics via dot notation:
        config.metrics.tuning.maintainability.thresholds.max_parameter_bloat
    '''
    _instance: Optional["Config"] = None
    _lock: threading.Lock = threading.Lock()

    def __new__(cls: Type[T], path: Optional[Union[str, Path]] = None) -> T:
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    instance = super().__new__(cls)
                    instance._InitConfig(path)  # type: ignore
                    cls._instance = instance    # type: ignore

        elif path is not None and Path(path).resolve() != cls._instance.config_path:
            raise RuntimeError("Config already initialized with a different path")

        return cls._instance  # type: ignore

    @classmethod
    def Reset(cls) -> None:
        '''Drop the singleton. Only meant for tests.'''
        with cls._lock:
            cls._instance = None

    def _InitConfig(self, path: Optional[Union[str, Path]]) -> None:
        explicit: bool = path is not None or bool(os.environ.get(CONFIG_ENV_VAR))
        chosen: Path   = Path(path or os.environ.get(CONFIG_ENV_VAR) or DEFAULT_CONFIG_PATH).resolve()

        self.config_path: Optional[Path] = chosen
        self._data: Dict[str, Any]       = copy.deepcopy(_DEFAULT_CONFIG)

        if chosen.exists():
            self._MergeFile(chosen)
        elif explicit:
            logger.Fatal(f"[Config]: Config file '{chosen}' not found")
        else:
            self.config_path = None  # Built-in defaults only

        self._Validate()
        self.metrics: ConfigNamespace = ConfigNamespace(self._data)

    def _MergeFile(self, path: Path) -> None:
        try:
            with path.open("r", encoding="utf-8") as f:
                user_cfg: Dict[str, Any] = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            logger.Fatal(f"[Config]: Failed to parse YAML '{path}': {e}")
            return

        self._WarnUnknownKeys(_DEFAULT_CONFIG, user_cfg, "")
        self._DeepMergeInto(self._data, user_cfg)

    def _WarnUnknownKeys(self, known: Dict[str, Any], given: Dict[str, Any], prefix: str) -> None:
        for key, value in given.items():
            dotted: str = f"{prefix}{key}"
            if key not in known:
                logger.Warn(f"[Config]: Unknown key '{dotted}' is ignored by PyMetricor")
            elif isinstance(known[key], dict) and isinstance(value, dict):
                self._WarnUnknownKeys(known[key], value, dotted + ".")  # type: ignore

    def _DeepMergeInto(self, target: Dict[str, Any], override: Dict[str, Any]) -> None:
        for key, value in override.items():
            if key in target and isinstance(target[key], dict) and isinstance(value, dict):
                self._DeepMergeInto(target[key], value)  # type: ignore
            else:
                target[key] = value

    def _Validate(self) -> None:
        weights: Dict[str, Any] = self._data["weights"]
        for group in _WEIGHT_GROUPS:
            total: float = sum(float(v) for v in weights[group].values())
            if abs(total - 1.0) > 1e-6:
                logger.Fatal(f"[Config]: weights.{group} must sum to 1.0, got {total:.6f}")

    # ----------------------
    # Raw dict access if needed
    # ----------------------
    def AsDict(self) -> Dict[str, Any]:
        return self._data
