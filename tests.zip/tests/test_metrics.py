'''
One test per metric: a clean snippet must score high and a snippet that
violates exactly that metric must score clearly lower. The coverage test
fails if a metric is added to core/enums.py without a test here.
'''

# Python stuff
import pytest

# My stuff
from conftest   import Metrics
from core.enums import ReadabilityMetric, EfficiencyMetric, MaintainabilityMetric, SecurityMetric

CLEAN: str = '''
"""Module docstring."""


def add(first: int, second: int) -> int:
    """Return the sum."""
    total: int = first + second
    return total


class Point:
    """A point."""

    def __init__(self, x_pos: int) -> None:
        """Store x."""
        self.x_pos: int = x_pos

    def get(self) -> int:
        """Return x."""
        return self.x_pos
'''

# Comment density is the one metric CLEAN does not satisfy: ~6% hash comments is the target
WELL_COMMENTED: str = (
    '"""Module docstring."""\n\n\n'
    'def compute(a: int) -> int:\n'
    '    """Compute a value."""\n'
    '    # Accumulate step by step\n'
    + "".join(f"    a = a + {i}\n" for i in range(14))
    + "    return a\n"
)

def _Lines(template: str, n: int) -> str:
    return "".join(template.format(i=i) for i in range(n))

BAD: dict[str, str] = {
    "LINE_LENGTH_DISTRIBUTION":           _Lines("value_{i} = '" + "a" * 300 + "'\n", 5),
    "INDENTATION_STABILITY":              "def f(a):\n    if a:\n          b = 2\n    if a:\n      c = 3\n"
                                          "    if a:\n            d = 4\n    for i in a:\n       e = 5\n",
    "IDENTIFIER_STYLE":                   "def BadName():\n    pass\nclass bad_class:\n    pass\nSomeVar = 1\nanotherVar = 2\n",
    "IDENTIFIER_LENGTH":                  "def f(a, b):\n    c = a + b\n    d = c * 2\n    return d\n",
    "COGNITIVE_COMPLEXITY":               "def f(x, y):\n" + "".join("    " * (i + 1) + f"if x > {i} and y:\n" for i in range(6))
                                          + "    " * 7 + "return x\n" + "    return y\n",
    "LINE_DENSITY":                       _Lines("v{i} = (a+b)*(c-d)/(e+f)-(g*h)+[i,j,k][0]\n", 6),
    "IDENTIFIER_QUALITY":                 "def qzx(vvk, bmp2):\n    xqt = vvk + bmp2\n    zzr = xqt * 2\n    return zzr\n",
    "FORMATTING_CONSISTENCY":             "a = 1\nb=2\nc = a+b\nd = [a,b, c]\ne = 'x'\nf = \"y\"\ng = a*b\n",
    "COMMENT_DENSITY":                    "def compute(a, b, c, d):\n" + _Lines("    v{i} = a + b + c + d + {i}\n", 25) + "    return v1\n",
    "NESTING_DEPTH":                      "def f(x):\n" + "".join("    " * (i + 1) + f"if x > {i}:\n" for i in range(10)) + "    " * 11 + "return x\n",
    "BLANK_LINE_RHYTHM":                  _Lines("v{i} = {i}\n" + "\n" * 6, 6),
    "ANNOTATION_CONSISTENCY":             "a: int = 1\nb = 2\nc: int = 3\nd = 4\ne: str = 'x'\nf = 'y'\n",
    "STRING_FORMATTING_CONSISTENCY":      "n = 1\na = f'{n}'\nb = '%s' % n\nc = '{}'.format(n)\nd = f'{n}'\ne = '%d' % n\nf = '{}'.format(n)\n",
    "CYCLOMATIC_COMPLEXITY":              "def f(x):\n" + _Lines("    if x == {i} and x > {i} or x < -{i}:\n        x += 1\n", 30) + "    return x\n",
    "REDUNDANT_CODE":                     "items = [1, 2]\na = [x for x in items]\nb = items[:]\nc = list(list(items))\nd = str('x')\n"
                                          + _Lines("def g{i}(v):\n    t = v + 1\n    t = t * 2\n    return t\n", 4),
    "DEAD_CODE":                          "import os\nimport sys\nimport json\ndef f():\n    unused_a = 1\n    unused_b = 2\n"
                                          "    return 1\n    print('never')\nif False:\n    x = 1\n",
    "INHERITANCE_DEPTH":                  "class A: pass\nclass C0(A): pass\n"
                                          + "".join(f"class C{i}(C{i - 1}): pass\n" for i in range(1, 10)),
    "METHOD_RECEIVER_NAMING_CONSISTENCY": "class K:\n    def a(this):\n        return 1\n    def b(me):\n        return 2\n"
                                          "    @classmethod\n    def c(klass):\n        return 3\n",
    "PARAMETER_BLOAT":                    "def f(" + ", ".join(f"p{i}" for i in range(20)) + "):\n    return p0\n",
    "EXCEPTION_HYGIENE":                  "def f():\n" + _Lines("    try:\n        pass\n    except:\n        pass\n", 6),
    "FUNCTION_LENGTH":                    "def f():\n" + _Lines("    v{i} = {i}\n", 600) + "    return v1\n",
    "CLASS_COMPLEXITY":                   "class Big(A, B, C, D, E):\n    def __init__(self):\n" + _Lines("        self.a{i} = {i}\n", 40)
                                          + _Lines("    def m{i}(self):\n        return {i}\n", 40),
    "BROKEN_CRYPTOGRAPHY":                "import hashlib\nh = hashlib.md5(b'x')\ng = hashlib.sha1(b'y')\n",
    "ARBITRARY_CODE_EXECUTION":           "import os\nexec(input())\nos.system(input())\n",
    "UNSAFE_FILE_ACCESS":                 "open(input())\nopen(input(), 'w')\n",
    "INJECTION_AND_REQUEST_FORGERY":      "import requests\ndef f(cur):\n    cur.execute('SELECT ' + input())\n"
                                          "    requests.get(input())\n",
}

ALL_METRICS: set[str] = {
    m.name for enum in (ReadabilityMetric, EfficiencyMetric, MaintainabilityMetric, SecurityMetric)
    for m in enum if m.name != "COUNT"
}

# Metrics that need a whole project; their tests are in test_project.py
PROJECT_METRICS: set[str] = {"MODULE_COUPLING"}

def test_every_metric_has_a_test():
    assert set(BAD) | PROJECT_METRICS == ALL_METRICS

@pytest.mark.parametrize("metric", sorted(BAD))
def test_violation_lowers_metric(metric: str):
    clean_src: str = WELL_COMMENTED if metric == "COMMENT_DENSITY" else CLEAN
    clean: float   = Metrics(clean_src)[metric]
    bad: float     = Metrics(BAD[metric])[metric]

    assert clean >= 90.0, f"{metric}: clean sample scored {clean:.1f}"
    assert bad <= clean - 10.0, f"{metric}: violation scored {bad:.1f} vs clean {clean:.1f}"

@pytest.mark.parametrize("metric", sorted(BAD))
def test_scores_stay_in_range(metric: str):
    for score in Metrics(BAD[metric]).values():
        assert 0.0 <= score <= 100.0

def test_more_violations_score_lower():
    one: float  = Metrics("import hashlib\nhashlib.md5(b'x')\n")["BROKEN_CRYPTOGRAPHY"]
    four: float = Metrics("import hashlib\n" + "hashlib.md5(b'x')\n" * 4)["BROKEN_CRYPTOGRAPHY"]
    assert four < one < 100.0

    shallow: float = Metrics("def f(" + ", ".join(f"p{i}" for i in range(10)) + "):\n    return p0\n")["PARAMETER_BLOAT"]
    deep: float    = Metrics(BAD["PARAMETER_BLOAT"])["PARAMETER_BLOAT"]
    assert deep < shallow

def test_identical_input_gives_identical_scores():
    assert Metrics(BAD["REDUNDANT_CODE"]) == Metrics(BAD["REDUNDANT_CODE"])


def test_empty_docstring_does_not_crash():
    """An empty or whitespace-only docstring used to raise IndexError and abort the whole run."""
    body = "".join(f"    x = x + {i}\n" for i in range(12))   # long enough to require a docstring
    m = Metrics('def f(x):\n    """   """\n' + body + '    return x\n')
    assert m


def test_docstrings_count_as_documentation():
    """A well-documented function must not lose comment-density points for its docstring."""
    body = "".join(f"    total = total + {i}\n" for i in range(12))
    documented = ('def accumulate(total):\n    """Add the first twelve integers to total.\n\n'
                  '    Args:\n        total: starting value.\n\n    Returns:\n        The new total.\n    """\n'
                  + body + "    return total\n")
    bare = "def accumulate(total):\n" + body + "    return total\n"
    assert Metrics(documented)["COMMENT_DENSITY"] > Metrics(bare)["COMMENT_DENSITY"] + 20


def test_short_snippet_needs_no_comments():
    """Code shorter than min_function_size is not penalised for having no comments."""
    assert Metrics("def area(width, height):\n    return width * height\n")["COMMENT_DENSITY"] == 100.0


def test_conventional_short_names_are_allowed():
    """Loop targets, comprehension targets, lambda parameters and exception names may be short."""
    src = ("def total_size(sizes):\n    result = 0\n    for i, s in enumerate(sizes):\n        result += s\n"
           "    squares = [x * x for x in sizes]\n    key = lambda v: -v\n    try:\n        pass\n"
           "    except ValueError as e:\n        raise\n    return result, squares, key\n")
    assert Metrics(src)["IDENTIFIER_LENGTH"] == 100.0


def test_cognitive_complexity_counts_nesting():
    """A nested branch costs more than the same branches in sequence (Campbell 2018)."""
    flat = "def f(x):\n" + "".join(f"    if x == {i}:\n        return {i}\n" for i in range(8)) + "    return x\n"
    nested = "def f(x):\n" + "".join("    " * (i + 1) + f"if x > {i}:\n" for i in range(8)) + "    " * 9 + "return x\n    return 0\n"
    assert Metrics(nested)["COGNITIVE_COMPLEXITY"] < Metrics(flat)["COGNITIVE_COMPLEXITY"]


def test_string_literals_do_not_make_a_line_dense():
    src = "message = 'one two three four five six seven eight nine ten eleven twelve thirteen fourteen'\n"
    assert Metrics(src)["LINE_DENSITY"] == 100.0


def test_words_and_code_abbreviations_are_readable_names():
    src = ("def parse_config(path, max_depth):\n    config_items = []\n    for i in range(max_depth):\n"
           "        config_items.append(path)\n    return config_items\n\nclass HttpClient:\n    pass\n")
    assert Metrics(src)["IDENTIFIER_QUALITY"] == 100.0
