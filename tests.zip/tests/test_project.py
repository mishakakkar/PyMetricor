'''Project-level analysis: function summaries across files and the module coupling metric.'''

# Python stuff
from pathlib import Path
from typing  import Dict, List

# My stuff
from core                   import Analyser, S0TokenScan, S1ASTScan
from core.context           import FileContext
from core.modules           import ModuleGraph
from core.reasoning.project import ProjectIndex

def _Write(root: Path, files: Dict[str, str]) -> None:
    for name, src in files.items():
        path: Path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(src)

def _Run(root: Path, files: Dict[str, str]) -> Dict[str, FileContext]:
    _Write(root, files)
    ctx, has_errors = Analyser([S0TokenScan(), S1ASTScan()]).Run([str(root)], progress_callback=lambda *_: None)
    assert not has_errors
    return {str(Path(f.file_path).relative_to(root)): f for f in ctx.GetFileOutputs()}

def _Score(ctx: FileContext, metric: str) -> float:
    return dict(ctx.GetAllMetricScores())[metric]

# vvv Module names and the import graph vvv
def test_module_names_follow_packages(tmp_path: Path):
    _Write(tmp_path, {"app/__init__.py": "", "app/sub/__init__.py": "", "app/sub/mod.py": "", "script.py": ""})
    index: ProjectIndex = ProjectIndex.FromPaths([str(tmp_path)])
    assert index.ModuleName(str(tmp_path / "app/sub/mod.py")) == "app.sub.mod"
    assert index.ModuleName(str(tmp_path / "app/sub/__init__.py")) == "app.sub"
    assert index.Absolute("other", 2, str(tmp_path / "app/sub/mod.py")) == "app.other"

def test_import_graph_counts_project_imports_only(tmp_path: Path):
    _Write(tmp_path, {
        "pkg/__init__.py": "",
        "pkg/a.py": "import os\nfrom . import b\nfrom pkg.c import thing\nimport pkg.d\n",
        "pkg/b.py": "", "pkg/c.py": "thing = 1\n", "pkg/d.py": "",
    })
    graph: ModuleGraph = ModuleGraph(ProjectIndex.FromPaths([str(tmp_path)]))
    a = graph.For(str(tmp_path / "pkg/a.py"))
    assert a is not None and a.imports == ["pkg.b", "pkg.c", "pkg.d"] and a.fan_out == 3
    assert graph.For(str(tmp_path / "pkg/b.py")).fan_in == 1  # type: ignore

def test_load_time_cycle_found_deferred_import_ignored(tmp_path: Path):
    _Write(tmp_path, {
        "p/__init__.py": "",
        "p/a.py": "from p import b\n",
        "p/b.py": "from p import c\n",
        "p/c.py": "from p import a\n",
        "p/x.py": "from p import y\n",
        "p/y.py": "def f():\n    from p import x\n",
    })
    graph: ModuleGraph = ModuleGraph(ProjectIndex.FromPaths([str(tmp_path)]))
    assert graph.Cycles() == [["p.a", "p.b", "p.c"]]

# vvv Module coupling metric vvv
def test_import_cycle_and_fan_out_lower_module_coupling(tmp_path: Path):
    files: Dict[str, str] = {"q/__init__.py": "", "q/a.py": "from q import b\n", "q/b.py": "from q import a\n",
                             "q/leaf.py": "x = 1\n"}
    files.update({f"q/m{i}.py": "" for i in range(20)})
    files["q/hub.py"] = "".join(f"from q import m{i}\n" for i in range(20))
    by_file = _Run(tmp_path, files)
    assert _Score(by_file["q/leaf.py"], "MODULE_COUPLING") == 100.0
    assert _Score(by_file["q/a.py"], "MODULE_COUPLING") <= 90.0
    assert _Score(by_file["q/hub.py"], "MODULE_COUPLING") <= 90.0
    assert by_file["q/a.py"].GetMetricExplanation("MODULE_COUPLING") is not None

# vvv Function summaries across files vvv
_PROJECT: Dict[str, str] = {
    "web/__init__.py":      "",
    "web/util/__init__.py": "from .shell import run_command\n",
    "web/util/shell.py":    "import subprocess as sp\n\ndef run_command(cmd, cwd=None):\n"
                            "    return sp.Popen(cmd, shell=True, cwd=cwd)\n\n"
                            "def safe(cmd):\n    import shlex\n    return run_command(shlex.quote(cmd))\n",
    "web/views.py":         "from flask import request\nfrom .util import run_command\nfrom web.util import shell\n\n"
                            "class Base:\n    def execute(self, c):\n        return run_command(c)\n\n"
                            "class View(Base):\n    def get(self):\n        c = request.args['c']\n"
                            "        self.execute(c)\n        return shell.safe(c)\n",
}

def _Offenders(ctx: FileContext, metric: str) -> List[str]:
    explanation = ctx.GetMetricExplanation(metric)
    return [o.detail for o in explanation.offenders] if explanation else []

def test_taint_followed_through_methods_and_re_exports(tmp_path: Path):
    views: FileContext = _Run(tmp_path, _PROJECT)["web/views.py"]
    details: List[str] = _Offenders(views, "ARBITRARY_CODE_EXECUTION")
    assert any("Base.execute→run_command→subprocess.Popen" in d for d in details)
    assert _Score(views, "ARBITRARY_CODE_EXECUTION") < 50.0

def test_sanitiser_inside_callee_is_respected(tmp_path: Path):
    project: Dict[str, str] = dict(_PROJECT)
    project["web/views.py"] = ("from flask import request\nfrom web.util import shell\n\n"
                               "def get():\n    return shell.safe(request.args['c'])\n")
    views: FileContext = _Run(tmp_path, project)["web/views.py"]
    assert _Score(views, "ARBITRARY_CODE_EXECUTION") == 100.0
