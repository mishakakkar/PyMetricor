'''Robustness: a bad file is recorded as an error instead of aborting the run.'''

# Python stuff
from pathlib import Path

# My stuff
from core         import Analyser, S0TokenScan, S1ASTScan
from core.context import FileContext

def _Run(tmp_path: Path, files: dict[str, str]):
    for name, src in files.items():
        (tmp_path / name).write_text(src)
    return Analyser([S0TokenScan(), S1ASTScan()]).Run([str(tmp_path)], progress_callback=lambda *_: None)

def test_mixed_tabs_and_spaces_is_a_file_error_not_a_crash(tmp_path: Path):
    ctx, has_errors = _Run(tmp_path, {"tabs.py": "if x:\n    a = 1\n\tb = 2\n", "ok.py": "y = 1\n"})
    assert has_errors
    by_name: dict[str, FileContext] = {Path(f.file_path).name: f for f in ctx.GetFileOutputs()}
    assert by_name["tabs.py"].HasErrors()
    assert not by_name["ok.py"].HasErrors()

def test_syntax_error_is_a_file_error(tmp_path: Path):
    ctx, has_errors = _Run(tmp_path, {"broken.py": "def f(:\n    pass\n"})
    assert has_errors and ctx.GetFileOutputs()[0].HasErrors()

def test_non_utf8_file_does_not_abort(tmp_path: Path):
    (tmp_path / "latin1.py").write_bytes("s = 'caf\xe9'\n".encode("latin-1"))
    ctx, _ = Analyser([S0TokenScan(), S1ASTScan()]).Run([str(tmp_path)], progress_callback=lambda *_: None)
    assert len(ctx.GetFileOutputs()) == 1

def test_empty_file_is_skipped_cleanly(tmp_path: Path):
    ctx, has_errors = _Run(tmp_path, {"empty.py": ""})
    assert not has_errors

def test_dict_literal_condition_does_not_crash(tmp_path: Path):
    # 'if {}:' used to raise AttributeError (Dict has no 'elts') and abort the run
    ctx, has_errors = _Run(tmp_path, {"d.py": "if {}:\n    x = 1\nif {1: 2}:\n    y = 2\nwhile {}:\n    pass\n"})
    assert not has_errors

def test_unexpected_exception_in_a_stage_is_a_file_error(tmp_path: Path):
    class Boom(S0TokenScan):
        def Run(self, ctx):
            if ctx.file_path.endswith("bad.py"):
                raise RuntimeError("rule bug")
            return super().Run(ctx)
    (tmp_path / "bad.py").write_text("x = 1\n")
    (tmp_path / "ok.py").write_text("y = 1\n")
    ctx, has_errors = Analyser([Boom(), S1ASTScan()]).Run([str(tmp_path)], progress_callback=lambda *_: None)
    by_name: dict[str, FileContext] = {Path(f.file_path).name: f for f in ctx.GetFileOutputs()}
    assert has_errors and by_name["bad.py"].HasErrors() and not by_name["ok.py"].HasErrors()
    assert "RuntimeError" in by_name["bad.py"].GetErrors()[0].message

def test_unparseable_file_does_not_lower_the_project_score(tmp_path: Path):
    weights = [0.30, 0.25, 0.25, 0.20]
    src = "def add(a_value, b_value):\n    return a_value + b_value\n"
    (tmp_path / "a").mkdir()
    (tmp_path / "b").mkdir()
    alone, _ = _Run(tmp_path / "a", {"ok.py": src})
    mixed, _ = _Run(tmp_path / "b", {"ok.py": src, "broken.py": "x = = 1\n"})
    assert mixed.ComputeFinalScore(weights) == alone.ComputeFinalScore(weights)
