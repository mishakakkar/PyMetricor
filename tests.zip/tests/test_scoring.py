'''Aggregation: signals -> metric -> section -> project composite.'''

# Python stuff
from math import exp, isclose, log1p
from pathlib import Path

# My stuff
from conftest      import Analyse
from config        import Config
from core          import Analyser, S0TokenScan, S1ASTScan, Section
from core.context  import FileContext, SignalContext
from core.enums    import SecurityMetric

def test_metric_score_is_weighted_mean_of_signals():
    ctx: FileContext = FileContext("x.py")
    ctx.AddSecuritySignal(SecurityMetric.BROKEN_CRYPTOGRAPHY, SignalContext(100.0, 1.0))
    ctx.AddSecuritySignal(SecurityMetric.BROKEN_CRYPTOGRAPHY, SignalContext(40.0, 0.5))
    assert isclose(dict(ctx.GetAllMetricScores())["BROKEN_CRYPTOGRAPHY"], 80.0)

def test_security_score_follows_exponential_decay():
    k: float = Config().metrics.tuning.security.sensitivity.broken_cryptography
    score: float = dict(Analyse("import hashlib\nhashlib.md5(b'x')\n").GetAllMetricScores())["BROKEN_CRYPTOGRAPHY"]
    assert isclose(score, 100.0 * exp(-1.0 * k), rel_tol=1e-9)  # one medium finding = weight 1.0

def test_composite_mass_is_log_damped():
    ctx: FileContext = FileContext("x.py")
    ctx.SetLOC(1000); ctx.SetTokenCount(5000); ctx.SetASTNodeCount(8000)
    assert isclose(ctx.ComputeCompositeMass(0.2, 0.4, 0.4), 0.2 * log1p(1000) + 0.4 * log1p(5000) + 0.4 * log1p(8000))

def test_section_scores_use_configured_weights():
    ctx: FileContext = Analyse("import hashlib\nhashlib.md5(b'x')\n")
    w = Config().metrics.weights.security
    scores: dict[str, float] = dict(ctx.GetAllMetricScores())
    ctx.ComputeSectionScores([0.0] * 8, [0.0] * 3, [w.broken_cryptography, w.arbitrary_code_execution, w.unsafe_file_access,
                                                     w.injection_and_request_forgery], [0.0] * 6)
    expected: float = (scores["BROKEN_CRYPTOGRAPHY"] * w.broken_cryptography
                       + scores["ARBITRARY_CODE_EXECUTION"] * w.arbitrary_code_execution
                       + scores["UNSAFE_FILE_ACCESS"] * w.unsafe_file_access
                       + scores["INJECTION_AND_REQUEST_FORGERY"] * w.injection_and_request_forgery)
    assert isclose(ctx.GetSectionScore(Section.SECURITY), expected)

def _Run(tmp_path: Path, files: dict[str, str]):
    for name, src in files.items():
        (tmp_path / name).write_text(src)
    return Analyser([S0TokenScan(), S1ASTScan()]).Run([str(tmp_path)], progress_callback=lambda *_: None)

def test_project_score_is_mass_weighted_and_deterministic(tmp_path: Path):
    files = {"small.py": "x = 1\n", "big.py": "".join(f"value_{i} = {i}\n" for i in range(200))}
    sw = Config().metrics.weights.sections
    weights = [sw.readability, sw.efficiency, sw.maintainability, sw.security]

    ctx, errors = _Run(tmp_path, files)
    assert not errors
    first: float = ctx.ComputeFinalScore(weights)
    ctx2, _ = _Run(tmp_path, files)
    assert first == ctx2.ComputeFinalScore(weights)
    assert 0.0 < first <= 100.0

def test_init_files_are_excluded(tmp_path: Path):
    ctx, _ = _Run(tmp_path, {"__init__.py": "x = 1\n", "a.py": "y = 2\n"})
    assert [Path(f.file_path).name for f in ctx.GetFileOutputs()] == ["a.py"]
