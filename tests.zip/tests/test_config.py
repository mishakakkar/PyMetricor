'''Config resolution and validation.'''

# Python stuff
import os
from pathlib import Path

import pytest
import yaml

# My stuff
from config        import Config
from config.config import _DEFAULT_CONFIG, DEFAULT_CONFIG_PATH

def test_builtin_defaults_match_shipped_yaml():
    with open(DEFAULT_CONFIG_PATH, encoding="utf-8") as f:
        assert yaml.safe_load(f) == _DEFAULT_CONFIG

def test_loads_tool_config_regardless_of_cwd(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.chdir(tmp_path)
    Config.Reset()
    cfg: Config = Config()
    assert cfg.config_path == DEFAULT_CONFIG_PATH
    assert cfg.metrics.tuning.readability.thresholds.preferred_line_length == 100
    assert os.listdir(tmp_path) == []  # nothing written to the working directory

def test_explicit_config_overrides_keys(tmp_path: Path):
    user: Path = tmp_path / "my.yml"
    user.write_text("tuning:\n  readability:\n    thresholds:\n      preferred_line_length: 99\n")
    Config.Reset()
    cfg: Config = Config(user)
    assert cfg.metrics.tuning.readability.thresholds.preferred_line_length == 99
    assert cfg.metrics.tuning.readability.thresholds.max_blank_lines == 2  # untouched default

def test_env_var_selects_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    user: Path = tmp_path / "env.yml"
    user.write_text("weights:\n  file_composite: {loc: 0.5, tokens: 0.25, ast_nodes: 0.25}\n")
    monkeypatch.setenv("PYMETRICOR_CONFIG", str(user))
    Config.Reset()
    assert Config().metrics.weights.file_composite.loc == 0.5

def test_missing_explicit_config_is_fatal(tmp_path: Path):
    Config.Reset()
    with pytest.raises(SystemExit):
        Config(tmp_path / "missing.yml")
    assert not (tmp_path / "missing.yml").exists()

def test_weights_must_sum_to_one(tmp_path: Path):
    user: Path = tmp_path / "bad.yml"
    user.write_text("weights:\n  efficiency: {cyclomatic_complexity: 0.4, redundant_code: 0.3, dead_code: 0.2}\n")
    Config.Reset()
    with pytest.raises(SystemExit):
        Config(user)

def test_unknown_key_is_warned(tmp_path: Path, caplog: pytest.LogCaptureFixture):
    user: Path = tmp_path / "typo.yml"
    user.write_text("tuning:\n  readability:\n    thresholds:\n      prefered_line_length: 80\n")
    Config.Reset()
    Config(user)
    assert "prefered_line_length" in caplog.text

def test_second_call_with_other_path_is_rejected(tmp_path: Path):
    other: Path = tmp_path / "other.yml"
    other.write_text("{}\n")
    with pytest.raises(RuntimeError):
        Config(other)
