'''
Shared test helpers. Tests run against the shipped pymetricor.yml and schema.yml.
Run from anywhere:  python -m pytest tests/
'''

# Python stuff
import sys
from pathlib import Path
from textwrap import dedent
from typing import Dict

import pytest

ROOT: Path = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# My stuff
from config        import Config        # noqa: E402
from core.context  import FileContext   # noqa: E402
from core          import S0TokenScan, S1ASTScan  # noqa: E402

def Analyse(source: str, path: str = "sample.py") -> FileContext:
    '''Run both pipeline stages on an in-memory source string.'''
    ctx: FileContext = FileContext(path)
    ctx.file_data    = dedent(source).lstrip("\n")
    for stage in (S0TokenScan(), S1ASTScan()):
        assert stage.Run(ctx), ctx.GetErrors()
    return ctx

def Metrics(source: str) -> Dict[str, float]:
    '''Metric name -> score (0-100) for a source string.'''
    return dict(Analyse(source).GetAllMetricScores())

@pytest.fixture(autouse=True)
def _default_config(monkeypatch: pytest.MonkeyPatch):
    '''Every test starts from the shipped config, regardless of environment.'''
    monkeypatch.delenv("PYMETRICOR_CONFIG", raising=False)
    Config.Reset()
    Config()
    yield
    Config.Reset()
