HELLO: int = 10
x: int = 3

class I():
    ...

class F(I):
    def __init__(self) -> None:
        pass

    def E(self) -> int:
        return 10

exec("a = input(); exec(a)")