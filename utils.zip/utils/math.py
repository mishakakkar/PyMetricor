# Python stuff
from collections import Counter
from math        import log
from typing      import Any

# vvv Constants vvv
FLOAT_EPSILON: float = 1e-8

# vvv Main Functions vvv
def ShannonEntropyFromCounts(counter: Counter[Any]) -> float:
    if not counter:
        return 0.0

    total: int = sum(counter.values())
    
    if total == 0:
        return 0.0
    
    ent: float = 0.0
    for v in counter.values():
        p: float = v / total
        if p > 0:
            ent -= p * log(p)
    
    return ent
