# Python stuff
import logging
import sys
from typing import TextIO, Tuple, Any, cast

class CustomLogger(logging.Logger):
    def Critical(self, msg: str, *args: Tuple[Any], **kwargs: Any) -> None:
        super().critical(msg, *args, **kwargs)
        sys.exit(1)

    def Fatal(self, msg: str, *args: Tuple[Any], **kwargs: Any) -> None:
        self.Critical(msg, *args, **kwargs)

    def Error(self, msg: str, *args: Tuple[Any], **kwargs: Any) -> None:
        super().error(msg, *args, **kwargs)

    def Warn(self, msg: str, *args: Tuple[Any], **kwargs: Any) -> None:
        super().warning(msg, *args, **kwargs)

    def Info(self, msg: str, *args: Tuple[Any], **kwargs: Any) -> None:
        super().info(msg, *args, **kwargs)

    def Debug(self, msg: str, *args: Tuple[Any], **kwargs: Any) -> None:
        super().debug(msg, *args, **kwargs)

# Setup function
def InitLogger(name: str = "PyMetricor_Logger") -> CustomLogger:
    logging.setLoggerClass(CustomLogger)

    logger: CustomLogger = cast(CustomLogger, logging.getLogger(name))
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        console: logging.StreamHandler[TextIO | Any] = logging.StreamHandler(sys.stderr)
        console.setFormatter(
            logging.Formatter(
                "[%(levelname)s] %(asctime)s - %(message)s",
                "%d-%m-%Y %H:%M:%S",
            )
        )
        logger.addHandler(console)

    return logger

# Usage
logger: CustomLogger = InitLogger()