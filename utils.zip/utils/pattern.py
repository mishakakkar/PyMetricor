# Python stuff
from typing import Dict, Iterator
from re     import Match, Pattern, compile

# vvv Constants vvv
CAMEL_CASE: Pattern[str]           = compile(r"^[a-z][a-zA-Z0-9]*$")
PASCAL_CASE: Pattern[str]          = compile(r"^[A-Z][a-zA-Z0-9]*$")
SNAKE_CASE: Pattern[str]           = compile(r"^[a-z0-9]+(_[a-z0-9]+)*$")
KEBAB_CASE: Pattern[str]           = compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
SCREAMING_SNAKE_CASE: Pattern[str] = compile(r"^[A-Z0-9]+(_[A-Z0-9]+)*$")
TRAIN_CASE: Pattern[str]           = compile(r"^[A-Z][a-z0-9]*(-[A-Z][a-z0-9]*)*$")
FLAT_CASE: Pattern[str]            = compile(r"^[a-z0-9]+$")
UPPER_FLAT_CASE: Pattern[str]      = compile(r"^[A-Z0-9]+$")
COBOL_CASE: Pattern[str]           = compile(r"^[A-Z0-9]+(-[A-Z0-9]+)*$")

PATTERN_REGISTRY: Dict[str, Pattern[str]] = {
    "CAMEL_CASE": CAMEL_CASE,
    "PASCAL_CASE": PASCAL_CASE,
    "SNAKE_CASE": SNAKE_CASE,
    "KEBAB_CASE": KEBAB_CASE,
    "SCREAMING_SNAKE_CASE": SCREAMING_SNAKE_CASE,
    "TRAIN_CASE": TRAIN_CASE,
    "FLAT_CASE": FLAT_CASE,
    "UPPER_FLAT_CASE": UPPER_FLAT_CASE,
    "COBOL_CASE": COBOL_CASE,
}

# vvv Helper Functions vvv
def GetMatchingConfig(type: str) -> Pattern[str]:
    return PATTERN_REGISTRY[type]

def GetMatchPercentage(text: str, pattern: Pattern[str]) -> float:
    if not text:
        return 0.0

    matches: Iterator[Match[str]] = pattern.finditer(text)
    max_match_len: int = 0

    for match in matches:
        match_len: int = len(match.group())
        if match_len > max_match_len:
            max_match_len = match_len

    return (max_match_len / len(text)) * 100